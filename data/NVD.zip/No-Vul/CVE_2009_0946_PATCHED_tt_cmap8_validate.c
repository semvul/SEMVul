FUN1( VAR1*      VAR2,                      FT_Validator  VAR3 )    
{
    VAR1*   VAR4 = VAR2 + 4;
    VAR1*   VAR5;
    FT_UInt32  VAR6;
    FT_UInt32  VAR7;


    if ( VAR2 + 16 + 8192 > VAR3->VAR8 )
      VAR9;

    VAR6 = FUN2( VAR4 );
    if ( VAR6 > (VAR10)( VAR3->VAR8 - VAR2 ) || VAR6 < 8192 + 16 )
      VAR9;

    VAR5       = VAR2 + 12;
    VAR4          = VAR5  + 8192;          
    VAR7 = FUN2( VAR4 );

    if ( VAR4 + VAR7 * 12 > VAR3->VAR8 )
      VAR9;

    
    {
      FT_UInt32  VAR11, VAR12, VAR13, VAR14, VAR15, VAR16 = 0;


      for ( VAR11 = 0; VAR11 < VAR7; VAR11++ )
      {
        FT_UInt   VAR17, VAR18;


        VAR12    = FUN2( VAR4 );
        VAR13      = FUN2( VAR4 );
        VAR14 = FUN2( VAR4 );

        if ( VAR12 > VAR13 )
          VAR19;

        if ( VAR11 > 0 && VAR12 <= VAR16 )
          VAR19;

        if ( VAR3->VAR20 >= VAR21 )
        {
          if ( VAR14 + VAR13 - VAR12 >= FUN3( VAR3 ) )
            VAR22;

          VAR15 = (VAR10)( VAR13 - VAR12 + 1 );

          if ( VAR12 & ~0xFFFFU )
          {
            
            
            for ( ; VAR15 > 0; VAR15--, VAR12++ )
            {
              VAR17 = (VAR23)( VAR12 >> 16 );
              VAR18 = (VAR23)( VAR12 & 0xFFFFU );

              if ( (VAR5[VAR17 >> 3] & ( 0x80 >> ( VAR17 & 7 ) ) ) == 0 )
                VAR19;

              if ( (VAR5[VAR18 >> 3] & ( 0x80 >> ( VAR18 & 7 ) ) ) == 0 )
                VAR19;
            }
          }
          else
          {
            
            

            
            if ( VAR13 & ~0xFFFFU )
              VAR19;

            for ( ; VAR15 > 0; VAR15--, VAR12++ )
            {
              VAR18 = (VAR23)( VAR12 & 0xFFFFU );

              if ( (VAR5[VAR18 >> 3] & ( 0x80 >> ( VAR18 & 7 ) ) ) != 0 )
                VAR19;
            }
          }
        }

        VAR16 = VAR13;
      }
    }

    return VAR24;
  }