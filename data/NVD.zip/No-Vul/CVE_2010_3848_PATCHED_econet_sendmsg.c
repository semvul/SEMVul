static int FUN1(struct VAR1 *VAR2, struct socket *VAR3, 			  struct VAR4 *VAR5, size_t VAR6)  
{
	struct VAR3 *VAR7 = VAR3->VAR7;
	struct VAR8 *VAR9=(struct VAR8 *)VAR5->VAR10;
	struct VAR11 *VAR12;
	struct ec_addr VAR13;
	int VAR14;
	unsigned char VAR15, VAR16;
#if FUN2(VAR17) || FUN2(VAR18)
	struct VAR19 *VAR20;
	struct VAR21 *VAR22;
#endif
#ifdef VAR17
	struct msghdr VAR23;
	struct iovec VAR24[2];
	struct aunhdr VAR25;
	struct sockaddr_in VAR26;
	__kernel_size_t VAR27;
	mm_segment_t VAR28;
	char *VAR29;
#endif

	

	if (VAR5->VAR30 & ~(VAR31|VAR32))
		return -VAR33;

	

	FUN3(&VAR34);

	if (VAR9 == NULL) {
		struct VAR35 *VAR36 = FUN4(VAR7);

		VAR13.VAR37 = VAR36->VAR37;
		VAR13.VAR38     = VAR36->VAR38;
		VAR15	     = VAR36->VAR15;
		VAR16	     = VAR36->VAR16;
	} else {
		if (VAR5->VAR39 < sizeof(struct VAR8)) {
			FUN5(&VAR34);
			return -VAR33;
		}
		VAR13.VAR37 = VAR9->VAR13.VAR37;
		VAR13.VAR38 = VAR9->VAR13.VAR38;
		VAR15 = VAR9->VAR15;
		VAR16 = VAR9->VAR16;
	}

	
	VAR12 = VAR40[VAR13.VAR38];

	
	if (VAR12 == NULL) {
		VAR12 = VAR40[0];
		
		if (VAR12 == NULL) {
			FUN5(&VAR34);
			return -VAR41;
		}
	}

	if (VAR12->VAR42 == VAR43) {
		
#ifdef VAR18
		unsigned short VAR44 = 0;
		int VAR45;

		if (VAR6 + 15 > VAR12->VAR46) {
			FUN5(&VAR34);
			return -VAR47;
		}

		FUN6(VAR12);

		VAR20 = FUN7(VAR7, VAR6+FUN8(VAR12),
					  VAR5->VAR30 & VAR31, &VAR14);
		if (VAR20==NULL)
			goto VAR48;

		FUN9(VAR20, FUN10(VAR12));
		FUN11(VAR20);

		VAR22 = (struct VAR21 *)&VAR20->VAR16;

		
		VAR22->VAR49 = VAR9->VAR49;
		VAR22->VAR50 = *VAR9;
		VAR22->VAR51 = VAR52;

		VAR14 = -VAR33;
		VAR45 = FUN12(VAR20, VAR12, FUN13(VAR44), &VAR13, NULL, VAR6);
		if (VAR45 < 0)
			goto VAR53;
		if (VAR45 > 0) {
			struct VAR54 *VAR55;
			
			VAR55 = (struct VAR54 *)(VAR20->VAR56);
			VAR55->VAR16 = VAR16;
			VAR55->VAR15 = VAR15;
			if (VAR3->VAR42 != VAR57) {
				FUN14(VAR20);
				VAR20->VAR6 = 0;
			}
		}

		
		VAR14 = FUN15(FUN16(VAR20,VAR6), VAR5->VAR58, VAR6);
		VAR20->VAR59 = VAR44;
		VAR20->VAR12 = VAR12;
		VAR20->VAR60 = VAR7->VAR61;
		if (VAR14)
			goto VAR53;

		VAR14 = -VAR41;
		if (!(VAR12->VAR62 & VAR63))
			goto VAR53;

		

		FUN17(VAR20);
		FUN18(VAR12);
		FUN5(&VAR34);
		return(VAR6);

	VAR53:
		FUN19(VAR20);
	VAR48:
		if (VAR12)
			FUN18(VAR12);
#else
		VAR14 = -VAR64;
#endif
		FUN5(&VAR34);

		return VAR14;
	}

#ifdef VAR17
	

	if (VAR65 == NULL) {
		FUN5(&VAR34);
		return -VAR41;		
	}

	if (VAR6 > 32768) {
		VAR14 = -VAR66;
		goto VAR67;
	}

	

	memset(&VAR26, 0, sizeof(VAR26));
	VAR26.VAR68 = VAR69;
	VAR26.VAR70 = FUN20(VAR71);

	
	{
		struct VAR72 *VAR73;
		unsigned long VAR74 = 0;

		FUN21();
		VAR73 = FUN22(VAR12);
		if (VAR73) {
			if (VAR73->VAR75)
				VAR74 = FUN23(VAR73->VAR75->VAR76) &
					0xffffff00;		
		}
		FUN24();
		VAR26.VAR77.VAR78 = FUN25(VAR74 | VAR13.VAR37);
	}

	VAR25.VAR15 = VAR15;
	VAR25.VAR16 = VAR16 & 0x7f;
	VAR25.VAR79 = 2;		
	VAR25.VAR80 = 0;

	
	VAR27 = sizeof(struct VAR81);
	VAR24[0].VAR82 = (void *)&VAR25;
	VAR24[0].VAR83 = VAR27;

	VAR29 = FUN26(VAR6);
	if (VAR29 == NULL) {
		VAR14 = -VAR84;
		goto VAR67;
	}

	VAR24[1].VAR82 = VAR29;
	VAR24[1].VAR83 = VAR6;
	VAR14 = FUN15(VAR29, VAR5->VAR58, VAR6);
	if (VAR14)
		goto VAR85;

	
	if ((VAR20 = FUN7(VAR7, 0,
				       VAR5->VAR30 & VAR31,
				       &VAR14)) == NULL)
		goto VAR85;

	VAR22 = (struct VAR21 *)&VAR20->VAR16;

	VAR22->VAR49 = VAR9->VAR49;
	VAR22->VAR86 = (5*VAR87);
	VAR22->VAR88 = VAR89;
	VAR25.VAR90 = VAR91;
	VAR22->VAR92 = (VAR91++);
	VAR22->VAR50 = *VAR9;

	FUN27(&VAR93, VAR20);

	VAR23.VAR10 = (void *)&VAR26;
	VAR23.VAR39 = sizeof(VAR26);
	VAR23.VAR58 = &VAR24[0];
	VAR23.VAR94 = 2;
	VAR23.VAR95 = NULL;
	VAR23.VAR96 = 0;
	VAR23.VAR30=0;

	VAR28 = FUN28(); FUN29(VAR97);	
	VAR14 = FUN30(VAR65, &VAR23, VAR27);
	FUN29(VAR28);

VAR85:
	FUN31(VAR29);
#else
	VAR14 = -VAR64;
#endif
	VAR67:
	FUN5(&VAR34);

	return VAR14;
}