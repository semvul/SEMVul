static void qmp_input_type_str(Visitor *v, char **obj, const char *name,

                               Error **errp)

{

    QmpInputVisitor *qiv = to_qiv(v);

    QObject *qobj = qmp_input_get_object(qiv, name, true);



    if (!qobj || qobject_type(qobj) != QTYPE_QSTRING) {

        error_setg(errp, QERR_INVALID_PARAMETER_TYPE, name ? name : "null",

                   "string");

        return;

    }



    *obj = g_strdup(qstring_get_str(qobject_to_qstring(qobj)));

}
