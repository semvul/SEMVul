NS_METHOD VAR1::FUN1(const char* VAR2, PRUint32 VAR3)  
{
    FUN2(VAR4, VAR5, ("", VAR2, VAR3));
    if (!VAR3 || !VAR6) 
        return VAR7;

    nsresult VAR8;
    if (VAR9 < VAR10) { 
        PRUint32 VAR11 = VAR10 - VAR9;
        if (VAR11 > VAR3)
            VAR11 = VAR3;
        memcpy(VAR12 + VAR9, VAR2, VAR11);
        VAR9 += VAR11;
        VAR3 -= VAR11;
        VAR2 += VAR11;
    }
    if (VAR9 == VAR10) {
        VAR8 = VAR13->FUN3(VAR14);
        FUN4(VAR8, VAR8);
        FUN5();
        if (VAR15.VAR16[0] != '' || VAR15.VAR16[1] != '')
            return VAR17;
        if (VAR15.VAR18 == VAR19)
            VAR20 = VAR21;
    }
    if (VAR9 >= VAR10 && VAR9 < VAR20) { 
        PRUint32 VAR11 = VAR20 - VAR9;
        if (VAR11 > VAR3)
            VAR11 = VAR3;
        memcpy(VAR12 + (VAR9 - VAR10), VAR2, VAR11);
        VAR9 += VAR11;
        VAR3 -= VAR11;
        VAR2 += VAR11;
    }
    if (VAR9 == VAR20) {
        FUN6();
        FUN2(VAR4, VAR5, ("",
            VAR22.VAR23, VAR22.VAR24, VAR22.VAR25, VAR22.VAR26));
        
        if (VAR22.VAR25 != 1 && VAR22.VAR25 != 4 && VAR22.VAR25 != 8 &&
            VAR22.VAR25 != 16 && VAR22.VAR25 != 24 && VAR22.VAR25 != 32)
          return VAR27;

        if (VAR22.VAR25 <= 8) {
            VAR28 = 1 << VAR22.VAR25;
            if (VAR22.VAR29 && VAR22.VAR29 < VAR28)
                VAR28 = VAR22.VAR29;

            
            
            VAR30 = new VAR31[256];
            if (!VAR30)
                return VAR32;

            memset(VAR30, 0, 256 * sizeof(VAR31));
        }
        else if (VAR22.VAR26 != VAR33 && VAR22.VAR25 == 16) {
            
            VAR34.VAR35   = 0x7C00;
            VAR34.VAR36 = 0x03E0;
            VAR34.VAR37  = 0x001F;
            FUN7();
        }
        
        if (VAR22.VAR23 < 0)
            return VAR17;

        PRUint32 VAR38 = (VAR22.VAR24 > 0) ? VAR22.VAR24 : -VAR22.VAR24;
        VAR8 = VAR39->FUN8(VAR22.VAR23, VAR38, VAR13);
        FUN4(VAR8, VAR8);
        VAR8 = VAR13->FUN9(VAR14, VAR39);
        FUN4(VAR8, VAR8);
        VAR6 = VAR38;

        VAR40 = new VAR41[(VAR22.VAR23 * VAR22.VAR25)/8 + 4];
        
        
        
        if (!VAR40) {
            return VAR32;
        }
        if ((VAR22.VAR26 == VAR42) || (VAR22.VAR26 == VAR43)) {
            VAR8 = VAR44->FUN8(0, 0, VAR22.VAR23, VAR38, VAR45, 24);
        } else {
            VAR8 = VAR44->FUN8(0, 0, VAR22.VAR23, VAR38, VAR46, 24);
        }
        FUN4(VAR8, VAR8);
        VAR8 = VAR39->FUN10(VAR44);
        FUN4(VAR8, VAR8);
        VAR13->FUN11(VAR14, VAR44);
        FUN4(VAR8, VAR8);
        VAR8 = VAR44->FUN12(&VAR47);
        FUN4(VAR8, VAR8);
    }
    PRUint8 VAR48; 
    VAR48 = (VAR15.VAR18 == VAR19) ? 3 : 4; 
    if (VAR30 && (VAR9 >= VAR20 && (VAR9 < (VAR20 + VAR28 * VAR48)))) {
        
        PRUint32 VAR49 = VAR9 - VAR20; 
        PRUint8 VAR50 = VAR49 / VAR48; 
        PRUint8 VAR51 = VAR49 % VAR48;
        while (VAR3 && (VAR9 < (VAR20 + VAR28 * VAR48))) {
            switch (VAR51) {
                case 0:
                    VAR30[VAR50].VAR37 = *VAR2;
                    break;
                case 1:
                    VAR30[VAR50].VAR36 = *VAR2;
                    break;
                case 2:
                    VAR30[VAR50].VAR35 = *VAR2;
                    VAR50++;
                    break;
                case 3:
                    
                    break;
            }
            VAR9++; VAR2++; VAR3--;
            VAR51 = (VAR51 + 1) % VAR48;
        }
    }
    else if (VAR3 && VAR22.VAR26 == VAR33 && VAR9 < (VAR52 + VAR53)) {
        
        
        PRUint32 VAR11 = (VAR52 + VAR53) - VAR9;
        if (VAR11 > VAR3)
            VAR11 = VAR3;
        memcpy(VAR12 + (VAR9 - VAR52), VAR2, VAR11);
        VAR9 += VAR11;
        VAR2 += VAR11;
        VAR3 -= VAR11;
    }
    if (VAR22.VAR26 == VAR33 && VAR9 == VAR52 + VAR53) {
        VAR34.VAR35 = FUN13(*(VAR54*)VAR12);
        VAR34.VAR36 = FUN13(*(VAR54*)(VAR12 + 4));
        VAR34.VAR37 = FUN13(*(VAR54*)(VAR12 + 8));
        FUN7();
    }
    while (VAR3 && (VAR9 < VAR15.VAR55)) { 
        VAR9++; VAR2++; VAR3--;
    }
    if (VAR3 && ++VAR9 >= VAR15.VAR55) {
        
        
        if (!VAR22.VAR26 || VAR22.VAR26 == VAR33) {
            PRUint32 VAR56 = (VAR22.VAR25 * VAR22.VAR23 + 7) / 8; 
            if (VAR56 % 4)
                VAR56 += (4 - (VAR56 % 4)); 
            PRUint32 VAR11;
            do {
                VAR11 = VAR56 - VAR57;
                if (VAR11) {
                    if (VAR11 > VAR3)
                        VAR11 = VAR3;
                    memcpy(VAR40 + VAR57, VAR2, VAR11);
                    VAR3 -= VAR11;
                    VAR2 += VAR11;
                    VAR57 += VAR11;
                }
                if ((VAR56 - VAR57) == 0) {
                    if (!VAR58) {
                        VAR58 = (VAR41*)malloc(VAR47);
                        if (!VAR58)
                            return VAR32;
                    }

                    VAR41* VAR59 = VAR40;
                    VAR41* VAR60 = VAR58;
                    PRUint32 VAR61 = VAR22.VAR23;
                    switch (VAR22.VAR25) {
                      case 1:
                        while (VAR61 > 0) {
                          PRInt8 VAR62;
                          PRUint8 VAR63;
                          for (VAR62 = 7; VAR62 >= 0 && VAR61 > 0; VAR62--) {
                              VAR63 = (*VAR59 >> VAR62) & 1;
                              FUN14(VAR60, VAR63, VAR30);
                              --VAR61;
                          }
                          ++VAR59;
                        }
                        break;
                      case 4:
                        while (VAR61 > 0) {
                          FUN15(VAR60, *VAR59, VAR61, VAR30);
                          ++VAR59;
                        }
                        break;
                      case 8:
                        while (VAR61 > 0) {
                          FUN14(VAR60, *VAR59, VAR30);
                          --VAR61;
                          ++VAR59;
                        }
                        break;
                      case 16:
                        while (VAR61 > 0) {
                          PRUint16 VAR64 = FUN16(*(VAR65*)VAR59);
                          FUN14(VAR60,
                                  (VAR64 & VAR34.VAR35) >> VAR34.VAR66 << VAR34.VAR67,
                                  (VAR64 & VAR34.VAR36) >> VAR34.VAR68 << VAR34.VAR69,
                                  (VAR64 & VAR34.VAR37) >> VAR34.VAR70 << VAR34.VAR71);
                          --VAR61;
                          VAR59+=2;
                        }
                        break;
                      case 32:
                      case 24:
                        while (VAR61 > 0) {
                          FUN14(VAR60, VAR59[2], VAR59[1], VAR59[0]);
                          VAR59 += 2;
                          --VAR61;
                          if (VAR22.VAR25 == 32)
                            VAR59++; 
                          ++VAR59;
                        }
                        break;
                      default:
                        FUN17("");
                    }
                      
                    nsresult VAR8 = FUN18();
                    FUN4(VAR8, VAR8);

                    if (VAR6 == 0) { 
                        return VAR13->FUN19(VAR14, VAR44);
                    }
                    VAR57 = 0;

                }
            } while (VAR3 > 0);
        } 
        else if ((VAR22.VAR26 == VAR42) || (VAR22.VAR26 == VAR43)) {
            if (((VAR22.VAR26 == VAR42) && (VAR22.VAR25 != 8)) 
             || ((VAR22.VAR26 == VAR43) && (VAR22.VAR25 != 4) && (VAR22.VAR25 != 1))) {
                FUN2(VAR4, VAR5, (""));
                return VAR17;
            }

            if (!VAR72) {
                PRUint32 VAR73;
                VAR8 = VAR44->FUN20(&VAR73);
                FUN4(VAR8, VAR8);
                
                VAR72 = (VAR41*)calloc(VAR73, 8);
                if (!VAR72)
                  return VAR32;
                VAR74 = VAR72;
            }

            if (!VAR58) {
                VAR58 = (VAR41*)calloc(VAR47, 1);
                if (!VAR58)
                  return VAR32;
                VAR75 = VAR58;
            }

            while (VAR3 > 0) {
                PRUint8 VAR76;

                switch(VAR77) {
                    case VAR78:
                        VAR79 = (VAR41)*VAR2++;
                        VAR3--;

                        VAR77 = VAR80;
                        continue;

                    case VAR80:
                        VAR76 = *VAR2++;
                        VAR3--;
                        if (VAR79 != VAR81) { 
                            
                            
                            
                            
                            
                            
                            if (VAR74 + VAR79 > VAR72 + VAR22.VAR23)
                                VAR79 = (VAR54)(VAR72 + VAR22.VAR23 - VAR74);
                            memset(VAR74, 0xFF, VAR79);
                            VAR74 += VAR79;
                            if (VAR22.VAR26 == VAR42) {
                                while (VAR79 > 0) {
                                    FUN14(VAR75, VAR76, VAR30);
                                    VAR79--;
                                }
                            } else {
                                while (VAR79 > 0) {
                                    FUN15(VAR75, VAR76, VAR79, VAR30);
                                }
                            }
                            
                            VAR77 = VAR78;
                            continue;
                        }

                        switch(VAR76) {
                            case VAR82:
                                
                                
                                VAR8 = FUN21(1);
                                FUN4(VAR8, VAR8);
                                VAR74 = VAR72;
                                VAR75 = VAR58;

                                VAR77 = VAR78;
                                break;

                            case VAR83: 
                                VAR8 = FUN21(VAR6);
                                FUN4(VAR8, VAR8);
                                break;

                            case VAR84:
                                VAR77 = VAR85;
                                continue;

                            default : 
                                
                                VAR79 = VAR76;
                                if (VAR74 + VAR79 > VAR72 + VAR22.VAR23) {
                                    
                                    
                                    VAR79 -= VAR22.VAR23 & 1;
                                    if (VAR74 + VAR79 > VAR72 + VAR22.VAR23)
                                        return VAR17;
                                }
                                memset(VAR74, 0xFF, VAR79);
                                VAR74 += VAR79;

                                
                                
                                
                                
                                
                                
                                
                                
                                
                                if (((VAR79 - 1) & VAR22.VAR26) != 0)
                                    VAR77 = VAR86;
                                else
                                    VAR77 = VAR87;
                                continue;
                        }
                        break;

                    case VAR85:
                        
                        VAR76 = *VAR2++;
                        VAR3--;
                        VAR74 += VAR76;
                        if (VAR74 > VAR72 + VAR22.VAR23)
                            VAR74 = VAR72 + VAR22.VAR23;
                        VAR75 += VAR76 * VAR88;

                        VAR77 = VAR89;
                        continue;

                    case VAR89:
                        
                        VAR76 = *VAR2++;
                        VAR3--;
                        VAR77 = VAR78;
                        if (VAR76 == 0)
                            continue; 

                        VAR8 = FUN21(FUN22(VAR76, VAR6));
                        FUN4(VAR8, VAR8);
                        break;

                    case VAR86: 
                    case VAR87:
                        
                        
                        
                        
                        if (VAR22.VAR26 == VAR42) {
                            while (VAR3 > 0 && VAR79 > 0) {
                                VAR76 = *VAR2++;
                                VAR3--;
                                FUN14(VAR75, VAR76, VAR30);
                                VAR79--;
                            }
                        } else {
                            while (VAR3 > 0 && VAR79 > 0) {
                                VAR76 = *VAR2++;
                                VAR3--;
                                FUN15(VAR75, VAR76, VAR79, VAR30);
                            }
                        }

                        if (VAR79 == 0) {
                            
                            

                            if (VAR77 == VAR86) { 
                                VAR77 = VAR78;
                            } else if (VAR3 > 0) {               
                                
                                
                                VAR2++;
                                VAR3--;
                                VAR77 = VAR78;
                            }
                        }
                        
                        continue;

                    default :
                        FUN17("");
                        return VAR17;
                }
                
                
                if (VAR6 == 0) { 
                    return VAR13->FUN19(VAR14, VAR44);
                }
            }
        }
    }
    
    return VAR7;
}