void VAR1::FUN1(VAR2* VAR3,                           TextRunType VAR4)  
{
  VAR5* VAR6 = FUN2(VAR4);
  if (!VAR6) {
    return;
  }

  VAR7<bool> VAR8 = VAR6 == VAR9;
  FUN3(VAR6, VAR3);
  FUN4(VAR8 ? !VAR9
                           : !FUN5().FUN6(FUN7()));

  











  if (!VAR6->FUN8()) {
    
    VAR10->FUN9(VAR6);
    delete VAR6;
  }
}