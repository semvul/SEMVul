static int FUN1(struct VAR1 *VAR2, 			   VAR3 **VAR4, int *VAR5)  
{
	struct VAR6 *VAR7;
	struct VAR8 *VAR9;
	struct VAR10 *VAR11;
	struct VAR12 *VAR13;
	FUN2(VAR14);
	struct VAR15 *VAR16;
	VAR3 *VAR17, *VAR18, *VAR19;
	uint8_t VAR20 = 0, VAR21 = 0, VAR22 = 0;
	uint16_t VAR23 = 0;
	int VAR24;

	FUN3(VAR25);

	if (*VAR5 >= sizeof(VAR23)) {
		
		VAR23 = FUN4(*VAR4);
		*VAR5 -= sizeof(VAR23);
		*VAR4 += sizeof(VAR23);
	}

	if (VAR23 == 0 || VAR23 > *VAR5) {
		*VAR4 += *VAR5;
		*VAR5 = 0;
		VAR24 = -1;
		goto VAR26;
	}

	
	VAR17 = *VAR4;
	VAR18 = VAR17 + VAR23;

	
	*VAR4 += VAR23;
	*VAR5 -= VAR23;

	memcpy(VAR2->VAR27, VAR17, VAR28);
	FUN5("", FUN6(VAR14, VAR2->VAR27));
	VAR17 += VAR28;

	if ((VAR18 - VAR17) < 12) {
		FUN5("");
		VAR24 = -1;
		goto VAR26;
	}

	

	
	VAR2->VAR29 = *VAR17;
	FUN5("", *VAR17);
	VAR17++;

	
	VAR17 += 8;

	
	VAR2->VAR30 = FUN4(VAR17);
	VAR17 += 2;

	
	VAR2->VAR31 = FUN4(VAR17);
	FUN5("", VAR2->VAR31);
	VAR17 += 2;

	if (VAR2->VAR31 & VAR32)
		FUN5("");
	if (VAR2->VAR31 & VAR33)
		VAR2->VAR34 = VAR35;
	else
		VAR2->VAR34 = VAR36;

	
	FUN5("", VAR18 - VAR17);
	FUN7(VAR25, "", VAR17, VAR18 - VAR17);

	
	while (VAR17 <= VAR18 - 2) {
		struct VAR37 * VAR38 = (void *)VAR17;

		if (VAR17 + VAR38->VAR39 > VAR18) {
			FUN5(""
				     "");
			break;
		}

		switch (VAR38->VAR40) {
		case VAR41:
			VAR2->VAR42 = FUN8(int, 32, VAR38->VAR39);
			memcpy(VAR2->VAR43, VAR38->VAR44, VAR2->VAR42);
			FUN5("",
			             FUN9(VAR2->VAR43, VAR2->VAR42),
			             VAR2->VAR42);
			break;

		case VAR45:
			VAR22 = FUN8(VAR3, VAR46, VAR38->VAR39);
			memcpy(VAR2->VAR47, VAR38->VAR44, VAR22);
			VAR21 = 1;
			FUN5("");
			break;

		case VAR48:
			VAR7 = (struct VAR6 *) VAR17;
			memmove(&VAR2->VAR49.VAR50, VAR7,
				sizeof(struct VAR6));
			FUN5("");
			break;

		case VAR51:
			VAR9 = (struct VAR8 *) VAR17;
			VAR2->VAR52 = VAR9->VAR53;
			memcpy(&VAR2->VAR49.VAR54, VAR9,
			       sizeof(struct VAR8));
			FUN5("", VAR2->VAR52);
			break;

		case VAR55:
			VAR11 = (struct VAR10 *) VAR17;
			memcpy(&VAR2->VAR56.VAR57, VAR11,
			       sizeof(struct VAR10));
			FUN5("");
			break;

		case VAR58:
			VAR13 = (struct VAR12 *) VAR17;
			VAR2->VAR59 = FUN10(VAR13->VAR59);
			memmove(&VAR2->VAR56.VAR60, VAR13,
				sizeof(struct VAR12));
			FUN5("");
			break;

		case VAR61:
			VAR16 = (struct VAR15 *) VAR17;
			FUN5("");
			if (VAR16->VAR39 < sizeof(VAR16->VAR62)
			    || VAR16->VAR39 > 254) {
				FUN5("",
					     VAR16->VAR39, sizeof(VAR16->VAR62));
				VAR24 = -1;
				goto VAR26;
			}

			memcpy(&VAR2->VAR63, VAR16, VAR16->VAR39 + 2);
			FUN7(VAR25, "",
				    (VAR3 *) VAR16,
				    (int) (VAR16->VAR39 + 2));
			break;

		case VAR64:
			
			FUN5("");
			if (!VAR21) {
				FUN5("");
				break;
			}

			VAR20 = VAR38->VAR39;
			if (VAR22 + VAR20 > VAR46)
				VAR20 = VAR46 - VAR22;

			VAR19 = VAR2->VAR47 + VAR22;
			memcpy(VAR19, VAR38->VAR44, VAR20);
			break;

		case VAR65:
			if (VAR38->VAR39 >= 4 &&
			    VAR38->VAR44[0] == 0x00 && VAR38->VAR44[1] == 0x50 &&
			    VAR38->VAR44[2] == 0xf2 && VAR38->VAR44[3] == 0x01) {
				VAR2->VAR66 = FUN11(VAR38->VAR39 + 2, VAR67);
				memcpy(VAR2->VAR68, VAR38, VAR2->VAR66);
				FUN5("");
				FUN7(VAR25, "", VAR2->VAR68, VAR38->VAR39);
			} else if (VAR38->VAR39 >= VAR69 &&
				   VAR38->VAR44[0] == 0x00 && VAR38->VAR44[1] == 0x50 &&
				   VAR38->VAR44[2] == 0x43 && VAR38->VAR44[3] == 0x04) {
				FUN5("");
				VAR2->VAR70 = 1;
			} else {
				FUN5("",
					VAR38->VAR44[0], VAR38->VAR44[1],
					VAR38->VAR44[2], VAR38->VAR44[3],
					VAR38->VAR39);
			}
			break;

		case VAR71:
			FUN5("");
			VAR2->VAR72 = FUN11(VAR38->VAR39 + 2, VAR67);
			memcpy(VAR2->VAR73, VAR38, VAR2->VAR72);
			FUN7(VAR25, "",
				    VAR2->VAR73, VAR38->VAR39);
			break;

		default:
			FUN5("",
				     VAR38->VAR40, VAR38->VAR39);
			break;
		}

		VAR17 += VAR38->VAR39 + 2;
	}

	
	VAR2->VAR74 = VAR75;
	FUN12(VAR2->VAR47, sizeof(VAR2->VAR47));

	VAR24 = 0;

VAR26:
	FUN13(VAR25, "", VAR24);
	return VAR24;
}