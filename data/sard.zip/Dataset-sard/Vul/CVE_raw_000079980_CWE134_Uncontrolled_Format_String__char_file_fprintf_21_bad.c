void FUN1()
{
    char * VAR1;
    char VAR2[100] = "";
    VAR1 = VAR2;
    {
        
        size_t VAR3 = strlen(VAR1);
        VAR4 * VAR5;
        
        if (100-VAR3 > 1)
        {
            VAR5 = fopen(VAR6, "");
            if (VAR5 != NULL)
            {
                
                if (fgets(VAR1+VAR3, (int)(100-VAR3), VAR5) == NULL)
                {
                    FUN2("");
                    
                    VAR1[VAR3] = '';
                }
                fclose(VAR5);
            }
        }
    }
    VAR7 = 1; 
    FUN3(VAR1);
}