struct VAR1 * FUN1(struct VAR2 *VAR3, struct VAR1 *VAR4, 	    struct VAR5 *VAR6)  
{
	int VAR7;
	int VAR8 = 0; 
	__u32 VAR9 = 0;
	__u16 VAR10 = 0;
	bool VAR11 = false;
	struct VAR12 *VAR13;
	struct VAR14 *VAR15;
	struct VAR16 *VAR17;
	struct VAR2 *VAR18 = NULL;
	char *VAR19 = NULL;
	struct VAR20 *VAR21;

	VAR7 = FUN2();

	FUN3(1, "",
	      VAR3, VAR4->VAR22.VAR23, VAR4);

	

	VAR13 = FUN4(VAR3->VAR24);
	VAR15 = VAR13->VAR25;

	
	if (!(VAR13->VAR26 & VAR27)) {
		int VAR28;
		for (VAR28 = 0; VAR28 < VAR4->VAR22.VAR29; VAR28++)
			if (VAR4->VAR22.VAR23[VAR28] == '') {
				FUN3(1, "");
				FUN5(VAR7);
				return FUN6(-VAR30);
			}
	}

	
	if (VAR6 && (VAR6->VAR31 & VAR32)) {
		FUN7(VAR4, NULL);
		return NULL;
	}

	
	VAR19 = FUN8(VAR4);
	if (VAR19 == NULL) {
		FUN5(VAR7);
		return FUN6(-VAR33);
	}

	if (VAR4->VAR34 != NULL) {
		FUN3(1, "");
	} else {
		FUN3(1, "");
	}
	FUN3(1, "", VAR19, VAR4->VAR34);

	
	if (VAR15->VAR35) {
		if (VAR6 && !(VAR6->VAR31 & (VAR36 | VAR37)) &&
		     (VAR6->VAR31 & VAR38) && !VAR15->VAR39 &&
		     (VAR6->VAR40.open.VAR31 & VAR41)) {
			VAR8 = FUN9(VAR19, &VAR18,
					VAR3->VAR24,
					VAR6->VAR40.open.VAR42,
					VAR6->VAR40.open.VAR31, &VAR9,
					&VAR10, VAR7);
			
			switch (VAR8) {
			case 0:
				
				if (VAR18 && !FUN10(VAR18->VAR43)) {
					FUN11(VAR7, VAR15, VAR10);
					break;
				}
			case -VAR44:
				VAR11 = true;
			case -VAR45:
				break;
			default:
				VAR15->VAR39 = true;
			}
		}
		if (!VAR11)
			VAR8 = FUN12(&VAR18, VAR19,
						VAR3->VAR24, VAR7);
	} else
		VAR8 = FUN13(&VAR18, VAR19, NULL,
				VAR3->VAR24, VAR7, NULL);

	if ((VAR8 == 0) && (VAR18 != NULL)) {
		if (VAR15->VAR46)
			VAR4->VAR47 = &VAR48;
		else
			VAR4->VAR47 = &VAR49;
		FUN14(VAR4, VAR18);
		if (VAR11) {
			VAR21 = FUN15(VAR6, VAR4,
						       VAR50);
			if (FUN16(VAR21)) {
				VAR8 = FUN17(VAR21);
				FUN11(VAR7, VAR15, VAR10);
				goto VAR51;
			}

			VAR17 = FUN18(VAR18, VAR10, VAR21,
						  VAR6->VAR52.VAR53,
						  VAR6->VAR40.open.VAR31);
			if (VAR17 == NULL) {
				FUN19(VAR21);
				FUN11(VAR7, VAR15, VAR10);
				VAR8 = -VAR33;
				goto VAR51;
			}
		}
		
		FUN20(VAR4);

	} else if (VAR8 == -VAR44) {
		VAR8 = 0;
		VAR4->VAR54 = VAR55;
		if (VAR15->VAR46)
			VAR4->VAR47 = &VAR48;
		else
			VAR4->VAR47 = &VAR49;
		FUN14(VAR4, NULL);
	
	} else if (VAR8 != -VAR56) {
		FUN21(1, "", VAR8);
		
	}

VAR51:
	FUN22(VAR19);
	FUN5(VAR7);
	return FUN6(VAR8);
}