static VAR1 FUN1(struct VAR2 * VAR2, const char VAR3 *VAR4, 			 size_t VAR5, VAR6 *VAR7)  
{
	int VAR8;
	char *VAR9;
	unsigned long VAR10 = *VAR7;
	struct VAR11 *VAR12 = VAR2->VAR13;

	if (!VAR12)
		return 0;

	VAR9 = (char *)FUN2(VAR14);
	if (!VAR9)
		return -VAR15;

	VAR8 = 0;
	while (VAR5 > 0) {
		int VAR16, VAR17;

		VAR16 = (VAR5 > VAR18) ? VAR18 : VAR5;
		if (FUN3(VAR9, VAR4, VAR16)) {
			VAR8 = -VAR19;
			break;
		}
		VAR17 = FUN4(VAR12, VAR10, VAR9, VAR16, 1);
		if (!VAR17) {
			if (!VAR8)
				VAR8 = -VAR20;
			break;
		}
		VAR8 += VAR17;
		VAR4 += VAR17;
		VAR10 += VAR17;
		VAR5 -= VAR17;			
	}
	*VAR7 = VAR10;

	FUN5((unsigned long) VAR9);
	return VAR8;
}