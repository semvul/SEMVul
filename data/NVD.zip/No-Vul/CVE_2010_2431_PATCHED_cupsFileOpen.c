*/  VAR1 *				 FUN1(const char *VAR2,	              const char *VAR3)		  
{
  VAR1	*VAR4;			
  int		VAR5;			
  char		VAR6[1024],		
		*VAR7;		
  VAR8 *VAR9;		


  FUN2((""%VAR10\""%VAR10\"", VAR2,
                VAR3));

 

  if (!VAR2 || !VAR3 ||
      (*VAR3 != '' && *VAR3 != '' && *VAR3 != '' && *VAR3 != '') ||
      (*VAR3 == '' && FUN3(VAR3[1] & 255)))
    return (NULL);

 

  switch (*VAR3)
  {
    case '' : 
        VAR5 = FUN4(VAR2,
		       VAR11 | VAR12 | VAR13 | VAR14 | VAR15);
        break;

    case '' : 
	VAR5 = open(VAR2, VAR16 | VAR14 | VAR15, 0);
	break;

    case '' : 
        VAR5 = FUN4(VAR2, VAR17 | VAR14 | VAR15);
	if (VAR5 < 0 && VAR18 == VAR19)
	{
	  VAR5 = FUN4(VAR2,
	                 VAR17 | VAR12 | VAR20 | VAR14 | VAR15);
	  if (VAR5 < 0 && VAR18 == VAR21)
	    VAR5 = FUN4(VAR2, VAR17 | VAR14 | VAR15);
	}

	if (VAR5 >= 0)
	  FUN5(VAR5, 0);
        break;

    case '' : 
        FUN6(VAR6, VAR2, sizeof(VAR6));
	if ((VAR7 = strrchr(VAR6, '')) != NULL)
	  *VAR7++ = '';
	else
	  return (NULL);

       

        if ((VAR9 = FUN7(VAR6, VAR22, VAR7)) == NULL)
	  return (NULL);

       

        if (!FUN8(VAR9, &VAR5))
	{
	  FUN9(VAR9);
	  return (NULL);
	}

	FUN9(VAR9);
	break;

    default : 
        return (NULL);
  }

  if (VAR5 < 0)
    return (NULL);

 

  if ((VAR4 = FUN10(VAR5, VAR3)) == NULL)
  {
    if (*VAR3 == '')
      FUN11(VAR5);
    else
      close(VAR5);
  }

 

  return (VAR4);
}