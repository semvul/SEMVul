int *FUN1(char *VAR1, int *VAR2, int VAR3)  
{
	int             VAR4, VAR5;

	for (VAR4 = 0; VAR4 < VAR6; VAR4++) {
		if (FUN2(VAR1, VAR7[VAR4].VAR1, 32) == 0) {
			if (VAR3)
				VAR7[VAR4].VAR8 = VAR4;
			return VAR7[VAR4].VAR2;
		}
	}
	if (VAR6 >= VAR9) {
		FUN3(VAR10 "", VAR1);
		return VAR2;
	}
	VAR5 = VAR6++;

	strncpy(VAR7[VAR5].VAR1, VAR1, 32);

	if (VAR3)
		VAR7[VAR5].VAR8 = VAR5;
	else
		VAR7[VAR5].VAR8 = -1;

	for (VAR4 = 0; VAR4 < 32; VAR4++)
		VAR7[VAR5].VAR2[VAR4] = VAR2[VAR4];
	return VAR7[VAR5].VAR2;
}