static int FUN1(VAR1 *VAR2)  
{
    VAR3 *VAR4 = &VAR2->VAR4;
    int VAR5, VAR6;
    unsigned VAR7;

#VAR8 FUN2(VAR9, VAR10, VAR11) \
    VAR7 = FUN3(VAR4); \
    if (VAR10) { \
        FUN4(VAR2->VAR12, VAR13, VAR11); \
        return -1; \
    }\
    VAR9 = VAR7;

    FUN5(VAR4);

    VAR2->VAR14 = VAR2->VAR15 ? FUN6(VAR4) : 0;
    if (VAR2->VAR14)
        return 0;

    
    FUN2(VAR2->VAR16, VAR7 > 6, "")

    FUN2(VAR2->VAR17, VAR7 > VAR18 || VAR7 < 1, "")

    if (!VAR2->VAR19) {
        
        if (FUN6(VAR4)) {
            for (VAR5 = 0; VAR5 <= VAR2->VAR17; VAR5++) {
                FUN2(VAR2->VAR20[VAR5].VAR21 , VAR7 < 1, "")
                FUN2(VAR2->VAR20[VAR5].VAR22, VAR7 < 1, "")
            }

            FUN2(VAR2->VAR23, VAR7 > 1, "")
        } else
            for (VAR5 = 0; VAR5 <= VAR2->VAR17; VAR5++)
                VAR2->VAR20[VAR5].VAR21 = VAR2->VAR20[VAR5].VAR22 = 1;
    } else {
        
        
        VAR2->VAR24.VAR25     = FUN3(VAR4);
        VAR2->VAR24.VAR26     = FUN3(VAR4);
        VAR2->VAR24.VAR27.VAR28 = FUN3(VAR4);
        VAR2->VAR24.VAR27.VAR29 = FUN3(VAR4);

        
        if (FUN6(VAR4)) {
            FUN4(VAR2->VAR12,VAR30,"");
            
            VAR2->VAR24.VAR31[0][0] = FUN3(VAR4);
            for (VAR6 = 0; VAR6 < VAR2->VAR17; VAR6++) {
                VAR2->VAR24.VAR31[VAR6][1] = FUN3(VAR4);
                VAR2->VAR24.VAR31[VAR6][2] = FUN3(VAR4);
                VAR2->VAR24.VAR31[VAR6][3] = FUN3(VAR4);
            }
        } else {
            
            for (VAR6 = 0; VAR6 < VAR2->VAR17; VAR6++)
                for (VAR5 = 0; VAR5 < 4; VAR5++) {
                    VAR2->VAR24.VAR31[VAR6][VAR5] = VAR32[VAR2->VAR16][VAR6][VAR5];
                    
                    if (VAR2->VAR16 == 3)
                        VAR2->VAR24.VAR31[VAR6][VAR5] += 4*(VAR2->VAR17-1 - VAR6);
                }
        }
    }
    return 0;
}