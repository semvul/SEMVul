static int FUN1(struct VAR1 *VAR1, const void *VAR2, size_t VAR3)  
{
	struct VAR4 *VAR5;
	unsigned long VAR6;
	int VAR7;
	size_t VAR8 = 0;
	const char *VAR9 = VAR2, *VAR10, *VAR11;

	FUN2("",
	       VAR1->VAR12, VAR1->VAR13,
	       (int)VAR3, (int)VAR3, VAR9, VAR3);

	if (VAR3 <= 1 || !VAR9 || VAR9[VAR3 - 1] != '')
		return -VAR14;
	VAR3--;

	
	VAR10 = VAR9 + VAR3;
	VAR11 = memchr(VAR9, '', VAR3);
	if (!VAR11) {
		
		FUN3("");
		VAR8 = VAR3;
	} else {
		const char *VAR15;

		VAR8 = VAR11 - VAR9;
		VAR11++;
		FUN3("", VAR11);
		do {
			const char *VAR16;
			int VAR17, VAR18, VAR19, VAR20;

			VAR15 = memchr(VAR11, '', VAR10 - VAR11) ?: VAR10;
			VAR17 = VAR15 - VAR11;
			if (!VAR17) {
				FUN4(VAR21
				       "",
				       VAR1->VAR12);
				return -VAR14;
			}

			VAR16 = memchr(VAR11, '', VAR17) ?: VAR10;
			VAR18 = VAR16 - VAR11;
			VAR16++;
			VAR19 = VAR15 - VAR16; 

			VAR20 = VAR19 >= 0 ? VAR19 : 0;
			FUN3("",
			       VAR18, VAR18, VAR11, VAR20, VAR20, VAR16);

			
			if (VAR18 == sizeof(VAR22) - 1 &&
			    memcmp(VAR11, VAR22, VAR18) == 0) {
				FUN3("");
				if (VAR19 <= 0)
					goto VAR23;

				VAR7 = FUN5(VAR16, 10, &VAR6);
				if (VAR7 < 0)
					goto VAR23;

				if (VAR6 < 1 || VAR6 > 511)
					goto VAR23;

				FUN3("", VAR6);
				VAR1->VAR24.VAR25[0] = -VAR6;
				continue;
			}

		VAR23:
			FUN4(VAR21
			       ""
			       "",
			       VAR18, VAR18, VAR11, VAR1->VAR12);
			return -VAR14;
		} while (VAR11 = VAR15 + 1, VAR11 < VAR10);
	}

	
	if (VAR1->VAR24.VAR25[0]) {
		FUN6("", VAR1->VAR24.VAR25[0]);
		return 0;
	}

	FUN3("");
	VAR7 = FUN7(VAR1, VAR8);
	if (VAR7 < 0)
		return -VAR14;

	VAR5 = FUN8(sizeof(*VAR5) + VAR8 + 1, VAR26);
	if (!VAR5) {
		FUN6("");
		return -VAR27;
	}

	VAR5->VAR3 = VAR8;
	memcpy(VAR5->VAR9, VAR9, VAR8);
	VAR5->VAR9[VAR8] = '';
	FUN9(VAR1->VAR28.VAR9, VAR5);

	FUN6("");
	return 0;
}