static VAR1 FUN1(struct VAR2 *VAR2, const char VAR3 *VAR4, 				size_t VAR5, VAR6 *VAR7)  
{
	struct VAR8 *VAR9 = FUN2(VAR2->VAR10.VAR11->VAR12)->VAR13;
#define PROC_WRITELEN	10
	char VAR14[VAR15+1];
	unsigned long VAR16;

	if (VAR5 > VAR15)
		return -VAR17;
	if (FUN3(VAR14, VAR4, VAR5))
		return -VAR18;
	VAR14[VAR5] = 0;

	if (*VAR14 == '') {
		VAR16 = FUN4(VAR14+1, NULL, 10);
		if (FUN5(VAR9, VAR16))
			return -VAR19;
	} else if (*VAR14 == '') {
		VAR16 = FUN4(VAR14+1, NULL,10);
		if (FUN6(VAR9, VAR16))
			return -VAR20;
	} else
		return -VAR17;

	return VAR5;
}