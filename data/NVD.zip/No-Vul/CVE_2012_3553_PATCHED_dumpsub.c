static void FUN1(struct VAR1 *VAR2, int VAR3)  
{
	struct VAR4 *VAR5 = VAR2->VAR6;
	struct VAR7 *VAR8 = VAR5->VAR9;
	struct VAR1 *VAR10 = NULL;
	struct VAR1 *VAR11;

	if (!VAR5->VAR9) {
		FUN2(VAR12, "", VAR5->VAR13);
		return;
	}

	if (VAR14) {
		FUN3(3, "", VAR2->VAR15);
	}

	if (!VAR3 && VAR2->VAR16 == VAR17) {
		VAR5->VAR18 = NULL;
		return;
	}

	if (VAR2 == VAR5->VAR18) {
		VAR8->VAR19 = VAR20;
		FUN4(VAR8, VAR21); 
		if (VAR2->VAR22) {
			VAR10 = VAR2->VAR22;
			FUN5(VAR2, VAR23);
			VAR5->VAR18 = VAR10;
			if (VAR5->VAR18->VAR16 != VAR17) {
				FUN2(VAR12, "", VAR2->VAR15);
				return;
			}
			FUN5(VAR5->VAR18, VAR17);
		} else {
			FUN5(VAR2, VAR23);
			FUN6(&VAR5->VAR2, VAR11, VAR24) {
				if (VAR11->VAR16 == VAR25) {
					VAR10 = VAR11;
				}
			}
			if (VAR10) {
				FUN5(VAR10, VAR26);
				return;
			}
			FUN6(&VAR5->VAR2, VAR11, VAR24) {
				if (VAR11->VAR16 == VAR17) {
					VAR10 = VAR11;
				}
			}
			if (VAR10) {
				FUN5(VAR10, VAR17);
				return;
			}
		}
	} else {
		FUN5(VAR2, VAR23);
	}
}