VAR1 FUN1(struct VAR2 *VAR3, struct VAR4 *VAR5, 			  VAR6 *VAR7, size_t VAR8, unsigned int VAR9)  
{
	struct VAR10 *VAR11 = VAR5->VAR12;
	struct VAR13 *VAR13 = VAR11->VAR14;
	struct splice_desc VAR15 = {
		.VAR16 = VAR8,
		.VAR9 = VAR9,
		.VAR17 = *VAR7,
		.VAR18.VAR4 = VAR5,
	};
	ssize_t VAR19;

	FUN2(FUN3(VAR13->VAR20));
	FUN4(&VAR13->VAR21, VAR22);
	VAR19 = FUN5(VAR5);
	if (FUN6(!VAR19)) {
		if (VAR3->VAR13)
			FUN4(&VAR3->VAR13->VAR21, VAR23);
		VAR19 = FUN7(VAR3, &VAR15, VAR24);
		if (VAR3->VAR13)
			FUN8(&VAR3->VAR13->VAR21);
	}
	FUN8(&VAR13->VAR21);
	if (VAR19 > 0) {
		unsigned long VAR25;

		*VAR7 += VAR19;
		VAR25 = (VAR19 + VAR26 - 1) >> VAR27;

		
		if (FUN9((VAR5->VAR28 & VAR29) || FUN10(VAR13))) {
			int VAR30;

			FUN11(&VAR13->VAR21);
			VAR30 = FUN12(VAR13, VAR11,
						  VAR31|VAR32);
			FUN8(&VAR13->VAR21);

			if (VAR30)
				VAR19 = VAR30;
		}
		FUN13(VAR11, VAR25);
	}

	return VAR19;
}