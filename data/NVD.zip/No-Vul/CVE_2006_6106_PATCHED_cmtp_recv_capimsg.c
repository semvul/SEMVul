void FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4)  
{
	struct VAR5 *VAR6 = &VAR2->VAR6;
	struct VAR7 *VAR8;
	__u16 VAR9, VAR10;
	__u32 VAR11;

	FUN2("", VAR2, VAR4, VAR4->VAR12);

	if (VAR4->VAR12 < VAR13)
		return;

	if (FUN3(VAR4->VAR14) == VAR15) {
		FUN4(VAR2, VAR4);
		return;
	}

	if (VAR2->VAR16 & (1 << VAR17)) {
		FUN5(VAR4);
		return;
	}

	VAR9 = FUN6(FUN3(VAR4->VAR14), FUN7(VAR4->VAR14));
	VAR10 = FUN8(VAR4->VAR14);
	VAR11 = FUN9(VAR4->VAR14);

	VAR8 = FUN10(VAR2, VAR18, VAR10);
	if (VAR8) {
		VAR10 = VAR8->VAR10;
		FUN11(VAR4->VAR14, VAR10);
	} else {
		FUN12("", VAR10);
		FUN5(VAR4);
		return;
	}

	if ((VAR11 & 0x7f) == 0x01) {
		VAR11 = (VAR11 & 0xffffff80) | VAR2->VAR19;
		FUN13(VAR4->VAR14, VAR11);
	}

	if (!VAR6) {
		FUN12("", VAR2->VAR19);
		FUN5(VAR4);
		return;
	}

	FUN14(VAR6, VAR10, VAR4);
}