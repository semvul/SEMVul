static struct VAR1 *FUN1(struct VAR2 *VAR2, int VAR3)  
{
static int VAR4[VAR5] = { VAR6, VAR7,
					VAR6 | VAR7 };

	if ((VAR3 & VAR5) == (VAR8 | VAR9)) {
		FUN2(VAR2);
		FUN3(VAR10);
		return FUN4(-VAR11);
	}

	if (FUN5(VAR2->VAR12, VAR4[VAR3 & VAR5], NULL)) {
		FUN2(VAR2);
		FUN3(VAR10);
		return FUN4(-VAR13);
	}

	return FUN6(VAR2, VAR10, VAR3);
}