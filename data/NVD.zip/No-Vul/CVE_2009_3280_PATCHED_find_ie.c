static VAR1 *FUN1(u8 VAR2, VAR1 *VAR3, int VAR4)  
{
	while (VAR4 > 2 && VAR3[0] != VAR2) {
		VAR4 -= VAR3[1] + 2;
		VAR3 += VAR3[1] + 2;
	}
	if (VAR4 < 2)
		return NULL;
	if (VAR4 < 2 + VAR3[1])
		return NULL;
	return VAR3;
}