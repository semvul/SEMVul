static int FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4, int VAR5)  
{
	struct VAR6 *VAR7 = FUN2(VAR2);
	VAR8 *VAR9 = &VAR7->VAR10;
	struct s_skfp_ioctl VAR11;
	int VAR12 = 0;

	if (FUN3(&VAR11, VAR4->VAR13, sizeof(struct VAR14)))
		return -VAR15;

	switch (VAR11.VAR5) {
	case VAR16:	
		VAR11.VAR17 = sizeof(VAR9->VAR18);
		VAR12 = FUN4(VAR11.VAR19, FUN5(VAR2), VAR11.VAR17)
				? -VAR15 : 0;
		break;
	case VAR20:	
		if (!FUN6(VAR21)) {
			VAR12 = -VAR22;
		} else {
			memset(&VAR9->VAR18, 0, sizeof(VAR9->VAR18));
		}
		break;
	default:
		FUN7("", VAR2->VAR23, VAR11.VAR5);
		VAR12 = -VAR24;

	}			

	return VAR12;
}