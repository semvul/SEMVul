struct VAR1 *FUN1(const struct VAR2 *VAR3, 				      const char *VAR4, 				      const struct VAR5 *VAR6, 				      const char *VAR7, 				      const char *VAR8, 				      rpc_authflavor_t VAR9, 				      struct VAR10 *VAR11)  
{
	struct nfs_fattr VAR12;
	struct VAR1 *VAR13;
	int VAR14;

	FUN2("");

	VAR13 = FUN3();
	if (!VAR13)
		return FUN4(-VAR15);

	
	VAR14 = FUN5(VAR13, VAR4, VAR6, VAR8, VAR9,
			VAR3->VAR16, VAR3->VAR17, VAR3->VAR18);
	if (VAR14 < 0)
		goto VAR14;

	
	VAR14 = FUN6(VAR13, VAR3, VAR9);
	if (VAR14 < 0)
		goto VAR14;

	if (VAR13->VAR19 == 0 || VAR13->VAR19 > VAR20)
		VAR13->VAR19 = VAR20;

	FUN7(!VAR13->VAR21);
	FUN7(!VAR13->VAR21->VAR22);
	FUN7(!VAR13->VAR21->VAR22->VAR23);

	
	VAR14 = FUN8(VAR13, VAR11, VAR7);
	if (VAR14 < 0)
		goto VAR14;

	FUN2("",
		(unsigned long long) VAR13->VAR24.VAR25,
		(unsigned long long) VAR13->VAR24.VAR26);
	FUN2("", VAR11->VAR27);

	VAR14 = FUN9(VAR13, VAR11, &VAR12);
	if (VAR14 < 0)
		goto VAR14;

	FUN7(!VAR13->VAR21);
	FUN7(!VAR13->VAR21->VAR22);
	FUN7(!VAR13->VAR21->VAR22->VAR23);

	FUN10(&VAR28);
	FUN11(&VAR13->VAR29, &VAR13->VAR21->VAR30);
	FUN11(&VAR13->VAR31, &VAR32);
	FUN12(&VAR28);

	VAR13->VAR33 = VAR34;
	FUN2("", VAR13);
	return VAR13;

VAR14:
	FUN13(VAR13);
	FUN2("", VAR14);
	return FUN4(VAR14);
}