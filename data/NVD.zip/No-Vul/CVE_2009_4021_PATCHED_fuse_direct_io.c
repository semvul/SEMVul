VAR1 FUN1(struct VAR2 *VAR2, const char VAR3 *VAR4, 		       size_t VAR5, VAR6 *VAR7, int write)  
{
	struct VAR8 *VAR9 = VAR2->VAR10;
	struct VAR11 *VAR12 = VAR9->VAR12;
	size_t VAR13 = write ? VAR12->VAR14 : VAR12->VAR15;
	loff_t VAR16 = *VAR7;
	ssize_t VAR17 = 0;
	struct VAR18 *VAR19;

	VAR19 = FUN2(VAR12);
	if (FUN3(VAR19))
		return FUN4(VAR19);

	while (VAR5) {
		size_t VAR20;
		fl_owner_t VAR21 = VAR22->VAR23;
		size_t VAR24 = FUN5(VAR5, VAR13);
		int VAR25 = FUN6(VAR19, VAR4, &VAR24, write);
		if (VAR25) {
			VAR17 = VAR25;
			break;
		}

		if (write)
			VAR20 = FUN7(VAR19, VAR2, VAR16, VAR24, VAR21);
		else
			VAR20 = FUN8(VAR19, VAR2, VAR16, VAR24, VAR21);

		FUN9(VAR19, !write);
		if (VAR19->VAR26.VAR27.VAR28) {
			if (!VAR17)
				VAR17 = VAR19->VAR26.VAR27.VAR28;
			break;
		} else if (VAR20 > VAR24) {
			VAR17 = -VAR29;
			break;
		}
		VAR5 -= VAR20;
		VAR17 += VAR20;
		VAR16 += VAR20;
		VAR4 += VAR20;
		if (VAR20 != VAR24)
			break;
		if (VAR5) {
			FUN10(VAR12, VAR19);
			VAR19 = FUN2(VAR12);
			if (FUN3(VAR19))
				break;
		}
	}
	if (!FUN3(VAR19))
		FUN10(VAR12, VAR19);
	if (VAR17 > 0)
		*VAR7 = VAR16;

	return VAR17;
}