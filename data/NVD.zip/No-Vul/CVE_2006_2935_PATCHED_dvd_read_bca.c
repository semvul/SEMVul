static int FUN1(struct VAR1 *VAR2, VAR3 *VAR4)  
{
	int VAR5;
	u_char VAR6[4 + 188];
	struct packet_command VAR7;
	struct VAR8 *VAR9 = VAR2->VAR10;

	FUN2(&VAR7, VAR6, sizeof(VAR6), VAR11);
	VAR7.VAR12[0] = VAR13;
	VAR7.VAR12[7] = VAR4->VAR14;
	VAR7.VAR12[9] = VAR7.VAR15 & 0xff;

	if ((VAR5 = VAR9->FUN3(VAR2, &VAR7)))
		return VAR5;

	VAR4->VAR16.VAR17 = VAR6[0] << 8 | VAR6[1];
	if (VAR4->VAR16.VAR17 < 12 || VAR4->VAR16.VAR17 > 188) {
		FUN4(VAR18, "", VAR4->VAR16.VAR17);
		return -VAR19;
	}
	memcpy(VAR4->VAR16.VAR20, &VAR6[4], VAR4->VAR16.VAR17);

	return 0;
}