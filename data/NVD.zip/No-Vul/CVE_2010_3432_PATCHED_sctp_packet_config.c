struct VAR1 *FUN1(struct VAR1 *VAR2, 				       __u32 VAR3, int VAR4)  
{
	struct VAR5 *VAR6 = NULL;

	FUN2("", VAR7,
			  VAR2, VAR3);

	VAR2->VAR3 = VAR3;

	if (VAR4 && FUN3(VAR2)) {
		VAR6 = FUN4(VAR2->VAR8->VAR9);

		
		if (VAR6)
			FUN5(VAR2, VAR6);
	}

	return VAR2;
}