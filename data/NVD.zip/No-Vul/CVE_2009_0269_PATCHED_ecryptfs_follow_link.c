static void *FUN1(struct VAR1 *VAR1, struct VAR2 *VAR3)  
{
	char *VAR4;
	int VAR5 = VAR6, VAR7;
	mm_segment_t VAR8;

	
	VAR4 = FUN2(VAR5, VAR9);
	if (!VAR4) {
		VAR7 = -VAR10;
		goto VAR11;
	}
	VAR8 = FUN3();
	FUN4(FUN5());
	FUN6(VAR12, ""
			"", VAR1->VAR13.VAR14);
	VAR7 = VAR1->VAR15->VAR16->readlink(VAR1, (char VAR17 *)VAR4, VAR5);
	FUN4(VAR8);
	if (VAR7 < 0)
		goto VAR18;
	else
		VAR4[VAR7] = '';
	VAR7 = 0;
	FUN7(VAR3, VAR4);
	goto VAR11;
VAR18:
	FUN8(VAR4);
VAR11:
	return FUN9(VAR7);
}