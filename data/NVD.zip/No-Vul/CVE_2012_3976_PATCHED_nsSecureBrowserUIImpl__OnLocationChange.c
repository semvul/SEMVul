NS_IMETHODIMP VAR1::FUN1(VAR2* VAR3,                                         VAR4* VAR5,                                         VAR6* VAR7,                                         PRUint32 VAR8)  
{
#ifdef VAR9
  VAR10 FUN2(VAR11);
  FUN3(VAR11 == 1,
               "");
#endif
  FUN4(VAR12, VAR13,
         ("", this));

  bool VAR14 = false;
  bool VAR15 = false;
  VAR16<VAR17> VAR18;

  if (VAR7)
  {
    bool VAR19;

    nsresult VAR20 = VAR7->FUN5("", &VAR19);
    FUN6(VAR20, VAR20);

    if (VAR19) {
      FUN4(VAR12, VAR13,
             ("", this));
    }

    VAR14 = true;
    VAR15 = VAR19;
  }

  {
    VAR21 FUN7(VAR22);
    if (VAR14) {
      VAR23 = VAR15;
    }
    VAR24 = VAR7;
    VAR18 = FUN8(VAR25);
    FUN3(VAR18, "");
  }

  
  
  
  if (VAR8 & VAR26)
    return VAR27;

  
  
  
  
  
  
  

  VAR16<VAR17> VAR28;
  VAR3->FUN9(FUN10(VAR28));

  VAR16<VAR29> FUN11(FUN12(VAR5));

  if (VAR28.FUN13() == VAR18.FUN13()) {
    
    VAR30 = true;
    return FUN14(VAR5, VAR31, true);
  }

  
  FUN15(VAR31);

  

  
  
  
  
  
  
  
  

  bool VAR32;
  {
    VAR21 FUN7(VAR22);
    VAR32 = VAR33;
  }

  if (VAR32)
    return FUN16(VAR5, true, false, false);

  return VAR27;
}