static int FUN1(const char *VAR1, struct VAR2 *VAR3)  
{
	struct path VAR4;
	struct VAR5 *VAR5;
	int VAR6;
	unsigned int VAR7 = VAR3->VAR8;
	
	while (*VAR1=='')
		VAR1++;
	if (!*VAR1)
		goto VAR9;

	VAR5 = VAR3->VAR10.VAR11->VAR12;
	if (VAR3->VAR13)
		VAR7 = VAR14 | (VAR3->VAR8 & VAR15);

	
	for(;;) {
		unsigned long VAR16;
		struct qstr this;
		unsigned int VAR17;

		VAR3->VAR8 |= VAR15;
		VAR6 = FUN2(VAR5);
 		if (VAR6)
			break;

		this.VAR1 = VAR1;
		VAR17 = *(const unsigned char *)VAR1;

		VAR16 = FUN3();
		do {
			VAR1++;
			VAR16 = FUN4(VAR17, VAR16);
			VAR17 = *(const unsigned char *)VAR1;
		} while (VAR17 && (VAR17 != ''));
		this.VAR18 = VAR1 - (const char *) this.VAR1;
		this.VAR16 = FUN5(VAR16);

		
		if (!VAR17)
			goto VAR19;
		while (*++VAR1 == '');
		if (!*VAR1)
			goto VAR20;

		
		if (this.VAR1[0] == '') switch (this.VAR18) {
			default:
				break;
			case 2:	
				if (this.VAR1[1] != '')
					break;
				FUN6(VAR3);
				VAR5 = VAR3->VAR10.VAR11->VAR12;
				
			case 1:
				continue;
		}
		
		if (VAR3->VAR10.VAR11->VAR21 && VAR3->VAR10.VAR11->VAR21->VAR22) {
			VAR6 = VAR3->VAR10.VAR11->VAR21->FUN7(VAR3->VAR10.VAR11,
							    &this);
			if (VAR6 < 0)
				break;
		}
		
		VAR6 = FUN8(VAR3, &this, &VAR4);
		if (VAR6)
			break;

		VAR6 = -VAR23;
		VAR5 = VAR4.VAR11->VAR12;
		if (!VAR5)
			goto VAR24;

		if (VAR5->VAR25->VAR26) {
			VAR6 = FUN9(&VAR4, VAR3);
			if (VAR6)
				goto VAR27;
			VAR6 = -VAR23;
			VAR5 = VAR3->VAR10.VAR11->VAR12;
			if (!VAR5)
				break;
		} else
			FUN10(&VAR4, VAR3);
		VAR6 = -VAR28; 
		if (!VAR5->VAR25->VAR29)
			break;
		continue;
		

VAR20:
		VAR7 |= VAR14 | VAR30;
VAR19:
		
		VAR3->VAR8 &= VAR7 | ~VAR15;
		if (VAR7 & VAR31)
			goto VAR32;
		if (this.VAR1[0] == '') switch (this.VAR18) {
			default:
				break;
			case 2:	
				if (this.VAR1[1] != '')
					break;
				FUN6(VAR3);
				VAR5 = VAR3->VAR10.VAR11->VAR12;
				
			case 1:
				goto VAR9;
		}
		if (VAR3->VAR10.VAR11->VAR21 && VAR3->VAR10.VAR11->VAR21->VAR22) {
			VAR6 = VAR3->VAR10.VAR11->VAR21->FUN7(VAR3->VAR10.VAR11,
							    &this);
			if (VAR6 < 0)
				break;
		}
		VAR6 = FUN8(VAR3, &this, &VAR4);
		if (VAR6)
			break;
		VAR5 = VAR4.VAR11->VAR12;
		if (FUN11(VAR5, VAR7)) {
			VAR6 = FUN9(&VAR4, VAR3);
			if (VAR6)
				goto VAR27;
			VAR5 = VAR3->VAR10.VAR11->VAR12;
		} else
			FUN10(&VAR4, VAR3);
		VAR6 = -VAR23;
		if (!VAR5)
			break;
		if (VAR7 & VAR30) {
			VAR6 = -VAR28; 
			if (!VAR5->VAR25->VAR29)
				break;
		}
		goto VAR33;
VAR32:
		VAR3->VAR34 = this;
		VAR3->VAR35 = VAR36;
		if (this.VAR1[0] != '')
			goto VAR33;
		if (this.VAR18 == 1)
			VAR3->VAR35 = VAR37;
		else if (this.VAR18 == 2 && this.VAR1[1] == '')
			VAR3->VAR35 = VAR38;
		else
			goto VAR33;
VAR9:
		
		if (VAR3->VAR10.VAR11 && VAR3->VAR10.VAR11->VAR39 &&
		    (VAR3->VAR10.VAR11->VAR39->VAR40->VAR41 & VAR42)) {
			VAR6 = -VAR43;
			
			if (!VAR3->VAR10.VAR11->VAR21->FUN12(
					VAR3->VAR10.VAR11, VAR3))
				break;
		}
VAR33:
		return 0;
VAR24:
		FUN13(&VAR4, VAR3);
		break;
	}
	FUN14(&VAR3->VAR10);
VAR27:
	return VAR6;
}