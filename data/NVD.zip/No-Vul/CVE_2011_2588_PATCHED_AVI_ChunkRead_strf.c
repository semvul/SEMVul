static int FUN1( VAR1 *VAR2, VAR3 *VAR4 )  
{
    VAR3 *VAR5;

    VAR6;
    if( VAR4->VAR7.VAR8 == NULL )
    {
        FUN2( (VAR9*)VAR2, "" );
        FUN3( VAR10 );
    }
    if( !( VAR5 = FUN4( VAR4->VAR7.VAR8, VAR11, 0 ) ) )
    {
        FUN2( (VAR9*)VAR2, "" );
        FUN3( VAR10 );
    }

    switch( VAR5->VAR12.VAR13 )
    {
        case( VAR14 ):
            VAR4->VAR15.VAR16.VAR17 = VAR18;
            VAR4->VAR15.VAR16.VAR19 = malloc( FUN5( VAR4->VAR7.VAR20, sizeof( VAR21 ) ) );
            FUN6( VAR4->VAR15.VAR16.VAR19->VAR22 );
            FUN6( VAR4->VAR15.VAR16.VAR19->VAR23 );
            FUN7( VAR4->VAR15.VAR16.VAR19->VAR24 );
            FUN7( VAR4->VAR15.VAR16.VAR19->VAR25 );
            FUN6( VAR4->VAR15.VAR16.VAR19->VAR26 );
            FUN6( VAR4->VAR15.VAR16.VAR19->VAR27 );
            if( VAR4->VAR15.VAR16.VAR19->VAR22 != VAR28
                 && VAR4->VAR7.VAR20 > sizeof( VAR21 ) )
            {
                FUN6( VAR4->VAR15.VAR16.VAR19->VAR29 );
                
                if( VAR4->VAR15.VAR16.VAR19->VAR29 >
                        VAR4->VAR7.VAR20 - sizeof( VAR21 ) )
                {
                    VAR4->VAR15.VAR16.VAR19->VAR29 =
                        VAR4->VAR7.VAR20 - sizeof( VAR21 );
                }
                if( VAR4->VAR15.VAR16.VAR19->VAR22 == VAR30 )
                {
                    
                    FUN8( (VAR9*)VAR2, ""
                              "" );
                }
            }
            else
            {
                VAR4->VAR15.VAR16.VAR19->VAR29 = 0;
            }
            if( VAR4->VAR15.VAR16.VAR19->VAR29 > 0 )
            {
                memcpy( &VAR4->VAR15.VAR16.VAR19[1] ,
                        VAR31 + 8 + sizeof( VAR21 ),    
                        VAR4->VAR15.VAR16.VAR19->VAR29 );
            }
#ifdef VAR32
            FUN9( (VAR9*)VAR2,
                     "",
                     VAR4->VAR15.VAR16.VAR19->VAR22,
                     VAR4->VAR15.VAR16.VAR19->VAR23,
                     VAR4->VAR15.VAR16.VAR19->VAR24,
                     VAR4->VAR15.VAR16.VAR19->VAR27,
                     VAR4->VAR15.VAR16.VAR19->VAR25 * 8 / 1024 );
#endif
            break;
        case( VAR33 ):
            VAR5->VAR12.VAR34 = 0; 
            VAR4->VAR15.VAR35.VAR17 = VAR36;
            VAR4->VAR15.VAR35.VAR37 = malloc( FUN5( VAR4->VAR7.VAR20,
                                         sizeof( *VAR4->VAR15.VAR35.VAR37 ) ) );
            FUN7( VAR4->VAR15.VAR35.VAR37->VAR38 );
            FUN7( VAR4->VAR15.VAR35.VAR37->VAR39 );
            FUN7( VAR4->VAR15.VAR35.VAR37->VAR40 );
            FUN6( VAR4->VAR15.VAR35.VAR37->VAR41 );
            FUN6( VAR4->VAR15.VAR35.VAR37->VAR42 );
            FUN10( VAR4->VAR15.VAR35.VAR37->VAR43 );
            FUN7( VAR4->VAR15.VAR35.VAR37->VAR44 );
            FUN7( VAR4->VAR15.VAR35.VAR37->VAR45 );
            FUN7( VAR4->VAR15.VAR35.VAR37->VAR46 );
            FUN7( VAR4->VAR15.VAR35.VAR37->VAR47 );
            FUN7( VAR4->VAR15.VAR35.VAR37->VAR48 );
            if( VAR4->VAR15.VAR35.VAR37->VAR38 > VAR4->VAR7.VAR20 )
            {
                VAR4->VAR15.VAR35.VAR37->VAR38 = VAR4->VAR7.VAR20;
            }
            if( VAR4->VAR7.VAR20 > sizeof(VAR49) )
            {
                memcpy( &VAR4->VAR15.VAR35.VAR37[1],
                        VAR31 + 8 + sizeof(VAR49), 
                        VAR4->VAR7.VAR20 -sizeof(VAR49) );
            }
#ifdef VAR32
            FUN9( (VAR9*)VAR2,
                     ""VAR50""VAR50"",
                     (char*)&VAR4->VAR15.VAR35.VAR37->VAR43,
                     (VAR51)VAR4->VAR15.VAR35.VAR37->VAR39,
                     (VAR51)VAR4->VAR15.VAR35.VAR37->VAR40,
                     VAR4->VAR15.VAR35.VAR37->VAR41,
                     VAR4->VAR15.VAR35.VAR37->VAR42 );
#endif
            break;
        default:
            FUN8( (VAR9*)VAR2, "" );
            VAR4->VAR15.VAR7.VAR17 = VAR52;
            break;
    }
    FUN3( VAR53 );
}