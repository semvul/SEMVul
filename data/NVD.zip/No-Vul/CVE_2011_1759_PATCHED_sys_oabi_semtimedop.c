asmlinkage long FUN1(int VAR1, 				    struct oabi_sembuf VAR2 *VAR3, 				    unsigned VAR4, 				    const struct timespec VAR2 *VAR5)  
{
	struct VAR6 *VAR7;
	struct timespec VAR8;
	long VAR9;
	int VAR10;

	if (VAR4 < 1 || VAR4 > VAR11)
		return -VAR12;
	VAR7 = FUN2(sizeof(*VAR7) * VAR4, VAR13);
	if (!VAR7)
		return -VAR14;
	VAR9 = 0;
	for (VAR10 = 0; VAR10 < VAR4; VAR10++) {
		FUN3(VAR7[VAR10].VAR15, &VAR3->VAR15, VAR9);
		FUN3(VAR7[VAR10].VAR16,  &VAR3->VAR16,  VAR9);
		FUN3(VAR7[VAR10].VAR17, &VAR3->VAR17, VAR9);
		VAR3++;
	}
	if (VAR5) {
		
		VAR9 |= FUN4(&VAR8, VAR5, sizeof(*VAR5));
		VAR5 = &VAR8;
	}
	if (VAR9) {
		VAR9 = -VAR18;
	} else {
		mm_segment_t VAR19 = FUN5();
		FUN6(VAR20);
		VAR9 = FUN7(VAR1, VAR7, VAR4, VAR5);
		FUN6(VAR19);
	}
	FUN8(VAR7);
	return VAR9;
}