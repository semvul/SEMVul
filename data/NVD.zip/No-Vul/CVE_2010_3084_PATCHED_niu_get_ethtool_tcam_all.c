static int FUN1(struct VAR1 *VAR2, 				    struct VAR3 *VAR4, 				    VAR5 *VAR6)  
{
	struct VAR7 *VAR8 = VAR2->VAR8;
	struct VAR9 *VAR10;
	int VAR11, VAR12, VAR13;
	unsigned long VAR14;
	int VAR15 = 0;

	
	VAR4->VAR16 = FUN2(VAR2);

	FUN3(VAR2, VAR14);
	for (VAR13 = 0, VAR11 = 0; VAR11 < VAR4->VAR16; VAR11++) {
		VAR12 = FUN4(VAR2, VAR11);
		VAR10 = &VAR8->VAR17[VAR12];
		if (!VAR10->VAR18)
			continue;
		if (VAR13 == VAR4->VAR19) {
			VAR15 = -VAR20;
			break;
		}
		VAR6[VAR13] = VAR11;
		VAR13++;
	}
	FUN5(VAR2, VAR14);

	return VAR15;
}