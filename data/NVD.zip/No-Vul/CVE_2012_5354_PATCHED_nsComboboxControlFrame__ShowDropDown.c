void VAR1::FUN1(bool VAR2)   
{
  VAR3 = false;
  nsEventStates VAR4 = VAR5->FUN2()->FUN3();
  if (VAR4.FUN4(VAR6)) {
    return;
  }

  if (!VAR7 && VAR2) {
    if (VAR8 == this) {
      if (VAR9) {
        VAR9->FUN5();
      }
      FUN6(VAR2); 
    } else {
      
      VAR3 = true;
    }
  } else if (VAR7 && !VAR2) {
    FUN6(VAR2); 
  }
}