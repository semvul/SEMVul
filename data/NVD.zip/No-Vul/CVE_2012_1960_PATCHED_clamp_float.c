float FUN1(float VAR1)  
{
	

	if (VAR1 > 1.)
		return 1.;
	else if (VAR1 >= 0)
		return VAR1;
	else 
		return 0;
}