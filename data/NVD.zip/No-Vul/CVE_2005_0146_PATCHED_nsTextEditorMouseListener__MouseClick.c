nsresult VAR1::FUN1(VAR2* VAR3)  
{
  VAR4<VAR5> FUN2 ( FUN3(VAR3) );
  VAR4<VAR6> FUN4 ( FUN3(VAR3) );
  PRBool VAR7 = VAR8;
  if (!VAR9 || !VAR10 ||
      FUN5(VAR10->FUN6(&VAR7)) || !VAR7) {
    
    return VAR11;
  }

  VAR4<VAR12> VAR13 = FUN3(VAR14);
  if (!VAR13) { return VAR11; }

  
  
  VAR4<VAR15> VAR16 = FUN3(VAR14);
  if (VAR16)
    VAR16->FUN7();

  PRUint16 VAR17 = (VAR18)-1;
  VAR9->FUN8(&VAR17);
  
  if (VAR17 == 1)
  {
    nsresult VAR19;
    VAR4<VAR20> VAR21 =
      FUN9(VAR22, &VAR19);
    if (FUN10(VAR19) && VAR21)
    {
      PRBool VAR23 = VAR8;;
      VAR19 = VAR21->FUN11("", &VAR23);
      if (FUN10(VAR19) && VAR23)
      {
        
        VAR4<VAR24> FUN12 (FUN3(VAR3));
        if (!VAR25)
          return VAR26;
        VAR4<VAR27> VAR28;
        if (FUN5(VAR25->FUN13(FUN14(VAR28))))
          return VAR26;
        PRInt32 VAR29 = 0;
        if (FUN5(VAR25->FUN15(&VAR29)))
          return VAR26;

        VAR4<VAR30> VAR31;
        if (FUN10(VAR13->FUN16(FUN14(VAR31))))
          (void)VAR31->FUN17(VAR28, VAR29);

        
        
        PRBool VAR32 = VAR8;
        VAR9->FUN18(&VAR32);

        VAR4<VAR33> VAR34;
        if (VAR32)
          VAR34 = FUN3(VAR14);

        PRInt32 VAR35;

#if FUN19(VAR36) || FUN19(VAR37)
        VAR35 = VAR38::VAR39;
#else
        VAR35 = VAR38::VAR40;
#endif

        if (VAR34)
          VAR34->FUN20(VAR35);
        else
          VAR13->FUN21(VAR35);

        
        
        VAR4<VAR6> FUN22(FUN3(VAR9));

        if (VAR41) {
          VAR41->FUN23();
        }

        VAR9->FUN24();

        
        return VAR11;
      }
    }
  }
  return VAR11;
}