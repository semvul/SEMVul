int FUN1(VAR1 *VAR2, unsigned char **VAR3, unsigned char *VAR4, int VAR5, int *VAR6) 	 
{
	unsigned short VAR7;
	unsigned short VAR8;
	unsigned short VAR9;
	unsigned char *VAR10 = *VAR3;
	int VAR11 = 0;

	VAR2->VAR12 = 0;
	VAR2->VAR13 = -1;

	if (VAR10 >= (VAR4+VAR5-2))
		goto VAR14;
	FUN2(VAR10,VAR9);

	if (VAR10 > (VAR4+VAR5-VAR9)) 
		goto VAR14;

	while (VAR10 <= (VAR4+VAR5-4))
		{
		FUN2(VAR10,VAR7);
		FUN2(VAR10,VAR8);

		if (VAR10+VAR8 > (VAR4+VAR5))
	   		goto VAR14;
#if 0
		fprintf(VAR15,"",VAR7,VAR8);
#endif
		if (VAR2->VAR16)
			VAR2->FUN3(VAR2, 0, VAR7, VAR10, VAR8,
						VAR2->VAR17);
      

		if (VAR7 == VAR18)
			{
			unsigned char *VAR19;
			int VAR20;
			int VAR21; 
		
			if (VAR8 < 2) 
				{
				*VAR6 = VAR22;
				return 0;
				}
			FUN2(VAR10,VAR21);  
			VAR8 -= 2;
			if (VAR21 > VAR8  ) 
				{
				*VAR6 = VAR22;
				return 0;
				} 

			VAR19 = VAR10;
			while (VAR21 > 3) 
				{
	 			VAR20 = *(VAR19++); 
				FUN2(VAR19,VAR9);
				VAR21 -= 3;

				if (VAR9 > VAR21) 
					{
					*VAR6 = VAR22;
					return 0;
					}
				if (VAR2->VAR12 == 0)
				switch (VAR20)
					{
				case VAR23:
					if (VAR2->VAR24->VAR25 == NULL)
						{
						if (VAR9 > VAR26 || 
							((VAR2->VAR24->VAR25 = FUN4(VAR9+1)) == NULL))
							{
							*VAR6 = VAR27;
							return 0;
							}
						memcpy(VAR2->VAR24->VAR25, VAR19, VAR9);
						VAR2->VAR24->VAR25[VAR9]='';
						if (strlen(VAR2->VAR24->VAR25) != VAR9) {
							FUN5(VAR2->VAR24->VAR25);
							VAR2->VAR24->VAR25 = NULL;
							*VAR6 = VAR27;
							return 0;
						}
						VAR2->VAR12 = 1; 

						}
					else 
						VAR2->VAR12 = strlen(VAR2->VAR24->VAR25) == VAR9 
							&& FUN6(VAR2->VAR24->VAR25, (char *)VAR19, VAR9) == 0;
					
					break;

				default:
					break;
					}
				 
				VAR21 -= VAR9;
				}
			if (VAR21 != 0) 
				{
				*VAR6 = VAR22;
				return 0;
				}

			}

#ifndef VAR28
		else if (VAR7 == VAR29 &&
	             VAR2->VAR30 != VAR31)
			{
			unsigned char *VAR19 = VAR10;
			int VAR32 = *(VAR19++);

			if (VAR32 != VAR8 - 1)
				{
				*VAR6 = VAR33;
				return 0;
				}
			VAR2->VAR24->VAR34 = 0;
			if (VAR2->VAR24->VAR35 != NULL) FUN5(VAR2->VAR24->VAR35);
			if ((VAR2->VAR24->VAR35 = FUN4(VAR32)) == NULL)
				{
				*VAR6 = VAR36;
				return 0;
				}
			VAR2->VAR24->VAR34 = VAR32;
			memcpy(VAR2->VAR24->VAR35, VAR19, VAR32);
#if 0
			fprintf(VAR15,"", VAR2->VAR24->VAR34);
			VAR19 = VAR2->VAR24->VAR35;
			for (VAR37 = 0; VAR37 < VAR2->VAR24->VAR34; VAR37++)
				fprintf(VAR15,"",*(VAR19++));
			fprintf(VAR15,"");
#endif
			}
		else if (VAR7 == VAR38 &&
	             VAR2->VAR30 != VAR31)
			{
			unsigned char *VAR19 = VAR10;
			int VAR39 = (*(VAR19++) << 8);
			VAR39 += (*(VAR19++));

			if (VAR39 != VAR8 - 2)
				{
				*VAR6 = VAR33;
				return 0;
				}
			VAR2->VAR24->VAR40 = 0;
			if (VAR2->VAR24->VAR41 != NULL) FUN5(VAR2->VAR24->VAR41);
			if ((VAR2->VAR24->VAR41 = FUN4(VAR39)) == NULL)
				{
				*VAR6 = VAR36;
				return 0;
				}
			VAR2->VAR24->VAR40 = VAR39;
			memcpy(VAR2->VAR24->VAR41, VAR19, VAR39);
#if 0
			fprintf(VAR15,"", VAR2->VAR24->VAR40);
			VAR19 = VAR2->VAR24->VAR41;
			for (VAR37 = 0; VAR37 < VAR2->VAR24->VAR40; VAR37++)
				fprintf(VAR15,"",*(VAR19++));
			fprintf(VAR15,"");
#endif
			}
#endif 
#ifdef VAR42
		else if (VAR7 == VAR42 &&
	             VAR2->VAR30 != VAR31)
			{
			unsigned char *VAR19 = VAR10;

			if (VAR8 < 2)
				{
				*VAR6 = VAR22;
				return 0;
				}
			FUN2(VAR19, VAR2->VAR43->VAR44);
			if (VAR2->VAR43->VAR44 != VAR8 - 2)
				{
				*VAR6 = VAR22;
				return 0;
				}

			if (VAR2->VAR43->VAR45 != NULL) 
				FUN5(VAR2->VAR43->VAR45);
			if (VAR2->VAR43->VAR44 == 0)
				VAR2->VAR43->VAR45 = FUN4(1); 
			else
				VAR2->VAR43->VAR45 = FUN7(VAR19, VAR2->VAR43->VAR44);
			if (VAR2->VAR43->VAR45 == NULL)
				{
				*VAR6 = VAR36;
				return 0;
				}
			}
#endif
		else if (VAR7 == VAR46)
			{
			if (VAR2->VAR47 &&
			    !VAR2->FUN8(VAR2, VAR10, VAR8, VAR2->VAR48))
				{
				*VAR6 = VAR36;
				return 0;
				}
			}
		else if (VAR7 == VAR49)
			{
			if(!FUN9(VAR2, VAR10, VAR8, VAR6))
				return 0;
			VAR11 = 1;
			}
		else if (VAR7 == VAR50 &&
		         VAR2->VAR30 != VAR31 && VAR2->VAR51->VAR52)
			{
		
			if (VAR8 < 5) 
				{
				*VAR6 = VAR22;
				return 0;
				}

			VAR2->VAR13 = *VAR10++;
			VAR8--;
			if (VAR2->VAR13 == VAR53)
				{
				const unsigned char *VAR19;
				int VAR21;
				
				FUN2(VAR10,VAR21);
				VAR8 -= 2;
				if (VAR21 > VAR8  ) 
					{
					*VAR6 = VAR22;
					return 0;
					}
				while (VAR21 > 0)
					{
					VAR54 *VAR55;
					int VAR56;
					if (VAR21 < 4)
						{
						*VAR6 = VAR22;
						return 0;
						}
					FUN2(VAR10, VAR56);
					VAR21 -= 2 + VAR56;
					VAR8 -= 2 + VAR56;
					if (VAR21 < 0)
						{
						*VAR6 = VAR22;
						return 0;
						}
					VAR19 = VAR10;
					VAR10 += VAR56;
					VAR55 = FUN10(NULL,
								&VAR19, VAR56);
					if (!VAR55)
						{
						*VAR6 = VAR22;
						return 0;
						}
					if (VAR10 != VAR19)
						{
						FUN11(VAR55);
						*VAR6 = VAR22;
						return 0;
						}
					if (!VAR2->VAR57
						&& !(VAR2->VAR57 =
						FUN12()))
						{
						FUN11(VAR55);
						*VAR6 = VAR58;
						return 0;
						}
					if (!FUN13(
							VAR2->VAR57, VAR55))
						{
						FUN11(VAR55);
						*VAR6 = VAR58;
						return 0;
						}
					}

				
				if (VAR8 < 2)
					{
					*VAR6 = VAR22;
					return 0;
					}
				FUN2(VAR10,VAR21);
				VAR8 -= 2;
				if (VAR21 != VAR8)
					{
					*VAR6 = VAR22;
					return 0;
					}
				VAR19 = VAR10;
				if (VAR21 > 0)
					{
					VAR2->VAR59 =
						FUN14(NULL,
							&VAR19, VAR21);
					if (!VAR2->VAR59
						|| (VAR10 + VAR21 != VAR19))
						{
						*VAR6 = VAR22;
						return 0;
						}
					}
				}
				
				else
					VAR2->VAR13 = -1;
			}

		
		VAR10+=VAR8;
		}
				
	*VAR3 = VAR10;

	VAR14:

	

	if (!VAR11 && VAR2->VAR60 &&
		!(VAR2->VAR61 & VAR62))
		{
		*VAR6 = VAR63;
	 	FUN15(VAR64,
				VAR65);
		return 0;
		}

	return 1;
	}