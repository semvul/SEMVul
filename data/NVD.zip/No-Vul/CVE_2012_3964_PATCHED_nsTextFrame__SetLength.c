void VAR1::FUN1(PRInt32 VAR2, VAR3* VAR4,                        PRUint32 VAR5)  
{
  VAR6 = VAR2;
  PRInt32 VAR7 = FUN2() + VAR2;
  VAR8* VAR9 = static_cast<VAR8*>(FUN3());
  if (!VAR9)
    return;

  
  
  
  
  
  
  
  if (VAR4 &&
      (VAR7 != VAR9->VAR10 || (VAR9->FUN4() & VAR11))) {
    VAR4->FUN5();
  }

  if (VAR7 < VAR9->VAR10) {
    
    if (VAR4 &&
        FUN6()->FUN7() &&
        FUN8() &&
        FUN9()->FUN10() != VAR12::VAR13 &&
        (VAR5 & VAR14)) {
      
      
      
      
      
      
      
      
      
      
      VAR15* VAR16 = FUN11();
      VAR17* VAR18;
      nsresult VAR19 = VAR16->FUN12()->FUN13()->
        FUN14(VAR16, this, FUN9(), &VAR18);
      if (FUN15(VAR19)) {
        VAR8* VAR20 = static_cast<VAR8*>(VAR18);
        VAR21 FUN16(VAR20, VAR20);
        FUN9()->FUN17(VAR22, this, VAR23);
        VAR9 = VAR20;
      }
    }

    VAR9->VAR10 = VAR7;
    if (VAR9->FUN18(VAR8::VAR24) != VAR25) {
      FUN19();
      VAR9->FUN19();
    }
    return;
  }
  
  
  
  
  

  
  
  VAR8* VAR26 = VAR27;
  while (VAR9 && VAR9->VAR10 < VAR7) {
    VAR9->VAR10 = VAR7;
    if (VAR9->FUN18(VAR8::VAR24) != VAR25) {
      FUN19();
      VAR9->FUN19();
    }
    VAR8* VAR20 = static_cast<VAR8*>(VAR9->FUN3());
    
    
    
    
    if (VAR20 && VAR20->VAR10 <= VAR7 && VAR9->FUN20() == VAR20 &&
        (VAR5 & VAR14)) {
      
      
      
      
      
      
      if (!VAR26) {
        
        VAR26 = VAR9;
      }

      
      
      
      if (VAR9->FUN21() == VAR9->FUN22()->FUN21()) {
        VAR9->FUN23(VAR28);
      }
    } else if (VAR26) {
      FUN24(VAR26, VAR9);
      VAR26 = VAR27;
    }
    VAR9 = VAR20;
  }
  FUN25(!VAR26 || (VAR9 && VAR9->VAR10 == VAR7),
                   ""
                   "");
  if (VAR26) {
    
    
    FUN24(VAR26, VAR9);
  }

#ifdef VAR29
  VAR9 = this;
  PRInt32 VAR30 = 0;
  while (VAR9 && VAR30 < 10) {
    VAR9->FUN26(); 
    VAR9 = static_cast<VAR8*>(VAR9->FUN27());
    ++VAR30;
  }
  VAR9 = this;
  VAR30 = 0;
  while (VAR9 && VAR30 < 10) {
    VAR9->FUN26(); 
    VAR9 = static_cast<VAR8*>(VAR9->FUN22());
    ++VAR30;
  }
#endif
}