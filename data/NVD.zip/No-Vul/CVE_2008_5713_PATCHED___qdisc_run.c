void FUN1(struct VAR1 *VAR2)  
{
	unsigned long VAR3 = VAR4;

	while (FUN2(VAR2)) {
		if (FUN3(VAR2))
			break;

		
		if (FUN4() || VAR4 != VAR3) {
			FUN5(VAR2);
			break;
		}
	}

	FUN6(VAR5, &VAR2->VAR6);
}