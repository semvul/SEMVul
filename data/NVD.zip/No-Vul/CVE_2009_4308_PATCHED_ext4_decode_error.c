static const char *FUN1(struct VAR1 *VAR2, int VAR3, 				     char VAR4[16])  
{
	char *VAR5 = NULL;

	switch (VAR3) {
	case -VAR6:
		VAR5 = "";
		break;
	case -VAR7:
		VAR5 = "";
		break;
	case -VAR8:
		if (!VAR2 || (FUN2(VAR2)->VAR9 &&
			    FUN2(VAR2)->VAR9->VAR10 & VAR11))
			VAR5 = "";
		else
			VAR5 = "";
		break;
	default:
		
		if (VAR4) {
			
			if (snprintf(VAR4, 16, "", -VAR3) >= 0)
				VAR5 = VAR4;
		}
		break;
	}

	return VAR5;
}