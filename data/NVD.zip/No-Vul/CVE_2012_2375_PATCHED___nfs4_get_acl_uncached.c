static VAR1 FUN1(struct VAR2 *VAR2, void *VAR3, size_t VAR4)  
{
	struct VAR5 *VAR6[VAR7] = {NULL, };
	struct nfs_getaclargs VAR8 = {
		.VAR9 = FUN2(VAR2),
		.VAR10 = VAR6,
		.VAR11 = VAR4,
	};
	struct nfs_getaclres VAR12 = {
		.VAR11 = VAR4,
	};
	void *VAR13;
	struct rpc_message VAR14 = {
		.VAR15 = &VAR16[VAR17],
		.VAR18 = &VAR8,
		.VAR19 = &VAR12,
	};
	int VAR20 = -VAR21, VAR22, VAR23, VAR11 = 0;

	VAR22 = (VAR4 + VAR24 - 1) >> VAR25;
	
	if (VAR22 == 0)
		VAR22 = 1;

	for (VAR23 = 0; VAR23 < VAR22; VAR23++) {
		VAR6[VAR23] = FUN3(VAR26);
		if (!VAR6[VAR23])
			goto VAR27;
	}
	if (VAR22 > 1) {
		
		VAR12.VAR28 = FUN3(VAR26);
		if (!VAR12.VAR28)
			goto VAR27;
	}
	VAR8.VAR11 = VAR22 * VAR24;
	VAR8.VAR29 = 0;
	
	if (VAR3 == NULL)
		VAR12.VAR30 |= VAR31;
	VAR13 = FUN4(VAR6[0]);

	FUN5("",
		VAR32, VAR3, VAR4, VAR22, VAR8.VAR11);
	VAR20 = FUN6(FUN7(VAR2)->VAR33, FUN7(VAR2),
			     &VAR14, &VAR8.VAR34, &VAR12.VAR35, 0);
	if (VAR20)
		goto VAR27;

	VAR11 = VAR12.VAR11 - VAR12.VAR36;
	if (VAR11 > VAR8.VAR11)
		FUN8(VAR2, NULL, VAR11);
	else
		FUN8(VAR2, VAR13 + VAR12.VAR36,
				      VAR11);
	if (VAR3) {
		VAR20 = -VAR37;
		if (VAR11 > VAR4)
			goto VAR27;
		FUN9(VAR3, VAR6, VAR12.VAR36,
				VAR11);
	}
	VAR20 = VAR11;
VAR27:
	for (VAR23 = 0; VAR23 < VAR22; VAR23++)
		if (VAR6[VAR23])
			FUN10(VAR6[VAR23]);
	if (VAR12.VAR28)
		FUN10(VAR12.VAR28);
	return VAR20;
}