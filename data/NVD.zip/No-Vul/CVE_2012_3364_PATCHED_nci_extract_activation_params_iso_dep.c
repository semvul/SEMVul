static int FUN1(struct VAR1 *VAR2, 			struct VAR3 *VAR4, VAR5 *VAR6)  
{
	struct VAR7 *VAR8;
	struct VAR9 *VAR10;

	switch (VAR4->VAR11) {
	case VAR12:
		VAR8 = &VAR4->VAR13.VAR14;
		VAR8->VAR15 = FUN2(VAR5, *VAR6++, 20);
		FUN3("", VAR8->VAR15);
		if (VAR8->VAR15 > 0) {
			memcpy(VAR8->VAR16,
			       VAR6, VAR8->VAR15);
		}
		break;

	case VAR17:
		VAR10 = &VAR4->VAR13.VAR18;
		VAR10->VAR19 = FUN2(VAR5, *VAR6++, 50);
		FUN3("", VAR10->VAR19);
		if (VAR10->VAR19 > 0) {
			memcpy(VAR10->VAR20,
			       VAR6, VAR10->VAR19);
		}
		break;

	default:
		FUN4("",
		       VAR4->VAR11);
		return VAR21;
	}

	return VAR22;
}