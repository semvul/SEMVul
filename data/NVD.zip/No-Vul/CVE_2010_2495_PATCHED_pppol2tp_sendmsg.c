static int FUN1(struct VAR1 *VAR2, struct socket *VAR3, struct VAR4 *VAR5, 			    size_t VAR6)  
{
	static const unsigned char VAR7[2] = { 0xff, 0x03 };
	struct VAR3 *VAR8 = VAR3->VAR8;
	struct VAR9 *VAR10;
	__wsum VAR11;
	struct VAR12 *VAR13;
	int VAR14;
	int VAR15;
	struct VAR16 *VAR17;
	struct VAR18 *VAR19;
	struct VAR20 *VAR21;
	unsigned int VAR22;
	struct VAR3 *VAR23;
	u16 VAR24;

	VAR14 = -VAR25;
	if (FUN2(VAR8, VAR26) || !(VAR8->VAR27 & VAR28))
		goto VAR14;

	
	VAR14 = -VAR29;
	VAR17 = FUN3(VAR8);
	if (VAR17 == NULL)
		goto VAR14;

	VAR23 = VAR17->VAR30;
	VAR19 = FUN4(VAR23);
	if (VAR19 == NULL)
		goto VAR31;

	
	VAR15 = FUN5(VAR17);

	
	VAR14 = -VAR32;
	VAR13 = FUN6(VAR8, VAR33 + sizeof(struct VAR34) +
			   sizeof(struct VAR20) + VAR15 +
			   sizeof(VAR7) + VAR6,
			   0, VAR35);
	if (!VAR13)
		goto VAR36;

	
	FUN7(VAR13, VAR33);
	FUN8(VAR13);
	FUN7(VAR13, sizeof(struct VAR34));
	FUN9(VAR13);

	
	VAR10 = FUN10(VAR23);
	VAR24 = VAR15 + sizeof(VAR7) + VAR6;
	VAR21 = (struct VAR20 *) VAR13->VAR37;
	VAR21->VAR38 = VAR10->VAR39;
	VAR21->VAR40 = VAR10->VAR41;
	VAR21->VAR22 = FUN11(VAR24);
	VAR21->VAR42 = 0;
	FUN12(VAR13, sizeof(struct VAR20));

	
	FUN13(VAR17, VAR13->VAR37);
	FUN12(VAR13, VAR15);

	
	VAR13->VAR37[0] = VAR7[0];
	VAR13->VAR37[1] = VAR7[1];
	FUN12(VAR13, 2);

	
	VAR14 = FUN14(VAR13->VAR37, VAR5->VAR43, VAR6);
	if (VAR14 < 0) {
		FUN15(VAR13);
		goto VAR36;
	}
	FUN12(VAR13, VAR6);

	
	if (VAR23->VAR44 == VAR45)
		VAR13->VAR46 = VAR47;
	else if ((FUN16(VAR13) && FUN16(VAR13)->VAR48) &&
		 (!(FUN16(VAR13)->VAR48->VAR49 & VAR50))) {
		VAR13->VAR46 = VAR51;
		VAR11 = FUN17(VAR13, 0, VAR24, 0);
		VAR21->VAR42 = FUN18(VAR10->VAR52,
					      VAR10->VAR53,
					      VAR24, VAR54, VAR11);
		if (VAR21->VAR42 == 0)
			VAR21->VAR42 = VAR55;
	} else {
		VAR13->VAR46 = VAR56;
		VAR13->VAR57 = FUN19(VAR13) - VAR13->VAR58;
		VAR13->VAR59 = FUN20(struct VAR20, VAR42);
		VAR21->VAR42 = ~FUN18(VAR10->VAR52,
					       VAR10->VAR53,
					       VAR24, VAR54, 0);
	}

	
	if (VAR17->VAR60)
		FUN21(VAR17->VAR61, VAR62, VAR63,
		       "", VAR17->VAR64,
		       VAR6, VAR17->VAR65 - 1);
	else
		FUN21(VAR17->VAR61, VAR62, VAR63,
		       "", VAR17->VAR64, VAR6);

	if (VAR17->VAR61 & VAR62) {
		int VAR66;
		unsigned char *VAR67 = VAR13->VAR37;

		FUN22(VAR63 "", VAR17->VAR64);
		for (VAR66 = 0; VAR66 < VAR6; VAR66++) {
			FUN22("", *VAR67++);
			if (VAR66 == 15) {
				FUN22("");
				break;
			}
		}
		FUN22("");
	}

	
	VAR22 = VAR13->VAR22;
	VAR14 = FUN23(VAR13, 1);

	
	if (VAR14 >= 0) {
		VAR19->VAR68.VAR69++;
		VAR19->VAR68.VAR70 += VAR22;
		VAR17->VAR68.VAR69++;
		VAR17->VAR68.VAR70 += VAR22;
	} else {
		VAR19->VAR68.VAR71++;
		VAR17->VAR68.VAR71++;
	}

	return VAR14;

VAR36:
	FUN24(VAR17->VAR30);
VAR31:
	FUN24(VAR8);
VAR14:
	return VAR14;
}