static void FUN1 (VAR1 * VAR2, VAR3 * VAR4,         VAR5 * VAR6, gboolean VAR7, gint VAR8,         gboolean VAR9, gboolean VAR10,         gboolean VAR11)  
{
  guint16 VAR12, VAR13, VAR14, VAR15, VAR16;
  guint16 VAR17;
  guint32 VAR18, VAR19;
  gboolean VAR20;
  const VAR21 *VAR22 = NULL;
  const VAR21 *VAR23 = NULL;
  const VAR21 *VAR24 = NULL;
  VAR25 *VAR26 = NULL;
  VAR25 *VAR27 = NULL;
  VAR25 *VAR28 = NULL;
  VAR25 *VAR29;
  VAR5 *volatile VAR30 = NULL;
  VAR5 *VAR31 = NULL;
  VAR5 *VAR32 = NULL;
  guint16 VAR33, VAR34, VAR35 = 0;
  gboolean VAR36, VAR37, VAR38;
  gint VAR39, VAR40, VAR41;
  gboolean VAR42 = 0;
  gboolean VAR43;
  VAR1 *volatile VAR44 = NULL;
  guint32 VAR45;
  volatile encap_t VAR46;
  guint8 VAR47, VAR48;
  char VAR49[VAR50];
  gint VAR51;
  guchar VAR52[4];
  const char *VAR53 = NULL;
  int VAR54 = -1;
  guint VAR55;
  const VAR56 *VAR57;
  gchar VAR58[] = "";
  gint VAR59;

  VAR60 *volatile VAR61;
  static wlan_hdr VAR62[4];
  gboolean VAR63;

  VAR61= &VAR62[0];

  FUN2 (VAR4->VAR64, VAR65, "");
  FUN3(VAR4->VAR64, VAR66);

  VAR12 = FUN4(0);
  VAR14 = FUN5(VAR12);
  if (VAR14 == VAR67)
    VAR15 = FUN4(10);
  else
    VAR15 = 0;

  if (VAR7)
    VAR33 = VAR68;
  else
    VAR33 = FUN6 (VAR12, VAR15, VAR11);
  VAR34 = VAR33;
  if (VAR10)
    VAR33 = FUN7(VAR33, 4);

  VAR57 = FUN8(VAR14, VAR69,
              "");
  FUN2 (VAR4->VAR64, VAR66, VAR57);


  VAR13 = FUN9 (VAR12);
  VAR20 = FUN10 (VAR13);

  for (VAR59 = 0; VAR59 < 8; VAR59++) {
    if (! (VAR13 & 0x80 >> VAR59)) {
      VAR58[VAR59] = '';
    }
  }

  if (VAR11 && FUN11(VAR13) &&
    ((FUN12(VAR12) == VAR70) || (FUN12(VAR12) == VAR71 &&
      FUN13(VAR14)))) {
    VAR35 = 4;
  }

  
  if (VAR6)
    {
      VAR26 = FUN14 (VAR6, VAR72, VAR2, 0, VAR33,
          "", VAR57);
      VAR30 = FUN15 (VAR26, VAR73);

      FUN16(VAR30, VAR2, VAR9, 0);

      if (VAR14 == VAR74)
        FUN17(VAR30, VAR75, VAR2, 2, 2, VAR76);

      else
        FUN17 (VAR30, VAR77, VAR2, 2, 2,
            FUN18 (VAR2, 2));
    }

  
  VAR17 = 0;
  VAR19 = 0;
  VAR18 = 0;

  switch (FUN12 (VAR12))
  {

    case VAR70:
      
      VAR22 = FUN19 (VAR2, 10, 6);
      VAR23 = FUN19 (VAR2, 4, 6);

      FUN20(&VAR4->VAR78, VAR79, 6, VAR22);
      FUN20(&VAR4->VAR22, VAR79, 6, VAR22);
      FUN20(&VAR4->VAR80, VAR79, 6, VAR23);
      FUN20(&VAR4->VAR23, VAR79, 6, VAR23);

      
      FUN20(&VAR61->VAR24, VAR79, 6, FUN19(VAR2, 16,6));
      FUN20(&VAR61->VAR22, VAR79, 6, VAR22);
      FUN20(&VAR61->VAR23, VAR79, 6, VAR23);
      VAR61->VAR81 = VAR14;

      VAR17 = FUN18(VAR2, 22);
      VAR19 = FUN21(VAR17);
      VAR18 = FUN22(VAR17);

      FUN23(VAR4->VAR64, VAR66,
            "", VAR18);

      FUN23(VAR4->VAR64, VAR66,
            "",VAR19);

      if (VAR6)
      {
        FUN24 (VAR30, VAR82, VAR2, 4, 6, VAR23);

        FUN24 (VAR30, VAR83, VAR2, 10, 6, VAR22);

        
        VAR29 = FUN24 (VAR30, VAR84, VAR2, 4, 6, VAR23);
        FUN25(VAR29);
        VAR29 = FUN24 (VAR30, VAR84, VAR2, 10, 6, VAR22);
        FUN25(VAR29);

        FUN26 (VAR30, VAR85, VAR2, 16, 6, VAR86);

        FUN17 (VAR30, VAR87, VAR2, 22, 2,
            VAR19);

        FUN17 (VAR30, VAR88, VAR2, 22, 2,
            VAR18);
      }
      break;

    case VAR89:
    {
      
      if (VAR14 == VAR67) {
        VAR55 = 10; 
        VAR15 = FUN4(10);
        VAR16 = FUN5(VAR15);
      } else {
        VAR55 = 10; 
        VAR15 = VAR12;
        VAR16 = VAR14;
      }

      switch (VAR16)
      {
        case VAR74:
          VAR53 = "";
          VAR54 = VAR85;
          break;
        case VAR90:
        case VAR91:
        case VAR92:
        case VAR93:
        case VAR94:
        case VAR95:
        case VAR96:
          VAR53 = "";
          VAR54 = VAR97;
          break;
        default:
          break;
      }

      if (!VAR53) 
        break;

      
      VAR23 = FUN19(VAR2, 4, 6);
      FUN27(VAR4, VAR23, VAR53);
      if (VAR6) {
        FUN26(VAR30, VAR54, VAR2, 4, 6, VAR98);
      }

      
      if (VAR14 == VAR67 && VAR6) {
        VAR28 = FUN28(VAR30, VAR2, VAR55, 2,
          "");
        VAR32 = FUN15 (VAR28, VAR99);
        FUN16(VAR32, VAR2, VAR98, VAR55);
        FUN29(VAR30, VAR2, VAR55 + 2);
        VAR55+=6;
        VAR28 = FUN28(VAR30, VAR2, VAR55, 2,
          "");
        VAR30 = FUN15 (VAR28, VAR99);
      }

      switch (VAR16)
      {
        case VAR74:
        case VAR93:
        case VAR94:
        {
          VAR22 = FUN19 (VAR2, VAR55, 6);
          FUN30(VAR4, VAR22, "");
          if (VAR6) {
            FUN26(VAR30, VAR100, VAR2, VAR55, 6, VAR98);
          }
          break;
        }

        case VAR90:
        {
          VAR22 = FUN19 (VAR2, VAR55, 6);
          FUN30(VAR4, VAR22, "");
          if (VAR6) {
            FUN26(VAR30, VAR100, VAR2, VAR55, 6, VAR98);
          }
          break;
        }

        case VAR67:
        {
          
          break;
        }

        case VAR95:
        {
          VAR22 = FUN19 (VAR2, VAR55, 6);
          FUN30(VAR4, VAR22, "");

          if (VAR6)
          {
            guint16 VAR101;
            guint8 VAR102;
            VAR25 *VAR103;
            VAR5 *VAR104;

            FUN26(VAR30, VAR100, VAR2, VAR55, 6, VAR98);
            VAR55 += 6;

            VAR101 = FUN18(VAR2, VAR55);
            VAR102 = (VAR101 & 0x0006) >> 1;
            FUN17(VAR30, VAR105, VAR2,
              VAR55, 1, VAR102);
            VAR103 = FUN31(VAR30,
              VAR106, VAR2, VAR55, 2, VAR101,
              "", VAR101);
            VAR104 = FUN15(VAR103,
              VAR107);
            FUN32(VAR104,
              VAR108, VAR2, VAR55, 1, VAR101);
            FUN32(VAR104, VAR109,
              VAR2, VAR55, 1, VAR101);
            FUN32(VAR104,
              VAR110, VAR2, VAR55, 1,
              VAR101);
            FUN17(VAR104, VAR111,
              VAR2, VAR55, 2, VAR101);

            switch (VAR102)
            {
              case 0: 
              {
                FUN17(VAR104,
                VAR112, VAR2, VAR55+1, 1,
                  VAR101);
                VAR55 += 2;

                VAR55 += FUN33(VAR30, VAR2, VAR55,
                  VAR113);
                break;
              }
              case 2: 
              {
                FUN17(VAR104,
                VAR114, VAR2, VAR55+1, 1,
                  VAR101);
                VAR55 += 2;

                VAR55 += FUN33(VAR30, VAR2, VAR55,
                  VAR113);
                break;
              }
              case 3: 
              {
                guint8 VAR115, VAR116;
                VAR5 *VAR117, *VAR118;

                VAR115 = ((VAR101 & 0xF000) >> 12) + 1;
                FUN31(VAR104, VAR119, VAR2, VAR55+1, 1, VAR101,
                FUN34(VAR101, 0xF000, 16,""), VAR115);
                VAR55 += 2;

                VAR103 = FUN28 (VAR30, VAR2, VAR55, VAR115*4, "");
                VAR117 = FUN15(VAR103, VAR107);
                for (VAR116 = 1; VAR116 <= VAR115; VAR116++) {
                  VAR103 = FUN17(VAR117, VAR120, VAR2, VAR55, 4, VAR116);
                  VAR118 = FUN15(VAR103, VAR107);

                  VAR101 = FUN18(VAR2, VAR55);
                  FUN17(VAR118, VAR121, VAR2, VAR55, 2, VAR101);
                  FUN17(VAR118, VAR122, VAR2, VAR55+1, 1, VAR101);
                  VAR55 += 2;

                  VAR55 += FUN33(VAR118, VAR2, VAR55, VAR113);
                }
                break;
              }
            }
          }
          break;
        }

        case VAR96:
        {
          VAR22 = FUN19 (VAR2, VAR55, 6);
          FUN30(VAR4, VAR22, "");

          if (VAR6)
          {
            guint16 VAR123;
            guint8 VAR102;
            VAR25 *VAR124;
            VAR5 *VAR125;

            FUN26(VAR30, VAR100, VAR2, VAR55, 6, VAR98);
            VAR55 += 6;

            VAR123 = FUN18(VAR2, VAR55);
            VAR102 = (VAR123 & 0x0006) >> 1;
            FUN17(VAR30, VAR126, VAR2, VAR55, 1, VAR102);
            VAR124 = FUN31(VAR30,
              VAR127, VAR2, VAR55, 2, VAR123,
              "", VAR123);
            VAR125 = FUN15(VAR124, VAR107);
            FUN32(VAR125, VAR108,
              VAR2, VAR55, 1, VAR123);
            FUN32(VAR125, VAR109,
              VAR2, VAR55, 1, VAR123);
            FUN32(VAR125,
              VAR110, VAR2, VAR55, 1,
              VAR123);
            FUN17(VAR125, VAR111, VAR2,
              VAR55, 2, VAR123);

            switch (VAR102)
            {
              case 0: 
              {
                FUN17(VAR125,
                VAR112, VAR2, VAR55+1, 1,
                  VAR123);
                VAR55 += 2;

                VAR55 += FUN33(VAR30, VAR2, VAR55, VAR113);
                FUN26(VAR30, VAR128, VAR2, VAR55, 128, VAR98);
                VAR55 += 128;
                break;
              }
              case 2: 
              {
                FUN17(VAR125, VAR112, VAR2, VAR55+1, 1, VAR123);
                VAR55 += 2;

                VAR55 += FUN33(VAR30, VAR2, VAR55, VAR113);
                FUN26(VAR30, VAR128, VAR2, VAR55, 8, VAR98);
                VAR55 += 8;
                break;
              }
              case 3:  
              {
                guint8 VAR115, VAR116;
                VAR5 *VAR129, *VAR130;

                VAR115 = ((VAR123 & 0xF000) >> 12) + 1;
                FUN31(VAR125,
                VAR114, VAR2, VAR55+1, 1,
                  VAR123, FUN34(VAR123, 0xF000,
                  16,""), VAR115);
                VAR55 += 2;

                VAR124 = FUN28 (VAR30, VAR2, VAR55, VAR115*4, "");
                VAR129 = FUN15(VAR124, VAR107);
                for (VAR116=1; VAR116<=VAR115; VAR116++) {
                  VAR124 = FUN17(VAR129, VAR120, VAR2, VAR55, 4, VAR116);
                  VAR130 = FUN15(VAR124, VAR107);

                  VAR123 = FUN18(VAR2, VAR55);
                  FUN17(VAR130, VAR121, VAR2, VAR55, 2, VAR123);
                  FUN17(VAR130, VAR122, VAR2, VAR55+1, 1, VAR123);
                  VAR55 += 2;

                  VAR55 += FUN33(VAR130, VAR2, VAR55, VAR113);
                  FUN26(VAR130, VAR128, VAR2, VAR55, 8, VAR98);
                  VAR55 += 8;
                }
                break;
              }
            }
          }
          break;
        }
      }
      break;
    }

    case VAR71:
      VAR45 = FUN35 (VAR12);

      
      switch (VAR45)
      {

        case VAR131:
          VAR22 = FUN19 (VAR2, 10, 6);
          VAR23 = FUN19 (VAR2, 4, 6);
          VAR24 = FUN19 (VAR2, 16, 6);
          break;

        case VAR132:
          VAR22 = FUN19 (VAR2, 16, 6);
          VAR23 = FUN19 (VAR2, 4, 6);
          VAR24 = FUN19 (VAR2, 10, 6);
          break;

        case VAR133:
          VAR22 = FUN19 (VAR2, 10, 6);
          VAR23 = FUN19 (VAR2, 16, 6);
          VAR24 = FUN19 (VAR2, 4, 6);
          break;

        case VAR134:
          VAR22 = FUN19 (VAR2, 24, 6);
          VAR23 = FUN19 (VAR2, 16, 6);
          VAR24 = FUN19 (VAR2, 16, 6);
          break;
      }

      FUN20(&VAR4->VAR78, VAR79, 6, VAR22);
      FUN20(&VAR4->VAR22, VAR79, 6, VAR22);
      FUN20(&VAR4->VAR80, VAR79, 6, VAR23);
      FUN20(&VAR4->VAR23, VAR79, 6, VAR23);

      

      FUN20(&VAR61->VAR24, VAR79, 6, VAR24);
      FUN20(&VAR61->VAR22, VAR79, 6, VAR22);
      FUN20(&VAR61->VAR23, VAR79, 6, VAR23);
      VAR61->VAR81 = VAR14;

      VAR17 = FUN18(VAR2, 22);
      VAR19 = FUN21(VAR17);
      VAR18 = FUN22(VAR17);

      FUN23(VAR4->VAR64, VAR66,
            "", VAR18,VAR19);

      
      if (VAR6)
      {

        switch (VAR45)
        {

          case VAR131:
            FUN24 (VAR30, VAR82, VAR2, 4, 6, VAR23);
            FUN24 (VAR30, VAR83, VAR2, 10, 6, VAR22);
            FUN24 (VAR30, VAR85, VAR2, 16, 6, VAR24);
            FUN17 (VAR30, VAR87, VAR2, 22, 2,
               VAR19);
            FUN17 (VAR30, VAR88, VAR2, 22, 2,
               VAR18);

            
            VAR29 = FUN24 (VAR30, VAR84, VAR2, 4, 6, VAR23);
            FUN25(VAR29);
            VAR29 = FUN24 (VAR30, VAR84, VAR2, 10, 6, VAR22);
            FUN25(VAR29);
            break;

          case VAR132:
            FUN24 (VAR30, VAR82, VAR2, 4, 6, VAR23);
            FUN24 (VAR30, VAR85, VAR2, 10, 6, VAR24);
            FUN24 (VAR30, VAR83, VAR2, 16, 6, VAR22);
            FUN17 (VAR30, VAR87, VAR2, 22, 2,
               VAR19);
            FUN17 (VAR30, VAR88, VAR2, 22, 2,
               VAR18);

            
            VAR29 = FUN24 (VAR30, VAR84, VAR2, 4, 6, VAR23);
            FUN25(VAR29);
            VAR29 = FUN24 (VAR30, VAR84, VAR2, 16, 6, VAR22);
            FUN25(VAR29);
            break;

          case VAR133:
            FUN24 (VAR30, VAR85, VAR2, 4, 6, VAR24);
            FUN24 (VAR30, VAR83, VAR2, 10, 6, VAR22);
            FUN24 (VAR30, VAR82, VAR2, 16, 6, VAR23);

            FUN17 (VAR30, VAR87, VAR2, 22, 2,
               VAR19);
            FUN17 (VAR30, VAR88, VAR2, 22, 2,
               VAR18);

            
            VAR29 = FUN24 (VAR30, VAR84, VAR2, 10, 6, VAR22);
            FUN25(VAR29);
            VAR29 = FUN24 (VAR30, VAR84, VAR2, 16, 6, VAR23);
            FUN25(VAR29);
            break;

          case VAR134:
            FUN26 (VAR30, VAR97, VAR2, 4, 6, VAR86);
            FUN26 (VAR30, VAR100, VAR2, 10, 6, VAR86);
            FUN24 (VAR30, VAR82, VAR2, 16, 6, VAR23);
            FUN17 (VAR30, VAR87, VAR2, 22, 2,
               VAR19);
            FUN17 (VAR30, VAR88, VAR2, 22, 2,
               VAR18);
            FUN24 (VAR30, VAR83, VAR2, 24, 6, VAR22);

            
            VAR29 = FUN24 (VAR30, VAR84, VAR2, 16, 6, VAR23);
            FUN25(VAR29);
            VAR29 = FUN24 (VAR30, VAR84, VAR2, 24, 6, VAR22);
            FUN25(VAR29);
            break;
        }

      }

#ifdef VAR135
      if (VAR6 &&
          (FUN35(VAR12) == VAR134 ||
           FUN35(VAR12) == VAR132))
      {
        VAR25 *VAR136;
        VAR5 *VAR137;

        guint16 VAR138;
        guint8 VAR139;
        guint8 VAR140;
        guint32 VAR141;
        guint8 VAR142;

        VAR138 = VAR33;
        VAR139 = FUN36(VAR2, VAR138 + 0);
        
        if (VAR139 & ~VAR143) {
#if 0
          FUN37("",  VAR139);
#endif
          break;
        }
        VAR142 = FUN38(FUN19(VAR2, VAR138, 1), 0, VAR12);
        VAR140 = FUN36(VAR2, VAR138 + 1);
        VAR141 = 0xffffff & FUN39(VAR2, VAR138 + 2);

        VAR136 = FUN28(VAR30, VAR2, VAR138, VAR142, "");
        VAR137 = FUN15 (VAR136, VAR144);

        FUN40 (VAR137, VAR145,
              VAR2, VAR138, 1, VAR139, "", VAR139 & VAR143);
        FUN17 (VAR137, VAR146, VAR2, VAR138 + 1, 1, VAR140);
        FUN17 (VAR137, VAR147, VAR2, VAR138 + 2, 4, VAR141);
        switch (VAR142) {
          case 24:
            FUN26(VAR137, VAR148, VAR2, VAR138 + 18, 6, VAR86);
          case 18:
            FUN26(VAR137, VAR149, VAR2, VAR138 + 12, 6, VAR86);
          case 12:
            FUN26(VAR137, VAR150, VAR2, VAR138 + 6, 6, VAR86);
          case 6:
            break;
          default:
            FUN41(VAR4, VAR26, VAR151, VAR152,
                "",
                VAR142);
        }
        VAR33 += VAR142;
      }
#endif 
      break;
  }

  VAR39 = FUN42(VAR2, VAR33);
  VAR40 = FUN43(VAR2, VAR33);

  switch (VAR8)
    {
      case 0: 
        VAR36 = VAR98;
        break;

      case 4: 
        VAR36 = VAR76;
        break;

      case -2: 
        if (FUN12 (VAR12) == VAR71)
          VAR36 = VAR98;
        else
          VAR36 = VAR76;
        break;

      default: 
        VAR36 = VAR153;
        break;
    }
  if (VAR36)
    {
      
      if (VAR40 < 4)
      {
        
        ;
      }
      else if (VAR39 < VAR40)
      {
        
        VAR40 -= 4;
        if (VAR39 > VAR40)
            VAR39 = VAR40;
      }
      else
      {
        
        VAR39 -= 4;
        VAR40 -= 4;
        if (VAR6)
        {
          guint32 VAR154 = FUN44(VAR2, VAR33 + VAR39);
          guint32 VAR155;

          if (VAR10)
            VAR155 = FUN45(VAR2, VAR34, VAR33, VAR39);
          else
            VAR155 = FUN46(VAR2, VAR33 + VAR39);
          if (VAR155 == VAR154) {
            VAR37 = VAR76;
            VAR38 = VAR98;
          } else {
            VAR37 = VAR98;
            VAR38 = VAR76;
          }

          if(VAR37) {
            VAR27 = FUN31(VAR30, VAR156, VAR2,
                VAR33 + VAR39, 4, VAR154,
                "", VAR154);
          } else {
            VAR27 = FUN31(VAR30, VAR156, VAR2,
                VAR33 + VAR39, 4, VAR154,
                "",
                VAR154, VAR155);
            VAR58[8] = '';
          }

          FUN47(VAR30, VAR2, VAR33 + VAR39, 4);

          VAR31 = FUN15(VAR27, VAR157);

          VAR27 = FUN32(VAR31,
              VAR158, VAR2,
              VAR33 + VAR39, 4,
              VAR37);
          FUN48(VAR27);

          VAR27 = FUN32(VAR31,
              VAR159, VAR2,
              VAR33 + VAR39, 4,
              VAR38);
          FUN48(VAR27);
        }
      }
    } else {
      VAR58[8] = '';
    }

    FUN49(VAR26, "", VAR58);
    FUN23 (VAR4->VAR64, VAR66, "", VAR58);


  
  switch (FUN12 (VAR12))
    {

    case VAR70:
      if (VAR35 == 4) {
        FUN29(VAR30, VAR2, VAR34 - 4);
      }
      break;

    case VAR71:
      if (VAR6 && FUN13(VAR14))
      {
        VAR25 *VAR160;
        VAR5 *VAR161;

        guint16 VAR162;
        guint16 VAR163;
        guint16 VAR164;
        guint16 VAR165;
        guint16 VAR166;
        guint16 VAR167;
        guint16 VAR168;
        guint16 VAR169;

        
        VAR162 = VAR34 - VAR35 - 2;
        VAR160 = FUN28(VAR30, VAR2, VAR162, 2,
            "");
        VAR161 = FUN15 (VAR160, VAR170);

        VAR163 = FUN18(VAR2, VAR162 + 0);
        VAR164 = FUN50(VAR163);
        VAR165 = FUN51(VAR163);
        VAR166 = FUN52(VAR163);
        VAR167 = FUN53(VAR163);
        VAR168 = FUN54(VAR163);
        VAR169 = FUN55(VAR163);

        FUN17 (VAR161, VAR171, VAR2,
            VAR162, 1, VAR164);

        FUN31 (VAR161, VAR172, VAR2,
            VAR162, 1, VAR165,
            "",
            VAR165, VAR173[VAR165], VAR174[VAR165]);

        if (VAR13 & VAR175) {
          FUN32 (VAR161, VAR176, VAR2,
              VAR162, 1, VAR163);
        } else {
          FUN32 (VAR161, VAR177, VAR2,
              VAR162, 1, VAR163);
        }

        FUN17 (VAR161, VAR178, VAR2, VAR162, 1,
            VAR166);

        if (VAR13 & VAR175) {
          if (!FUN56(VAR14)) {
            FUN32(VAR161, VAR179, VAR2,
                VAR162, 1, VAR167);
            VAR42 = VAR167;
          }
          if (FUN57(VAR14)) {
            
            if (VAR169 == 0) {
              FUN58 (VAR161, VAR180, VAR2,
                  VAR162 + 1, 1, VAR169,
                                                "");
            } else {
              FUN17 (VAR161, VAR180, VAR2,
                                   VAR162 + 1, 1, VAR169);
            }
          } else {
            
            VAR25 *VAR181;
            VAR5 *VAR182;
            guint8 VAR183;

            VAR181 = FUN28(VAR161, VAR2, VAR162 + 1, 1,
                "", VAR169);
            VAR182 = FUN15 (VAR181, VAR184);

            FUN32 (VAR182, VAR185,
                                    VAR2, VAR162 + 1, 1, VAR169);

            if (FUN59(VAR169)) {
              FUN17 (VAR182, VAR186, VAR2,
                  VAR162 + 1, 1, VAR169);

              VAR183 = FUN60(VAR169);
              switch (VAR183) {

              case 0:
                FUN58 (VAR182, VAR187, VAR2,
                    VAR162 + 1, 1, VAR169,
                    "");
                break;

              default:
                FUN58 (VAR182, VAR187, VAR2,
                    VAR162 + 1, 1, VAR169,
                    "", VAR183*4096, VAR183);
                break;

              case 15:
                FUN58 (VAR182, VAR187, VAR2,
                    VAR162 + 1, 1, VAR169,
                    "");
                break;
              }
            }
          }
        } else {
          if (!FUN56(VAR14)) {
            FUN32(VAR161, VAR179, VAR2,
                VAR162, 1, VAR167);
            VAR42 = VAR167;
          }
          if (VAR168) {
            
            switch (VAR169) {

            case 0:
              FUN58 (VAR161, VAR188,
                                                VAR2, VAR162 + 1, 1, VAR169,
                  "");
              break;

            default:
              FUN58 (VAR161, VAR188,
                                                VAR2, VAR162 + 1, 1, VAR169,
                                                "", VAR169*256, VAR169);
              break;

            case 254:
              FUN58 (VAR161, VAR188,
                                                VAR2, VAR162 + 1, 1, VAR169,
                  "");
              break;

            case 255:
              FUN58 (VAR161, VAR188,
                                                VAR2, VAR162 + 1, 1, VAR169,
                  "");
              break;
            }
          } else {
            
            if (VAR169 == 0) {
              FUN58 (VAR161, VAR189,
                                                VAR2, VAR162 + 1, 1, VAR169,
                                                "");
            } else {
              FUN17 (VAR161, VAR189,
                                   VAR2, VAR162 + 1, 1, VAR169);
            }
          }
        }

        
        if (VAR35 == 4) {
          FUN29(VAR30, VAR2, VAR34 - 4);
        }
      } 

#ifdef VAR190
      
      
      
      if (VAR191 && !VAR4->VAR192->VAR13.VAR193) {
        const VAR21 *VAR194 = FUN19(VAR2, 0, VAR33+VAR40);
        FUN61(&VAR195, VAR194, VAR33, VAR33+VAR40, NULL, 0, NULL, VAR76, VAR98);
      }
      
#endif

      
      if (FUN56(VAR14))
        return;

      if (!VAR196) {
        guint VAR197 = 0;

        
        VAR63 = VAR98;
        if(!VAR4->VAR192->VAR13.VAR193){
          retransmit_key VAR198;
          VAR199 *VAR200;

          memcpy(VAR198.VAR24, VAR24, 6);
          memcpy(VAR198.VAR22, VAR22, 6);
          VAR198.VAR17 = 0;
          VAR200 = (VAR199 *)FUN62(VAR201, &VAR198);
          if (VAR200 && VAR200->VAR17 == VAR17) {
               
               VAR197 = VAR200->VAR197;
               FUN63(VAR202, FUN64( VAR4->VAR192->VAR203),
                  FUN64(VAR197));
               VAR63 = VAR76;
          } else {
               
               if (!VAR200) {
                  VAR200 = FUN65(sizeof(VAR199));
                  *VAR200 = VAR198;
                  FUN63(VAR201, VAR200, VAR200);
               }
               VAR200->VAR17 = VAR17;
               VAR200->VAR197 =  VAR4->VAR192->VAR203;
           }
        }
        else if ((VAR197 = FUN66(FUN62(VAR202, FUN64( VAR4->VAR192->VAR203))))) {
           VAR63 = VAR76;
        }

        if (VAR63) {
            FUN67(VAR4->VAR64, VAR66, "");
            if (VAR6) {
                VAR25 *VAR204;

                VAR204=FUN68(VAR30, VAR205, VAR2, 0, 0, "");
                FUN48(VAR204);
                VAR204=FUN17(VAR30, VAR206,VAR2, 0, 0, VAR197);
                FUN48(VAR204);
            }
            VAR44 = FUN69 (VAR2, VAR33, VAR39, VAR40);
            FUN70(VAR207, VAR44, VAR4, VAR6);
            goto VAR208;
        }
      }

      break;

    case VAR89:
      return;

    default:
      return;
    }

  if (FUN71(FUN9(VAR12)) && VAR209 != VAR210) {
    

    gboolean VAR211 = VAR98;
    VAR5 *VAR212 = NULL;
    guint32 VAR213;
    guint8 VAR198, VAR214;

    
#ifdef VAR190
#define PROTECTION_ALG_TKIP  VAR215
#define PROTECTION_ALG_CCMP  VAR216
#define PROTECTION_ALG_WEP  VAR217
#define PROTECTION_ALG_RSNA  VAR218 | VAR219
#else
#define PROTECTION_ALG_WEP  0
#define PROTECTION_ALG_TKIP  1
#define PROTECTION_ALG_CCMP  2
#define PROTECTION_ALG_RSNA  VAR218 | VAR219
#endif
    guint8 VAR220=VAR221;
    
    
#VAR222 FUN72(VAR2, VAR33)  (FUN36(VAR2, VAR33 + 1) & 0x20)
#VAR222 FUN73(VAR2, VAR33)  (FUN36(VAR2, VAR33 + 2) == 0)
    

#ifdef  VAR190
    
    
    guint32 VAR223=0;
    guint32 VAR224=0;

    VAR44 = FUN74(VAR2, VAR33, VAR40, &VAR220, &VAR223, &VAR224);
#endif
    

    VAR214 = FUN36(VAR2, VAR33 + 3);
    VAR198 = FUN75(VAR214);
    if ((VAR214 & VAR225) && (VAR39 >= VAR226)) {
      


      if (VAR6) {
        VAR25 *VAR227;

#ifdef VAR190
        
        
        if (VAR220==VAR219)
          VAR227 = FUN28(VAR30, VAR2, VAR33, 8,
              "");
        else if (VAR220==VAR218)
          VAR227 = FUN28(VAR30, VAR2, VAR33, 8,
            "");
        else {
          
#endif
          
          
          if (FUN72(VAR2, VAR33)) {
            VAR220=VAR219;
            VAR227 = FUN28(VAR30, VAR2, VAR33, 8,
                "");
          } else if (FUN73(VAR2, VAR33)) {
            VAR220=VAR218;
            VAR227 = FUN28(VAR30, VAR2, VAR33, 8,
                "");
          } else
            VAR227 = FUN28(VAR30, VAR2, VAR33, 8,
                "");
#ifdef VAR190
        }
#endif
        FUN76 (VAR26, VAR33 + 8);

        VAR212 = FUN15 (VAR227, VAR228);

        if (VAR220==VAR219) {
          FUN77(VAR49, VAR50, "",
              FUN39(VAR2, VAR33 + 4),
              FUN36(VAR2, VAR33),
              FUN36(VAR2, VAR33 + 2));
          FUN78(VAR212, VAR229, VAR2, VAR33,
              VAR226, VAR49);
        } else if (VAR220==VAR218) {
          FUN77(VAR49, VAR50, "",
              FUN39(VAR2, VAR33 + 4),
              FUN36(VAR2, VAR33 + 1),
              FUN36(VAR2, VAR33));
          FUN78(VAR212, VAR230, VAR2, VAR33,
              VAR226, VAR49);
        }

        FUN17(VAR212, VAR231, VAR2, VAR33 + 3, 1, VAR198);
      }

      
      VAR39 -= VAR226;
      VAR40 -= VAR226;
      VAR41 = VAR226;
      

#ifdef VAR190
      
      
      if (VAR44!=NULL) {
        if (VAR40 < (VAR232) VAR224) {
          
          ;
        } else if (VAR39 < VAR40) {
          
          
          VAR40 -= VAR224;
          if (VAR39 > VAR40)
            VAR39 = VAR40;
        } else {
          
          
          
          VAR39 -= VAR224;
          VAR40 -= VAR224;
          VAR211 = VAR76;
        }
      }
      
#endif
    } else {
      
      
      VAR213 = FUN79(VAR2, VAR33);
      if (VAR6) {
        VAR25 *VAR233;

        VAR233 = FUN28(VAR30, VAR2, VAR33, 4,
            "");

        VAR212 = FUN15 (VAR233, VAR228);
        FUN17 (VAR212, VAR234, VAR2, VAR33, 3, VAR213);
        FUN80(VAR2, VAR52, VAR33, 3);
        VAR51 = FUN81(VAR52);
        if (VAR51 != -1) {
          FUN40 (VAR212, VAR235,
              VAR2, 0, 0, VAR76,
              "",
              VAR51);
        }
      }
      if (VAR6)
        FUN17 (VAR212, VAR231, VAR2, VAR33 + 3, 1, VAR198);

      
      VAR39 -= 4;
      VAR40 -= 4;
      VAR41 = 4;

      
      
      VAR220=VAR236;

      
      if (VAR40 < 4) {
        
        ;
      } else if (VAR39 < VAR40) {
        
        VAR40 -= 4;
        if (VAR39 > VAR40)
          VAR39 = VAR40;
      } else {
        
        VAR39 -= 4;
        VAR40 -= 4;
        VAR211 = VAR76;
      }
    }

    if (VAR220 == VAR236) {
      FUN82 (VAR237.VAR238, "", VAR239);
    } else if (VAR220 == VAR219) {
      FUN82 (VAR237.VAR238, "", VAR239);
    } else if (VAR220 == VAR218) {
      FUN82 (VAR237.VAR238, "", VAR239);
    } else {
      FUN82 (VAR237.VAR238, "", VAR239);
    }

#ifndef VAR190
    if (VAR211)
      VAR44 = FUN83(VAR2, VAR33, VAR40 + 8);
#else
    
    
#endif
    if (!VAR211 || VAR44 == NULL) {
      
      VAR44 = FUN69(VAR2, VAR33 + VAR41, VAR39, VAR40);

      if (VAR6) {
        
        if (VAR220==VAR236) {
          if (VAR211)
            FUN31 (VAR212, VAR240, VAR2,
                VAR33 + VAR41 + VAR39, 4,
                FUN44(VAR2, VAR33 + VAR41 + VAR39),
                "",
                FUN44(VAR2, VAR33 + VAR41 + VAR39));
        } else if (VAR220==VAR218) {
        } else if (VAR220==VAR219) {
        }
      }
      

      if (VAR4->VAR241 != VAR242 && VAR209 == VAR243) {
        
        FUN70(VAR207, VAR44, VAR4, VAR6);
        goto VAR208;
      }
    } else {
      
      if (VAR220==VAR236) {
        if (VAR6)
          FUN31 (VAR212, VAR240, VAR2,
              VAR33 + VAR41 + VAR39, 4,
              FUN44(VAR2, VAR33 + VAR41 + VAR39),
              "",
              FUN44(VAR2, VAR33 + VAR41 + VAR39));

        FUN84(VAR4, VAR44, "");
      } else if (VAR220==VAR218) {
        FUN84(VAR4, VAR44, "");
      } else if (VAR220==VAR219) {
        FUN84(VAR4, VAR44, "");
      }
      
      
#undef VAR244
#undef VAR245
#undef VAR218
#undef VAR219
#undef VAR236
      
    }

    
    VAR33 = 0;

  } else {
    
    VAR44 = VAR2;
  }

  
  VAR43 = VAR4->VAR246;
  if (VAR247 && (VAR20 || VAR19 != 0)) {
    VAR248 *VAR249;

    
    if (VAR40 < 0)
      FUN85(VAR250);
    VAR249 = FUN86(VAR44, VAR33, VAR4, VAR18,
        VAR251,
        VAR252,
        VAR19,
        VAR40,
        VAR20);
    VAR44 = FUN87(VAR2, VAR33, VAR4,
        "", VAR249,
        &VAR253, NULL, VAR30);
  } else {
    
    if (VAR19 != 0) {
      
      VAR44 = NULL;
    } else {
      

      
      VAR44 = FUN69 (VAR44, VAR33, VAR39, VAR40);

      
      if (VAR20)
        VAR4->VAR246 = VAR76;
      else
        VAR4->VAR246 = VAR98;
    }
  }

  if (VAR44 == NULL) {
    
    FUN2(VAR4->VAR64, VAR66, "");
    VAR44 = FUN69 (VAR2, VAR33, VAR39, VAR40);
    FUN70(VAR207, VAR44, VAR4, VAR6);
    VAR4->VAR246 = VAR43;
    goto VAR208;
  }

  switch (FUN12 (VAR12))
    {

    case VAR70:
      FUN88 (VAR12, VAR44, VAR4, VAR6);
      break;

    case VAR71:
      if (VAR42 && FUN43(VAR44, 0) > 4){
        VAR1 *volatile VAR254 = NULL;
        guint32 VAR255 = 0;
        guint VAR116 = 1;
        const VAR21 *VAR256 = NULL;
        const VAR21 *VAR257 = NULL;
        guint16 VAR258;
        VAR25 *VAR259;
        VAR5 *VAR260;
        VAR5 *VAR261;

        VAR259 = FUN14(VAR6, VAR262, VAR44, 0,
                                    FUN43(VAR44, 0), "");
        VAR260 = FUN15(VAR259, VAR263);

        do {
          VAR257 = FUN19 (VAR44, VAR255, 6);
          VAR256 = FUN19 (VAR44, VAR255+6, 6);
          VAR258 = FUN89 (VAR44, VAR255+12);

          VAR259 = FUN31(VAR260, VAR264, VAR44,
                            VAR255, FUN7(VAR255+14+VAR258, 4),
                            VAR116, "", VAR116);
          VAR261 = FUN15(VAR259, VAR265);
          VAR116++;

          FUN24(VAR261, VAR82, VAR44, VAR255, 6, VAR257);
          FUN24(VAR261, VAR83, VAR44, VAR255+6, 6, VAR256);
          FUN31(VAR261, VAR266, VAR44, VAR255+12, 2,
          VAR258, "", VAR258);

          VAR255 += 14;
          VAR254 = FUN69(VAR44, VAR255, VAR258, -1);
          FUN70(VAR267, VAR254, VAR4, VAR261);
          VAR255 = FUN7(VAR255+VAR258, 4);
        } while (FUN43(VAR44, VAR255) > 14);

        break;
      }
      
      VAR46 = VAR268;
      VAR269 {
        VAR47 = FUN36(VAR44, 0);
        VAR48 = FUN36(VAR44, 1);
        if (VAR47 != 0xaa || VAR48 != 0xaa) {
          if (FUN90(VAR44, 6, VAR4->VAR78.VAR270, 6) == 0 ||
              FUN90(VAR44, 0, VAR4->VAR80.VAR270, 6) == 0)
            VAR46 = VAR271;
          else if (VAR47 == 0xff && VAR48 == 0xff)
            VAR46 = VAR272;
          else if (VAR47 == 0x00 && VAR48 == 0x00) {
            FUN28(VAR6, VAR44, 0, 2, "");
            VAR44 = FUN91 (VAR44, 2);
          }
        }
      }
      FUN92(VAR273, VAR250) {
      ; 

      }
      VAR274;

      switch (VAR46) {

      case VAR268:
        FUN70(VAR267, VAR44, VAR4, VAR6);
        break;

      case VAR271:
        FUN70(VAR275, VAR44, VAR4, VAR6);
        break;

      case VAR272:
        FUN70(VAR276, VAR44, VAR4, VAR6);
        break;
      }
      break;
    }
  VAR4->VAR246 = VAR43;

  VAR208:
  VAR61->VAR277 = VAR237;
  FUN93(VAR278, VAR4, VAR61);
  memset (&VAR237, 0, sizeof VAR237);
}