static int FUN1(struct VAR1 *VAR1, int VAR2, struct VAR3 *VAR4)  
{
	struct VAR5 *VAR6 = FUN2(VAR1->VAR7->VAR8);
	struct VAR9 *VAR10 = FUN3(VAR1->VAR7->VAR8);
	struct VAR11 *VAR12 = &VAR10->VAR13;

	if (!(VAR4->VAR14 & VAR15))
		return -VAR16;
	if (FUN4(&VAR6->VAR17) && VAR4->VAR18 != VAR19)
		return -VAR16;

	if (VAR2 == VAR20) {
		
		VAR2 = VAR21;
		VAR4->VAR18 = VAR19;
	}
	if (FUN5(FUN6(VAR22, &VAR10->VAR23)))
		return -VAR24;
	if (FUN7(VAR2))
		return FUN8(VAR12->VAR25, VAR6->VAR26, VAR1, VAR4);
	else if (VAR4->VAR18 == VAR19)
		return FUN9(VAR12->VAR25, VAR6->VAR26, VAR1, VAR4);
	else
		return FUN10(VAR12->VAR25, VAR6->VAR26, VAR1, VAR2, VAR4);
}