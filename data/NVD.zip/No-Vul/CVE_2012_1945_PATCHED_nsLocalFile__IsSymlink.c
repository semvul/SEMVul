NS_IMETHODIMP VAR1::FUN1(bool *VAR2)  
{
    
    FUN2();

    FUN3(VAR2);

    
    if (!FUN4(VAR3)) {
        *VAR2 = false;
        return VAR4;
    }

    
    nsresult VAR5 = FUN5();
    if (FUN6(VAR5)) {
        return VAR5;
    }

    
    
    
    
    *VAR2 = true;
    return VAR4;
}