int FUN1(const int VAR1, struct VAR2 *VAR3, 		 __u16 VAR4, struct VAR5 *VAR6)  
{
	VAR7 *VAR8 = NULL;
	VAR9 *VAR10 = NULL;
	VAR11 *VAR12;
	char *VAR13;
	int VAR14 = 0;
	int VAR15;
	unsigned int VAR16;
	__u16 VAR17, VAR18;

	FUN2(1, "");

	if (VAR6->VAR19)
		return -VAR20;

	VAR14 = FUN3(VAR21, 15, VAR3, (void **) &VAR8,
		(void **) &VAR10);
	if (VAR14)
		return VAR14;

	VAR17 = 14; 
	VAR18 = 0;
	VAR8->VAR22 = 0;       
	VAR8->VAR23 = FUN4(8);
	VAR8->VAR24 =
		FUN4((VAR3->VAR25->VAR26->VAR27 - VAR28) &
				0xFFFFFF00);
	VAR8->VAR29 = 0;
	VAR8->VAR30 = 0;
	VAR8->VAR31 = 0;
	VAR8->VAR32 = 0;
	VAR8->VAR33 = 0;
	VAR8->VAR34 =  FUN4(
	      FUN5(struct VAR35,VAR36) - 4);
	VAR8->VAR37 = 0;
	VAR8->VAR38 = 0;
	VAR8->VAR39 = 1;
	VAR8->VAR40 = 0;
	VAR8->VAR41 = FUN4(VAR42);
	VAR8->VAR36 = VAR4;      
	VAR8->VAR43 =
		FUN4(VAR44 / sizeof(VAR45));
	VAR8->VAR46 = FUN4(VAR6->VAR47);
	VAR8->VAR48 = VAR6->VAR49;
	VAR8->VAR50 =
	      FUN4(VAR51 | VAR52);

	VAR16 = VAR6->VAR53;
	VAR17 += VAR16;
	if (VAR16 < VAR54) {
		memcpy(VAR8->VAR55, VAR6->VAR56, VAR16);
		VAR18 += VAR16;
		
		VAR8->VAR55[VAR16] = 0;
		VAR8->VAR55[VAR16+1] = 0;
	} else {
		VAR14 = -VAR57;
		goto VAR58;
	}
	VAR18 = VAR17 + 1  ;
	VAR8->VAR59 = FUN4(VAR17);
	VAR8->VAR60 = VAR8->VAR59;
	VAR8->VAR61.VAR62 += VAR18;
	VAR8->VAR63 = FUN4(VAR18);

	VAR14 = FUN6(VAR1, VAR3->VAR25, (struct VAR64 *) VAR8,
			(struct VAR64 *) VAR10, &VAR15, 0);
	FUN7(&VAR3->VAR65);
	if (VAR14) {
		if (VAR14 == -VAR66) {
			VAR6->VAR19 = true;
			FUN8(VAR8);
			VAR14 = 0; 
		} else
			FUN2(1, "", VAR14);
	} else {                
		VAR14 = FUN9((struct VAR67 *)VAR10);

		if (VAR14 == 0) {
			unsigned int VAR68;

			
			if (VAR10->VAR61.VAR69 & VAR70)
				VAR6->VAR71 = true;
			else
				VAR6->VAR71 = false;
			VAR13 = (char *) &VAR10->VAR61.VAR72 +
			       FUN10(VAR10->VAR73.VAR34);
			VAR12 = (VAR11 *)VAR13;
			VAR13 = (char *)&VAR10->VAR61.VAR72 +
				FUN10(VAR10->VAR73.VAR38);
			if (VAR6->VAR74)
				FUN11(
					VAR6->VAR75);
			else
				FUN8(VAR6->VAR75);
			VAR6->VAR76 = VAR13;
			VAR6->VAR75 = (char *)VAR8;
			VAR6->VAR74 = 0;
			if (VAR12->VAR77)
				VAR6->VAR19 = true;
			else
				VAR6->VAR19 = false;
			VAR6->VAR78 =
						FUN10(VAR12->VAR43);
			VAR6->VAR79 +=
				VAR6->VAR78;
			VAR68 = FUN10(VAR12->VAR80);
			if (VAR3->VAR25->VAR26->VAR27 - VAR28 <
			      VAR68) {
				FUN12(1, "");
				VAR6->VAR81 = NULL;
				return VAR14;
			} else
				VAR6->VAR81 =
					VAR6->VAR76 + VAR68;



			
		}

	}

	

	
VAR58:
	if (VAR14 != 0)
		FUN8(VAR8);
	return VAR14;
}