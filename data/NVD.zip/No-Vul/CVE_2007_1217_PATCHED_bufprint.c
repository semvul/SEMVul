static VAR1 *FUN1(VAR1 *VAR2, char *VAR3,...)  
{
	va_list VAR4;
	size_t VAR5,VAR6;

	if (!VAR2)
		return NULL;
	FUN2(VAR4, VAR3);
	VAR6 = VAR2->VAR7 - VAR2->VAR8;
	VAR5 = vsnprintf(VAR2->VAR9, VAR6, VAR3, VAR4);
	FUN3(VAR4);
	if (VAR5 >= VAR6) {
		
		size_t VAR10 = 2 * VAR2->VAR7;
		VAR11 *VAR12;

		while ((VAR10 - VAR2->VAR8) <= VAR5)
			VAR10 *= 2;
		VAR12 = FUN4(VAR10, VAR13);
		if (!VAR12) {
			FUN5(VAR2);
			return NULL;
		}
		memcpy(VAR12, VAR2->VAR14, VAR2->VAR8);
		FUN6(VAR2->VAR14);
		VAR12[VAR2->VAR8] = 0;
		VAR2->VAR14 = VAR12;
		VAR2->VAR9 = VAR2->VAR14 + VAR2->VAR8;
		VAR2->VAR7 = VAR10;
		FUN2(VAR4, VAR3);
		VAR6 = VAR2->VAR7 - VAR2->VAR8;
		VAR5 = vsnprintf(VAR2->VAR9, VAR6, VAR3, VAR4);
		FUN3(VAR4);
	}
	VAR2->VAR9 += VAR5;
	VAR2->VAR8 += VAR5;
	return VAR2;
}