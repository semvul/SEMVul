static VAR1 FUN1(struct VAR2 *VAR3)  
{
	VAR4;
	struct VAR5 *VAR6;
	struct VAR7 *VAR8;
	int VAR9;

	
	FUN2(4);
	FUN3(VAR3->VAR10);
	FUN2(VAR3->VAR10 + 8);
	FUN4(VAR3->VAR11, VAR3->VAR10);
	FUN3(VAR3->VAR12);
	FUN3(VAR3->VAR13);

	if (VAR3->VAR10 > VAR14)
		goto VAR15;
	if (VAR3->VAR13 > 100)
		goto VAR15;

	if (VAR3->VAR13 > FUN5(VAR3->VAR16)) {
		VAR3->VAR8 = FUN6(VAR3->VAR13 * sizeof(*VAR3->VAR8), VAR17);
		if (!VAR3->VAR8) {
			VAR3->VAR8 = VAR3->VAR16;
			FUN7("");
			goto VAR15;
		}
	}

	if (VAR3->VAR12 >= FUN5(VAR18))
		VAR3->VAR13 = 0;

	VAR8 = &VAR18[VAR3->VAR12];
	for (VAR9 = 0; VAR9 < VAR3->VAR13; VAR9++) {
		VAR6 = &VAR3->VAR8[VAR9];
		VAR6->VAR19 = NULL;

		

		if (VAR3->VAR20 == VAR3->VAR21) {
			if (VAR3->VAR22 < 4) {
				
				VAR6->VAR23 = VAR24 + 1;
				VAR6->VAR25 = VAR26;
				VAR3->VAR13 = VAR9+1;
				break;
			}

			
			VAR3->VAR20 = FUN8(VAR3->VAR27[0]);
			VAR3->VAR27++;
			if (VAR3->VAR22 < VAR28) {
				VAR3->VAR21 = VAR3->VAR20 + (VAR3->VAR22>>2);
				VAR3->VAR22 = 0;
			} else {
				VAR3->VAR21 = VAR3->VAR20 + (VAR28>>2);
				VAR3->VAR22 -= VAR28;
			}
		}
		VAR6->VAR23 = FUN9(*VAR3->VAR20++);

		if (VAR6->VAR23 >= VAR29 && VAR6->VAR23 < VAR8->VAR30)
			VAR6->VAR25 = VAR8->VAR31[VAR6->VAR23](VAR3, &VAR6->VAR32);
		else {
			VAR6->VAR23 = VAR33;
			VAR6->VAR25 = VAR34;
		}

		if (VAR6->VAR25) {
			VAR3->VAR13 = VAR9+1;
			break;
		}
	}

	VAR35;
}