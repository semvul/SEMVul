static int FUN1(pid_t VAR1, const struct VAR2 *VAR3, int VAR4)  
{
	struct VAR5 *VAR6;
	struct VAR7 *VAR8, *VAR9, *VAR10;
	unsigned int VAR11;

	if (!FUN2(VAR3, VAR12))
		return -VAR13;

	VAR8 = NULL;
	if (VAR4 == VAR14) {
		FUN3(VAR11, VAR3) {
			if (!VAR8)
				VAR8 = FUN4(sizeof(struct VAR7),
						 VAR15, FUN5(VAR11));
			if (!VAR8)
				goto VAR16;
			VAR8->VAR1 = VAR1;
			FUN6(&VAR8->VAR17);
			VAR8->VAR18 = 1;

			VAR6 = &FUN7(VAR19, VAR11);
			FUN8(&VAR6->VAR20);
			FUN9(VAR10, VAR9, &VAR6->VAR17, VAR17) {
				if (VAR10->VAR1 == VAR1)
					goto VAR21;
			}
			FUN10(&VAR8->VAR17, &VAR6->VAR17);
			VAR8 = NULL;
VAR21:
			FUN11(&VAR6->VAR20);
		}
		FUN12(VAR8);
		return 0;
	}

	
VAR16:
	FUN3(VAR11, VAR3) {
		VAR6 = &FUN7(VAR19, VAR11);
		FUN8(&VAR6->VAR20);
		FUN9(VAR8, VAR9, &VAR6->VAR17, VAR17) {
			if (VAR8->VAR1 == VAR1) {
				FUN13(&VAR8->VAR17);
				FUN12(VAR8);
				break;
			}
		}
		FUN11(&VAR6->VAR20);
	}
	return 0;
}