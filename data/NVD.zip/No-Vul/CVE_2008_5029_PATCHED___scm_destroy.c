void FUN1(struct VAR1 *VAR2)  
{
	struct VAR3 *VAR4 = VAR2->VAR5;
	int VAR6;

	if (VAR4) {
		VAR2->VAR5 = NULL;
		if (VAR7->VAR8) {
			FUN2(&VAR4->VAR9, VAR7->VAR8);
		} else {
			FUN3(VAR10);

			VAR7->VAR8 = &VAR10;

			FUN4(&VAR4->VAR9, &VAR10);
			while (!FUN5(&VAR10)) {
				VAR4 = FUN6(&VAR10, struct VAR3, VAR9);

				FUN7(&VAR4->VAR9);
				for (VAR6=VAR4->VAR11-1; VAR6>=0; VAR6--)
					FUN8(VAR4->VAR5[VAR6]);
				FUN9(VAR4);
			}

			VAR7->VAR8 = NULL;
		}
	}
}