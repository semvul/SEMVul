static void FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4)  
{
	struct VAR5 *VAR6;
	u8 VAR7 *VAR8 = NULL;
	u8 VAR7 *VAR9 = NULL;
	int VAR10 = 0;
	int VAR11;

	if (!VAR4->VAR12)
		return;

	for (VAR11 = 0; VAR11 < VAR4->VAR13; VAR11++) {
		VAR6 = &VAR4->VAR12[VAR11];
		if (!VAR6)
			continue;

		switch (VAR2->VAR14) {
		case VAR15:
			
			if (VAR6->VAR16 && VAR6->VAR17 < 1)
				break;

			if (!VAR8) {
				VAR8 = VAR6->VAR16;
				
				if (VAR6->VAR17 > 1)
					VAR9 = VAR8 + 1;
			} else if (!VAR9)
				VAR9 = VAR6->VAR16;

			if (VAR8 && VAR9) {
				FUN2(VAR2->VAR18, VAR8);
				FUN2(VAR2->VAR19, VAR9);
				VAR10 = 1;
			}
			break;
		default:
			VAR10 = 1;
			break;
		}
		if (VAR10)
			break;
	}
}