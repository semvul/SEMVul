****************************************************************************/ static void FUN1( VAR1 *VAR2,                               VAR3 *VAR4,                               VAR5 *VAR6 )  
{
    VAR7 *VAR8;
    bool VAR9;
    int VAR10 = 0;
    mtime_t VAR11 = -1, VAR12;
    VAR13 *VAR14 = VAR2->VAR15;

    
    if( !VAR6->VAR16 )
    {
        FUN2( VAR2, "" );
        return;
    }

    if( VAR6->VAR16 >= 7 &&
        ! memcmp ( VAR6->VAR17, "", 7 ) )
    {
        
        return;
    }
    else if( VAR6->VAR16 >= 7 &&
        ! memcmp ( VAR6->VAR17, "", 7 ) )
    {
        
        return;
    }

    if( VAR4->VAR18.VAR19 == VAR20 &&
        VAR6->VAR17[0] & VAR21 ) return;

    
    FUN3( VAR2->VAR22, VAR23,
                    VAR4->VAR24, &VAR9 );

    if( VAR4->VAR25 )
    {
        bool VAR26;
        VAR4->VAR27++;
        switch( VAR4->VAR18.VAR19 )
        {
        case VAR28:
        case VAR29:
        case VAR30:
            if( VAR4->VAR27 == 3 ) VAR4->VAR25 = 0;
            VAR26 = true;
            break;

        case VAR31:
            if( !VAR4->VAR18.VAR32.VAR33 && VAR4->VAR27 == 2 )
            {
                FUN4( VAR2, VAR4, VAR6 );
                VAR4->VAR25 = 0;
            }
            else if( VAR4->VAR18.VAR32.VAR33 )
            {
                VAR4->VAR25 = 0;
                if( VAR6->VAR16 >= 9 )
                {
                    VAR6->VAR17 += 9;
                    VAR6->VAR16 -= 9;
                }
            }
            VAR26 = false;
            break;

        case VAR34:
            if( VAR4->VAR27 == VAR4->VAR35 ) VAR4->VAR25 = 0;
            VAR26 = true;
            break;

        default:
            VAR4->VAR25 = 0;
            VAR26 = false;
            break;
        }

        
        if( !VAR26 )
        {
            void *VAR36 = VAR4->VAR37;
            VAR4->VAR38 += VAR6->VAR16;
            VAR4->VAR37 = realloc( VAR4->VAR37, VAR4->VAR38 );
            if( VAR4->VAR37 )
            {
                memcpy( (unsigned char *)VAR4->VAR37 + VAR4->VAR38 - VAR6->VAR16,
                        VAR6->VAR17, VAR6->VAR16 );
            }
            else
            {
#warning Memory VAR39
                VAR4->VAR38 = 0;
                VAR4->VAR37 = NULL;
                free( VAR36 );
            }
        }
        else if( FUN5( &VAR4->VAR38, &VAR4->VAR37,
                                     VAR6->VAR16, VAR6->VAR17 ) )
        {
            VAR4->VAR38 = 0;
            VAR4->VAR37 = NULL;
        }
        if( VAR4->VAR38 > 0 )
        {
            if( !VAR4->VAR25 )
            {
                
                free( VAR4->VAR18.VAR40 );

                VAR4->VAR18.VAR41 = VAR4->VAR38;
                VAR4->VAR18.VAR40 = malloc( VAR4->VAR38 );
                if( VAR4->VAR18.VAR40 )
                    memcpy( VAR4->VAR18.VAR40, VAR4->VAR37,
                            VAR4->VAR38 );
                else
                    VAR4->VAR18.VAR41 = 0;

                if( FUN6( VAR2, VAR4 ) )
                    FUN3( VAR2->VAR22, VAR42,
                                    VAR4->VAR24, &VAR4->VAR18 );

                if( VAR4->VAR38 > 0 )
                    FUN7( VAR2, VAR4->VAR18.VAR19,
                                     VAR4->VAR37, VAR4->VAR38 );

                
                VAR14->VAR43--;
            }
        }

        VAR9 = false; 
    }

    
    if( VAR4->VAR18.VAR19 == VAR28 ||
        VAR4->VAR18.VAR19 == VAR29 ||
        VAR4->VAR18.VAR19 == VAR31 )
    {
        if( VAR4->VAR44 >= 0 )
        {
            
            if( VAR4->VAR45 == 0 &&
                VAR4->VAR44  > 3 * VAR46 )
            {
                FUN3( VAR2->VAR22, VAR47 );

                
                FUN3( VAR2->VAR22, VAR48,
                                VAR49 + VAR4->VAR44 );
            }

            VAR4->VAR45 = VAR4->VAR44;

            
            VAR11 =  VAR4->VAR44;
        }
    }

    
    VAR12 = VAR4->VAR50;
    FUN8( VAR4, VAR6 );

    
    if( VAR4->VAR18.VAR51 != VAR52 )
    {
        if( VAR4->VAR44 >= 0 )
        {
            
            if( VAR4->VAR45 == 0 &&
                VAR4->VAR44  > 3 * VAR46 )
            {
                FUN3( VAR2->VAR22, VAR47 );

                
                FUN3( VAR2->VAR22, VAR48, VAR49 + VAR4->VAR44 );
            }
        }
    }

    if( VAR4->VAR18.VAR19 != VAR28 &&
        VAR4->VAR18.VAR19 != VAR29 &&
        VAR4->VAR18.VAR19 != VAR31 &&
        VAR4->VAR44 >= 0 )
    {
        VAR4->VAR45 = VAR4->VAR44;

        
        VAR11 = VAR4->VAR44;
    }

    if( !VAR9 )
    {
        
        return;
    }

    if( VAR6->VAR16 <= 0 )
        return;

    if( !( VAR8 = FUN9( VAR2, VAR6->VAR16 ) ) ) return;


    
    if ( VAR4->VAR53 > 0 )
    {
        VAR8->VAR54 |= VAR55;
        VAR4->VAR53--;
    }


    
    if( VAR11 == 0 ) VAR11 = VAR49;
    else if( VAR11 == -1 && VAR12 == 0 ) VAR11 = VAR49;
    else if( VAR11 == -1 ) VAR11 = VAR56;

    if( VAR4->VAR18.VAR51 == VAR57 )
        VAR8->VAR58 = VAR8->VAR11 = VAR11;
    else if( VAR4->VAR18.VAR51 == VAR52 )
    {
        VAR8->VAR58 = VAR8->VAR11 = VAR11;
        VAR8->VAR59 = 0;
    }
    else if( VAR4->VAR18.VAR19 == VAR30 )
    {
        VAR8->VAR58 = VAR8->VAR11 = VAR11;
        if( (VAR6->VAR60 & ((1<<VAR4->VAR61)-1)) == 0 )
        {
            VAR8->VAR54 |= VAR62;
        }
    }
    else if( VAR4->VAR18.VAR19 == VAR63 )
    {
        ogg_int64_t VAR64 = VAR6->VAR60 >> 31;
        ogg_int64_t VAR65 = (VAR6->VAR60 >> 9) & 0x1fff;

        uint64_t VAR66 = VAR64 + VAR65;

        VAR8->VAR58 = VAR4->VAR44;
        VAR8->VAR11 = VAR56;
        

        
        if( -1 != VAR6->VAR60 )
            VAR8->VAR11 = VAR66 * FUN10(1000000) / VAR4->VAR67 / 2;
    }
    else
    {
        VAR8->VAR58 = VAR11;
        VAR8->VAR11 = VAR56;
    }

    if( VAR4->VAR18.VAR19 != VAR28 &&
        VAR4->VAR18.VAR19 != VAR29 &&
        VAR4->VAR18.VAR19 != VAR31 &&
        VAR4->VAR18.VAR19 != VAR68 &&
        VAR4->VAR18.VAR19 != VAR30 &&
        VAR4->VAR18.VAR19 != VAR69 &&
        VAR4->VAR18.VAR19 != VAR63 &&
        VAR4->VAR18.VAR19 != VAR34 )
    {
        
        VAR10 = (*VAR6->VAR17 & VAR70) >> 6;
        VAR10 |= (*VAR6->VAR17 & VAR71) << 1;

        if( VAR4->VAR18.VAR19 == VAR20)
        {
            
            int VAR72, VAR73 = 0;

            if( VAR10 > 0 && VAR6->VAR16 >= VAR10 + 1 )
            {
                for( VAR72 = 0, VAR73 = 0; VAR72 < VAR10; VAR72++ )
                {
                    VAR73 = VAR73 << 8;
                    VAR73 += *(VAR6->VAR17 + VAR10 - VAR72);
                }
            }
            if( VAR6->VAR16 - 1 - VAR10 > 2 ||
                ( VAR6->VAR17[VAR10 + 1] != '' &&
                  VAR6->VAR17[VAR10 + 1] != 0 &&
                  VAR6->VAR17[VAR10 + 1] != '' &&
                  VAR6->VAR17[VAR10 + 1] != '' ) )
            {
                VAR8->VAR59 = (VAR74)VAR73 * 1000;
            }
        }

        VAR10++;
        if( VAR8->VAR75 >= (unsigned int)VAR10 )
            VAR8->VAR75 -= VAR10;
        else
            VAR8->VAR75 = 0;
    }

    if( VAR4->VAR18.VAR19 == VAR68 )
    {
        
        FUN11( VAR2, ""VAR76""VAR76,
                  VAR8->VAR11, VAR8->VAR58 );
        FUN12(10000);
    }

    memcpy( VAR8->VAR77, VAR6->VAR17 + VAR10,
            VAR6->VAR16 - VAR10 );

    FUN13( VAR2->VAR22, VAR4->VAR24, VAR8 );
}