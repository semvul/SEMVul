nsresult VAR1::FUN1(VAR2& VAR3, VAR4* VAR5)  
{
  
  FUN2();

  if (VAR3.FUN3()) {
    return VAR6;
  }

  
  
  if (!VAR5 && FUN4()) {
    VAR5 = FUN5();
  }
  
  
  VAR7* VAR8;
  VAR9* VAR10 = &VAR11;
  VAR9::iterator VAR12 = VAR10->FUN6();
  PRInt32 VAR13 = -1;
  if (VAR5) {
    
    
    

    
    if (!VAR14::FUN7(VAR5, VAR10->FUN8(),
                                        VAR12, VAR15.FUN9(),
                                        &VAR13)) {
      
      VAR8 = FUN10();
      VAR10 = VAR8 ? &VAR8->VAR11 : VAR16;
      if (VAR8) {
        VAR12 = VAR8->VAR11.FUN6();
        VAR13 = -1;
        if (!VAR14::FUN7(VAR5, VAR10->FUN8(),
                                            VAR12,
                                            VAR8->VAR15.FUN9(),
                                            &VAR13)) {
          VAR10 = VAR16;
        }
      }
      if (!VAR10) {
        
        
        FUN11("");
        VAR10 = &VAR11;
        VAR5 = VAR16;
        VAR12 = VAR10->FUN6();
      }
    }
  }

  
  
  if (VAR5) {
    
    
    PRInt32 VAR17 = VAR12->FUN12() - VAR13 - 1;
    if (VAR17) {
      
      VAR14* VAR18 = FUN13(VAR12, VAR5->FUN14(), VAR17);
      if (!VAR18) {
        return VAR19;
      }
      VAR10->FUN15(VAR12, VAR18);
      
      
      
      FUN16(VAR12, VAR10);
      
      
      VAR18->FUN17();
      VAR18->FUN18(true);
    }
  }
  else if (! VAR10->FUN19()) {
    VAR10->FUN20()->FUN17();
    VAR10->FUN20()->FUN18(true);
  }
  VAR2& VAR20 = VAR10 == &VAR11 ? VAR15 : VAR8->VAR15;
  const VAR2::VAR21& VAR22 =
    VAR20.FUN21(VAR16, VAR5, VAR3);

  
  
  for (VAR2::VAR23 FUN22(VAR22); !VAR24.FUN23(); VAR24.FUN24()) {
    VAR4* VAR25 = VAR24.FUN25();
    FUN26(!VAR5 || VAR5->FUN14() == VAR25,
                 "");
    FUN26(VAR25->FUN27() != VAR26::VAR27 ||
                 (!VAR25->FUN28()->FUN29() &&
                  !VAR25->FUN28()->FUN30()),
                 "");

    bool VAR28 = VAR25->FUN28()->FUN31();

    
    
    
    
    
    if (VAR28 || VAR12 == VAR10->FUN6() || VAR12->FUN32() ||
        (VAR5 && FUN33(VAR5))) {
      
      
      VAR14* VAR18 = FUN13(VAR25, VAR28);
      if (!VAR18) {
        return VAR19;
      }
      if (VAR12 != VAR10->FUN6()) {
        
        VAR10->FUN15(VAR12, VAR18);
        ++VAR12;
      }
      else {
        
        VAR10->FUN34(VAR18);
        VAR12 = VAR10->FUN8();
      }
    }
    else {
      VAR12->FUN35(VAR25);
      
      
      
      FUN16(VAR12, VAR10);
    }

    VAR5 = VAR25;
  }

#ifdef VAR29
  FUN36(true);
#endif
  return VAR6;
}