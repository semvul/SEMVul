void VAR1::FUN1(VAR2* VAR3)  
{
  FUN2(VAR3, "");
  FUN2(VAR3->FUN3(),
                  "");

  for (VAR2* VAR4 = VAR3; VAR4; ) {
    
    
    VAR2* VAR5 = VAR4->FUN3();
    if (VAR6 &&
        VAR6->FUN4() == VAR5 &&
        (!VAR5->FUN5() ||
         VAR5->FUN5() == VAR5->FUN3())) {
      VAR6 = VAR7;
      VAR8 = VAR7;
      VAR9 = VAR7;
      VAR10 = static_cast<VAR11*>(VAR4->FUN6());
      break;
    }
    if (VAR4 == VAR9) {
      
      VAR2* VAR12 = VAR8;
      FUN7();
      if (VAR8 == VAR5) {
        
        
        VAR8 = VAR12;
      }
    }
    VAR4 = VAR5;
  }
}