static int FUN1(u8 VAR1, VAR2 *VAR3, size_t VAR4, VAR2 *VAR5, size_t VAR6)  
{
	const VAR2 *VAR7 = FUN2(VAR1, VAR3, VAR4);
	const VAR2 *VAR8 = FUN2(VAR1, VAR5, VAR6);
	int VAR9;

	if (!VAR7 && !VAR8)
		return 0;
	if (!VAR7 || !VAR8)
		return -1;

	VAR9 = memcmp(VAR7 + 2, VAR8 + 2, FUN3(VAR7[1], VAR8[1]));
	if (VAR9 == 0 && VAR7[1] != VAR8[1])
		return VAR8[1] - VAR7[1];
	return VAR9;
}