void VAR1::FUN1(const char *VAR2,                                    VAR3 *VAR4,                                    char **VAR5)  
{
    
    
    
    
    
    
    
    
    
    
    
    
    

    char *VAR6 = (char *) strchr(VAR2, '');
    if (!VAR6) {
        FUN2(("", VAR2));
        return;
    }

    
    if (!VAR7::FUN3(VAR2, VAR6)) {
        FUN2(("", VAR2));
        return;
    }
    
    *VAR6 = 0; 

    nsHttpAtom VAR8 = VAR7::FUN4(VAR2);
    if (!VAR8) {
        FUN2(("", VAR2));
        return;
    }

    
    VAR6 = FUN5(++VAR6, VAR9);

    
    char *VAR10 = FUN6(VAR6, VAR9);

    *++VAR10 = 0; 
               
               

    
    if (VAR4) *VAR4 = VAR8;
    if (VAR5) *VAR5 = VAR6;

    
    FUN7(VAR8, FUN8(VAR6, VAR10 - VAR6), VAR11, VAR12);
}