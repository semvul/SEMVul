struct VAR1 *FUN1(const char *VAR2, const char *VAR3, struct VAR1 *VAR4, int *VAR5)  
{
	struct VAR1 *VAR6;
	char *VAR7;
	struct VAR1 *VAR8 = NULL;
	struct VAR1 *VAR9;
	int VAR10;
	char *VAR11 = FUN2(VAR3);

	VAR9 = VAR4;
	while (VAR4) {
		VAR8 = VAR4;
		VAR4 = VAR4->VAR12;
	}

	VAR6 = FUN3(sizeof(*VAR6));
	if (!VAR6)
		return VAR9;

	VAR7 = strchr(VAR11, '');
	if (!VAR7) {
		
		VAR6->VAR13.VAR14 = FUN4(0xFFFFFFFF);
	} else {
		*VAR7 = '';
		VAR7++;

		if (!strchr(VAR7, '')) {
			if ((sscanf(VAR7, "", &VAR10) == 1) && (VAR10 >= 0) && (VAR10 <= 32))
				if (VAR10 == 0) {
					
					VAR6->VAR13.VAR14 = 0;
				} else {
					VAR6->VAR13.VAR14 = FUN4(0xFFFFFFFF << (32 - VAR10));
				}
			else {
				FUN5(VAR15, "", VAR3);
				FUN6(VAR6);
				if (VAR5)
					*VAR5 = 1;
				return VAR9;
			}
		} else if (!FUN7(VAR7, &VAR6->VAR13)) {
			FUN5(VAR15, "", VAR3);
			FUN6(VAR6);
			if (VAR5)
				*VAR5 = 1;
			return VAR9;
		}
	}

	if (!FUN7(VAR11, &VAR6->VAR16)) {
		FUN5(VAR15, "", VAR3);
		FUN6(VAR6);
		if (VAR5)
			*VAR5 = 1;
		return VAR9;
	}

	VAR6->VAR16.VAR14 &= VAR6->VAR13.VAR14;

	VAR6->VAR2 = FUN8(VAR2, "", 1) ? VAR17 : VAR18;

	VAR6->VAR12 = NULL;
	if (VAR8) {
		VAR8->VAR12 = VAR6;
	} else {
		VAR9 = VAR6;
	}

	FUN9(1, "", FUN2(FUN10(VAR6->VAR16)), FUN2(FUN10(VAR6->VAR13)), VAR6->VAR2);

	return VAR9;
}