nsresult VAR1::FUN1(VAR2* VAR3, VAR4& VAR5)  
{
  FUN2(VAR3, "");

  VAR5.FUN3();

  VAR6<VAR2> VAR7 = FUN4(VAR3);
  FUN5(VAR7, VAR8);

  nsCString VAR9;
  nsresult VAR10 = VAR7->FUN6(VAR9);

  if (FUN7(VAR10) && !VAR9.FUN8()) {
    nsCString VAR11;
    VAR10 = VAR7->FUN9(VAR11);
    FUN10(VAR10, VAR10);

    PRInt32 VAR12 = -1;
    VAR7->FUN11(&VAR12);
    if (VAR12 != -1 && VAR12 == FUN12(VAR11.FUN13()))
      VAR12 = -1;

    nsCString VAR13;
    VAR10 = FUN14(VAR9, VAR12, VAR13);
    FUN10(VAR10, VAR10);

    VAR5 = VAR11 + FUN15("") + VAR13;
  }
  else {
    VAR5.FUN16("");
  }

  return VAR14;
}