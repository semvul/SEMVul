NS_IMETHODIMP VAR1::FUN1(const VAR2& VAR3,                                 PRUint32 VAR4,                                 VAR5** VAR6)  
{
  *VAR6 = VAR7;

  if (VAR3.FUN2())
    return VAR8;

  if (VAR4 >= VAR9.FUN3())
    return VAR10;

  nsAutoString VAR11;
  FUN4(VAR3, VAR11);

  VAR12<VAR13>& VAR14 = VAR9[VAR4];

  
  
  

  PRUint32 VAR15 = VAR14.FUN3();
  for (PRUint32 VAR16 = 0; VAR16 < VAR15; VAR16++) {
    VAR13& VAR17 = VAR14[VAR16];
    if (VAR17.VAR18.FUN5(VAR11)) {
      if (VAR17.VAR19 &&
          !VAR20::FUN6("")) {
        if (VAR21 != VAR22 && VAR21 != VAR23) {
          PRBool VAR24;
          VAR25* VAR26 = FUN7();
          if (VAR26 &&
              (FUN8(VAR26->FUN9(VAR17.VAR19, &VAR24)) ||
               !VAR24))
            return VAR27;
        } else {
          VAR28 *VAR29 = VAR20::FUN10();
          PRBool VAR30;
          if (FUN8(VAR29->FUN11(VAR17.VAR19, &VAR30)) ||
              VAR30)
            return VAR27;
        }
      }

      if (!VAR17.VAR31)
        FUN12(VAR17, VAR4);
      *VAR6 = VAR17.VAR31;
      FUN13(*VAR6);
      return VAR8;
    }
  }

  return VAR8;
}