static int FUN1(struct VAR1 *VAR2, void VAR3 * VAR3 *VAR4)  
{
	struct VAR5 *VAR5 = VAR2->VAR5;
	struct usbdevfs_urb32 VAR3 *VAR6 = VAR2->VAR6;
	void VAR3 *VAR7 = VAR2->VAR6;
	unsigned int VAR8;

	if (VAR2->VAR9)
		if (FUN2(VAR2->VAR9, VAR5->VAR10,
				 VAR5->VAR11))
			return -VAR12;
	if (FUN3(VAR2->VAR13, &VAR6->VAR13))
		return -VAR12;
	if (FUN3(VAR5->VAR14, &VAR6->VAR14))
		return -VAR12;
	if (FUN3(VAR5->VAR15, &VAR6->VAR15))
		return -VAR12;

	if (FUN4(&VAR5->VAR16->VAR17)) {
		for (VAR8 = 0; VAR8 < VAR5->VAR18; VAR8++) {
			if (FUN3(VAR5->VAR19[VAR8].VAR14,
				     &VAR6->VAR19[VAR8].VAR14))
				return -VAR12;
			if (FUN3(VAR5->VAR19[VAR8].VAR13,
				     &VAR6->VAR19[VAR8].VAR13))
				return -VAR12;
		}
	}

	if (FUN3(FUN5(VAR7), (u32 VAR3 *)VAR4))
		return -VAR12;
	return 0;
}