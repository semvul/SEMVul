char * FUN1(char *VAR1, const VAR2 *VAR3, guint32 VAR4, char VAR5)  
{
  guint32 VAR6;

  if (!VAR3)
    FUN2("");

  VAR1 = FUN3(VAR1, VAR3[0]);
  for (VAR6 = 1; VAR6 < VAR4; VAR6++) {
    *VAR1++ = VAR5;
    VAR1 = FUN3(VAR1, VAR3[VAR6]);
  }
  return VAR1;
}