int FUN1(void)  
{
	int VAR1, VAR2, VAR3;
	int VAR4;
	struct VAR5 *VAR6;
	struct pollfd VAR7;
	struct VAR8 *VAR9;
	struct VAR5	*VAR10;
	struct VAR11 *VAR12;
	char	*VAR13;
	char	*VAR14;
	char	*VAR15;

	FUN2(1, 0);
	FUN3("", 0, VAR16);
	syslog(VAR17, "", FUN4());
	
	FUN5();

	if (FUN6()) {
		syslog(VAR18, "");
		FUN7(-1);
	}

	VAR1 = socket(VAR19, VAR20, VAR21);
	if (VAR1 < 0) {
		syslog(VAR18, "", VAR1);
		FUN7(-1);
	}
	VAR22.VAR23 = VAR19;
	VAR22.VAR24 = 0;
	VAR22.VAR25 = 0;
	VAR22.VAR26 = VAR27;


	VAR4 = FUN8(VAR1, (struct VAR28 *)&VAR22, sizeof(VAR22));
	if (VAR4 < 0) {
		syslog(VAR18, "", VAR4);
		close(VAR1);
		FUN7(-1);
	}
	VAR3 = VAR22.VAR26;
	FUN9(VAR1, 270, 1, &VAR3, sizeof(VAR3));
	
	VAR6 = (struct VAR5 *)VAR29;
	VAR6->VAR30.VAR31 = VAR27;
	VAR6->VAR30.VAR32 = VAR33;

	VAR12 = (struct VAR11 *)VAR6->VAR34;
	VAR12->VAR35.VAR36 = VAR37;
	VAR6->VAR38 = 0;
	VAR6->VAR2 = sizeof(struct VAR11);

	VAR2 = FUN10(VAR1, VAR6);
	if (VAR2 < 0) {
		syslog(VAR18, "", VAR2);
		close(VAR1);
		FUN7(-1);
	}

	VAR7.VAR1 = VAR1;

	while (1) {
		struct VAR28 *VAR39 = (struct VAR28 *) &VAR22;
		socklen_t VAR40 = sizeof(VAR22);
		VAR7.VAR41 = VAR42;
		VAR7.VAR43 = 0;
		FUN11(&VAR7, 1, -1);

		VAR2 = recvfrom(VAR1, VAR44, sizeof(VAR44), 0,
				VAR39, &VAR40);

		if (VAR2 < 0 || VAR22.VAR25) {
			syslog(VAR18, "",
					VAR22.VAR25, VAR45, strerror(VAR45));
			close(VAR1);
			return -1;
		}

		VAR9 = (struct VAR8 *)VAR44;
		VAR10 = (struct VAR5 *)FUN12(VAR9);
		VAR12 = (struct VAR11 *)VAR10->VAR34;

		switch (VAR12->VAR35.VAR36) {
		case VAR37:
			
			VAR13 = (char *)VAR12->VAR46.VAR47.VAR48;
			VAR49 = malloc(strlen(VAR13) + 1);
			if (VAR49) {
				strcpy(VAR49, VAR13);
				syslog(VAR17, "",
					VAR49);
			} else {
				syslog(VAR18, "");
			}
			continue;

		

		case VAR50:
			if (FUN13(VAR12->VAR35.VAR51,
					VAR12->VAR46.VAR52.VAR34.VAR53,
					VAR12->VAR46.VAR52.VAR34.VAR54,
					VAR12->VAR46.VAR52.VAR34.VAR55,
					VAR12->VAR46.VAR52.VAR34.VAR56))
				strcpy(VAR12->VAR46.VAR52.VAR34.VAR53, "");
			break;

		case VAR57:
			if (FUN14(VAR12->VAR35.VAR51,
					VAR12->VAR46.VAR52.VAR34.VAR53,
					VAR12->VAR46.VAR52.VAR34.VAR54,
					VAR12->VAR46.VAR52.VAR34.VAR55,
					VAR12->VAR46.VAR52.VAR34.VAR56))
				strcpy(VAR12->VAR46.VAR52.VAR34.VAR53, "");
			break;

		case VAR58:
			if (FUN15(VAR12->VAR35.VAR51,
					VAR12->VAR46.VAR59.VAR53,
					VAR12->VAR46.VAR59.VAR54))
				strcpy(VAR12->VAR46.VAR59.VAR53, "");
			break;

		default:
			break;
		}

		if (VAR12->VAR35.VAR36 != VAR60)
			goto VAR61;

		
		if (VAR12->VAR35.VAR51 != VAR62) {
			FUN16(VAR12->VAR35.VAR51,
					VAR12->VAR46.VAR63.VAR64,
					VAR12->VAR46.VAR63.VAR34.VAR53,
					VAR65,
					VAR12->VAR46.VAR63.VAR34.VAR55,
					VAR66);
			goto VAR61;
		}

		VAR12 = (struct VAR11 *)VAR10->VAR34;
		VAR15 = (char *)VAR12->VAR46.VAR63.VAR34.VAR53;
		VAR14 = (char *)VAR12->VAR46.VAR63.VAR34.VAR55;

		switch (VAR12->VAR46.VAR63.VAR64) {
		case VAR67:
			FUN17(VAR14,
					VAR66);
			strcpy(VAR15, "");
			break;
		case VAR68:
			strcpy(VAR15, "");
			strcpy(VAR14, VAR49);
			break;
		case VAR69:
			FUN18(VAR70, VAR14,
					VAR66);
			strcpy(VAR15, "");
			break;
		case VAR71:
			FUN18(VAR72, VAR14,
					VAR66);
			strcpy(VAR15, "");
			break;
		case VAR73:
			strcpy(VAR14, VAR74);
			strcpy(VAR15, "");
			break;
		case VAR75:
			strcpy(VAR14, VAR76);
			strcpy(VAR15, "");
			break;
		case VAR77:
			strcpy(VAR14, VAR78);
			strcpy(VAR15, "");
			break;
		case VAR79:
			strcpy(VAR14, VAR80);
			strcpy(VAR15, "");
			break;
		case VAR81:
			strcpy(VAR14, VAR74);
			strcpy(VAR15, "");
			break;
		case VAR82:
			strcpy(VAR14, VAR83);
			strcpy(VAR15, "");
			break;
		default:
			strcpy(VAR14, "");
			
			strcpy(VAR15, "");
			break;
		}
		
VAR61:

		VAR10->VAR30.VAR31 = VAR27;
		VAR10->VAR30.VAR32 = VAR33;
		VAR10->VAR38 = 0;
		VAR10->VAR2 = sizeof(struct VAR11);

		VAR2 = FUN10(VAR1, VAR10);
		if (VAR2 < 0) {
			syslog(VAR18, "", VAR2);
			FUN7(-1);
		}
	}

}