struct VAR1 *FUN1(struct VAR2 *VAR3, unsigned long VAR4, 				     unsigned long VAR5, int VAR6, 				     int *VAR7)  
{
	struct VAR1 *VAR8;
	gfp_t VAR9;
	long VAR10;
	int VAR11;
	int VAR12 = (VAR5 + (VAR13 - 1)) >> VAR14;

	VAR11 = -VAR15;
	if (VAR12 > VAR16)
		goto VAR17;

	VAR9 = VAR3->VAR18;
	if (VAR9 & VAR19)
		VAR9 |= VAR20;

	VAR10 = FUN2(VAR3, VAR6);
	while (1) {
		VAR11 = FUN3(VAR3);
		if (VAR11 != 0)
			goto VAR17;

		VAR11 = -VAR21;
		if (VAR3->VAR22 & VAR23)
			goto VAR17;

		if (FUN4(&VAR3->VAR24) < VAR3->VAR25) {
			VAR8 = FUN5(VAR4, VAR9);
			if (VAR8) {
				int VAR26;

				
				if (!VAR5)
					break;

				VAR8->VAR27 += VAR5;
				FUN6(VAR8)->VAR28 = VAR12;
				for (VAR26 = 0; VAR26 < VAR12; VAR26++) {
					struct VAR29 *VAR29;
					VAR30 *VAR31;

					VAR29 = FUN7(VAR3->VAR18, 0);
					if (!VAR29) {
						VAR11 = -VAR32;
						FUN6(VAR8)->VAR28 = VAR26;
						FUN8(VAR8);
						goto VAR17;
					}

					VAR31 = &FUN6(VAR8)->VAR33[VAR26];
					VAR31->VAR29 = VAR29;
					VAR31->VAR34 = 0;
					VAR31->VAR35 = (VAR5 >= VAR13 ?
						      VAR13 :
						      VAR5);
					VAR5 -= VAR13;
				}

				
				break;
			}
			VAR11 = -VAR32;
			goto VAR17;
		}
		FUN9(VAR36, &VAR3->VAR37->VAR38);
		FUN9(VAR39, &VAR3->VAR37->VAR38);
		VAR11 = -VAR40;
		if (!VAR10)
			goto VAR17;
		if (FUN10(VAR41))
			goto VAR42;
		VAR10 = FUN11(VAR3, VAR10);
	}

	FUN12(VAR8, VAR3);
	return VAR8;

VAR42:
	VAR11 = FUN13(VAR10);
VAR17:
	*VAR7 = VAR11;
	return NULL;
}