static VAR1 FUN1(VAR2 *VAR3, VAR4 *VAR5, VAR6 *VAR7)  
{
    VAR8 *VAR9 = FUN2(*VAR5);

    if (!VAR7->VAR10.FUN3(''))
        return VAR11;

    jsval VAR12[4] = {VAR13, VAR13, VAR13, *VAR5};
    VAR14 FUN4(VAR3, 4, VAR12);
    VAR4& VAR15 = VAR12[0];
    VAR4& VAR16 = VAR12[1];

    VAR8 *VAR17 = NULL;
    VAR4 *VAR18 = VAR5;
    bool VAR19 = false;

    
    if (VAR7->VAR20 && FUN5(VAR3, VAR7->VAR20)) {
        VAR19 = true;
        VAR12[2] = FUN6(VAR7->VAR20);
        VAR18 = &VAR12[2];
    }

    if (!FUN7(VAR3, VAR21, VAR18))
        return VAR11;
    VAR17 = FUN2(*VAR18);

    JSBool VAR22 = VAR11;

    bool VAR23 = false;
    while (true) {
        VAR16 = VAR24;
        if (!FUN8(VAR3, VAR17, &VAR15))
            goto VAR25;
        if (VAR15 == VAR26)
            break;

        jsuint VAR27 = 0;
        if (VAR19) {
            
            if (!FUN9(VAR15, &VAR27))
                continue;

            jsval VAR28;
            if (!VAR7->VAR20->FUN10(VAR3, VAR15, &VAR28))
                goto VAR25;
            VAR15 = VAR28;
        }

        VAR29 *VAR30;
        if (FUN11(VAR15)) {
            VAR30 = FUN12(VAR15);
        } else {
            VAR30 = FUN13(VAR3, VAR15);
            if (!VAR30)
                goto VAR25;
        }
        VAR14 FUN14(VAR3, VAR30);

        
        
        jsid VAR31;
        jsval VAR32 = VAR11;
        if (!FUN15(VAR3, FUN16(VAR30), &VAR31) ||
            !FUN17(VAR3, VAR9->VAR33->VAR34->VAR35, VAR9, VAR31, &VAR32)) {
            goto VAR25;
        }

        if (VAR32 != VAR36)
            continue;

        if (!FUN18(VAR3, VAR9, VAR31, &VAR16))
            goto VAR25;

        if (FUN19(VAR16) && !FUN20(VAR3, &VAR16))
            goto VAR25;

        
        
        if (!FUN21(VAR3, VAR31, VAR9, VAR7, &VAR16))
            goto VAR25;

        JSType VAR37 = FUN22(VAR3, VAR16);

        
        if (VAR16 == VAR24 || VAR37 == VAR38 || VAR37 == VAR39)
            continue;

        
        if (VAR22 && !VAR7->VAR10.FUN3(''))
            goto VAR25;
        VAR22 = VAR40;

        if (!FUN23(VAR3, VAR7, VAR7->VAR41))
            goto VAR25;

        
        VAR29 *VAR42 = FUN13(VAR3, VAR15);
        if (!VAR42)
            goto VAR25;

        const VAR43 *VAR44;
        size_t VAR45;
        VAR42->FUN24(VAR44, VAR45);
        if (!FUN25(VAR3, VAR7->VAR10, VAR44, VAR45) ||
            !VAR7->VAR10.FUN3('') ||
            !FUN26(VAR3, VAR31, VAR9, VAR7, &VAR16, false)) {
            goto VAR25;
        }
    }
    VAR23 = true;

  VAR25:
    if (VAR17) {
        
        FUN27(FUN6(VAR17) == *VAR18);
        VAR23 &= FUN28(VAR3, *VAR18);
    }

    if (!VAR23)
        return VAR11;

    if (VAR22 && !FUN23(VAR3, VAR7, VAR7->VAR41 - 1))
        return VAR11;

    return VAR7->VAR10.FUN3('');
}