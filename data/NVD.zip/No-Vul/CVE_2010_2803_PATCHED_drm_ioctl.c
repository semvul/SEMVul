long FUN1(struct VAR1 *VAR2, 	      unsigned int VAR3, unsigned long VAR4)  
{
	struct VAR5 *VAR6 = VAR2->VAR7;
	struct VAR8 *VAR9;
	struct VAR10 *VAR11;
	VAR12 *VAR13;
	unsigned int VAR14 = FUN2(VAR3);
	int VAR15 = -VAR16;
	char VAR17[128];
	char *VAR18 = NULL;

	VAR9 = VAR6->VAR19->VAR9;
	FUN3(&VAR9->VAR20);
	FUN3(&VAR9->VAR21[VAR22]);
	++VAR6->VAR20;

	FUN4("",
		  FUN5(VAR23), VAR3, VAR14,
		  (long)FUN6(VAR6->VAR19->VAR24),
		  VAR6->VAR25);

	if ((VAR14 >= VAR26) &&
	    ((VAR14 < VAR27) || (VAR14 >= VAR28)))
		goto VAR29;
	if ((VAR14 >= VAR27) && (VAR14 < VAR28) &&
	    (VAR14 < VAR27 + VAR9->VAR30->VAR31))
		VAR11 = &VAR9->VAR30->VAR32[VAR14 - VAR27];
	else if ((VAR14 >= VAR28) || (VAR14 < VAR27)) {
		VAR11 = &VAR33[VAR14];
		VAR3 = VAR11->VAR3;
	} else
		goto VAR29;

	
	VAR13 = VAR11->VAR13;
	
	if ((VAR14 == FUN2(VAR34)) && VAR9->VAR30->VAR35)
		VAR13 = VAR9->VAR30->VAR35;

	if (!VAR13) {
		FUN4("");
		VAR15 = -VAR16;
	} else if (((VAR11->VAR36 & VAR37) && !FUN7(VAR38)) ||
		   ((VAR11->VAR36 & VAR39) && !VAR6->VAR25) ||
		   ((VAR11->VAR36 & VAR40) && !VAR6->VAR41) ||
		   (!(VAR11->VAR36 & VAR42) && (VAR6->VAR19->VAR43 == VAR44))) {
		VAR15 = -VAR45;
	} else {
		if (VAR3 & (VAR46 | VAR47)) {
			if (FUN8(VAR3) <= sizeof(VAR17)) {
				VAR18 = VAR17;
			} else {
				VAR18 = FUN9(FUN8(VAR3), VAR48);
				if (!VAR18) {
					VAR15 = -VAR49;
					goto VAR29;
				}
			}
		}

		if (VAR3 & VAR46) {
			if (FUN10(VAR18, (void VAR50 *)VAR4,
					   FUN8(VAR3)) != 0) {
				VAR15 = -VAR51;
				goto VAR29;
			}
		} else
			memset(VAR18, 0, FUN8(VAR3));

		if (VAR11->VAR36 & VAR52)
			VAR15 = FUN11(VAR9, VAR18, VAR6);
		else {
			FUN12();
			VAR15 = FUN11(VAR9, VAR18, VAR6);
			FUN13();
		}

		if (VAR3 & VAR47) {
			if (FUN14((void VAR50 *)VAR4, VAR18,
					 FUN8(VAR3)) != 0)
				VAR15 = -VAR51;
		}
	}

      VAR29:
	if (VAR18 != VAR17)
		FUN15(VAR18);
	FUN16(&VAR9->VAR20);
	if (VAR15)
		FUN4("", VAR15);
	return VAR15;
}