int FUN1(VAR1 *VAR2, struct VAR3 *VAR3, 			ext4_lblk_t VAR4, 			unsigned int VAR5, struct VAR6 *VAR7, 			int VAR8)  
{
	struct VAR9 *VAR10 = NULL;
	struct VAR11 *VAR12;
	struct ext4_extent VAR13, *VAR14;
	ext4_fsblk_t VAR15;
	int VAR16 = 0, VAR17, VAR18, VAR19;
	unsigned int VAR20 = 0;
	struct ext4_allocation_request VAR21;
	VAR22 *VAR23 = FUN2(VAR3)->VAR24;

	FUN3(VAR25, &VAR7->VAR26);
	FUN4("",
			VAR4, VAR5, VAR3->VAR27);

	
	VAR19 = FUN5(VAR3, VAR4, &VAR13);
	if (VAR19) {
		if (VAR19 == VAR28) {
			if ((VAR8 & VAR29) == 0) {
				
				goto VAR30;
			}
			
		} else if (VAR19 == VAR31) {
			
			VAR15 = VAR4
				   - FUN6(VAR13.VAR32)
				   + FUN7(&VAR13);
			
			VAR20 = FUN8(&VAR13) -
					(VAR4 - FUN6(VAR13.VAR32));
			goto VAR33;
		} else {
			FUN9();
		}
	}

	
	VAR10 = FUN10(VAR3, VAR4, NULL);
	if (FUN11(VAR10)) {
		VAR16 = FUN12(VAR10);
		VAR10 = NULL;
		goto VAR30;
	}

	VAR17 = FUN13(VAR3);

	
	if (VAR10[VAR17].VAR34 == NULL && VAR17 != 0) {
		FUN14(VAR3->VAR35, VAR36, ""
			   "",
			   VAR3->VAR27, VAR4, VAR17);
		VAR16 = -VAR37;
		goto VAR30;
	}
	VAR12 = VAR10[VAR17].VAR38;

	VAR14 = VAR10[VAR17].VAR34;
	if (VAR14) {
		ext4_lblk_t VAR32 = FUN6(VAR14->VAR32);
		ext4_fsblk_t VAR39 = FUN7(VAR14);
		unsigned short VAR40;

		
		VAR40 = FUN8(VAR14);
		
		if (FUN15(VAR4, VAR32, VAR40)) {
			VAR15 = VAR4 - VAR32 + VAR39;
			
			VAR20 = VAR40 - (VAR4 - VAR32);
			FUN4("", VAR4,
					VAR32, VAR40, VAR15);

			
			if (!FUN16(VAR14)) {
				FUN17(VAR3, VAR32,
							VAR40, VAR39,
							VAR31);
				goto VAR33;
			}
			VAR18 = FUN18(VAR2,
					VAR3, VAR4, VAR5, VAR10,
					VAR8, VAR20, VAR7, VAR15);
			return VAR18;
		}
	}

	
	if ((VAR8 & VAR29) == 0) {
		
		FUN19(VAR3, VAR10, VAR4);
		goto VAR30;
	}
	

	
	VAR21.VAR41 = VAR4;
	VAR16 = FUN20(VAR3, VAR10, &VAR21.VAR41, &VAR21.VAR42);
	if (VAR16)
		goto VAR30;
	VAR21.VAR43 = VAR4;
	VAR16 = FUN21(VAR3, VAR10, &VAR21.VAR43, &VAR21.VAR44);
	if (VAR16)
		goto VAR30;

	
	if (VAR5 > VAR45 &&
	    !(VAR8 & VAR46))
		VAR5 = VAR45;
	else if (VAR5 > VAR47 &&
		 (VAR8 & VAR46))
		VAR5 = VAR47;

	
	VAR13.VAR32 = FUN22(VAR4);
	VAR13.VAR40 = FUN23(VAR5);
	VAR16 = FUN24(VAR3, &VAR13, VAR10);
	if (VAR16)
		VAR20 = FUN8(&VAR13);
	else
		VAR20 = VAR5;

	
	VAR21.VAR3 = VAR3;
	VAR21.VAR48 = FUN25(VAR3, VAR10, VAR4);
	VAR21.VAR49 = VAR4;
	VAR21.VAR50 = VAR20;
	if (FUN26(VAR3->VAR51))
		VAR21.VAR8 = VAR52;
	else
		
		VAR21.VAR8 = 0;
	VAR15 = FUN27(VAR2, &VAR21, &VAR16);
	if (!VAR15)
		goto VAR30;
	FUN4("",
		  VAR21.VAR48, VAR15, VAR20);

	
	FUN28(&VAR13, VAR15);
	VAR13.VAR40 = FUN23(VAR21.VAR50);
	
	if (VAR8 & VAR46){
		FUN29(&VAR13);
		
		if (VAR8 == VAR53) {
			if (VAR23)
				VAR23->VAR54 = VAR55;
			else
				FUN2(VAR3)->VAR56 |=
					VAR57;;
		}
	}
	VAR16 = FUN30(VAR2, VAR3, VAR10, &VAR13, VAR8);
	if (VAR16) {
		
		
		FUN31(VAR3);
		FUN32(VAR2, VAR3, 0, FUN7(&VAR13),
				 FUN8(&VAR13), 0);
		goto VAR30;
	}

	
	VAR15 = FUN7(&VAR13);
	VAR20 = FUN8(&VAR13);
	if (VAR20 > VAR5)
		VAR20 = VAR5;
	FUN33(VAR7);

	
	if (VAR8 & VAR58)
		FUN34(VAR3, VAR20, 1);

	
	if ((VAR8 & VAR46) == 0) {
		FUN17(VAR3, VAR4, VAR20, VAR15,
						VAR31);
		FUN35(VAR2, VAR3, 1);
	} else
		FUN35(VAR2, VAR3, 0);
VAR33:
	if (VAR20 > VAR5)
		VAR20 = VAR5;
	FUN36(VAR3, VAR10);
	FUN37(VAR7);
	VAR7->VAR59 = VAR3->VAR35->VAR60;
	VAR7->VAR61 = VAR15;
VAR30:
	if (VAR10) {
		FUN38(VAR10);
		FUN39(VAR10);
	}
	return VAR16 ? VAR16 : VAR20;
}