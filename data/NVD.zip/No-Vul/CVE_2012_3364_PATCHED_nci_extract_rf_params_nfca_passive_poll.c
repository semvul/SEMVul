static VAR1 *FUN1(struct VAR2 *VAR3, 			struct VAR4 *VAR5, 						     VAR1 *VAR6)  
{
	VAR5->VAR7 = FUN2(*((VAR8 *)VAR6));
	VAR6 += 2;

	VAR5->VAR9 = FUN3(VAR1, *VAR6++, VAR10);

	FUN4("",
		 VAR5->VAR7, VAR5->VAR9);

	memcpy(VAR5->VAR11, VAR6, VAR5->VAR9);
	VAR6 += VAR5->VAR9;

	VAR5->VAR12 = *VAR6++;

	if (VAR5->VAR12 != 0)
		VAR5->VAR13 = *VAR6++;

	FUN4("",
		 VAR5->VAR12,
		 VAR5->VAR13);

	return VAR6;
}