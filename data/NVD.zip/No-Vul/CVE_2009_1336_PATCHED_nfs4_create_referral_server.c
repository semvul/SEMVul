struct VAR1 *FUN1(struct VAR2 *VAR3, 					       struct VAR4 *VAR5)  
{
	struct VAR6 *VAR7;
	struct VAR1 *VAR8, *VAR9;
	struct nfs_fattr VAR10;
	int VAR11;

	FUN2("");

	VAR8 = FUN3();
	if (!VAR8)
		return FUN4(-VAR12);

	VAR9 = FUN5(VAR3->VAR13);
	VAR7 = VAR9->VAR6;

	
	VAR11 = FUN6(VAR8, VAR3->VAR14, VAR3->VAR15,
			VAR7->VAR16,
			VAR3->VAR17,
			VAR9->VAR18->VAR19->VAR20,
			VAR7->VAR21,
			VAR7->VAR22);
	if (VAR11 < 0)
		goto VAR11;

	
	FUN7(VAR8, VAR9);
	VAR8->VAR23 |= VAR24;

	VAR11 = FUN8(VAR8, VAR3->VAR17);
	if (VAR11 < 0)
		goto VAR11;

	FUN9(!VAR8->VAR6);
	FUN9(!VAR8->VAR6->VAR25);
	FUN9(!VAR8->VAR6->VAR25->VAR26);

	
	VAR11 = FUN10(VAR8, VAR5, VAR3->VAR27);
	if (VAR11 < 0)
		goto VAR11;

	
	VAR11 = FUN11(VAR8, VAR5, &VAR10);
	if (VAR11 < 0)
		goto VAR11;

	if (VAR8->VAR28 == 0 || VAR8->VAR28 > VAR29)
		VAR8->VAR28 = VAR29;

	FUN2("",
		(unsigned long long) VAR8->VAR30.VAR31,
		(unsigned long long) VAR8->VAR30.VAR32);

	FUN12(&VAR33);
	FUN13(&VAR8->VAR34, &VAR8->VAR6->VAR35);
	FUN13(&VAR8->VAR36, &VAR37);
	FUN14(&VAR33);

	VAR8->VAR38 = VAR39;

	FUN2("", VAR8);
	return VAR8;

VAR11:
	FUN15(VAR8);
	FUN2("", VAR11);
	return FUN4(VAR11);
}