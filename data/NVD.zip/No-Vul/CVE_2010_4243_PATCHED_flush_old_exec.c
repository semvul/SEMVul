int FUN1(struct VAR1 * VAR2)  
{
	int VAR3;

	
	VAR3 = FUN2(VAR4);
	if (VAR3)
		goto VAR5;

	FUN3(VAR2->VAR6, VAR2->VAR7);

	
	FUN4(VAR2, 0);
	VAR3 = FUN5(VAR2->VAR6);
	if (VAR3)
		goto VAR5;

	VAR2->VAR6 = NULL;		

	VAR4->VAR8 &= ~VAR9;
	FUN6();
	VAR4->VAR10 &= ~VAR2->VAR11;

	return 0;

VAR5:
	return VAR3;
}