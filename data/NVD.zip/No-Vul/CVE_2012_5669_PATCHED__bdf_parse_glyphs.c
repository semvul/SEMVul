static VAR1   FUN1( char*          VAR2,                      unsigned long  VAR3,                      unsigned long  VAR4,                      void*          VAR5,                      void*          VAR6 )    
{
    int                VAR7, VAR8;
    char*              VAR9;
    unsigned char*     VAR10;
    unsigned long      VAR11, VAR12, VAR13;

    VAR14*      VAR15;
    VAR16*       VAR17;
    VAR18*        VAR19;

    FT_Memory          VAR20;
    FT_Error           VAR21 = VAR22;

    FUN2( VAR5 );
    FUN2( VAR4 );        


    VAR15 = (VAR14 *)VAR6;

    VAR19   = VAR15->VAR19;
    VAR20 = VAR19->VAR20;

    
    if ( FUN3( VAR2, "", 7 ) == 0 )
    {
      VAR3 -= 7;

      VAR9 = VAR2 + 7;
      if ( *VAR9 != 0 )
      {
        VAR9++;
        VAR3--;
      }
      VAR21 = FUN4( VAR15->VAR19, VAR9, VAR3 );
      goto VAR23;
    }

    
    if ( !( VAR15->VAR24 & VAR25 ) )
    {
      if ( FUN3( VAR2, "", 5 ) != 0 )
      {
        FUN5(( "" VAR26, VAR4, "" ));
        VAR21 = VAR27;
        goto VAR23;
      }

      VAR21 = FUN6( &VAR15->VAR28, (char *)"", VAR2, VAR3 );
      if ( VAR21 )
        goto VAR23;
      VAR15->VAR29 = VAR19->VAR30 = FUN7( VAR15->VAR28.VAR31[1], 0, 10 );

      
      if ( VAR15->VAR29 == 0 )
        VAR19->VAR30 = 64;

      
      
      if ( VAR15->VAR29 >= 0x110000UL )
      {
        FUN5(( "" VAR32, VAR4, "" ));
        VAR21 = VAR33;
        goto VAR23;
      }

      if ( FUN8( VAR19->VAR34, VAR19->VAR30 ) )
        goto VAR23;

      VAR15->VAR24 |= VAR25;

      goto VAR23;
    }

    
    if ( FUN3( VAR2, "", 7 ) == 0 )
    {
      
      FUN9( (char *)VAR19->VAR34,
                VAR19->VAR35,
                sizeof ( VAR16 ),
                VAR36 );

      VAR15->VAR24 &= ~VAR37;

      goto VAR23;
    }

    
    if ( FUN3( VAR2, "", 7 ) == 0 )
    {
      VAR15->VAR38 = 0;
      VAR15->VAR24    &= ~VAR39;

      goto VAR23;
    }

    
    
    if ( ( VAR15->VAR24 & VAR40 )     &&
         VAR15->VAR38            == -1 &&
         VAR15->VAR41->VAR42 == 0  )
      goto VAR23;

    
    if ( FUN3( VAR2, "", 9 ) == 0 )
    {
      
      
      FUN10( VAR15->VAR43 );

      VAR21 = FUN6( &VAR15->VAR28, (char *)"", VAR2, VAR3 );
      if ( VAR21 )
        goto VAR23;

      FUN11( &VAR15->VAR28, 1 );

      VAR9 = FUN12( &VAR15->VAR28, '', &VAR12 );

      if ( !VAR9 )
      {
        FUN5(( "" VAR44, VAR4, "" ));
        VAR21 = VAR45;
        goto VAR23;
      }

      if ( FUN8( VAR15->VAR43, VAR12 + 1 ) )
        goto VAR23;

      FUN13( VAR15->VAR43, VAR9, VAR12 + 1 );

      VAR15->VAR24 |= VAR40;

      FUN14(( VAR46, VAR4, VAR9 ));

      goto VAR23;
    }

    
    if ( FUN3( VAR2, "", 8 ) == 0 )
    {
      if ( !( VAR15->VAR24 & VAR40 ) )
      {
        
        FUN5(( "" VAR26, VAR4, "" ));
        VAR21 = VAR47;
        goto VAR23;
      }

      VAR21 = FUN6( &VAR15->VAR28, (char *)"", VAR2, VAR3 );
      if ( VAR21 )
        goto VAR23;

      VAR15->VAR38 = FUN15( VAR15->VAR28.VAR31[1], 0, 10 );

      
      
      if ( VAR15->VAR38 < -1 )
        VAR15->VAR38 = -1;

      
      if ( VAR15->VAR38 == -1 && VAR15->VAR28.VAR48 > 2 )
        VAR15->VAR38 = FUN15( VAR15->VAR28.VAR31[2], 0, 10 );

      FUN14(( VAR49, VAR15->VAR38 ));

      
      
      if ( VAR15->VAR38 > 0                                      &&
           (VAR50)VAR15->VAR38 >= sizeof ( VAR15->VAR51 ) /
                                   sizeof ( unsigned long ) * 32 )
      {
        FUN5(( "" VAR32, VAR4, "" ));
        VAR21 = VAR45;
        goto VAR23;
      }

      
      
      
      if ( VAR15->VAR38 >= 0 )
      {
        if ( FUN16( VAR15->VAR51, VAR15->VAR38 ) )
        {
          
          
          FUN17(( "" VAR52,
                      VAR15->VAR38, VAR15->VAR43 ));
          VAR15->VAR38 = -1;
          VAR19->VAR53 = 1;
        }
        else
          FUN18( VAR15->VAR51, VAR15->VAR38 );
      }

      if ( VAR15->VAR38 >= 0 )
      {
        
        
        if ( VAR19->VAR35 == VAR19->VAR30 )
        {
          if ( FUN19( VAR19->VAR34,
                               VAR19->VAR30,
                               VAR19->VAR30 + 64 ) )
            goto VAR23;

          VAR19->VAR30 += 64;
        }

        VAR17           = VAR19->VAR34 + VAR19->VAR35++;
        VAR17->VAR54     = VAR15->VAR43;
        VAR17->VAR55 = VAR15->VAR38;

        
        VAR15->VAR43 = 0;
      }
      else
      {
        
        
        if ( VAR15->VAR41->VAR42 != 0 )
        {
          
          if ( VAR19->VAR56 == VAR19->VAR57 )
          {
            if ( FUN19( VAR19->VAR58 ,
                                 VAR19->VAR57,
                                 VAR19->VAR57 + 4 ) )
              goto VAR23;

            VAR19->VAR57 += 4;
          }

          VAR17           = VAR19->VAR58 + VAR19->VAR56;
          VAR17->VAR54     = VAR15->VAR43;
          VAR17->VAR55 = VAR19->VAR56++;
        }
        else
          
          
          FUN10( VAR15->VAR43 );

        VAR15->VAR43 = 0;
      }

      
      
      VAR15->VAR24 &= ~( VAR59 | VAR60 );

      VAR15->VAR24 |= VAR61;

      goto VAR23;
    }

    
    if ( VAR15->VAR38 == -1 )
      VAR17 = VAR19->VAR58 + ( VAR19->VAR56 - 1 );
    else
      VAR17 = VAR19->VAR34 + ( VAR19->VAR35 - 1 );

    
    if ( VAR15->VAR24 & VAR62 )
    {
      
      
      if ( VAR15->VAR63 >= (unsigned long)VAR17->VAR64.VAR65 )
      {
        if ( !( VAR15->VAR24 & VAR60 ) )
        {
          FUN17(( "" VAR66, VAR17->VAR55 ));
          VAR15->VAR24 |= VAR60;
          VAR19->VAR53 = 1;
        }

        goto VAR23;
      }

      
      
      VAR13 = VAR17->VAR67 << 1;
      VAR10      = VAR17->VAR68 + VAR15->VAR63 * VAR17->VAR67;

      for ( VAR11 = 0; VAR11 < VAR13; VAR11++ )
      {
        VAR7 = VAR2[VAR11];
        if ( !FUN20( VAR69, VAR7 ) )
          break;
        *VAR10 = (VAR70)( ( *VAR10 << 4 ) + VAR71[VAR7] );
        if ( VAR11 + 1 < VAR13 && ( VAR11 & 1 ) )
          *++VAR10 = 0;
      }

      
      
      if ( VAR11 < VAR13                            &&
           !( VAR15->VAR24 & VAR59 ) )
      {
        FUN17(( "" VAR72, VAR17->VAR55 ));
        VAR15->VAR24       |= VAR59;
        VAR19->VAR53  = 1;
      }

      
      VAR8 = ( VAR17->VAR64.VAR73 * VAR15->VAR19->VAR74 ) & 7;
      if ( VAR17->VAR64.VAR73 )
        *VAR10 &= VAR75[VAR8];

      
      if ( VAR11 == VAR13                           &&
           FUN20( VAR69, VAR2[VAR13] )      &&
           !( VAR15->VAR24 & VAR59 ) )
      {
        FUN17(( "" VAR76, VAR17->VAR55 ));
        VAR15->VAR24       |= VAR59;
        VAR19->VAR53  = 1;
      }

      VAR15->VAR63++;
      goto VAR23;
    }

    
    if ( FUN3( VAR2, "", 6 ) == 0 )
    {
      if ( !( VAR15->VAR24 & VAR61 ) )
        goto VAR77;

      VAR21 = FUN6( &VAR15->VAR28, (char *)"", VAR2, VAR3 );
      if ( VAR21 )
        goto VAR23;

      VAR17->VAR78 = (unsigned short)FUN7( VAR15->VAR28.VAR31[1], 0, 10 );
      VAR15->VAR24 |= VAR79;

      goto VAR23;
    }

    
    if ( FUN3( VAR2, "", 6 ) == 0 )
    {
      if ( !( VAR15->VAR24 & VAR61 ) )
        goto VAR77;

      VAR21 = FUN6( &VAR15->VAR28, (char *)"", VAR2, VAR3 );
      if ( VAR21 )
        goto VAR23;

      VAR17->VAR80 = (unsigned short)FUN7( VAR15->VAR28.VAR31[1], 0, 10 );

      if ( !( VAR15->VAR24 & VAR79 ) )
      {
        
        
        FUN17(( "" VAR81, VAR4 ));

        VAR17->VAR78 = (unsigned short)FUN21(
                          VAR17->VAR80, 72000L,
                          (VAR82)( VAR19->VAR83 *
                                     VAR19->VAR84 ) );
      }

      VAR15->VAR24 |= VAR85;
      goto VAR23;
    }

    
    if ( FUN3( VAR2, "", 3 ) == 0 )
    {
      if ( !( VAR15->VAR24 & VAR61 ) )
        goto VAR77;

      VAR21 = FUN6( &VAR15->VAR28, (char *)"", VAR2, VAR3 );
      if ( VAR21 )
        goto VAR23;

      VAR17->VAR64.VAR73    = FUN22( VAR15->VAR28.VAR31[1], 0, 10 );
      VAR17->VAR64.VAR65   = FUN22( VAR15->VAR28.VAR31[2], 0, 10 );
      VAR17->VAR64.VAR86 = FUN22( VAR15->VAR28.VAR31[3], 0, 10 );
      VAR17->VAR64.VAR87 = FUN22( VAR15->VAR28.VAR31[4], 0, 10 );

      
      VAR17->VAR64.VAR88  = (short)( VAR17->VAR64.VAR65 + VAR17->VAR64.VAR87 );
      VAR17->VAR64.VAR89 = (short)( -VAR17->VAR64.VAR87 );

      
      
      VAR15->VAR90    = (short)FUN23( VAR17->VAR64.VAR88, VAR15->VAR90 );
      VAR15->VAR91    = (short)FUN23( VAR17->VAR64.VAR89, VAR15->VAR91 );

      VAR15->VAR92 = (short)( VAR17->VAR64.VAR73 + VAR17->VAR64.VAR86 );

      VAR15->VAR93    = (short)FUN23( VAR15->VAR92, VAR15->VAR93 );
      VAR15->VAR94    = (short)FUN24( VAR17->VAR64.VAR86, VAR15->VAR94 );
      VAR15->VAR95    = (short)FUN23( VAR17->VAR64.VAR86, VAR15->VAR95 );

      if ( !( VAR15->VAR24 & VAR85 ) )
      {
        
        
        FUN17(( "" VAR96, VAR4 ));
        VAR17->VAR80 = VAR17->VAR64.VAR73;
      }

      
      
      if ( VAR15->VAR41->VAR97 != 0 )
      {
        
        unsigned short  VAR98 = (unsigned short)FUN21(
                               VAR17->VAR80, 72000L,
                               (VAR82)( VAR19->VAR83 *
                                          VAR19->VAR84 ) );


        if ( VAR98 != VAR17->VAR78 )
        {
          VAR17->VAR78 = VAR98;

          if ( VAR15->VAR38 == -1 )
            FUN18( VAR19->VAR99,
                                     VAR19->VAR56 - 1 );
          else
            FUN18( VAR19->VAR100, VAR17->VAR55 );

          VAR15->VAR24       |= VAR101;
          VAR19->VAR53  = 1;
        }
      }

      VAR15->VAR24 |= VAR102;
      goto VAR23;
    }

    
    if ( FUN3( VAR2, "", 6 ) == 0 )
    {
      unsigned long  VAR103;


      if ( !( VAR15->VAR24 & VAR102 ) )
      {
        
        FUN5(( "" VAR26, VAR4, "" ));
        VAR21 = VAR104;
        goto VAR23;
      }

      
      VAR17->VAR67 = ( VAR17->VAR64.VAR73 * VAR15->VAR19->VAR74 + 7 ) >> 3;

      VAR103 = VAR17->VAR67 * VAR17->VAR64.VAR65;
      if ( VAR17->VAR67 > 0xFFFFU || VAR103 > 0xFFFFU )
      {
        FUN5(( "" VAR105, VAR4 ));
        VAR21 = VAR106;
        goto VAR23;
      }
      else
        VAR17->VAR107 = (unsigned short)VAR103;

      if ( FUN8( VAR17->VAR68, VAR17->VAR107 ) )
        goto VAR23;

      VAR15->VAR63    = 0;
      VAR15->VAR24 |= VAR62;

      goto VAR23;
    }

    FUN5(( "" VAR108, VAR4 ));
    VAR21 = VAR45;
    goto VAR23;

  VAR77:
    
    FUN5(( "" VAR26, VAR4, "" ));
    VAR21 = VAR109;

  VAR23:
    if ( VAR21 && ( VAR15->VAR24 & VAR40 ) )
      FUN10( VAR15->VAR43 );

    return VAR21;
  }