void VAR1::FUN1(SVGObserverNotifyFunction VAR2,                             modificationType VAR3)  
{
  
  
  VAR4<VAR5, 1> FUN2(VAR6);
  PRInt32 VAR7 = VAR8.FUN3();

  for (PRInt32 VAR9 = VAR7 - 1; VAR9 >= 0; VAR9--) {
    VAR10* VAR11 = VAR8.FUN4(VAR9);
    VAR12<VAR13> VAR14 = FUN5(VAR11);
    if (VAR14)
       (static_cast<VAR13*>(VAR14)->*VAR2)(this, VAR3);
  }
}