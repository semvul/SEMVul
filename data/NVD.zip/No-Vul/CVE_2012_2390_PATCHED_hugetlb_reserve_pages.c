int FUN1(struct VAR1 *VAR1, 					long VAR2, long VAR3, 					struct VAR4 *VAR5, 					vm_flags_t VAR6)  
{
	long VAR7, VAR8;
	struct VAR9 *VAR10 = FUN2(VAR1);
	struct VAR11 *VAR12 = FUN3(VAR1);

	
	if (VAR6 & VAR13)
		return 0;

	
	if (!VAR5 || VAR5->VAR6 & VAR14)
		VAR8 = FUN4(&VAR1->VAR15->VAR16, VAR2, VAR3);
	else {
		struct VAR17 *VAR17 = FUN5();
		if (!VAR17)
			return -VAR18;

		VAR8 = VAR3 - VAR2;

		FUN6(VAR5, VAR17);
		FUN7(VAR5, VAR19);
	}

	if (VAR8 < 0) {
		VAR7 = VAR8;
		goto VAR20;
	}

	
	if (FUN8(VAR12, VAR8)) {
		VAR7 = -VAR21;
		goto VAR20;
	}

	
	VAR7 = FUN9(VAR10, VAR8);
	if (VAR7 < 0) {
		FUN10(VAR12, VAR8);
		goto VAR20;
	}

	
	if (!VAR5 || VAR5->VAR6 & VAR14)
		FUN11(&VAR1->VAR15->VAR16, VAR2, VAR3);
	return 0;
VAR20:
	FUN12(VAR5);
	return VAR7;
}