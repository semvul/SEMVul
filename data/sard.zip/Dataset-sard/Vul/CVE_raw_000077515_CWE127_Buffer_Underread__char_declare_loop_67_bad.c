void CWE127_Buffer_Underread__char_declare_loop_67_bad()
{
    char * data;
    CWE127_Buffer_Underread__char_declare_loop_67_structType myStruct;
    char dataBuffer[100];
    memset(dataBuffer, 'A', 100-1);
    dataBuffer[100-1] = '\0';
    /* FLAW: Set data pointer to before the allocated memory buffer */
    data = dataBuffer - 8;
    myStruct.structFirst = data;
    CWE127_Buffer_Underread__char_declare_loop_67b_badSink(myStruct);
}
