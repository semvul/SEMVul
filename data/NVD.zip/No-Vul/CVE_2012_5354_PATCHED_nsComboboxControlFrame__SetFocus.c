void VAR1::FUN1(bool VAR2, bool VAR3)  
{
  VAR4 FUN2(this);
  if (VAR2) {
    VAR5::FUN3();
    VAR6 = this;
    if (VAR7) {
      FUN4(true); 
      if (!VAR8.FUN5()) {
        return;
      }
      FUN6(!VAR7);
    }
  } else {
    VAR6 = VAR9;
    VAR7 = false;
    if (VAR10) {
      VAR11->FUN7(VAR12); 
      if (!VAR8.FUN5()) {
        return;
      }
    }
    
    VAR11->FUN8();
  }

  if (!VAR8.FUN5()) {
    return;
  }

  
  
  
  FUN9(FUN10(0,0,VAR13.VAR14,VAR13.VAR15));

  
  
  
  
  VAR16* VAR17 = FUN11()->FUN12()->FUN13();
  if (VAR17) {
    VAR17->FUN14(VAR18);
  }
}