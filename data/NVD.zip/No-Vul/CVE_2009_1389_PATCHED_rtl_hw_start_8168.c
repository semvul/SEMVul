static void FUN1(struct VAR1 *VAR2)  
{
	struct VAR3 *VAR4 = FUN2(VAR2);
	void VAR5 *VAR6 = VAR4->VAR7;
	struct VAR8 *VAR9 = VAR4->VAR8;

	FUN3(VAR10, VAR11);

	FUN3(VAR12, VAR13);

	FUN4(VAR6, VAR4->VAR14);

	VAR4->VAR15 |= FUN5(VAR16) | VAR17 | VAR18;

	FUN6(VAR16, VAR4->VAR15);

	FUN6(VAR19, 0x5151);

	
	if (VAR4->VAR20 == VAR21) {
		VAR4->VAR22 |= VAR23 | VAR24;
		VAR4->VAR22 &= ~VAR25;
	}

	FUN7(VAR4, VAR6);

	FUN8(VAR2);

	FUN9(VAR26, (VAR27 << VAR28) |
		(VAR29 << VAR30));

	FUN10(VAR31);

	switch (VAR4->VAR20) {
	case VAR21:
		FUN11(VAR6, VAR9);
	break;

	case VAR32:
	case VAR33:
		FUN12(VAR6, VAR9);
	break;

	case VAR34:
		FUN13(VAR6, VAR9);
	break;

	case VAR35:
		FUN14(VAR6, VAR9);
	break;

	case VAR36:
		FUN15(VAR6, VAR9);
	break;

	case VAR37:
		FUN16(VAR6, VAR9);
	break;

	case VAR38:
		FUN17(VAR6, VAR9);
	break;

	case VAR39:
		FUN18(VAR6, VAR9);
	break;

	case VAR40:
		FUN19(VAR6, VAR9);
	break;

	case VAR41:
		FUN20(VAR6, VAR9);
	break;

	default:
		FUN21(KERN_ERR VAR42 "",
			VAR2->VAR43, VAR4->VAR20);
	break;
	}

	FUN3(VAR44, VAR45 | VAR46);

	FUN3(VAR10, VAR47);

	FUN6(VAR48, FUN5(VAR48) & 0xF000);

	FUN6(VAR31, VAR4->VAR22);
}