nsresult VAR1::FUN1(VAR2* VAR3,                                      VAR4** VAR5)  
{
    *VAR5 = VAR6;
    if (!FUN2(2, 3, VAR3))
        return VAR7;

    
    double VAR8;
    txExpandedName VAR9;

    nsresult VAR10 = FUN3(VAR11[0], VAR3, &VAR8);
    FUN4(VAR10, VAR10);

    nsAutoString VAR12;
    VAR10 = VAR11[1]->FUN5(VAR3, VAR12);
    FUN4(VAR10, VAR10);

    if (VAR11.FUN6() == 3) {
        nsAutoString VAR13;
        VAR10 = VAR11[2]->FUN5(VAR3, VAR13);
        FUN4(VAR10, VAR10);

        VAR10 = VAR9.FUN7(VAR13, VAR14, false);
        FUN4(VAR10, VAR10);
    }

    VAR15* VAR16 = VAR17->FUN8(VAR9);
    if (!VAR16) {
        VAR18 FUN9(FUN10(""));
#ifdef VAR19
        VAR20.FUN11("");
        FUN12(VAR20);
#endif
        VAR3->FUN13(VAR20, VAR21);
        return VAR21;
    }

    
    if (FUN14(VAR8)) {
        return VAR3->FUN15()->FUN16(VAR16->VAR22, VAR5);
    }

    if (VAR8 == FUN17()) {
        return VAR3->FUN15()->FUN16(VAR16->VAR23,
                                                     VAR5);
    }

    if (VAR8 == FUN18()) {
        nsAutoString VAR24;
        VAR24.FUN19(VAR16->VAR25);
        VAR24.FUN19(VAR16->VAR23);
        return VAR3->FUN15()->FUN16(VAR24, VAR5);
    }
    
    
    nsAutoString VAR26;
    nsAutoString VAR27;
    int VAR28=0;
    int VAR29=0;
    int VAR30=0;
    int VAR31=1;
    int VAR32=-1;

    PRUint32 VAR33 = 0;
    PRUint32 VAR34 = VAR12.FUN6();
    bool VAR35;

    
    VAR35 = false;
    if (FUN20(VAR8)) {
        while (VAR33 < VAR34 &&
               (VAR35 ||
                VAR12.FUN21(VAR33) != VAR16->VAR36)) {
            if (VAR12.FUN21(VAR33) == VAR37)
                VAR35 = !VAR35;
            VAR33++;
        }

        if (VAR33 == VAR34) {
            VAR33 = 0;
            VAR26.FUN19(VAR16->VAR25);
        }
        else
            VAR33++;
    }

    
    FormatParseState VAR38 = VAR39;
    VAR35 = false;

    PRUnichar VAR40 = 0;
    while (VAR33 < VAR34 && VAR38 != VAR41) {
        VAR40=VAR12.FUN21(VAR33++);

        switch (VAR38) {

        case VAR39:
        case VAR42:
            if (!VAR35) {
                if (VAR40 == VAR16->VAR43) {
                    if (VAR31 == 1)
                        VAR31 = 100;
                    else {
                        VAR18 FUN9(VAR44);
#ifdef VAR19
                        VAR20.FUN11("");
                        FUN12(VAR20);
#endif
                        VAR3->FUN13(VAR20,
                                               VAR21);
                        return VAR21;
                    }
                }
                else if (VAR40 == VAR16->VAR45) {
                    if (VAR31 == 1)
                        VAR31 = 1000;
                    else {
                        VAR18 FUN9(VAR44);
#ifdef VAR19
                        VAR20.FUN11("");
                        FUN12(VAR20);
#endif
                        VAR3->FUN13(VAR20,
                                               VAR21);
                        return VAR21;
                    }
                }
                else if (VAR40 == VAR16->VAR46 ||
                         VAR40 == VAR16->VAR47 ||
                         VAR40 == VAR16->VAR48 ||
                         VAR40 == VAR16->VAR49 ||
                         VAR40 == VAR16->VAR36) {
                    VAR38 = VAR38 == VAR39 ? VAR50 : VAR41;
                    VAR33--;
                    break;
                }
            }

            if (VAR40 == VAR37)
                VAR35 = !VAR35;
            else if (VAR38 == VAR39)
                VAR26.FUN19(VAR40);
            else
                VAR27.FUN19(VAR40);
            break;

        case VAR50:
            if (VAR40 == VAR16->VAR47)
                VAR32=0;
            else if (VAR40 == VAR16->VAR49) {
                if (VAR32 >= 0)
                    VAR32++;
            }
            else {
                VAR38 = VAR51;
                VAR33--;
            }
            break;

        case VAR51:
            if (VAR40 == VAR16->VAR47)
                VAR32 = 0;
            else if (VAR40 == VAR16->VAR48) {
                if (VAR32 >= 0)
                    VAR32++;
                VAR28++;
            }
            else if (VAR40 == VAR16->VAR46) {
                VAR38 = VAR52;
            }
            else {
                VAR38 = VAR42;
                VAR33--;
            }
            break;

        case VAR52:
            if (VAR40 == VAR16->VAR48) {
                VAR30++;
                VAR29++;
            }
            else {
                VAR38 = VAR53;
                VAR33--;
            }
            break;

        case VAR53:
            if (VAR40 == VAR16->VAR49)
                VAR30++;
            else {
                VAR38 = VAR42;
                VAR33--;
            }
            break;

        case VAR41:
            break;
        }
    }

    
    if ((VAR40 != VAR16->VAR36 && VAR33 < VAR34) ||
        VAR35 ||
        VAR32 == 0) {
        VAR18 FUN9(VAR44);
#ifdef VAR19
        VAR20.FUN11("");
        FUN12(VAR20);
#endif
        VAR3->FUN13(VAR20, VAR21);
        return VAR21;
    }


    

    VAR8 = FUN22(VAR8) * VAR31;

    
    VAR18 FUN23(VAR26);

    int VAR54;
    if (VAR8 > 1)
        VAR54 = (int)FUN24(VAR8) + 30;
    else
        VAR54 = 1 + 30;

    char* VAR55 = new char[VAR54];
    FUN25(VAR55, VAR56);

    PRIntn VAR57, VAR58;
    char* VAR59;
    FUN26(VAR8, 0, 0, &VAR57, &VAR58, &VAR59, VAR55, VAR54-1);

    int VAR60 = VAR59 - VAR55;
    int VAR61;
    VAR61 = VAR57 > VAR28 ? VAR57 : VAR28;

    if (VAR32 < 0)
        VAR32 = VAR61 + 10; 

    
    VAR24.FUN27(VAR24.FUN6() +
                  VAR61 +               
                  1 +                       
                  VAR30 +         
                  (VAR61-1)/VAR32); 

    PRInt32 VAR62 = VAR57 + VAR30 - 1;
    bool VAR63 = (0 <= VAR62+1) && (VAR62+1 < VAR60) && (VAR55[VAR62+1] >= '');
    bool VAR64 = false;

    PRUint32 VAR65 = VAR24.FUN6()-1;

    
    for (; VAR62 >= VAR57; --VAR62) {
        int VAR66;
        if (VAR62 >= VAR60 || VAR62 < 0) {
            VAR66 = 0;
        }
        else {
            VAR66 = VAR55[VAR62] - '';
        }
        
        if (VAR63) {
            VAR66 = (VAR66 + 1) % 10;
            VAR63 = VAR66 == 0;
        }

        if (VAR64 || VAR66 != 0 || VAR62 < VAR57+VAR29) {
            VAR64 = true;
            VAR24.FUN28((VAR67)(VAR66 + VAR16->VAR48),
                          VAR65--);
        }
        else {
            VAR24.FUN29(VAR65--);
        }
    }

    
    if (VAR64) {
        VAR24.FUN28(VAR16->VAR46, VAR65--);
    }
    else {
        VAR24.FUN29(VAR65--);
    }

    
    for (VAR62 = 0; VAR62 < VAR61; ++VAR62) {
        int VAR66;
        if (VAR57-VAR62-1 >= VAR60 || VAR57-VAR62-1 < 0) {
            VAR66 = 0;
        }
        else {
            VAR66 = VAR55[VAR57-VAR62-1] - '';
        }
        
        if (VAR63) {
            VAR66 = (VAR66 + 1) % 10;
            VAR63 = VAR66 == 0;
        }

        if (VAR62 != 0 && VAR62%VAR32 == 0) {
            VAR24.FUN28(VAR16->VAR47, VAR65--);
        }

        VAR24.FUN28((VAR67)(VAR66 + VAR16->VAR48), VAR65--);
    }

    if (VAR63) {
        if (VAR62%VAR32 == 0) {
            VAR24.FUN30(VAR16->VAR47, VAR65 + 1);
        }
        VAR24.FUN30((VAR67)(1 + VAR16->VAR48), VAR65 + 1);
    }
    
    if (!VAR64 && !VAR61 && !VAR63) {
        
        
        VAR24.FUN19(VAR16->VAR48);
    }

    delete [] VAR55;

    
    VAR24.FUN19(VAR27);

    return VAR3->FUN15()->FUN16(VAR24, VAR5);
}