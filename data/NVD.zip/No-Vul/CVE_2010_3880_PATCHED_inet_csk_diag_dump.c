static int FUN1(struct VAR1 *VAR2, 			      struct VAR3 *VAR4, 			      struct VAR5 *VAR6)  
{
	struct VAR7 *VAR8 = FUN2(VAR6->VAR9);

	if (FUN3(VAR6->VAR9, sizeof(*VAR8))) {
		struct inet_diag_entry VAR10;
		const struct VAR11 *VAR12 = FUN4(VAR6->VAR9,
							  sizeof(*VAR8),
							  VAR13);
		struct VAR14 *VAR15 = FUN5(VAR2);

		VAR10.VAR16 = VAR2->VAR17;
#if FUN6(VAR18) || FUN6 (VAR19)
		if (VAR10.VAR16 == VAR20) {
			struct VAR21 *VAR22 = FUN7(VAR2);

			VAR10.VAR23 = VAR22->VAR24.VAR25;
			VAR10.VAR26 = VAR22->VAR26.VAR25;
		} else
#endif
		{
			VAR10.VAR23 = &VAR15->VAR27;
			VAR10.VAR26 = &VAR15->VAR28;
		}
		VAR10.VAR29 = VAR15->VAR30;
		VAR10.VAR31 = FUN8(VAR15->VAR32);
		VAR10.VAR33 = VAR2->VAR34;

		if (!FUN9(FUN10(VAR12), FUN11(VAR12), &VAR10))
			return 0;
	}

	return FUN12(VAR2, VAR4, VAR8->VAR35,
				  FUN13(VAR6->VAR4).VAR36,
				  VAR6->VAR9->VAR37, VAR38, VAR6->VAR9);
}