static int FUN1(struct socket *VAR1, struct msghdr VAR2 *VAR3, 			 struct VAR4 *VAR5, unsigned VAR6, 			 struct VAR7 *VAR7)  
{
	struct compat_msghdr VAR2 *VAR8 =
	    (struct compat_msghdr VAR2 *)VAR3;
	struct sockaddr_storage VAR9;
	struct iovec VAR10[VAR11], *VAR12 = VAR10;
	unsigned char VAR13[sizeof(struct VAR14) + 20]
	    FUN2 ((FUN3(sizeof(VAR15))));
	
	unsigned char *VAR16 = VAR13;
	int VAR17, VAR18, VAR19, VAR20;

	VAR17 = -VAR21;
	if (VAR22 & VAR6) {
		if (FUN4(VAR5, VAR8))
			return -VAR21;
	} else if (FUN5(VAR5, VAR3, sizeof(struct VAR4)))
		return -VAR21;

	
	VAR17 = -VAR23;
	if (VAR5->VAR24 > VAR25)
		goto VAR26;

	
	VAR17 = -VAR27;
	VAR19 = VAR5->VAR24 * sizeof(struct VAR28);
	if (VAR5->VAR24 > VAR11) {
		VAR12 = FUN6(VAR1->VAR29, VAR19, VAR30);
		if (!VAR12)
			goto VAR26;
	}

	
	if (VAR22 & VAR6) {
		VAR17 = FUN7(VAR5, VAR12,
					  (struct VAR31 *)&VAR9,
					  VAR32);
	} else
		VAR17 = FUN8(VAR5, VAR12,
				   (struct VAR31 *)&VAR9,
				   VAR32);
	if (VAR17 < 0)
		goto VAR33;
	VAR20 = VAR17;

	VAR17 = -VAR34;

	if (VAR5->VAR35 > VAR36)
		goto VAR33;
	VAR18 = VAR5->VAR35;
	if ((VAR22 & VAR6) && VAR18) {
		VAR17 =
		    FUN9(VAR5, VAR1->VAR29, VAR13,
						     sizeof(VAR13));
		if (VAR17)
			goto VAR33;
		VAR16 = VAR5->VAR37;
		VAR18 = VAR5->VAR35;
	} else if (VAR18) {
		if (VAR18 > sizeof(VAR13)) {
			VAR16 = FUN6(VAR1->VAR29, VAR18, VAR30);
			if (VAR16 == NULL)
				goto VAR33;
		}
		VAR17 = -VAR21;
		
		if (FUN5(VAR16,
				   (void __user VAR38 *)VAR5->VAR37,
				   VAR18))
			goto VAR39;
		VAR5->VAR37 = VAR16;
	}
	VAR5->VAR40 = VAR6;

	if (VAR1->VAR41->VAR42 & VAR43)
		VAR5->VAR40 |= VAR44;
	
	if (VAR7 && VAR5->VAR45 &&
	    VAR7->VAR46 == VAR5->VAR47 &&
	    !memcmp(&VAR7->VAR48, VAR5->VAR45,
		    VAR7->VAR46)) {
		VAR17 = FUN10(VAR1, VAR5, VAR20);
		goto VAR39;
	}
	VAR17 = FUN11(VAR1, VAR5, VAR20);
	
	if (VAR7 && VAR17 >= 0) {
		VAR7->VAR46 = VAR5->VAR47;
		if (VAR5->VAR45)
			memcpy(&VAR7->VAR48, VAR5->VAR45,
			       VAR7->VAR46);
	}

VAR39:
	if (VAR16 != VAR13)
		FUN12(VAR1->VAR29, VAR16, VAR18);
VAR33:
	if (VAR12 != VAR10)
		FUN12(VAR1->VAR29, VAR12, VAR19);
VAR26:
	return VAR17;
}