char * FUN1(char *VAR1, const VAR2 *VAR3, guint32 VAR4)  
{
  guint32 VAR5;

  if (!VAR3)
    FUN2("");

  for (VAR5 = 0; VAR5 < VAR4; VAR5++)
    VAR1 = FUN3(VAR1, VAR3[VAR5]);
  return VAR1;
}