static int FUN1(struct VAR1 *VAR2)  
{
	struct VAR3 *VAR4 = VAR2->VAR5.VAR6;
	__be32 VAR7;

	VAR7 = FUN2((VAR8 *)&VAR4->VAR9);
	return FUN3(VAR2, VAR7) > 0 ? : 0;
}