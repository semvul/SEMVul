void helper_store_sdr1(CPUPPCState *env, target_ulong val)

{

    ppc_store_sdr1(env, val);

}
