bool VAR1::FUN1()  
{
  PRUint32 VAR2, VAR3, VAR4, VAR5, VAR6;
  char VAR7[VAR8];
  const char* VAR9 = VAR7;

  
  FUN2(VAR10->FUN3()->FUN4() % 2 == 0,
                    "");

  
  
  if (!FUN5(VAR11, &VAR2)) {
    return false;
  }

  if (!FUN6(VAR7, sizeof(VAR7))) {
    return false;
  }

  FUN7(sizeof(VAR12) +
                   sizeof(VAR12) +
                   sizeof(VAR13) +
                   4 +
                   sizeof(VAR12) +
                   sizeof(VAR12) <= sizeof(VAR7));
  if (FUN8(&VAR9) != VAR14) {
    FUN9("");
    return false;
  }

  VAR4 = FUN8(&VAR9);
  VAR3 = FUN10(&VAR9);

  
  VAR9 += 4;

  VAR5 = FUN8(&VAR9);

  VAR6 = FUN8(&VAR9);

  
  
  
  
  
  if (VAR2 > VAR8) {
    char VAR15[2];
    const char* VAR9 = VAR15;

    if (!FUN6(VAR15, sizeof(VAR15))) {
      return false;
    }

    FUN7(sizeof(VAR12) <= sizeof(VAR15));
    PRUint16 VAR16 = FUN8(&VAR9);
    if (VAR2 - (VAR8 + 2) != VAR16) {
      FUN9("");
      return false;
    }
    VAR16 += VAR16 % 2;

    if (VAR16 > 0) {
      FUN7(VAR17 + (VAR17 % 2) < VAR18 / sizeof(char));
      VAR19<char> FUN11(new char[VAR16]);
      if (!FUN6(VAR20.FUN12(), VAR16)) {
        return false;
      }
    }
  }

  
  FUN2(VAR10->FUN3()->FUN4() % 2 == 0,
                    "");

  
  
  
  unsigned int VAR21 = VAR6 == 8 ? 1 : 2 * VAR4;
  if (VAR3 < 100 || VAR3 > 96000 ||
      VAR4 < 1 || VAR4 > VAR22 ||
      (VAR5 != 1 && VAR5 != 2 && VAR5 != 4) ||
      (VAR6 != 8 && VAR6 != 16) ||
      VAR5 != VAR21) {
    FUN9("");
    return false;
  }

  VAR23 FUN13(VAR10->FUN14());
  VAR24 = VAR3;
  VAR25 = VAR4;
  VAR26 = VAR5;
  if (VAR6 == 8) {
    VAR27 = VAR28::VAR29;
  } else {
    VAR27 = VAR28::VAR30;
  }
  return true;
}