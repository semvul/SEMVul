static int FUN1(struct VAR1 *VAR2, 			       struct VAR3 **VAR4, struct VAR5 *VAR6)  
{
	int VAR7;
	struct VAR8 *VAR8 = FUN2(VAR2);

	if (*VAR4 == NULL)
		*VAR4 = FUN3(VAR8, VAR2, VAR6);

	if ((VAR7 = (*VAR4)->VAR9))
		goto VAR10;

	if (FUN4(&VAR6->VAR11)) {
		VAR7 = FUN5(FUN6(*VAR4)->VAR12,
					 &VAR6->VAR13,
					 VAR2 ? FUN7(VAR2)->VAR14 : 0,
					 &VAR6->VAR11);
		if (VAR7)
			goto VAR10;
	}

#ifdef VAR15
	
	if ((*VAR4)->VAR16 && !((*VAR4)->VAR16->VAR17 & VAR18)) {
		struct VAR19 *VAR20;
		struct flowi VAR21;
		int VAR22;

		VAR20 = FUN8(VAR8, &VAR6->VAR11,
				      (*VAR4)->VAR12, 1);

		VAR22 = (VAR20 && VAR20->VAR23 & VAR24);
		if (VAR20)
			FUN9(VAR20);

		if (VAR22) {
			
			FUN10(*VAR4);
			memcpy(&VAR21, VAR6, sizeof(struct VAR5));
			memset(&VAR21.VAR13, 0, sizeof(struct VAR25));
			*VAR4 = FUN3(VAR8, VAR2, &VAR21);
			if ((VAR7 = (*VAR4)->VAR9))
				goto VAR10;
		}
	}
#endif

	return 0;

VAR10:
	if (VAR7 == -VAR26)
		FUN11(NULL, VAR27);
	FUN10(*VAR4);
	*VAR4 = NULL;
	return VAR7;
}