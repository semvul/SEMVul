int FUN1(unsigned int VAR1, struct VAR2 *VAR3, long VAR4)  
{
	struct file_lock VAR5, *VAR6 = &VAR5;
	struct VAR7 *VAR7 = VAR3->VAR8;
	struct VAR9 *VAR9 = VAR7->VAR10;
	int VAR11;

	if ((VAR12->VAR13 != VAR9->VAR14) && !FUN2(VAR15))
		return -VAR16;
	if (!FUN3(VAR9->VAR17))
		return -VAR18;
	VAR11 = FUN4(VAR3, VAR4);
	if (VAR11)
		return VAR11;

	FUN5(&VAR5);
	VAR11 = FUN6(VAR3, VAR4, &VAR5);
	if (VAR11)
		return VAR11;

	FUN7();

	VAR11 = FUN8(VAR3, VAR4, &VAR6);
	if (VAR11 || VAR4 == VAR19)
		goto VAR20;

	VAR11 = FUN9(VAR1, VAR3, 1, &VAR6->VAR21);
	if (VAR11 < 0) {
		
		VAR6->VAR22 = VAR19 | VAR23;
		VAR6->VAR24 = VAR25- 10;
		FUN10(VAR9);
		goto VAR20;
	}

	VAR11 = FUN11(VAR3, VAR12->VAR26, 0);
VAR20:
	FUN12();
	return VAR11;
}