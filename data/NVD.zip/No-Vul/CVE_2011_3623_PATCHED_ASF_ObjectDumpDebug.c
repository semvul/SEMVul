static void FUN1( VAR1 *VAR2,                                  VAR3 *VAR4, unsigned VAR5 )  
{
    unsigned VAR6;
    union VAR7 *VAR8;
    const char *VAR9;

    
    for( VAR6 = 0; VAR10[VAR6].VAR11 != NULL; VAR6++ )
    {
        if( FUN2( VAR10[VAR6].VAR11,
                          &VAR4->VAR12 ) )
            break;
    }
    VAR9 = VAR10[VAR6].VAR9;

    char VAR13[512];
    if( VAR5 * 5 + 1 >= sizeof(VAR13) )
        return;

    memset( VAR13, '', sizeof( VAR13 ) );
    for( VAR6 = 1; VAR6 < VAR5; VAR6++ )
    {
        VAR13[VAR6 * 5] = '';
    }
    snprintf( &VAR13[5*VAR5], sizeof(VAR13) - 5*VAR5,
             ""VAR14""VAR15""VAR15,
             VAR9,
             FUN3( VAR4->VAR12 ),
             VAR4->VAR16, VAR4->VAR17 );

    FUN4( VAR2, "", VAR13 );

    for( VAR8 = VAR4->VAR18; VAR8 != NULL;
                                             VAR8 = VAR8->VAR19.VAR20 )
    {
        FUN1( VAR2, &VAR8->VAR19, VAR5 + 1 );
    }
}