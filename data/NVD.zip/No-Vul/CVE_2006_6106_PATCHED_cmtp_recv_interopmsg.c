static void FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4)  
{
	struct VAR5 *VAR6 = &VAR2->VAR6;
	struct VAR7 *VAR8;
	__u16 VAR9, VAR10, VAR11, VAR12;
	__u32 VAR13;

	FUN2("", VAR2, VAR4, VAR4->VAR14);

	switch (FUN3(VAR4->VAR15)) {
	case VAR16:
		if (VAR4->VAR14 < VAR17 + 10)
			break;

		VAR11 = FUN4(VAR4->VAR15, VAR17 + 5);
		VAR12 = FUN4(VAR4->VAR15, VAR17 + 8);

		switch (VAR11) {
		case VAR18:
			VAR10 = FUN5(VAR4->VAR15);

			VAR8 = FUN6(VAR2, VAR19, VAR10);
			if (VAR8) {
				VAR8->VAR20 = VAR21;
				VAR8->VAR10 = 0;
				VAR8->VAR22 = FUN7(VAR4->VAR15);
				FUN8(&VAR2->VAR23);
			}

			break;

		case VAR24:
			VAR9 = FUN7(VAR4->VAR15);

			VAR8 = FUN6(VAR2, VAR25, VAR9);
			if (VAR8) {
				VAR8->VAR20 = VAR26;
				VAR8->VAR10 = 0;
				FUN8(&VAR2->VAR23);
			}

			break;

		case VAR27:
			if (VAR4->VAR14 < VAR17 + 11 + sizeof(VAR28))
				break;

			VAR13 = FUN4(VAR4->VAR15, VAR17 + 11);
			VAR10 = FUN5(VAR4->VAR15);

			if (!VAR12 && (VAR10 == VAR29)) {
				VAR2->VAR30 = VAR13;
				FUN8(&VAR2->VAR23);
				break;
			}

			if (!VAR12 && VAR6) {
				memcpy(&VAR6->VAR31,
					VAR4->VAR15 + VAR17 + 11,
					sizeof(VAR28));
				VAR2->VAR20 = VAR21;
				FUN9(VAR6);
			}

			break;

		case VAR32:
			if (VAR4->VAR14 < VAR17 + 15)
				break;

			VAR13 = FUN10(VAR4->VAR15, VAR17 + 10);

			if (!VAR12 && VAR6) {
				int VAR14 = FUN11(VAR33, VAR34,
						VAR4->VAR15[VAR17 + 14]);

				memset(VAR6->VAR35, 0, VAR34);
				strncpy(VAR6->VAR35,
					VAR4->VAR15 + VAR17 + 15, VAR14);
			}

			break;

		case VAR36:
			if (VAR4->VAR14 < VAR17 + 32)
				break;

			VAR13 = FUN10(VAR4->VAR15, VAR17 + 12);

			if (!VAR12 && VAR6) {
				VAR6->VAR37.VAR38 = FUN10(VAR4->VAR15, VAR17 + 16);
				VAR6->VAR37.VAR39 = FUN10(VAR4->VAR15, VAR17 + 20);
				VAR6->VAR37.VAR40 = FUN10(VAR4->VAR15, VAR17 + 24);
				VAR6->VAR37.VAR41 = FUN10(VAR4->VAR15, VAR17 + 28);
			}

			break;

		case VAR42:
			if (VAR4->VAR14 < VAR17 + 17)
				break;

			VAR13 = FUN10(VAR4->VAR15, VAR17 + 12);

			if (!VAR12 && VAR6) {
				int VAR14 = FUN11(VAR33, VAR43,
						VAR4->VAR15[VAR17 + 16]);

				memset(VAR6->VAR44, 0, VAR43);
				strncpy(VAR6->VAR44,
					VAR4->VAR15 + VAR17 + 17, VAR14);
			}

			break;
		}

		break;

	case VAR45:
		if (VAR4->VAR14 < VAR17 + 6)
			break;

		VAR11 = FUN4(VAR4->VAR15, VAR17 + 3);

		if (VAR11 == VAR46) {
			int VAR14 = FUN11(VAR33, VAR4->VAR14 - VAR17 - 6,
						VAR4->VAR15[VAR17 + 5]);
			VAR9 = FUN7(VAR4->VAR15);
			VAR10 = FUN5(VAR4->VAR15);
			FUN12(VAR2, VAR47, VAR9, VAR10, VAR11,
						VAR4->VAR15 + VAR17 + 6, VAR14);
		}

		break;
	}

	FUN13(VAR4);
}