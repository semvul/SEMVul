VAR1 * FUN1(VAR1 *VAR2, const int VAR3, int VAR4)  
{
	gint VAR5 = VAR6;
	guint VAR7 = 0;
	VAR8 *VAR9 = NULL;
	VAR8 *VAR10 = NULL;
	VAR1 *VAR11 = NULL;
	z_streamp VAR12 = NULL;
	VAR13 *VAR14 = NULL;
	guint VAR15 = 0;
	gint VAR16 = VAR17;
	VAR8 *VAR18 = NULL;
	guint VAR19 = VAR20;
#ifdef VAR21
	guint VAR22 = 0;
	guint VAR23 = FUN2(VAR2, VAR3);
#endif

	if (VAR2 == NULL) {
		return NULL;
	}

	VAR9 = FUN3(VAR2, VAR3, VAR4);

	if (!VAR9)
		return NULL;

	
	VAR19 = FUN2(VAR2, VAR3) * 2;
	VAR19 = FUN4(VAR19, VAR20, VAR24);

#ifdef VAR21
	FUN5("", VAR19);
#endif

	VAR18 = VAR9;

	VAR12 = FUN6(VAR25, 1);
	VAR12->VAR26 = VAR18;
	VAR12->VAR27 = VAR4;

	VAR14 = FUN7(VAR19);
	VAR12->VAR28 = VAR14;
	VAR12->VAR29 = VAR19;

	VAR5 = FUN8(VAR12, VAR16);
	VAR15 = 1;
	if (VAR5 != VAR6) {
		FUN9(VAR12);
		FUN10(VAR12);
		FUN10(VAR9);
		FUN10(VAR14);
		return NULL;
	}

	while (1) {
		memset(VAR14, '', VAR19);
		VAR12->VAR28 = VAR14;
		VAR12->VAR29 = VAR19;

		VAR5 = FUN11(VAR12, VAR30);

		if (VAR5 == VAR6 || VAR5 == VAR31) {
			guint VAR32 = VAR19 - VAR12->VAR29;

#ifdef VAR21
			++VAR22;
#endif

			if (VAR10 == NULL) {
				VAR10 = FUN12(VAR14, VAR32);
			} else {
				VAR8 *VAR33 = FUN7(VAR7 + VAR32);

				FUN13(VAR33, VAR10, VAR7);
				FUN13((VAR33 + VAR7), VAR14,
					VAR32);

				FUN10(VAR10);
				VAR10 = VAR33;
			}

			VAR7 += VAR32;

			if ( VAR5 == VAR31) {
				FUN9(VAR12);
				FUN10(VAR12);
				FUN10(VAR14);
				break;
			}
		} else if (VAR5 == VAR34) {
			
			FUN9(VAR12);
			FUN10(VAR12);
			FUN10(VAR14);

			if (VAR10 != NULL) {
				break;
			} else {
				FUN10(VAR9);
				return NULL;
			}

		} else if (VAR5 == VAR35 && VAR15 == 1
			&& VAR10 == NULL && (*VAR9  == 0x1f) &&
			(*(VAR9 + 1) == 0x8b)) {
			

			
			VAR13 *VAR36 = VAR9 + 2;
			Bytef VAR37 = 0;

			if (*VAR36 == VAR38) {
				VAR36++;
			} else {
				FUN9(VAR12);
				FUN10(VAR12);
				FUN10(VAR9);
				FUN10(VAR14);
				return NULL;
			}

			VAR37 = *VAR36;

			
			VAR36 += 7;

			if (VAR37 & (1 << 2)) {
				
				gint VAR39 = (VAR40)(*VAR36 |
					(*(VAR36 + 1) << 8));

				VAR36 += VAR39;
			}

			if (VAR37 & (1 << 3)) {
				

				while ((VAR36 - VAR9) < VAR4 && *VAR36 != '') {
					VAR36++;
				}

				VAR36++;
			}

			if (VAR37 & (1 << 4)) {
				

				while ((VAR36 - VAR9) < VAR4 && *VAR36 != '') {
					VAR36++;
				}

				VAR36++;
			}


			FUN14(VAR12);
			VAR18 = VAR36;
			VAR12->VAR26 = VAR18;
			if (VAR36 - VAR9 > VAR4) {
				FUN9(VAR12);
				FUN10(VAR12);
				FUN10(VAR9);
				FUN10(VAR14);
				return NULL;
			}
			VAR4 -= (int) (VAR36 - VAR9);

			FUN9(VAR12);
			VAR5 = FUN8(VAR12, VAR16);
			VAR15++;
		} else if (VAR5 == VAR35 && VAR10 == NULL &&
			VAR15 <= 3) {

			
			VAR16 = -VAR17;

			FUN14(VAR12);

			VAR12->VAR26 = VAR18;
			VAR12->VAR27 = VAR4;

			FUN9(VAR12);
			memset(VAR14, '', VAR19);
			VAR12->VAR28 = VAR14;
			VAR12->VAR29 = VAR19;

			VAR5 = FUN8(VAR12, VAR16);

			VAR15++;

			if (VAR5 != VAR6) {
				FUN10(VAR12);
				FUN10(VAR14);
				FUN10(VAR9);
				FUN10(VAR10);

				return NULL;
			}
		} else {
			FUN9(VAR12);
			FUN10(VAR12);
			FUN10(VAR14);

			if (VAR10 == NULL) {
				FUN10(VAR9);
				return NULL;
			}

			break;
		}
	}

#ifdef VAR21
	FUN5("", VAR22);
	FUN5("", VAR23, VAR7);
#endif

	if (VAR10 != NULL) {
		VAR11 =  FUN15((VAR8*) VAR10, VAR7,
			VAR7);
		FUN16(VAR11, VAR41);
	}
	FUN10(VAR9);
	return VAR11;
}