static void FUN1(VAR1 *VAR2, VAR3 *VAR4, VAR3 *VAR5, int VAR6, int VAR7)  
{
    VAR8           *VAR9 = (VAR8 *)VAR2->VAR10;
    int             VAR11 = 0;              
    register int    VAR12;                              
    register VAR3 *VAR13, *VAR14;                 
    guint16         VAR15,VAR16;      
    guint8          VAR17;                       
    guint64         VAR18 = VAR19, VAR20 = VAR19; 
                                                        
    guint32         VAR21 = 0;
    guint64         VAR22, VAR23, VAR24 = VAR19; 
    guint64         VAR25;                            
    guint16         VAR26, VAR27, VAR28;            
    guint32         VAR29;
    guint16         VAR30;                          
    guint32         VAR31, VAR32;                
    int             VAR33;                         
    guint32         VAR34;                     
    stats_ethernettap_fields    VAR35;           
    stats_common_fields VAR36;                 
    guint16         VAR37;                      
    int             VAR38, VAR39, VAR40;      
    guint64         VAR41, VAR42;                   
    guint64         VAR43;    

    
    
    VAR14 = &(VAR5[0]);                              
    VAR13 = &(VAR5[VAR6 - VAR9->VAR44]);      
    
    VAR15 = FUN2(&VAR13[VAR9->VAR45]);
    VAR16 = VAR15;
    
    
    if (VAR15 > (VAR6 - (int)VAR9->VAR44)) {
        VAR15 = (VAR6 - (int)VAR9->VAR44);
    }

    VAR30 = FUN2(&VAR13[VAR9->VAR46]) & VAR9->VAR47;
    VAR17 = VAR13[VAR9->VAR48];
    VAR34 = FUN3(&VAR13[VAR9->VAR49]);

    if (VAR9->VAR50 == VAR51) {
        VAR28 = FUN2(&VAR13[VAR9->VAR52]);
        VAR33 = VAR28 & VAR9->VAR53;

        VAR38 = (VAR28 & VAR9->VAR54) ? 16 : 14;           


        VAR29 = FUN2(&VAR13[VAR9->VAR55]);
    }
    else {
        VAR33 = VAR13[VAR9->VAR52] & VAR9->VAR53;
        VAR38 = (VAR34 & VAR9->VAR54) ? 16 : 14;             


        
        VAR29 = FUN2(&VAR13[VAR9->VAR55]);
    }

    VAR27 = FUN2(&VAR13[VAR9->VAR56]);
    
    VAR31 = FUN4(&VAR13[VAR9->VAR57]);

    
    
    VAR42 = (VAR13[VAR9->VAR58 + 6] << 8) | (VAR13[VAR9->VAR58 + 7]);
    for (VAR12 = 0; VAR12 < 4; VAR12++)
        VAR42 = (VAR42 << 8) | VAR13[VAR9->VAR58 + VAR12];


    VAR26 = FUN2(&VAR13[VAR9->VAR59]);

    
    
    VAR18 = FUN5(&VAR13[VAR9->VAR60]);
    VAR20 = FUN5(&VAR13[VAR9->VAR61]);

    
    VAR32 = (VAR62)((VAR20 - VAR18));  

    
    VAR22 = VAR18 / VAR63;                     
    VAR23 = (VAR22 / VAR64);                   
    VAR24 = VAR22 - (VAR23 * VAR64);          

    
    VAR25 = VAR20 / VAR63;                       

    if (VAR34 & VAR9->VAR65)                       
    {
        VAR40 = VAR38 + 40;
    }
    else if (VAR34 & VAR9->VAR66)                  
    {
        VAR40 = VAR38 + 28;
    }
    else if (VAR34 & VAR9->VAR67)                 
    {
        VAR40 = VAR38 + 24;
    }
    else if (VAR34 & VAR9->VAR68)                 
    {
        VAR40 = VAR38 + 28;
    }
    else                                                
    {
        VAR40 = VAR38 + 20;
    }

    VAR39 = FUN6(VAR14, VAR40, VAR31, VAR17);
    if ((VAR14[VAR39] == 0xdd) && (VAR39 + 15 <= VAR15) && (VAR33 != 0))
        VAR41 = FUN7(VAR14, VAR39);
    else
        VAR41 = 0;

    
    if (!VAR7) {
        if (VAR41 < VAR18) {
            VAR21 = (VAR62)(VAR18 - VAR41);
        } else {
            
            
            VAR43 = VAR41 - VAR18;
            if (VAR43 >  0x10000000) {
                VAR21 = 0;
            } else
                VAR21 = (VAR62)VAR43;
        }
    }
    
    
    
    
    
    
    VAR37 = VAR69 + VAR70;
    VAR2->VAR71.VAR72 = (VAR16 - 4) + VAR37;
    VAR2->VAR71.VAR73 = (VAR15 - 4) + VAR37;

    VAR2->VAR71.VAR74 = VAR75;

    VAR2->VAR71.VAR76.VAR77 = (VAR78)VAR23;
    VAR2->VAR71.VAR76.VAR79 = (long)(VAR24 * 1000);
    VAR2->VAR71.VAR80 = VAR81;

    
    VAR36.VAR82 = 1;
    VAR36.VAR83 = VAR69;
    VAR35.VAR83 = VAR70;

    VAR35.VAR84 = (VAR62)VAR29;
    VAR35.VAR85 = (VAR86)VAR27;
    VAR36.VAR87 = (VAR86)VAR15;
    

    VAR36.VAR88 = (VAR62)VAR31;
    VAR36.VAR89 = (VAR86)VAR30;
    VAR36.VAR90 = (VAR86)VAR17;

    if (!VAR7 && (VAR41 != 0))
        VAR36.VAR91 = (VAR62)VAR21;
    else
        VAR36.VAR91 = 0;
    VAR36.VAR92 = (VAR62)VAR32;
    VAR35.VAR93 = (VAR62)VAR26;
    VAR35.VAR94 = 0;
    if (VAR7)
        VAR35.VAR94 |= VAR95;
    if (VAR29 & VAR9->VAR96)
        VAR35.VAR94 |= VAR97;
    VAR36.VAR98 = VAR22;                  
    VAR36.VAR99 = VAR25;
    VAR36.VAR100 = (VAR62)(VAR41);

    VAR35.VAR101 = 0;

    
    FUN8(&VAR4[VAR11], VAR36.VAR82);
    VAR11 += 2;
    FUN8(&VAR4[VAR11], VAR36.VAR83);
    VAR11 += 2;
    FUN8(&VAR4[VAR11], VAR36.VAR87);
    VAR11 += 2;
    
    memset(&VAR4[VAR11], 0, 2);
    VAR11 += 2;
    FUN9(&VAR4[VAR11], VAR36.VAR88);
    VAR11 += 4;
    FUN8(&VAR4[VAR11], VAR36.VAR89);
    VAR11 += 2;
    FUN8(&VAR4[VAR11], VAR36.VAR90);
    VAR11 += 2;
    FUN9(&VAR4[VAR11], VAR36.VAR91);
    VAR11 += 4;
    FUN9(&VAR4[VAR11], VAR36.VAR100);
    VAR11 += 4;
    FUN10(&VAR4[VAR11], VAR36.VAR98);
    VAR11 += 8;
    FUN10(&VAR4[VAR11], VAR36.VAR99);
    VAR11 += 8;
    FUN9(&VAR4[VAR11], VAR36.VAR92);
    VAR11 += 4;
    
    memset(&VAR4[VAR11], 0, 4);
    VAR11 += 4;

    
    FUN8(&VAR4[VAR11], VAR35.VAR83);
    VAR11 += 2;
    FUN8(&VAR4[VAR11], VAR35.VAR94);
    VAR11 += 2;
    FUN8(&VAR4[VAR11], VAR35.VAR85);
    VAR11 += 2;
    
    memset(&VAR4[VAR11], 0, 2);
    VAR11 += 2;
    FUN9(&VAR4[VAR11], VAR35.VAR84);
    VAR11 += 4;
    FUN9(&VAR4[VAR11], VAR35.VAR93);
    VAR11 += 4;
    
    memset(&VAR4[VAR11], 0, 4);
    VAR11 += 4;

    
    if ( VAR6 < ((int)VAR16 + (int)VAR9->VAR44) ) 
        
        memcpy(&VAR4[VAR11], VAR14, VAR15);
    else if (VAR15 >= 4)
        memcpy(&VAR4[VAR11], VAR14, VAR15 - 4);
    else
        memcpy(&VAR4[VAR11], VAR14, VAR15);
}