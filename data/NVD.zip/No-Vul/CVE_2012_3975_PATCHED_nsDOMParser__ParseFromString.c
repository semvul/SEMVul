NS_IMETHODIMP  VAR1::FUN1(const VAR2 *VAR3,                               const char *VAR4,                              VAR5 **VAR6)  
{
  FUN2(VAR3);
  FUN3(VAR6);

  nsresult VAR7;

  if (!VAR8::strcmp(VAR4, "")) {
    VAR9<VAR5> VAR10;
    VAR9<VAR11> VAR12;  
    VAR9<VAR13> VAR14;
    VAR7 = FUN4(VAR15,
                       "",
                       VAR4,
                       FUN5(VAR10),
                       FUN5(VAR12),
                       FUN5(VAR14));
    FUN6(VAR7, VAR7);
    VAR9<VAR16> VAR17 = FUN7(VAR10);
    VAR18 FUN8(VAR3);
    VAR7 = VAR19::FUN9(VAR20, VAR17, false);
    VAR17->FUN10();
    FUN6(VAR7, VAR7);

    VAR10.FUN11(VAR6);
    return VAR7;
  }

  VAR21 FUN12(VAR3);

  
  VAR9<VAR22> VAR23;
  VAR7 = FUN13(FUN5(VAR23),
                             VAR24.FUN14(), VAR24.FUN15(),
                             VAR25);
  if (FUN16(VAR7))
    return VAR7;

  return FUN17(VAR23, "", VAR24.FUN15(), VAR4, VAR6);
}