void *FUN1(struct VAR1 *VAR2)  
{
	struct VAR3 * VAR3;

	VAR3 = FUN2(VAR4 | VAR5 | VAR6);
	if (VAR3 == NULL)
		return NULL;

	FUN3(VAR3);

	FUN4(VAR3);
	FUN5(&VAR7->VAR8);
	return FUN6(VAR3);
}