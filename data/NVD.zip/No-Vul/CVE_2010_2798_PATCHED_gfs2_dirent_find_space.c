static int FUN1(const struct VAR1 *VAR2, 				  const struct VAR3 *VAR4, 				  void *VAR5)  
{
	unsigned VAR6 = FUN2(VAR4->VAR7);
	unsigned VAR8 = FUN2(FUN3(VAR2->VAR9));
	unsigned VAR10 = FUN3(VAR2->VAR11);

	if (FUN4(VAR2))
		VAR8 = 0;
	if (VAR10 - VAR8 >= VAR6)
		return 1;
	return 0;
}