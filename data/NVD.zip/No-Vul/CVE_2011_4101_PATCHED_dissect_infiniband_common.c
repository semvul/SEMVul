static void FUN1(VAR1 *VAR2, VAR3 *VAR4, VAR5 *VAR6, gboolean VAR7)  
{
    
    VAR8 *VAR9 = NULL;

    
    VAR5 *VAR10 = NULL;

    
    VAR5 *VAR11 = NULL;
    VAR8 *VAR12 = NULL;

    
    VAR5 *VAR13 = NULL;
    VAR8 *VAR14 = NULL;

    
    VAR5 *VAR15 = NULL;
    VAR8 *VAR16 = NULL;

    
    VAR5 *VAR17;
    VAR8 *VAR18;
    guint8 VAR19 = 0;             
    gint VAR20 = 0;                

    
    gboolean VAR21 = 0;        
    guint8 VAR22 = 0;         
    guint8 VAR23 = 0;              
    gint32 VAR24 = -1; 
    guint16 VAR25 = 0;      
    guint8 VAR26 = 0;              
    guint16 VAR27 = 0;       
                                    
                                    
    struct e_in6_addr VAR28;       
    struct e_in6_addr VAR29;
    gint VAR30 = 0;

    
    if (!VAR31)
        VAR31 = FUN2(VAR32);

    if (!VAR33)
        VAR33 = FUN2(VAR32);

    VAR4->VAR34 = VAR4->VAR35 = 0xffffffff;  

    
    if (!VAR4->VAR36->VAR37.VAR38)
    {
        VAR4->VAR39 = VAR40;     
    }

    
    
    FUN3(VAR4->VAR41, VAR42, "");
    FUN4(VAR4->VAR41, VAR43);

    
    if(VAR6 && VAR6->VAR44)
    {
        
        VAR6 = VAR6->VAR44;
        
        VAR45 = VAR6;
    }

    
    if(0 && !VAR6)
    {
        
        
        FUN5(VAR2, VAR20, VAR4, VAR7);
        return;
    }

    
    VAR9 = FUN6(VAR6, VAR46, VAR2, VAR20, -1, VAR47);

    
    VAR10 = FUN7(VAR9, VAR48);

    if (VAR7) {
        
        VAR19 = VAR49;
        VAR27 = FUN8(VAR2, 4);   
        goto VAR50;
    }

    
    VAR12 = FUN6(VAR10, VAR51, VAR2, VAR20, 8, VAR47);
    FUN9(VAR12, "", "");
    VAR11 = FUN7(VAR12, VAR52);

    FUN6(VAR11, VAR53,            VAR2, VAR20, 1, VAR47);


    
    VAR22 =  FUN10(VAR2, VAR20);
    VAR22 = VAR22 & 0xF0;


    FUN6(VAR11, VAR54,            VAR2, VAR20, 1, VAR47); VAR20+=1;
    FUN6(VAR11, VAR55,           VAR2, VAR20, 1, VAR47);

    FUN6(VAR11, VAR56,               VAR2, VAR20, 1, VAR47);
    FUN6(VAR11, VAR57,        VAR2, VAR20, 1, VAR47);


    
    VAR19 =  FUN10(VAR2, VAR20);
    VAR19 = VAR19 & 0x03;
    VAR20+=1;


    FUN6(VAR11, VAR58,    VAR2, VAR20, 2, VAR47);


    
    *((VAR59*) VAR33) = FUN8(VAR2, VAR20);
    FUN11(&VAR4->VAR60, VAR61, sizeof(VAR59), VAR33);

    VAR20+=2;

    FUN6(VAR11, VAR62,               VAR2, VAR20, 2, VAR47);

    VAR27 = FUN8(VAR2, VAR20); 
    VAR27 = VAR27 & 0x07FF;      
    VAR27 = VAR27 * 4;           
                                               

    FUN6(VAR11, VAR63,           VAR2, VAR20, 2, VAR47); VAR20+=2;
    FUN6(VAR11, VAR64,         VAR2, VAR20, 2, VAR47);

    
    *((VAR59*) VAR31) = FUN8(VAR2, VAR20);
    FUN11(&VAR4->VAR65, VAR61, sizeof(VAR59), VAR31);

    VAR20+=2;
    VAR27 -= 8; 

VAR50:

    
    switch(VAR19)
    {
        case VAR49:
            VAR14 = FUN6(VAR10, VAR66, VAR2, VAR20, 40, VAR47);
            FUN9(VAR14, "", "");
            VAR13 = FUN7(VAR14, VAR67);

            FUN6(VAR13, VAR68,         VAR2, VAR20, 1, VAR47);
            FUN6(VAR13, VAR69,      VAR2, VAR20, 2, VAR47);
            FUN6(VAR13, VAR70,         VAR2, VAR20, 4, VAR47); VAR20 += 4;

            VAR25 = FUN8(VAR2, VAR20);

            FUN6(VAR13, VAR71,     VAR2, VAR20, 2, VAR47); VAR20 += 2;

            VAR26 = FUN10(VAR2, VAR20);

            FUN6(VAR13, VAR72,        VAR2, VAR20, 1, VAR47); VAR20 +=1;
            FUN6(VAR13, VAR73,          VAR2, VAR20, 1, VAR47); VAR20 +=1;
            FUN6(VAR13, VAR74,         VAR2, VAR20, 16, VAR47);

            FUN12(VAR2, VAR20, &VAR28);

            
            memcpy(VAR31, &VAR28, VAR75);
            FUN11(&VAR4->VAR65, VAR61, VAR75, VAR31);

            VAR20 += 16;

            FUN6(VAR13, VAR76,    VAR2, VAR20, 16, VAR47);

            FUN12(VAR2, VAR20, &VAR29);

            
            memcpy(VAR33, &VAR29, VAR75);
            FUN11(&VAR4->VAR60, VAR61, VAR75, VAR33);

            VAR20 += 16;
            VAR27 -= 40; 

            if(VAR26 != 0x1B)
            {
                
                break;
            }
            
        case VAR77:
            VAR21 = VAR78;
            VAR16 = FUN6(VAR10, VAR79, VAR2, VAR20, 12, VAR47);
            FUN9(VAR16, "", "");
            VAR15 = FUN7(VAR16, VAR80);
            FUN6(VAR15, VAR81,                       VAR2, VAR20, 1, VAR47);

            
            VAR23 = FUN10(VAR2, VAR20);
            FUN13(VAR4->VAR41, VAR43, FUN14((VAR82)VAR23, VAR83, ""));
            VAR20 +=1;

            FUN6(VAR15, VAR84,              VAR2, VAR20, 1, VAR47);
            FUN6(VAR15, VAR85,                       VAR2, VAR20, 1, VAR47);
            FUN6(VAR15, VAR86,                    VAR2, VAR20, 1, VAR47);
            FUN6(VAR15, VAR87,     VAR2, VAR20, 1, VAR47); VAR20 +=1;
            FUN6(VAR15, VAR88,                VAR2, VAR20, 2, VAR47); VAR20 +=2;
            FUN6(VAR15, VAR89,                    VAR2, VAR20, 1, VAR47); VAR20 +=1;
            FUN6(VAR15, VAR90,               VAR2, VAR20, 3, VAR47);
            VAR4->VAR35 = FUN15(VAR2, VAR20); VAR20 +=3;
            FUN6(VAR15, VAR91,          VAR2, VAR20, 1, VAR47);
            FUN6(VAR15, VAR92,                    VAR2, VAR20, 1, VAR47); VAR20 +=1;
            FUN6(VAR15, VAR93,       VAR2, VAR20, 3, VAR47); VAR20 +=3;


            VAR27 -= 12; 

        break;
        case VAR94:
            
            FUN16(VAR33,  VAR32, "");
            FUN11(&VAR4->VAR60,  VAR95, (int)strlen(VAR33)+1, VAR33);

            FUN17(VAR10, VAR2, &VAR20, VAR4);
            break;
        case VAR96:
            FUN18(VAR10, VAR2, &VAR20, VAR4);
            break;
        default:
            
            VAR18 = FUN6(VAR10, VAR97, VAR2, VAR20, -1, VAR47);
            FUN9(VAR18, "", "");
            VAR17 = FUN7(VAR18, VAR98);
            break;
    }

    
    
    if(VAR21)
    {
        

        VAR99 = (VAR23 & 0xE0) >> 5;   
        VAR24 = FUN19((VAR82) VAR23);

        
        
        switch(VAR24)
        {
            case VAR100:
                FUN20(VAR10, VAR2, &VAR20);
                FUN21(VAR10, VAR4, VAR2, &VAR20);

                VAR27 -= 4; 
                VAR27 -= 8; 

                FUN22(VAR10, VAR4, VAR2, &VAR20, VAR27);
                break;
            case VAR101:
                FUN20(VAR10, VAR2, &VAR20);
                FUN21(VAR10, VAR4, VAR2, &VAR20);
                FUN23(VAR10, VAR2, &VAR20);

                VAR27 -= 4; 
                VAR27 -= 8; 
                VAR27 -= 16; 

                FUN22(VAR10, VAR4, VAR2, &VAR20, VAR27);
                break;
            case VAR102:
                FUN20(VAR10, VAR2, &VAR20);
                FUN21(VAR10, VAR4, VAR2, &VAR20);
                FUN24(VAR10, VAR2, &VAR20);

                VAR27 -= 4; 
                VAR27 -= 8; 
                VAR27 -= 4; 

                FUN22(VAR10, VAR4, VAR2, &VAR20, VAR27);
                break;
            case VAR103:
                FUN20(VAR10, VAR2, &VAR20);
                FUN21(VAR10, VAR4, VAR2, &VAR20);
                FUN23(VAR10, VAR2, &VAR20);
                FUN24(VAR10, VAR2, &VAR20);

                VAR27 -= 4; 
                VAR27 -= 8; 
                VAR27 -= 16; 
                VAR27 -= 4; 

                FUN22(VAR10, VAR4, VAR2, &VAR20, VAR27);
                break;
            case VAR104:
                FUN20(VAR10, VAR2, &VAR20);
                FUN21(VAR10, VAR4, VAR2, &VAR20);
                FUN23(VAR10, VAR2, &VAR20);

                VAR27 -= 4; 
                VAR27 -= 8; 
                VAR27 -= 16; 

                break;
            case VAR105:
                FUN20(VAR10, VAR2, &VAR20);
                FUN25(VAR10, VAR2, &VAR20);

                VAR27 -= 4; 
                VAR27 -= 4; 

                FUN22(VAR10, VAR4, VAR2, &VAR20, VAR27);
                break;
            case VAR106:
                FUN20(VAR10, VAR2, &VAR20);

                VAR27 -= 4; 

                FUN22(VAR10, VAR4, VAR2, &VAR20, VAR27);
                break;
            case VAR107:
                FUN25(VAR10, VAR2, &VAR20);

                VAR27 -= 4; 
                VAR27 -= 4; 


                break;
            case VAR108:
                FUN20(VAR10, VAR2, &VAR20);
                FUN25(VAR10, VAR2, &VAR20);
                FUN26(VAR10, VAR2, &VAR20);

                VAR27 -= 4; 
                VAR27 -= 4; 
                VAR27 -= 8; 


                break;
            case VAR109:
                FUN20(VAR10, VAR2, &VAR20);
                FUN21(VAR10, VAR4, VAR2, &VAR20);
                FUN27(VAR10, VAR2, &VAR20);

                VAR27 -= 4; 
                VAR27 -= 8; 
                VAR27 -= 28; 

                break;
            case VAR110:
                FUN20(VAR10, VAR2, &VAR20);
                FUN21(VAR10, VAR4, VAR2, &VAR20);

                VAR27 -= 4; 
                VAR27 -= 8; 

                break;
            case VAR111:
                FUN21(VAR10, VAR4, VAR2, &VAR20);

                VAR27 -= 8; 

                FUN22(VAR10, VAR4, VAR2, &VAR20, VAR27);
                break;
            case VAR112:

                FUN22(VAR10, VAR4, VAR2, &VAR20, VAR27);
                break;
            case VAR113:
                FUN24(VAR10, VAR2, &VAR20);

                VAR27 -= 4; 

                FUN22(VAR10, VAR4, VAR2, &VAR20, VAR27);
                break;
            case VAR114:
                FUN23(VAR10, VAR2, &VAR20);

                VAR27 -= 16; 

                FUN22(VAR10, VAR4, VAR2, &VAR20, VAR27);
                break;
            case VAR115:
                FUN23(VAR10, VAR2, &VAR20);

                VAR27 -= 16; 

                break;
            case VAR116:
                FUN25(VAR10, VAR2, &VAR20);

                VAR27 -= 4; 

                FUN22(VAR10, VAR4, VAR2, &VAR20, VAR27);
                break;
            case VAR117:
                FUN25(VAR10, VAR2, &VAR20);

                VAR27 -= 4; 

                break;
            case VAR118:
                FUN25(VAR10, VAR2, &VAR20);
                FUN26(VAR10, VAR2, &VAR20);

                VAR27 -= 4; 
                VAR27 -= 8; 

                break;
            case VAR119:
                FUN27(VAR10, VAR2, &VAR20);

                VAR27 -= 28; 

                break;
            case VAR120:
                FUN28(VAR10, VAR2, &VAR20);

                VAR27 -= 4; 

                FUN22(VAR10, VAR4, VAR2, &VAR20, VAR27);
                break;
            case VAR121:
                FUN21(VAR10, VAR4, VAR2, &VAR20);
                FUN24(VAR10, VAR2, &VAR20);

                VAR27 -= 8; 
                VAR27 -= 4; 

                FUN22(VAR10, VAR4, VAR2, &VAR20, VAR27);
                break;
            default:
                FUN29(VAR10, VAR2, &VAR20);
                break;

        }

    }
    
    
    
    VAR30 = FUN30(VAR2, VAR20);
    if(VAR30 == 6)
    {
        FUN6(VAR10, VAR122, VAR2, VAR20, 4, VAR47); VAR20 +=4;
        FUN6(VAR10, VAR123,   VAR2, VAR20, 2, VAR47); VAR20+=2;
    }
    else if(VAR30 == 4)
    {
        FUN6(VAR10, VAR122, VAR2, VAR20, 4, VAR47); VAR20 +=4;
    }
    else if(VAR30 == 2)
    {
        FUN6(VAR10, VAR123,   VAR2, VAR20, 2, VAR47); VAR20+=2;
    }

}