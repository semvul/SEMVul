*/ int FUN1(const char *VAR1, struct VAR2 *VAR3, int VAR4, int VAR5)  
{
	char *VAR6;
	struct VAR7 *VAR8 = FUN2(16);

	
	const struct VAR9 {
		const char *VAR10;
		const VAR11 *VAR12;
	} *VAR13, VAR14[] = {
		{ "", &VAR3->VAR15 },
		{ "", &VAR3->VAR16 },
		{ "", &VAR3->VAR17 },
		{ "", &VAR3->VAR18 },
		{ "", &VAR3->VAR19 },
		{ "", &VAR3->VAR20 },
		{ "", &VAR3->VAR21 },
		{ "", &VAR3->VAR22 },
		
		{ "", NULL },
		{ "", NULL },
		{ "", NULL },
		{ NULL, 0 },
	};

	if (FUN3(VAR1) || !VAR3 || !VAR8) {
		FUN4(VAR8);
		return -1;
	}

	FUN5(&VAR8, 0, "", VAR1);

	VAR6 = FUN6(FUN7(VAR8));

	if (FUN8(VAR6, "", strlen(""))) {
		FUN9(VAR23, "");
		FUN4(VAR8);
		return -1;
	}
	VAR6 += strlen("");

	
	while (VAR6 && *VAR6 && *(VAR6 = FUN6(VAR6))) {
		
		for (VAR13 = VAR14; VAR13->VAR10 != NULL; VAR13++) {
			char *VAR24, *VAR25;
			int VAR26 = 0;
			if (FUN8(VAR6, VAR13->VAR10, strlen(VAR13->VAR10)) != 0) {
				continue;
			}

			
			VAR6 += strlen(VAR13->VAR10);
			if (*VAR6 == '') {
				VAR24 = ++VAR6;
				VAR25 = """;
				VAR26 = 1;
			} else {
				VAR24 = VAR6;
				VAR25 = "";
			}
			FUN10(&VAR6, VAR25); 
			if (VAR26) {
				FUN11(VAR24);
			}
			if (VAR13->VAR12) {
				FUN12(VAR3, VAR13->VAR12, VAR24);
			} else {
				
				if (!FUN13(VAR13->VAR10, "")) {
					if (FUN13(VAR24, "")) {
						FUN9(VAR23, ""%VAR27\"", VAR24);
						FUN4(VAR8);
						return -1;
					}
				} else if (!FUN13(VAR13->VAR10, "") && !FUN13(VAR24, "")) {
					VAR3->VAR28 = 1;
				} else if (!FUN13(VAR13->VAR10, "")) {
					unsigned long VAR29;
					if (sscanf(VAR24, "", &VAR29) != 1) {
						FUN9(VAR23, ""%VAR27\"", VAR24);
						FUN4(VAR8);
						return -1;
					}
					FUN14(VAR3, VAR30, VAR24);
				}
			}
			break;
		}
		if (VAR13->VAR10 == NULL) { 
			FUN10(&VAR6, "");
		}
	}
	FUN4(VAR8);

	
	if (FUN3(VAR3->VAR16) || FUN3(VAR3->VAR17)) {
		
		return -1;
	}

	if (!VAR4) {
		
		if (FUN3(VAR3->VAR15) || FUN3(VAR3->VAR18) || FUN3(VAR3->VAR20)) {
			return -1;
		}

		if (VAR5 && VAR3->VAR28 && (FUN3(VAR3->VAR21) || FUN3(VAR3->VAR30))) {
			return -1;
		}
	}

	return 0;
}