VAR1 FUN1(const void* VAR2)  
{
        if (VAR3 == VAR4) {
            VAR5 = realloc(VAR5, VAR6);
            if (!VAR5) {
                VAR6 = 0;
                return VAR7;
            }
            memcpy(VAR5, VAR2, VAR6);
        }
        return VAR8;
    }