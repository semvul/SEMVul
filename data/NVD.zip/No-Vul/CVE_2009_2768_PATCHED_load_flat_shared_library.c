static int FUN1(int VAR1, struct VAR2 *VAR3)  
{
	struct linux_binprm VAR4;
	int VAR5;
	char VAR6[16];

	
	sprintf(VAR6, "", VAR1);

	
	VAR4.VAR7 = VAR6;
	VAR4.VAR8 = FUN2(VAR4.VAR7);
	VAR5 = FUN3(VAR4.VAR8);
	if (FUN4(VAR4.VAR8))
		return VAR5;

	VAR4.VAR9 = FUN5();
	VAR5 = -VAR10;
	if (!VAR4.VAR9)
		goto VAR11;

	VAR5 = FUN6(&VAR4);

	if (VAR5 <= (unsigned long)-4096)
		VAR5 = FUN7(&VAR4, VAR3, VAR1, NULL);

	FUN8(VAR4.VAR9);

VAR11:
	FUN9(VAR4.VAR8);
	FUN10(VAR4.VAR8);

	return(VAR5);
}