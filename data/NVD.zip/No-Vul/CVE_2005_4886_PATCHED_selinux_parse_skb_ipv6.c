static int FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4)  
{
	u8 VAR5;
	int VAR6 = -VAR7, VAR8;
	struct ipv6hdr VAR9, *VAR10;

	VAR8 = VAR2->VAR11.VAR12 - VAR2->VAR13;
	VAR10 = FUN2(VAR2, VAR8, sizeof(VAR9), &VAR9);
	if (VAR10 == NULL)
		goto VAR14;

	FUN3(&VAR4->VAR15.VAR16.VAR17.VAR18, &VAR10->VAR18);
	FUN3(&VAR4->VAR15.VAR16.VAR17.VAR19, &VAR10->VAR19);
	VAR6 = 0;

	VAR5 = VAR10->VAR5;
	VAR8 += sizeof(VAR9);
	VAR8 = FUN4(VAR2, VAR8, &VAR5);
	if (VAR8 < 0)
		goto VAR14;

	switch (VAR5) {
	case VAR20: {
        	struct tcphdr VAR21, *VAR22;

		VAR22 = FUN2(VAR2, VAR8, sizeof(VAR21), &VAR21);
		if (VAR22 == NULL)
			break;

		VAR4->VAR15.VAR16.VAR23 = VAR22->VAR24;
		VAR4->VAR15.VAR16.VAR25 = VAR22->VAR26;
		break;
	}

	case VAR27: {
		struct udphdr VAR28, *VAR29;

		VAR29 = FUN2(VAR2, VAR8, sizeof(VAR28), &VAR28);
		if (VAR29 == NULL)
			break;

		VAR4->VAR15.VAR16.VAR23 = VAR29->VAR24;
		VAR4->VAR15.VAR16.VAR25 = VAR29->VAR26;
		break;
	}

	
	default:
		break;
	}
VAR14:
	return VAR6;
}