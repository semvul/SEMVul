int FUN1(struct VAR1 *VAR1, struct VAR2 *VAR3, int VAR4, 		struct VAR5 *VAR6)  
{
	int VAR7 = -VAR8;
	int VAR9;
	int VAR10 = VAR11;
	__u32 VAR12 = 0;
	int VAR13;
	bool VAR14 = false;
	
	int VAR15 = VAR16 | VAR17;
	__u16 VAR18;
	struct VAR19 *VAR20;
	struct VAR21 *VAR22;
	char *VAR23 = NULL;
	VAR24 *VAR25 = NULL;
	struct VAR1 *VAR26 = NULL;
	int VAR27 = VAR28;

	VAR9 = FUN2();

	VAR20 = FUN3(VAR1->VAR29);
	VAR22 = VAR20->VAR22;

	VAR23 = FUN4(VAR3);
	if (VAR23 == NULL) {
		VAR7 = -VAR30;
		FUN5(VAR9);
		return VAR7;
	}

	if (VAR31)
		VAR12 = VAR32;

	if (VAR6 && (VAR6->VAR33 & VAR34))
		VAR13 = VAR6->VAR35.open.VAR33;
	else
		VAR13 = VAR36 | VAR37;

	if (VAR22->VAR38 && (VAR22->VAR39->VAR40 & VAR41) &&
	    (VAR42 &
			FUN6(VAR22->VAR43.VAR44))) {
		VAR7 = FUN7(VAR23, &VAR26,
			VAR6 ? VAR6->VAR45.VAR46 : NULL,
			VAR1->VAR29, VAR4, VAR13, &VAR12, &VAR18, VAR9);
		

		if (VAR7 == 0) {
			VAR14 = true;
			if (VAR26 == NULL) 
				goto VAR47;
			else 
				goto VAR48;
		} else if ((VAR7 != -VAR49) && (VAR7 != -VAR50) &&
			 (VAR7 != -VAR51) && (VAR7 != -VAR52))
			goto VAR53;
		
	}

	if (VAR6 && (VAR6->VAR33 & VAR34)) {
		
		VAR15 = 0;
		if (VAR13 & VAR36)
			VAR15 |= VAR16; 
		if (VAR13 & VAR54)
			VAR15 |= VAR17;

		if ((VAR13 & (VAR55 | VAR56)) == (VAR55 | VAR56))
			VAR27 = VAR57;
		else if ((VAR13 & (VAR55 | VAR58)) == (VAR55 | VAR58))
			VAR27 = VAR28;
		else if ((VAR13 & VAR55) == VAR55)
			VAR27 = VAR59;
		else
			FUN8(1, (""));
	}

	

	VAR25 = FUN9(sizeof(VAR24), VAR60);
	if (VAR25 == NULL) {
		FUN10(VAR23);
		FUN5(VAR9);
		return -VAR30;
	}

	
	if (!VAR22->VAR38 && (VAR4 & VAR61) == 0)
		VAR10 |= VAR62;

	if (VAR20->VAR22->VAR39->VAR40 & VAR63)
		VAR7 = FUN11(VAR9, VAR22, VAR23, VAR27,
			 VAR15, VAR10,
			 &VAR18, &VAR12, VAR25, VAR20->VAR64,
			 VAR20->VAR65 & VAR66);
	else
		VAR7 = -VAR49; 

	if (VAR7 == -VAR49) {
		
		VAR7 = FUN12(VAR9, VAR22, VAR23, VAR27,
			VAR15, VAR10,
			&VAR18, &VAR12, VAR25, VAR20->VAR64,
			VAR20->VAR65 & VAR66);
	}
	if (VAR7) {
		FUN8(1, ("", VAR7));
		goto VAR53;
	}

	
	if ((VAR22->VAR38) && (VAR12 & VAR67)) {
		struct cifs_unix_set_info_args VAR68 = {
				.VAR4	= VAR4,
				.VAR69	= VAR70,
				.VAR71	= VAR70,
				.VAR72	= VAR70,
				.VAR73	= 0,
		};

		if (VAR20->VAR65 & VAR74) {
			VAR68.VAR75 = (VAR76) FUN13();
			if (VAR1->VAR77 & VAR78)
				VAR68.VAR79 = (VAR76) VAR1->VAR80;
			else
				VAR68.VAR79 = (VAR76) FUN14();
		} else {
			VAR68.VAR75 = VAR70;
			VAR68.VAR79 = VAR70;
		}
		FUN15(VAR9, VAR22, VAR23, &VAR68,
					VAR20->VAR64,
					VAR20->VAR65 &
						VAR66);
	} else {
		
		

		
	}

VAR47:
	
	if (VAR22->VAR38)
		VAR7 = FUN16(&VAR26, VAR23,
					      VAR1->VAR29, VAR9);
	else {
		VAR7 = FUN17(&VAR26, VAR23, VAR25,
					 VAR1->VAR29, VAR9, &VAR18);
		if (VAR26) {
			if (VAR20->VAR65 & VAR81)
				VAR26->VAR77 = VAR4;
			if ((VAR12 & VAR67) &&
			    (VAR20->VAR65 & VAR74)) {
				VAR26->VAR82 = FUN13();
				if (VAR1->VAR77 & VAR78)
					VAR26->VAR80 = VAR1->VAR80;
				else
					VAR26->VAR80 = FUN14();
			}
		}
	}

VAR48:
	if (VAR7 == 0)
		FUN18(VAR22, VAR3, VAR26);
	else
		FUN8(1, ("", VAR7));

	
	if ((VAR6 == NULL) || (!(VAR6->VAR33 & VAR34))) {
		
		FUN19(VAR9, VAR22, VAR18);
	} else if (!(VAR14) && (VAR26)) {
			FUN20(VAR26, VAR18, NULL,
						VAR6->VAR45.VAR46, VAR13);
	}
VAR53:
	FUN10(VAR25);
	FUN10(VAR23);
	FUN5(VAR9);
	return VAR7;
}