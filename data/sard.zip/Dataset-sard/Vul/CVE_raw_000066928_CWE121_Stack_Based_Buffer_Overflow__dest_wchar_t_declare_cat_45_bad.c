void FUN1()
{
    wchar_t * VAR1;
    wchar_t VAR2[50];
    wchar_t VAR3[100];
    
    VAR1 = VAR2;
    VAR1[0] = VAR4''; 
    VAR5 = VAR1;
    FUN2();
}