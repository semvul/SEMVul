void VAR1::FUN1(void *VAR2, bool VAR3)  
{
  
  VAR4<VAR5> VAR6 =
    FUN2("");
  if (VAR6 && FUN3(VAR6->FUN4(VAR7))) {
    VAR6 = VAR8;
  }

  if (VAR2) {
    VAR9 *VAR10 = (VAR9 *)VAR2;
    VAR11 FUN5(VAR7);

    JSAutoEnterCompartment VAR12;
    VAR12.FUN6(VAR7, VAR10);

    
    
    
    
    jsval VAR13;
    uintN VAR14;
    JSPropertyOp VAR15;
    JSStrictPropertyOp VAR16;
    JSBool VAR17;
    if (!FUN7(VAR7, VAR10, "", &VAR13) ||
        !FUN8(VAR7, VAR10, "",
                                            &VAR14, &VAR17,
                                            &VAR15, &VAR16) ||
        !VAR17) {
      VAR13 = VAR18;

      FUN9(VAR7);
    }

    FUN10(VAR7, VAR10);

    FUN11(!VAR19::VAR20::FUN12(VAR10), "");

    if (VAR13 != VAR18) {
      if (!FUN13(VAR7, VAR10, "", VAR13,
                             VAR15, VAR16, VAR14)) {
        FUN9(VAR7);
      }
    }

    if (!VAR21::FUN14(VAR10)) {
      FUN15(VAR7, VAR10);
    }

    
    
    
    
    
    
    
    
    
    
    ::FUN16(VAR7, VAR10);

    
    
    
    
    if (VAR3) {
      VAR22::FUN17(VAR7, VAR10);

      
      for (VAR9 *VAR23 = ::FUN18(VAR7, VAR10), *VAR24;
           VAR23 && (VAR24 = ::FUN18(VAR7, VAR23)); VAR23 = VAR24)
        ::FUN10(VAR7, VAR23);
    }
  }

  if (VAR6) {
    VAR6->FUN19(VAR8);
  }
}