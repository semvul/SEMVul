void FUN1()
{
    char * VAR1;
    char VAR2[100] = "";
    VAR1 = VAR2;
    VAR3 = 1; 
    VAR1 = FUN2(VAR1);
    
    
    FUN3(VAR4, VAR4, VAR5, VAR6, VAR7, NULL);
}