static VAR1 FUN1(VAR2 *VAR3, uintN argc, VAR4 *VAR5)  
{
    FUN2(VAR3);
    VAR6 *VAR7 = FUN3(VAR3, VAR5);
    if (!VAR7)
        return VAR8;

    nsresult VAR9;

    VAR10 *VAR11;
    xpc_qsSelfRef VAR12;
    VAR13::VAR14 FUN4(VAR3);
    if (!FUN5(VAR3, VAR7, VAR15, &VAR11, &VAR12.VAR16, VAR17.FUN6(), VAR15))
        return VAR8;

    if (argc < 6 || argc == 7 || argc == 8)
        return FUN7(VAR3, VAR18);

    VAR4 *argv = FUN8(VAR3, VAR5);

    
    FUN9(VAR19, 0);
    FUN10(VAR20, 1);

    if (argc > 5 &&
        !FUN11(argv[5]))
    {
        
        FUN9(VAR21, 2);
        FUN9(VAR22, 3);
        FUN9(VAR23, 4);

        VAR24 *VAR25;
        xpc_qsSelfRef VAR26;
        VAR9 = VAR27<VAR24>(VAR3, argv[5], &VAR25, &VAR26.VAR16, &argv[5]);
        if (FUN12(VAR9)) return VAR8;

        VAR9 = VAR11->FUN13(VAR19, VAR20, VAR21, VAR22, VAR23, VAR25);

        
        
        if (VAR9 == VAR28) {
            FUN14(VAR3, VAR9, VAR5, 5);
            return VAR8;
        }

        if (FUN12(VAR9)) {
            
            VAR6 *VAR29 = FUN15(argv[5]);

            jsval VAR30, VAR31, VAR32;
            FUN16(VAR3, VAR29, "", &VAR30);
            FUN16(VAR3, VAR29, "", &VAR31);
            FUN16(VAR3, VAR29, "", &VAR32);
            if (VAR30  == VAR33 ||
                VAR31 == VAR33 ||
                !VAR32.FUN17())
            {
                FUN14(VAR3, VAR34, VAR5, 5);
                return VAR8;
            }
            int32_t VAR35, VAR36;
            VAR6 *VAR37 = FUN15(VAR32);
            if (!FUN18(VAR3, VAR30, &VAR35) ||
                !FUN18(VAR3, VAR31, &VAR36))
            {
                return VAR8;
            }
            if (!FUN19(VAR37))
            {
                FUN14(VAR3, VAR34, VAR5, 5);
                return VAR8;
            }
            VAR9 = VAR11->FUN20(VAR19, VAR20, VAR21,
                                            VAR35, VAR36, 0,
                                            VAR22, VAR23, VAR13::VAR38::FUN21(VAR37));
        }
    } else if (argc > 8 &&
               FUN22(argv[8])) 
    {
        
        FUN9(VAR21, 2);
        FUN10(VAR22, 3);
        FUN10(VAR23, 4);
        FUN10(VAR29, 5);
        FUN9(VAR39, 6);
        FUN9(VAR40, 7);

        VAR6 *VAR41 = FUN15(argv[8]);

        
        if (VAR41 == VAR15) {
            VAR9 = VAR11->FUN23(VAR19, VAR20, VAR21, VAR22,
                                        VAR23, VAR29, VAR39, VAR40,
                                        VAR15);
        } else if (FUN19(VAR41)) {
            VAR9 = VAR11->FUN23(VAR19, VAR20, VAR21, VAR22,
                                        VAR23, VAR29, VAR39, VAR40,
                                        VAR13::VAR38::FUN21(VAR41));
        } else {
            FUN14(VAR3, VAR34, VAR5, 8);
            return VAR8;
        }
    } else {
        FUN7(VAR3, VAR18);
        return VAR8;
    }

    if (FUN12(VAR9))
        return FUN24(VAR3, VAR9, VAR5);

    *VAR5 = VAR33;
    return VAR42;
}