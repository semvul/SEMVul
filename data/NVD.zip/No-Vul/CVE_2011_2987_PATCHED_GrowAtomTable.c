static int FUN1(VAR1 *VAR2, int VAR3)  
{
    int *VAR4, *VAR5;

    if (VAR2->VAR3 < VAR3) {
        if (VAR2->VAR6) {
            VAR4 = realloc(VAR2->VAR6, sizeof(int)*VAR3);
            VAR5 = realloc(VAR2->VAR7, sizeof(int)*VAR3);
        } else {
            VAR4 = malloc(sizeof(int)*VAR3);
            VAR5 = malloc(sizeof(int)*VAR3);
            VAR2->VAR3 = 0;
        }
        if (!VAR4 || !VAR5) {
            
            if (VAR4)
                VAR2->VAR6 = VAR4;
            if (VAR5)
                VAR2->VAR7 = VAR5;
            return -1;
        }
        memset(&VAR4[VAR2->VAR3], 0, (VAR3 - VAR2->VAR3) * sizeof(int));
        memset(&VAR5[VAR2->VAR3], 0, (VAR3 - VAR2->VAR3) * sizeof(int));
        VAR2->VAR6 = VAR4;
        VAR2->VAR7 = VAR5;
        VAR2->VAR3 = VAR3;
    }
    return 0;
}