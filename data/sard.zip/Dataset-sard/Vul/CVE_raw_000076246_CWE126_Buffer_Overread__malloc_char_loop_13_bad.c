void CWE126_Buffer_Overread__malloc_char_loop_13_bad()
{
    char * data;
    data = NULL;
    if(GLOBAL_CONST_FIVE==5)
    {
        /* FLAW: Use a small buffer */
        data = (char *)malloc(50*sizeof(char));
        memset(data, 'A', 50-1); /* fill with 'A's */
        data[50-1] = '\0'; /* null terminate */
    }
    {
        size_t i, destLen;
        char dest[100];
        memset(dest, 'C', 100-1);
        dest[100-1] = '\0'; /* null terminate */
        destLen = strlen(dest);
        /* POTENTIAL FLAW: using length of the dest where data
         * could be smaller than dest causing buffer overread */
        for (i = 0; i < destLen; i++)
        {
            dest[i] = data[i];
        }
        dest[100-1] = '\0';
        printLine(dest);
        free(data);
    }
}
