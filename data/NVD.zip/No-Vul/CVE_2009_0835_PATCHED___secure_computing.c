void FUN1(int VAR1)  
{
	int VAR2 = VAR3->VAR4.VAR2;
	int * VAR5;

	switch (VAR2) {
	case 1:
		VAR5 = VAR6;
#ifdef VAR7
		if (VAR7)
			VAR5 = VAR8;
#endif
		do {
			if (*VAR5 == VAR1)
				return;
		} while (*++VAR5);
		break;
	default:
		FUN2();
	}

#ifdef VAR9
	FUN3();
#endif
	FUN4(VAR10);
}