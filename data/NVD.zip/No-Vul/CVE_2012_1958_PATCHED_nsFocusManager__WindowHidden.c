NS_IMETHODIMP VAR1::FUN1(VAR2* VAR3)  
{
  
  
  

  VAR4<VAR5> VAR6 = FUN2(VAR3);
  FUN3(VAR6, VAR7);

  VAR6 = VAR6->FUN4();

#ifdef VAR8
  FUN5("", VAR6.FUN6(), VAR9.FUN6(), VAR10.FUN6());
  nsCAutoString VAR11;
  VAR4<VAR12> VAR13 = FUN2(VAR6->FUN7());
  if (VAR13) {
    VAR13->FUN8()->FUN9(VAR11);
    FUN5("", VAR11.FUN6());
  }

  if (VAR10) {
    VAR13 = FUN2(VAR10->FUN7());
    if (VAR13) {
      VAR13->FUN8()->FUN9(VAR11);
      FUN5("", VAR11.FUN6());
    }
  }

  if (VAR9) {
    VAR13 = FUN2(VAR9->FUN7());
    if (VAR13) {
      VAR13->FUN8()->FUN9(VAR11);
      FUN5("", VAR11.FUN6());
    }
  }
  FUN5("");
#endif

  if (!FUN10(VAR6, VAR10))
    return VAR14;

  
  
  

  VAR4<VAR15> VAR16 = VAR17.FUN11();

  if (VAR16 && VAR16->FUN12()) {
    FUN13(VAR16,
                           VAR10->FUN14(),
                           false);
  }

  VAR4<VAR18> VAR19 = VAR10->FUN15();
  VAR4<VAR20> VAR21;
  VAR19->FUN16(FUN17(VAR21));

  VAR22::FUN18(VAR23, VAR23);
  if (VAR21) {
    VAR22::FUN19(VAR21->FUN20(), VAR23, VAR24::VAR25);
    FUN21(VAR21, false, VAR23);
  }

  
  
  
  
  
  
  bool VAR26;
  VAR4<VAR18> VAR27 = VAR6->FUN15();
  VAR27->FUN22(&VAR26);
  if (VAR26) {
    
    
    
    
    
    FUN23(VAR10->FUN24(), "");
    if (VAR9 == VAR10 || VAR9 == VAR6)
      FUN25(VAR9);
    else
      FUN26(VAR9);
    return VAR14;
  }

  
  
  
  
  if (VAR6 != VAR10) {
    VAR4<VAR28> FUN27(FUN28(VAR10));
    VAR4<VAR29> VAR30 = FUN2(VAR31);
    if (VAR30) {
      VAR4<VAR29> VAR32;
      VAR30->FUN29(FUN17(VAR32));
      VAR4<VAR5> VAR33 = FUN28(VAR32);
      if (VAR33)
        VAR33->FUN30(VAR23);
    }

    VAR10 = VAR6;
  }

  return VAR14;
}