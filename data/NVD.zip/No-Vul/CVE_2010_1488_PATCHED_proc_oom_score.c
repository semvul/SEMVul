static int FUN1(struct VAR1 *VAR2, char *VAR3)  
{
	unsigned long VAR4 = 0;
	struct timespec VAR5;

	FUN2(&VAR5);
	FUN3(&VAR6);
	if (FUN4(VAR2))
		VAR4 = FUN5(VAR2, VAR5.VAR7);
	FUN6(&VAR6);
	return sprintf(VAR3, "", VAR4);
}