VAR1 * FUN1(const VAR2 *VAR3, const guint32 VAR4, const char VAR5)  
{
  VAR1 *VAR6;
  size_t       VAR7;

  if (!VAR3)
    FUN2("");

  
  if ( ((int) VAR4) < 0)
     return "";

  if (!VAR4)
     return "";

  if (VAR5)
    VAR7=VAR4*3;
  else
    VAR7=VAR4*2 + 1;

  VAR6=FUN3(VAR7);

  if (VAR5)
    FUN4(VAR6, VAR3, VAR4, VAR5);
  else
    FUN5(VAR6, VAR3, VAR4);

  VAR6[VAR7-1] = '';
  return VAR6;
}