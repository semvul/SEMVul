static void FUN1( VAR1 *VAR2 )  
{
    VAR3 *VAR4 = (VAR3*)VAR2;
    VAR5 *VAR6 = VAR4->VAR6;

    for( int VAR7 = 0; VAR7 < VAR6->VAR8; VAR7++ )
    {
        VAR9 *VAR10 = VAR6->VAR11[VAR7];

        FUN2( &VAR10->VAR12 );

        if( VAR10->VAR13 )
            FUN3( VAR10->VAR13 );

        for( int VAR14 = 0; VAR14 < VAR10->VAR15; VAR14++ )
        {
            if( VAR10->VAR16[ VAR14 ] )
                FUN3( VAR10->VAR16[ VAR14 ] );
        }
        free( VAR10->VAR16 );
        free( VAR10->VAR17 );
        if( VAR10->VAR18 )
            FUN3( VAR10->VAR18 );
        free( VAR10 );
    }
    if( VAR6->VAR8 > 0 )
        free( VAR6->VAR11 );

    free( VAR6->VAR19 );
    free( VAR6->VAR20 );
    free( VAR6->VAR21 );
    free( VAR6->VAR22 );
    free( VAR6->VAR23 );

    free( VAR6 );
}