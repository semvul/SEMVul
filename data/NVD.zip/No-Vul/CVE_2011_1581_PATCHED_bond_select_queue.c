static VAR1 FUN1(struct VAR2 *VAR3, struct VAR4 *VAR5)  
{
	
	u16 VAR6 = FUN2(VAR5) ? FUN3(VAR5) : 0;

	if (FUN4(VAR6 >= VAR3->VAR7)) {
		do
			VAR6 -= VAR3->VAR7;
		while (VAR6 >= VAR3->VAR7);
	}
	return VAR6;
}