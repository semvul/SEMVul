static int FUN1( VAR1 *VAR2, const VAR3 *VAR4, int VAR5 )  
{
    int VAR6[2];
    int VAR7, VAR8;
    int VAR9, VAR10;

    VAR6[0] = VAR4[0] & 0x0f;
    VAR6[1] = VAR4[1] & 0x0f;

    VAR8 = (VAR4[2] & 0x1f)*12;
    VAR7 = (VAR4[3] & 0x3f)*6;

    for( VAR10 = 0; VAR10 < 12; VAR10++ )
    {
        for( VAR9 = 0; VAR9 < 6; VAR9++ )
        {
            const int VAR11 = ( VAR4[4+VAR10] >> (5-VAR9) ) & 0x01;

            int VAR12 = (VAR8+VAR10)*VAR13+(VAR7+VAR9);
            if( VAR12 >= VAR13*VAR14 )
                return 0;

            VAR3 *VAR15 = &VAR2->VAR16[VAR12];

            if( VAR5 )
                *VAR15 ^= VAR6[VAR11];
            else
                *VAR15 = VAR6[VAR11];
        }
    }
    return 0;
}