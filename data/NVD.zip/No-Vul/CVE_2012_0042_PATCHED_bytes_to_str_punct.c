VAR1 * FUN1(const VAR2 *VAR3, int VAR4, gchar VAR5)  
{
  VAR1 *VAR6;
  VAR1 *VAR7;
  int VAR8 = 0;

  if (!VAR5)
    return FUN2(VAR3, VAR4);

  VAR6=FUN3(VAR9+3+1);
  if (VAR4 <= 0) { VAR6[0] = ''; return VAR6; }

  if (VAR4 > VAR9/3) {	
   VAR8 = 1;
   VAR4 = VAR9/3;
  }

  VAR7 = FUN4(VAR6, VAR3, VAR4, VAR5); 

  if (VAR8) {
    *VAR7++ = VAR5;				
    VAR7    = FUN5(VAR7, "");	
  }

  *VAR7 = '';
  return VAR6;
}