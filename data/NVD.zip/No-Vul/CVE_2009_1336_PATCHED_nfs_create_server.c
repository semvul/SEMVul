struct VAR1 *FUN1(const struct VAR2 *VAR3, 				     struct VAR4 *VAR5)  
{
	struct VAR1 *VAR6;
	struct nfs_fattr VAR7;
	int VAR8;

	VAR6 = FUN2();
	if (!VAR6)
		return FUN3(-VAR9);

	
	VAR8 = FUN4(VAR6, VAR3);
	if (VAR8 < 0)
		goto VAR8;

	FUN5(!VAR6->VAR10);
	FUN5(!VAR6->VAR10->VAR11);
	FUN5(!VAR6->VAR10->VAR11->VAR12);

	
	VAR8 = FUN6(VAR6, VAR5, &VAR7);
	if (VAR8 < 0)
		goto VAR8;
	if (VAR6->VAR10->VAR11->VAR13 == 3) {
		if (VAR6->VAR14 == 0 || VAR6->VAR14 > VAR15)
			VAR6->VAR14 = VAR15;
		if (!(VAR3->VAR16 & VAR17))
			VAR6->VAR18 |= VAR19;
	} else {
		if (VAR6->VAR14 == 0 || VAR6->VAR14 > VAR20)
			VAR6->VAR14 = VAR20;
	}

	if (!(VAR7.VAR21 & VAR22)) {
		VAR8 = VAR6->VAR10->VAR11->FUN7(VAR6, VAR5, &VAR7);
		if (VAR8 < 0) {
			FUN8("", -VAR8);
			goto VAR8;
		}
	}
	memcpy(&VAR6->VAR23, &VAR7.VAR23, sizeof(VAR6->VAR23));

	FUN8("",
		(unsigned long long) VAR6->VAR23.VAR24,
		(unsigned long long) VAR6->VAR23.VAR25);

	FUN5(!VAR6->VAR10);
	FUN5(!VAR6->VAR10->VAR11);
	FUN5(!VAR6->VAR10->VAR11->VAR12);

	FUN9(&VAR26);
	FUN10(&VAR6->VAR27, &VAR6->VAR10->VAR28);
	FUN10(&VAR6->VAR29, &VAR30);
	FUN11(&VAR26);

	VAR6->VAR31 = VAR32;
	return VAR6;

VAR8:
	FUN12(VAR6);
	return FUN3(VAR8);
}