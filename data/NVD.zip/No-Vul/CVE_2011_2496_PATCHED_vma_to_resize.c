static struct VAR1 *FUN1(unsigned long VAR2, 	unsigned long VAR3, unsigned long VAR4, unsigned long *VAR5)  
{
	struct VAR6 *VAR7 = VAR8->VAR7;
	struct VAR1 *VAR9 = FUN2(VAR7, VAR2);

	if (!VAR9 || VAR9->VAR10 > VAR2)
		goto VAR11;

	if (FUN3(VAR9))
		goto VAR12;

	
	if (VAR3 > VAR9->VAR13 - VAR2)
		goto VAR11;

	
	if (VAR4 > VAR3) {
		unsigned long VAR14;

		if (VAR9->VAR15 & (VAR16 | VAR17))
			goto VAR11;
		VAR14 = (VAR2 - VAR9->VAR10) >> VAR18;
		VAR14 += VAR9->VAR19;
		if (VAR14 + (VAR4 >> VAR18) < VAR14)
			goto VAR12;
	}

	if (VAR9->VAR15 & VAR20) {
		unsigned long VAR21, VAR22;
		VAR21 = VAR7->VAR23 << VAR18;
		VAR22 = FUN4(VAR24);
		VAR21 += VAR4 - VAR3;
		if (VAR21 > VAR22 && !FUN5(VAR25))
			goto VAR26;
	}

	if (!FUN6(VAR7, (VAR4 - VAR3) >> VAR18))
		goto VAR27;

	if (VAR9->VAR15 & VAR28) {
		unsigned long VAR29 = (VAR4 - VAR3) >> VAR18;
		if (FUN7(VAR29))
			goto VAR11;
		*VAR5 = VAR29;
	}

	return VAR9;

VAR11:	
	return FUN8(-VAR30);
VAR12:
	return FUN8(-VAR31);
VAR27:
	return FUN8(-VAR32);
VAR26:
	return FUN8(-VAR33);
}