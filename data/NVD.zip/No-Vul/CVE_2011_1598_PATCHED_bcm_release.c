static int FUN1(struct socket *VAR1)  
{
	struct VAR1 *VAR2 = VAR1->VAR2;
	struct VAR3 *VAR4;
	struct VAR5 *VAR6, *VAR7;

	if (VAR2 == NULL)
		return 0;

	VAR4 = FUN2(VAR2);

	

	FUN3(&VAR4->VAR8);

	FUN4(VAR2);

	FUN5(VAR6, VAR7, &VAR4->VAR9, VAR10)
		FUN6(VAR6);

	FUN5(VAR6, VAR7, &VAR4->VAR11, VAR10) {
		
		if (VAR6->VAR12) {
			
			if (VAR6->VAR13) {
				struct VAR14 *VAR15;

				VAR15 = FUN7(&VAR16, VAR6->VAR12);
				if (VAR15) {
					FUN8(VAR15, VAR6);
					FUN9(VAR15);
				}
			}
		} else
			FUN10(NULL, VAR6->VAR17,
					  FUN11(VAR6->VAR17),
					  VAR18, VAR6);

		FUN6(VAR6);
	}

	
	if (VAR19 && VAR4->VAR20)
		FUN12(VAR4->VAR21, VAR19);

	
	if (VAR4->VAR22) {
		VAR4->VAR22   = 0;
		VAR4->VAR12 = 0;
	}

	FUN13(VAR2);
	VAR1->VAR2 = NULL;

	FUN14(VAR2);
	FUN15(VAR2);

	return 0;
}