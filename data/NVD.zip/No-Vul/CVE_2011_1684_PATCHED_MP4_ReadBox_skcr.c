static int FUN1( VAR1 *VAR2, VAR3 *VAR4 )  
{
    FUN2( VAR5 );

    FUN3( VAR4->VAR6.VAR7->VAR8 );
    FUN3( VAR4->VAR6.VAR7->VAR9 );
    FUN3( VAR4->VAR6.VAR7->VAR10 );

#ifdef VAR11
    FUN4( VAR2, ""VAR12\"",
             VAR4->VAR6.VAR7->VAR8,
             VAR4->VAR6.VAR7->VAR9,
             VAR4->VAR6.VAR7->VAR10 );
#endif

    FUN5( 1 );
}