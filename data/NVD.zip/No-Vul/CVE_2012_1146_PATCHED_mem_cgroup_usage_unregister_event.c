static void FUN1(struct VAR1 *VAR2, 	struct VAR3 *VAR4, struct VAR5 *VAR6)  
{
	struct VAR7 *VAR8 = FUN2(VAR2);
	struct VAR9 *VAR10;
	struct VAR11 *new;
	int VAR12 = FUN3(VAR4->private);
	u64 VAR13;
	int VAR14, VAR15, VAR16;

	FUN4(&VAR8->VAR17);
	if (VAR12 == VAR18)
		VAR10 = &VAR8->VAR10;
	else if (VAR12 == VAR19)
		VAR10 = &VAR8->VAR20;
	else
		FUN5();

	
	FUN6(!VAR10);

	if (!VAR10->VAR21)
		goto VAR22;

	VAR13 = FUN7(VAR8, VAR12 == VAR19);

	
	FUN8(VAR8, VAR12 == VAR19);

	
	VAR16 = 0;
	for (VAR14 = 0; VAR14 < VAR10->VAR21->VAR16; VAR14++) {
		if (VAR10->VAR21->VAR23[VAR14].VAR6 != VAR6)
			VAR16++;
	}

	new = VAR10->VAR24;

	
	if (!VAR16) {
		FUN9(new);
		new = NULL;
		goto VAR25;
	}

	new->VAR16 = VAR16;

	
	new->VAR26 = -1;
	for (VAR14 = 0, VAR15 = 0; VAR14 < VAR10->VAR21->VAR16; VAR14++) {
		if (VAR10->VAR21->VAR23[VAR14].VAR6 == VAR6)
			continue;

		new->VAR23[VAR15] = VAR10->VAR21->VAR23[VAR14];
		if (new->VAR23[VAR15].VAR27 < VAR13) {
			
			++new->VAR26;
		}
		VAR15++;
	}

VAR25:
	
	VAR10->VAR24 = VAR10->VAR21;
	FUN10(VAR10->VAR21, new);

	
	FUN11();
VAR22:
	FUN12(&VAR8->VAR17);
}