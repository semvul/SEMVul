static int FUN1(struct VAR1 *VAR2, 				    char VAR3 *VAR4, 				    int VAR5)  
{
	struct VAR6 *VAR7;
	struct VAR8 *VAR9;
	int VAR10;

	if (!VAR11)
		return -VAR12;

	if (VAR5 <= sizeof(struct VAR6))
		return -VAR13;

	VAR7 = FUN2(VAR5, VAR14);
	if (!VAR7)
		return -VAR15;

	if (FUN3(VAR7, VAR4, VAR5)) {
		VAR10 = -VAR16;
		goto VAR17;
	}

	VAR9 = FUN4(VAR2, VAR7->VAR18);
	if (!VAR9 && VAR7->VAR18 && FUN5(VAR2, VAR19)) {
		VAR10 = -VAR13;
		goto VAR17;
	}

	VAR10 = FUN6(FUN7(VAR2)->VAR20, VAR9, VAR7);
VAR17:
	FUN8(VAR7);
	return VAR10;
}