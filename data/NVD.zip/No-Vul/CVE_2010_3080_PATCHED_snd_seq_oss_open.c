int FUN1(struct VAR1 *VAR1, int VAR2)  
{
	int VAR3, VAR4;
	struct VAR5 *VAR6;

	VAR6 = FUN2(sizeof(*VAR6), VAR7);
	if (!VAR6) {
		FUN3(VAR8 "");
		return -VAR9;
	}
	FUN4(("", VAR6));

	VAR6->VAR10 = VAR11;
	VAR6->VAR12 = -1;
	VAR6->VAR13 = -1;

	for (VAR3 = 0; VAR3 < VAR14; VAR3++) {
		if (VAR15[VAR3] == NULL)
			break;
	}

	VAR6->VAR16 = VAR3;
	if (VAR3 >= VAR14) {
		FUN3(VAR8 "");
		VAR4 = -VAR9;
		goto VAR17;
	}

	
	FUN5(VAR6);
	FUN6(VAR6);

	if (VAR6->VAR18 == 0 && VAR6->VAR19 == 0) {
		
		VAR4 = -VAR20;
		goto VAR17;
	}

	
	FUN4((""));
	VAR4 = FUN7(VAR6);
	if (VAR4 < 0) {
		FUN3(VAR8 "");
		goto VAR17;
	}

	
	FUN4((""));
	VAR4 = FUN8(VAR6);
	if (VAR4 < 0)
		goto VAR17;

	
	VAR6->VAR21.VAR22 = VAR6->VAR10;
	VAR6->VAR21.VAR12 = VAR6->VAR12;
	
	

	VAR6->VAR23 = VAR2;

	
	VAR6->VAR24 = FUN9(VAR1);

	
	FUN4((""));
	if (FUN10(VAR6->VAR24)) {
		VAR6->VAR25 = FUN11(VAR6, VAR26);
		if (!VAR6->VAR25) {
			VAR4 = -VAR9;
			goto VAR17;
		}
	}

	
	FUN4((""));
	if (FUN12(VAR6->VAR24)) {
		VAR6->VAR27 = FUN13(VAR6, VAR26);
		if (!VAR6->VAR27) {
			VAR4 = -VAR9;
			goto VAR17;
		}
	}

	
	FUN4((""));
	VAR6->VAR28 = FUN14(VAR6);
	if (!VAR6->VAR28) {
		FUN3(VAR8 "");
		VAR4 = -VAR9;
		goto VAR17;
	}
	FUN4((""));

	
	VAR1->VAR29 = VAR6;

	
	if (VAR2 == VAR30)
		FUN15(VAR6);
	else if (FUN10(VAR6->VAR24))
		FUN16(VAR6, VAR31);

	VAR15[VAR6->VAR16] = VAR6;
	VAR32++;

	FUN4((""));
	return 0;

 VAR17:
	FUN17(VAR6);
	FUN18(VAR6);
	FUN19(VAR6->VAR13);
	FUN20(VAR6);

	return VAR4;
}