static int FUN1(struct VAR1 *VAR2,struct VAR3 *VAR4)  
{
	char *VAR5, *VAR6, *VAR7;
	struct VAR8 *VAR8;
	char VAR9[VAR10];
	int VAR11;

	if ((VAR2->VAR12[0] != '') || (VAR2->VAR12[1] != '') ||
	    (VAR2->VAR13 > VAR14))
		return -VAR15;
	

	VAR2->VAR13++;
	FUN2(VAR2->VAR8);
	FUN3(VAR2->VAR8);
	VAR2->VAR8 = NULL;

	VAR2->VAR12[VAR10 - 1] = '';
	if ((VAR5 = strchr(VAR2->VAR12, '')) == NULL)
		VAR5 = VAR2->VAR12+VAR10-1;
	*VAR5 = '';
	while (VAR5 > VAR2->VAR12) {
		VAR5--;
		if ((*VAR5 == '') || (*VAR5 == ''))
			*VAR5 = '';
		else
			break;
	}
	for (VAR5 = VAR2->VAR12+2; (*VAR5 == '') || (*VAR5 == ''); VAR5++);
	if (*VAR5 == '') 
		return -VAR15; 
	VAR6 = VAR5;
	VAR7 = NULL;
	for ( ; *VAR5 && (*VAR5 != '') && (*VAR5 != ''); VAR5++)
		 ;
	while ((*VAR5 == '') || (*VAR5 == ''))
		*VAR5++ = '';
	if (*VAR5)
		VAR7 = VAR5;
	strcpy (VAR9, VAR6);
	
	VAR11 = FUN4(VAR2);
	if (VAR11)
		return VAR11;
	VAR11 = FUN5(1, &VAR2->VAR9, VAR2);
	if (VAR11 < 0) return VAR11; 
	VAR2->argc++;
	if (VAR7) {
		VAR11 = FUN5(1, &VAR7, VAR2);
		if (VAR11 < 0) return VAR11; 
		VAR2->argc++;
	}
	VAR11 = FUN5(1, &VAR6, VAR2);
	if (VAR11) return VAR11; 
	VAR2->argc++;
	VAR11 = FUN6(VAR9, VAR2);
	if (VAR11 < 0)
		return VAR11;

	
	VAR8 = FUN7(VAR9);
	if (FUN8(VAR8))
		return FUN9(VAR8);

	VAR2->VAR8 = VAR8;
	VAR11 = FUN10(VAR2);
	if (VAR11 < 0)
		return VAR11;
	return FUN11(VAR2,VAR4);
}