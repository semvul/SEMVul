static VAR1   FUN1( FT_Renderer       VAR2,                             FT_GlyphSlot      VAR3,                             FT_Render_Mode    VAR4,                             const VAR5*  VAR6,                             FT_Render_Mode    VAR7 )    
{
    FT_Error     VAR8;
    VAR9*  VAR10 = NULL;
    FT_BBox      VAR11;
    FT_UInt      VAR12, VAR13, VAR14, VAR15, VAR16;
    VAR17*   VAR18;
    FT_Memory    VAR19;
    FT_Int       VAR20 = VAR4 == VAR21;
    FT_Int       VAR22 = VAR4 == VAR23;
    FT_Pos       VAR24, VAR25, VAR26, VAR27;

    FT_Raster_Params  VAR28;


    
    if ( VAR3->VAR29 != VAR2->VAR30 )
    {
      VAR8 = VAR31;
      goto VAR32;
    }

    
    if ( VAR4 != VAR7 )
      return VAR33;

    VAR10 = &VAR3->VAR10;

    
    if ( VAR6 )
      FUN2( VAR10, VAR6->VAR34, VAR6->VAR35 );

    
    FUN3( VAR10, &VAR11 );

    VAR11.VAR36 = FUN4( VAR11.VAR36 );
    VAR11.VAR37 = FUN4( VAR11.VAR37 );
    VAR11.VAR38 = FUN5( VAR11.VAR38 );
    VAR11.VAR39 = FUN5( VAR11.VAR39 );

    VAR12  = (VAR40)( ( VAR11.VAR38 - VAR11.VAR36 ) >> 6 );
    VAR13 = (VAR40)( ( VAR11.VAR39 - VAR11.VAR37 ) >> 6 );
    VAR18 = &VAR3->VAR18;
    VAR19 = VAR2->VAR41.VAR19;

    VAR15  = VAR12;
    VAR14 = VAR13;

    
    if ( VAR3->VAR42->VAR43 & VAR44 )
    {
      FUN6( VAR18->VAR45 );
      VAR3->VAR42->VAR43 &= ~VAR44;
    }

    
    VAR16 = VAR12;
    if ( VAR20 )
    {
      VAR12 = VAR12 * 3;
      VAR16 = FUN7( VAR12, 4 );
    }

    if ( VAR22 )
      VAR13 *= 3;

    VAR24 = (VAR46) VAR11.VAR36;
    VAR25 = (VAR46) VAR11.VAR37;
    VAR26  = (VAR46)( VAR11.VAR36 >> 6 );
    VAR27   = (VAR46)( VAR11.VAR39 >> 6 );

#ifdef VAR47

    if ( VAR3->VAR48->VAR49 )
    {
      FT_Int  VAR50 = VAR3->VAR48->VAR51;


      if ( VAR20 )
      {
        VAR24 -= 64 * ( VAR50 >> 1 );
        VAR12   += 3 * VAR50;
        VAR16    = FUN7( VAR12, 4 );
        VAR26  -= VAR50 >> 1;
      }

      if ( VAR22 )
      {
        VAR25 -= 64 * ( VAR50 >> 1 );
        VAR13  += 3 * VAR50;
        VAR27   += VAR50 >> 1;
      }
    }

#endif

    if ( VAR16 > 0xFFFF || VAR13 > 0xFFFF )
    {
      FUN8(( "",
                 VAR12, VAR13 ));
      return VAR52;
    }

    VAR18->VAR53 = VAR54;
    VAR18->VAR55  = 256;
    VAR18->VAR12      = VAR12;
    VAR18->VAR56       = VAR13;
    VAR18->VAR16      = VAR16;

    
    FUN2( VAR10, -VAR24, -VAR25 );

    if ( FUN9( VAR18->VAR45, (VAR57)VAR16 * VAR13 ) )
      goto VAR32;

    VAR3->VAR42->VAR43 |= VAR44;

    
    VAR28.VAR58 = VAR18;
    VAR28.VAR59 = VAR10;
    VAR28.VAR43  = VAR60;

#ifdef VAR47

    
    {
      VAR5*  VAR61     = VAR10->VAR61;
      VAR5*  VAR62 = VAR61 + VAR10->VAR63;
      VAR5*  VAR64;


      if ( VAR20 )
        for ( VAR64 = VAR61; VAR64 < VAR62; VAR64++ )
          VAR64->VAR34 *= 3;

      if ( VAR22 )
        for ( VAR64 = VAR61; VAR64 < VAR62; VAR64++ )
          VAR64->VAR35 *= 3;
    }

    
    VAR8 = VAR2->FUN10( VAR2->VAR65, &VAR28 );

    
    {
      VAR5*  VAR61     = VAR10->VAR61;
      VAR5*  VAR62 = VAR61 + VAR10->VAR63;
      VAR5*  VAR64;


      if ( VAR20 )
        for ( VAR64 = VAR61; VAR64 < VAR62; VAR64++ )
          VAR64->VAR34 /= 3;

      if ( VAR22 )
        for ( VAR64 = VAR61; VAR64 < VAR62; VAR64++ )
          VAR64->VAR35 /= 3;
    }

    if ( VAR3->VAR48->VAR49 )
      VAR3->VAR48->FUN11( VAR18, VAR4, VAR3->VAR48 );

#else 

    
    VAR8 = VAR2->FUN10( VAR2->VAR65, &VAR28 );

    
    if ( VAR20 )
    {
      VAR66*  VAR67 = VAR18->VAR45;
      FT_UInt   VAR68;


      for ( VAR68 = VAR14; VAR68 > 0; VAR68--, VAR67 += VAR16 )
      {
        FT_UInt   VAR69;
        VAR66*  VAR70 = VAR67 + VAR12;


        for ( VAR69 = VAR15; VAR69 > 0; VAR69-- )
        {
          FT_UInt  VAR71 = VAR67[VAR69-1];


          VAR70[-3] = (VAR66)VAR71;
          VAR70[-2] = (VAR66)VAR71;
          VAR70[-1] = (VAR66)VAR71;
          VAR70    -= 3;
        }
      }
    }

    
    if ( VAR22 )
    {
      VAR66*  read  = VAR18->VAR45 + ( VAR13 - VAR14 ) * VAR16;
      VAR66*  write = VAR18->VAR45;
      FT_UInt   VAR68;


      for ( VAR68 = VAR14; VAR68 > 0; VAR68-- )
      {
        memcpy( write, read, VAR16 );
        write += VAR16;

        memcpy( write, read, VAR16 );
        write += VAR16;

        memcpy( write, read, VAR16 );
        write += VAR16;
        read  += VAR16;
      }
    }

#endif 

    FUN2( VAR10, VAR24, VAR25 );

    if ( VAR8 )
      goto VAR32;

    VAR3->VAR29      = VAR72;
    VAR3->VAR73 = VAR26;
    VAR3->VAR74  = VAR27;

  VAR32:
    if ( VAR10 && VAR6 )
      FUN2( VAR10, -VAR6->VAR34, -VAR6->VAR35 );

    return VAR8;
  }