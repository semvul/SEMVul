static void FUN1( VAR1 *VAR2, VAR3 *VAR4, mtime_t VAR5, unsigned int VAR6 )  
{
    VAR7 *VAR8 = VAR2->VAR8;
    VAR9 *VAR10 = VAR8->VAR11;

    
    if( (VAR6 & 2) || VAR8->VAR12 )
    {
        VAR4->VAR13 = 0;
        VAR4->VAR14 = 0;
        VAR8->VAR12 = false;
    }

    if( VAR4->VAR15.VAR16 == VAR17 ||
        VAR4->VAR15.VAR16 == VAR18 )
    {
        const int VAR19 = VAR4->VAR20 / VAR4->VAR21;
        const int VAR22 = VAR4->VAR13 / ( VAR4->VAR20 / VAR4->VAR21 );

        for( int VAR23 = 0; VAR23 < VAR19; VAR23++ )
        {
            int VAR24 = VAR4->VAR25 * VAR23 +
                          ((VAR4->VAR25 + 1) / 2) * (VAR22&1) + (VAR22>>1);
            if( VAR24 >= VAR4->VAR26 )
                return;

            VAR27 *VAR28 = FUN2( VAR2, VAR4->VAR21 );
            if( !VAR28 )
                return;
            if( &VAR10[VAR4->VAR21] > &VAR8->VAR11[VAR8->VAR29] )
                return;

            memcpy( VAR28->VAR30, VAR10, VAR4->VAR21 );
            VAR28->VAR31 =
            VAR28->VAR5 = VAR32;

            VAR10 += VAR4->VAR21;

            if( VAR4->VAR33[VAR24] != NULL )
            {
                FUN3(VAR2, "",  VAR24 );
                FUN4( VAR4->VAR33[VAR24] );
            }

            VAR4->VAR33[VAR24] = VAR28;
            if( VAR4->VAR13 == 0 )
                VAR4->VAR34[0] = VAR5;
            VAR4->VAR13++;
        }
    }
    else
    {
        const int VAR22 = VAR4->VAR13 / (VAR4->VAR25 / 2);
        assert( VAR4->VAR15.VAR16 == VAR35 );

        for( int VAR23 = 0; VAR23 < VAR4->VAR25 / 2; VAR23++ )
        {
            int VAR24 = (VAR23 * 2 * VAR4->VAR20 / VAR4->VAR36) + VAR22;
            if( VAR24 >= VAR4->VAR26 )
                return;

            VAR27 *VAR28 = FUN2( VAR2, VAR4->VAR36);
            if( !VAR28 )
                return;
            if( &VAR10[VAR4->VAR36] > &VAR8->VAR11[VAR8->VAR29] )
                return;

            memcpy( VAR28->VAR30, VAR10, VAR4->VAR36 );
            VAR28->VAR31 =
            VAR28->VAR5 = VAR24 == 0 ? VAR5 : VAR32;

            VAR10 += VAR4->VAR36;

            if( VAR4->VAR33[VAR24] != NULL )
            {
                FUN3(VAR2, "",  VAR24 );
                FUN4( VAR4->VAR33[VAR24] );
            }

            VAR4->VAR33[VAR24] = VAR28;
            VAR4->VAR13++;
        }
    }

    while( VAR4->VAR14 != VAR4->VAR26 &&
           VAR4->VAR33[VAR4->VAR14] )
    {
        VAR27 *VAR28 = VAR4->VAR33[VAR4->VAR14];
        VAR4->VAR33[VAR4->VAR14] = NULL;

        if( VAR4->VAR34[VAR4->VAR14] )
        {
            VAR28->VAR31 =
            VAR28->VAR5 = VAR4->VAR34[VAR4->VAR14];

            VAR4->VAR34[VAR4->VAR14] = 0;
        }
        VAR4->VAR14++;

        FUN5( VAR2, VAR4, VAR28->VAR5 );
        FUN6( VAR2->VAR37, VAR4->VAR38, VAR28 );
    }

    if( VAR4->VAR13 == VAR4->VAR26 &&
        VAR4->VAR14 != VAR4->VAR26 )
    {
        FUN7( VAR2, ""
                  "" );
    }

    if( VAR4->VAR13 == VAR4->VAR26 )
    {
        VAR4->VAR13 = 0;
        VAR4->VAR14 = 0;
    }
}