static VAR1 * FUN1(VAR1 *VAR2, VAR3 *VAR4, VAR5 *VAR6, gint VAR7, VAR8 *VAR9)  
{
    gint                VAR10 = 0;
    gint                VAR11;
    int                 VAR12;
    guint8              VAR13;
    guint8              VAR14 = 0;
    guint8              VAR15;
    VAR5 *        VAR16 = NULL;
    VAR8 *        VAR17;
    VAR1 *          VAR18;
    
    guint8              VAR19;
    struct ip6_hdr      VAR20;
    struct VAR21 *VAR22;

    
    
    if (VAR6) {
        VAR17 = FUN2(VAR6, VAR2, 0, sizeof(VAR23), "");
        VAR16 = FUN3(VAR17, VAR24);

        
        FUN4(VAR16, VAR25, VAR2, 0, VAR26, VAR27);
    }
    VAR10 += sizeof(VAR28);

    
    VAR13 = FUN5(VAR2, VAR10);
    VAR15 = ((VAR13 & VAR29) >> 1);
    if (VAR6) {
        FUN6(VAR16, VAR30, VAR2, VAR10, sizeof(VAR28), VAR13 & VAR31);
        FUN6(VAR16, VAR32, VAR2, VAR10, sizeof(VAR28), VAR13 & VAR33);
        FUN6(VAR16, VAR34, VAR2, VAR10, sizeof(VAR28), VAR13 & VAR35);
        FUN6(VAR16, VAR36, VAR2, VAR10, sizeof(VAR28), VAR13 & VAR37);
        FUN6(VAR16, VAR38, VAR2, VAR10, sizeof(VAR28), VAR13 & VAR39);
        FUN7(VAR16, VAR40, VAR2, VAR10, sizeof(VAR28), VAR13 & VAR29);
        FUN6(VAR16, VAR41, VAR2, VAR10, sizeof(VAR28), VAR13 & VAR42);
    }
    VAR10 += sizeof(VAR28);

    
    if (VAR13 & VAR42) {
        if (VAR15 == VAR43) {
            VAR14 = FUN5(VAR2, VAR10);
            if (VAR6) {
                VAR17 = FUN2(VAR6, VAR2, 0, sizeof(VAR28), "");
                VAR16 = FUN3(VAR17, VAR44);
                FUN6(VAR16, VAR45, VAR2, VAR10, sizeof(VAR28), VAR14 & VAR46);
                FUN6(VAR16, VAR47, VAR2, VAR10, sizeof(VAR28), VAR14 & VAR48);
                FUN6(VAR16, VAR49, VAR2, VAR10, sizeof(VAR28), VAR14 & VAR50);
            }
            VAR10 += sizeof(VAR28);
        }
        else {
            
            FUN8(VAR4, NULL, VAR51, VAR52, "");
            return NULL;
        }
    }

    
    
    VAR11 = VAR10 << 3;

    
    VAR20.VAR53 = FUN9(VAR2, VAR11, VAR54);
    if (VAR6) {
        FUN7(VAR6, VAR55, VAR2, VAR11>>3,
                FUN10(VAR11, VAR54), VAR20.VAR53);
    }
    VAR11 += VAR54;

    
    VAR10 = VAR11;
    if (!(VAR13 & VAR31)) {
        for (VAR12=0; VAR12<8; VAR12++, VAR11 += 8) {
            VAR20.VAR56.VAR57[VAR12] = FUN9(VAR2, VAR11, 8);
        }
    }
    else {
        memcpy(VAR20.VAR56.VAR57, VAR58, sizeof(VAR58));
    }
    if (!(VAR13 & VAR33)) {
        for (VAR12=8; VAR12<16; VAR12++, VAR11 += 8) {
            VAR20.VAR56.VAR57[VAR12] = FUN9(VAR2, VAR11, 8);
        }
    }
    
    else if (VAR4->VAR59.VAR60 == VAR61) {
        memcpy(&VAR20.VAR56.VAR57[8], VAR4->VAR59.VAR62, 8);
    }
    
    else {
        FUN11(VAR4, &VAR20.VAR56.VAR57[8]);
    }
    
    if (VAR6) {
        FUN12(VAR6, VAR63, VAR2, VAR10>>3,
                FUN10(VAR10, (VAR11-VAR10)), (VAR28 *)&VAR20.VAR56);
    }
    

    
    VAR10 = VAR11;
    if (!(VAR13 & VAR35)) {
        for (VAR12=0; VAR12<8; VAR12++, VAR11 += 8) {
            VAR20.VAR64.VAR57[VAR12] = FUN9(VAR2, VAR11, 8);
        }
    }
    else {
        memcpy(VAR20.VAR64.VAR57, VAR58, sizeof(VAR58));
    }
    if (!(VAR13 & VAR37)) {
        for (VAR12=8; VAR12<16; VAR12++, VAR11 += 8) {
            VAR20.VAR64.VAR57[VAR12] = FUN9(VAR2, VAR11, 8);
        }
    }
    
    else if (VAR4->VAR65.VAR60 == VAR61) {
        memcpy(&VAR20.VAR64.VAR57[8], VAR4->VAR65.VAR62, 8);
    }
    
    else {
        FUN13(VAR4, &VAR20.VAR64.VAR57[8]);
    }
    
    if (VAR6) {
        FUN12(VAR6, VAR66, VAR2, VAR10>>3,
                FUN10(VAR10, (VAR11-VAR10)), (VAR28 *)&VAR20.VAR64);
    }
    

    
    VAR19 = 0;
    VAR20.VAR67 = 0;
    if (!(VAR13 & VAR39)) {
        
        VAR19 = FUN9(VAR2, VAR11, VAR68);
        if (VAR6) {
            FUN7(VAR6, VAR69, VAR2, VAR11>>3,
                    FUN10(VAR11, VAR68), VAR19);
        }
        VAR11 += VAR68;

        
        VAR20.VAR67 = FUN14(VAR2, VAR11, VAR70, VAR27);
        if (VAR6) {
            FUN7(VAR6, VAR71, VAR2, VAR11>>3,
                    FUN10(VAR11, VAR70), VAR20.VAR67);
        }
        VAR11 += VAR70;
    }
    VAR20.VAR67 = FUN15(VAR20.VAR67 | (VAR19 << VAR70));
    VAR20.VAR72 = ((0x6 << 4) | (VAR19 >> 4));

    
    if (VAR15 == VAR43) {
        VAR20.VAR73 = VAR74;
    }
    else if (VAR15 == VAR75) {
        VAR20.VAR73 = VAR76;
    }
    else if (VAR15 == VAR77) {
        VAR20.VAR73 = VAR78;
    }
    else {
        
        VAR20.VAR73 = FUN9(VAR2, VAR11, VAR79);
        if (VAR6) {
            FUN16(VAR6, VAR80, VAR2, VAR11>>3,
                    FUN10(VAR11, VAR79), VAR20.VAR73,
                    "", FUN17(VAR20.VAR73), VAR20.VAR73);
        }
        VAR11 += VAR79;
    }

    
    if ((VAR13 & VAR42) && (VAR15 == VAR43)) {
        struct udp_hdr  VAR81;
        gint            VAR82;

        
        VAR10 = VAR11;
        if (VAR14 & VAR46) {
            VAR81.VAR83 = FUN9(VAR2, VAR11, VAR84) + VAR85;
            VAR11 += VAR84;
        }
        else {
            VAR81.VAR83 = FUN18(VAR2, VAR11, VAR86, VAR27);
            VAR11 += VAR86;
        }
        if (VAR6) {
            FUN7(VAR6, VAR87, VAR2, VAR10>>3,
                    FUN10(VAR10, (VAR11-VAR10)), VAR81.VAR83);
        }
        VAR81.VAR83 = FUN19(VAR81.VAR83);

        
        VAR10 = VAR11;
        if (VAR14 & VAR48) {
            VAR81.VAR88 = FUN9(VAR2, VAR11, VAR84) + VAR85;
            VAR11 += VAR84;
        }
        else {
            VAR81.VAR88 = FUN18(VAR2, VAR11, VAR86, VAR27);
            VAR11 += VAR86;
        }
        if (VAR6) {
            FUN7(VAR6, VAR89, VAR2, VAR10>>3,
                    FUN10(VAR10, (VAR11-VAR10)), VAR81.VAR88);
        }
        VAR81.VAR88 = FUN19(VAR81.VAR88);

        
        if (!(VAR14 & VAR50)) {
            VAR81.VAR82 = FUN18(VAR2, VAR11, VAR90, VAR27);
            if (VAR6) {
                FUN7(VAR6, VAR91, VAR2, VAR11>>3,
                        FUN10(VAR11, VAR90), VAR81.VAR82);

            }
            VAR11 += VAR90;
        }
        
        else if (VAR7 >= 0) {
            if (VAR7 < (VAR92)sizeof(struct VAR93)) {
                
                FUN8(VAR4, VAR9, VAR51,
                    VAR52, "",
                    (VAR94)sizeof(struct VAR93));
                return NULL;
            }
            VAR81.VAR82 = VAR7 - (VAR92)sizeof(struct VAR93);
        }
        
        else {
            VAR81.VAR82 = FUN20(VAR2);
            VAR81.VAR82 -= FUN10(0, VAR11 + VAR95);
            VAR81.VAR82 += sizeof(struct VAR96);
        }
        VAR81.VAR82 = FUN19(VAR81.VAR82);

        
        VAR81.VAR97 = FUN18(VAR2, VAR11, VAR95, VAR27);
        if (VAR6) {
            FUN7(VAR6, VAR98, VAR2, VAR11>>3,
                    FUN10(VAR11, VAR95), VAR81.VAR97);
        }
        VAR11 += VAR95;
        VAR81.VAR97 = FUN19(VAR81.VAR97);

        
        VAR10 = FUN10(0, VAR11);
        VAR82 = (VAR92)FUN21(VAR2, VAR10);
        VAR22 = (struct VAR21 *)FUN22(sizeof(struct VAR21) + sizeof(struct VAR96) + VAR82);
        VAR22->VAR99 = NULL;
        VAR22->VAR100 = VAR74;
        VAR22->VAR82 = VAR82 + sizeof(struct VAR96);
        VAR22->VAR101 = FUN19(VAR81.VAR82);

        
        memcpy(FUN23(VAR22), &VAR81, sizeof(struct VAR96));
        FUN24(VAR2, FUN23(VAR22) + sizeof(struct VAR96), VAR10, VAR82);
    }
    
    else {
        gint VAR82;
        VAR10 = FUN10(0, VAR11);
        VAR82 = (VAR92)FUN21(VAR2, VAR10);
        VAR22 = (struct VAR21 *)FUN22(sizeof(struct VAR21) + VAR82);
        VAR22->VAR99 = NULL;
        VAR22->VAR100 = VAR20.VAR73;
        VAR22->VAR82 = VAR82;
        if (VAR7 < 0) {
            VAR22->VAR101 = FUN25(VAR2, VAR10);
        }
        else {
            VAR22->VAR101 = VAR7 - sizeof(struct VAR93);
        }
        FUN24(VAR2, FUN23(VAR22), VAR10, VAR22->VAR82);
    }

    
    VAR18 = FUN26(VAR2, &VAR20, VAR22);
    FUN27(VAR4, VAR18, "");
    return VAR18;
}