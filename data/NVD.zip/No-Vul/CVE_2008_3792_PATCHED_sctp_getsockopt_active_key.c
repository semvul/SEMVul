static int FUN1(struct VAR1 *VAR2, int VAR3, 				    char VAR4 *VAR5, int VAR4 *VAR6)  
{
	struct sctp_authkeyid VAR7;
	struct VAR8 *VAR9;

	if (!VAR10)
		return -VAR11;

	if (VAR3 < sizeof(struct VAR12))
		return -VAR13;
	if (FUN2(&VAR7, VAR5, sizeof(struct VAR12)))
		return -VAR14;

	VAR9 = FUN3(VAR2, VAR7.VAR15);
	if (!VAR9 && VAR7.VAR15 && FUN4(VAR2, VAR16))
		return -VAR13;

	if (VAR9)
		VAR7.VAR17 = VAR9->VAR18;
	else
		VAR7.VAR17 = FUN5(VAR2)->VAR19->VAR18;

	VAR3 = sizeof(struct VAR12);
	if (FUN6(VAR3, VAR6))
		return -VAR14;
	if (FUN7(VAR5, &VAR7, VAR3))
		return -VAR14;

	return 0;
}