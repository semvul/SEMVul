void CWE126_Buffer_Overread__malloc_char_memcpy_67_bad()
{
    char * data;
    CWE126_Buffer_Overread__malloc_char_memcpy_67_structType myStruct;
    data = NULL;
    /* FLAW: Use a small buffer */
    data = (char *)malloc(50*sizeof(char));
    memset(data, 'A', 50-1); /* fill with 'A's */
    data[50-1] = '\0'; /* null terminate */
    myStruct.structFirst = data;
    CWE126_Buffer_Overread__malloc_char_memcpy_67b_badSink(myStruct);
}
