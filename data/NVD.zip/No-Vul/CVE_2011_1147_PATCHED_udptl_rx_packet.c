static int FUN1(struct VAR1 *VAR2, VAR3 *VAR4, int VAR5)  
{
	int VAR6;
	int VAR7;
	int VAR8;
	int VAR9;
	int VAR10;
	int VAR11;
	int VAR12;
	int VAR13;
	int VAR14;
	int VAR15;
	int VAR16;
	int VAR17;
	int VAR18;
	int VAR19;
	const VAR3 *VAR20;
	const VAR3 *VAR21;
	int VAR22;
	int VAR23[16];
	const VAR3 *VAR24[FUN2(VAR2->VAR25) - 1];
	int VAR26[FUN2(VAR2->VAR25) - 1];
	int VAR27;
	int VAR28;
	int VAR29;

	VAR16 = 0;
	VAR29 = 0;
	memset(&VAR2->VAR25[0], 0, sizeof(VAR2->VAR25[0]));

	
	if (VAR16 + 2 > VAR5)
		return -1;
	VAR19 = (VAR4[0] << 8) | VAR4[1];
	VAR16 += 2;

	
	if ((VAR6 = FUN3(VAR4, VAR5, &VAR16, &VAR20, &VAR22)) != 0)
		return -1;
	
	if (VAR16 + 1 > VAR5)
		return -1;
	if ((VAR4[VAR16++] & 0x80) == 0) {
		
		if (VAR19 > VAR2->VAR30) {
			
			VAR18 = 0;
			do {
				if ((VAR7 = FUN4(VAR4, VAR5, &VAR16, &VAR17)) < 0)
					return -1;
				for (VAR8 = 0; VAR8 < VAR17 && VAR18 + VAR8 < FUN2(VAR24); VAR8++) {
					if ((VAR6 = FUN3(VAR4, VAR5, &VAR16, &VAR24[VAR18 + VAR8], &VAR26[VAR18 + VAR8])) != 0)
						return -1;
				}
				VAR18 += VAR8;
			}
			while (VAR7 > 0 && VAR18 < FUN2(VAR24));
			
			for (VAR8 = VAR18; VAR8 > 0; VAR8--) {
				if (VAR19 - VAR8 >= VAR2->VAR30) {
					
					
					
					VAR2->VAR25[VAR29].VAR31 = VAR32;
					VAR2->VAR25[VAR29].VAR33 = VAR34;

					VAR2->VAR25[VAR29].VAR35 = 0;
					VAR2->VAR25[VAR29].VAR36 = VAR19 - VAR8;
					VAR2->VAR25[VAR29].VAR37 = VAR26[VAR8 - 1];
					VAR2->VAR25[VAR29].VAR21 = (VAR3 *) VAR24[VAR8 - 1];
					VAR2->VAR25[VAR29].VAR38 = 0;
					VAR2->VAR25[VAR29].VAR39 = "";
					if (VAR29 > 0)
						FUN5(&VAR2->VAR25[VAR29 - 1], VAR40) = &VAR2->VAR25[VAR29];
					FUN5(&VAR2->VAR25[VAR29], VAR40) = NULL;
					VAR29++;
				}
			}
		}
	}
	else
	{
		
		
		if (VAR22 > VAR41)
			return -1;
		
		for ( ; VAR19 > VAR2->VAR30; VAR2->VAR30++) {
			VAR13 = VAR2->VAR30 & VAR42;
			VAR2->VAR43[VAR13].VAR44 = -1;
			VAR2->VAR43[VAR13].VAR45[0] = 0;
			VAR2->VAR43[VAR13].VAR46 = 0;
			VAR2->VAR43[VAR13].VAR47 = 0;
		}

		VAR13 = VAR19 & VAR42;

		memset(VAR23, 0, sizeof(VAR23));

		
		memcpy(VAR2->VAR43[VAR13].VAR4, VAR20, VAR22);
		VAR2->VAR43[VAR13].VAR44 = VAR22;
		VAR23[VAR13] = VAR48;

		
		
		if (VAR16 + 2 > VAR5)
			return -1;
		if (VAR4[VAR16++] != 1)
			return -1;
		VAR27 = VAR4[VAR16++];
		VAR2->VAR43[VAR13].VAR46 = VAR27;

		
		if (VAR16 + 1 > VAR5)
			return -1;
		VAR28 = VAR4[VAR16++];
		if (VAR28 > VAR49) {
			return -1;
		}
		VAR2->VAR43[VAR13].VAR47 = VAR28;

		
		for (VAR8 = 0; VAR8 < VAR28; VAR8++) {
			if ((VAR6 = FUN3(VAR4, VAR5, &VAR16, &VAR21, &VAR2->VAR43[VAR13].VAR45[VAR8])) != 0)
				return -1;
			if (VAR2->VAR43[VAR13].VAR45[VAR8] > VAR41)
				return -1;

			
			memcpy(VAR2->VAR43[VAR13].VAR50[VAR8], VAR21, VAR2->VAR43[VAR13].VAR45[VAR8]);
#if 0
			fprintf(VAR51, "");
			for (VAR9 = 0; VAR9 < VAR2->VAR43[VAR13].VAR45[VAR8]; VAR9++)
				fprintf(VAR51, "", VAR21[VAR9]);
			fprintf(VAR51, "");
#endif
		}

		
		
		for (VAR11 = VAR13; VAR11 != ((VAR13 - (16 - VAR27*VAR28)) & VAR42); VAR11 = (VAR11 - 1) & VAR42) {
			if (VAR2->VAR43[VAR11].VAR45[0] <= 0)
				continue;
			for (VAR12 = 0; VAR12 < VAR2->VAR43[VAR11].VAR47; VAR12++) {
				VAR14 = (VAR11 + VAR12) & VAR42;
				for (VAR15 = -1, VAR10 = (VAR14 - VAR2->VAR43[VAR11].VAR46 * VAR2->VAR43[VAR11].VAR47) & VAR42; VAR10 != VAR14; VAR10 = (VAR10 + VAR2->VAR43[VAR11].VAR47) & VAR42) {
					if (VAR2->VAR43[VAR10].VAR44 <= 0)
						VAR15 = (VAR15 == -1) ? VAR10 : -2;
				}
				if (VAR15 >= 0) {
					
					for (VAR9 = 0; VAR9 < VAR2->VAR43[VAR11].VAR45[VAR12]; VAR9++) {
						VAR2->VAR43[VAR15].VAR4[VAR9] = VAR2->VAR43[VAR11].VAR50[VAR12][VAR9];
						for (VAR10 = (VAR14 - VAR2->VAR43[VAR11].VAR46 * VAR2->VAR43[VAR11].VAR47) & VAR42; VAR10 != VAR14; VAR10 = (VAR10 + VAR2->VAR43[VAR11].VAR47) & VAR42)
							VAR2->VAR43[VAR15].VAR4[VAR9] ^= (VAR2->VAR43[VAR10].VAR44 > VAR9) ? VAR2->VAR43[VAR10].VAR4[VAR9] : 0;
					}
					VAR2->VAR43[VAR15].VAR44 = VAR2->VAR43[VAR11].VAR45[VAR12];
					VAR23[VAR15] = VAR48;
				}
			}
		}
		
		for (VAR11 = (VAR13 + 1) & VAR42, VAR9 = VAR19 - VAR42; VAR11 != VAR13; VAR11 = (VAR11 + 1) & VAR42, VAR9++) {
			if (VAR23[VAR11]) {
				
				VAR2->VAR25[VAR29].VAR31 = VAR32;
				VAR2->VAR25[VAR29].VAR33 = VAR34;
			
				VAR2->VAR25[VAR29].VAR35 = 0;
				VAR2->VAR25[VAR29].VAR36 = VAR9;
				VAR2->VAR25[VAR29].VAR37 = VAR2->VAR43[VAR11].VAR44;
				VAR2->VAR25[VAR29].VAR21 = VAR2->VAR43[VAR11].VAR4;
				VAR2->VAR25[VAR29].VAR38 = 0;
				VAR2->VAR25[VAR29].VAR39 = "";
				if (VAR29 > 0)
					FUN5(&VAR2->VAR25[VAR29 - 1], VAR40) = &VAR2->VAR25[VAR29];
				FUN5(&VAR2->VAR25[VAR29], VAR40) = NULL;
				VAR29++;
			}
		}
	}

	
	if (VAR19 >= VAR2->VAR30) {
		
		VAR2->VAR25[VAR29].VAR31 = VAR32;
		VAR2->VAR25[VAR29].VAR33 = VAR34;
		
		VAR2->VAR25[VAR29].VAR35 = 0;
		VAR2->VAR25[VAR29].VAR36 = VAR19;
		VAR2->VAR25[VAR29].VAR37 = VAR22;
		VAR2->VAR25[VAR29].VAR21 = (VAR3 *) VAR20;
		VAR2->VAR25[VAR29].VAR38 = 0;
		VAR2->VAR25[VAR29].VAR39 = "";
		if (VAR29 > 0)
			FUN5(&VAR2->VAR25[VAR29 - 1], VAR40) = &VAR2->VAR25[VAR29];
		FUN5(&VAR2->VAR25[VAR29], VAR40) = NULL;

		VAR29++;
	}

	VAR2->VAR30 = VAR19 + 1;
	return VAR29;
}