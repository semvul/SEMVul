nsresult VAR1::FUN1(const VAR2& VAR3,                             const VAR2& VAR4,                             VAR5& VAR6)  
{
    PRUword VAR7 = ((VAR8)VAR3.VAR9) - ((VAR8)VAR4.VAR9);
    if (!VAR3.FUN2()) {
        FUN3(FUN4(VAR10, VAR11, VAR7),
                         VAR6);
    }
    else {
        FUN3(FUN4(VAR12, VAR13,
                                         VAR7, VAR3.VAR14), VAR6);
    }

    return VAR15;
}