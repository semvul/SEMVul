void VAR1::FUN1(VAR2* VAR3,                                   VAR4* VAR5,                                   VAR6 *VAR7,                                   PRUint32 VAR8)  
{
  
  VAR9<VAR10> VAR11;
  PRInt32 VAR12 = VAR13.FUN2();

  while (--VAR12 >= 0) {
    VAR14 *VAR15;

    VAR15 = static_cast<VAR14*>(VAR13.FUN3(VAR12));
    if (!VAR15 || !(VAR15->VAR16 & VAR2::VAR17)) {
      continue;
    }

    VAR11 = FUN4(VAR15->VAR18);
    if (!VAR11) {
      
      VAR13.FUN5(VAR12);
      delete VAR15;
      continue;
    }

    FUN6(VAR19, VAR20, ("", this, VAR11));
    VAR11->FUN7(VAR3, VAR5, VAR7, VAR8);
  }

  VAR13.FUN8();

  
  if (VAR21) {
    VAR21->FUN1(VAR3, VAR5, VAR7, VAR8);
  }
}