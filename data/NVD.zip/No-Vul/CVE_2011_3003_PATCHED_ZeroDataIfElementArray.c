VAR1 FUN1()  
{
        if (VAR2 == VAR3) {
            VAR4 = realloc(VAR4, VAR5);
            if (!VAR4) {
                VAR5 = 0;
                return VAR6;
            }
            memset(VAR4, 0, VAR5);
        }
        return VAR7;
    }