void FUN1(PRInt32 VAR1)  
{
    if (VAR1 >= VAR2 && VAR1 <= VAR3) {

      
      VAR4<VAR5> VAR6;
      FUN2(VAR7->VAR8, VAR6);

      VAR2 = VAR1;
      VAR3 = VAR1;
      
      VAR9* VAR10 = VAR7->VAR8;
      if (VAR11)
        VAR11->VAR12 = VAR12;
      if (VAR12)
        VAR12->VAR11 = VAR11;
      VAR12 = VAR11 = VAR13;
      
      if (VAR10 != this) {
        delete VAR7->VAR8;
        VAR7->VAR8 = this;
      }
      FUN3(VAR7->VAR14, VAR6);
    }
    else if (VAR12)
      VAR12->FUN1(VAR1);
  }