static bool FUN1(VAR1* VAR2, VAR3* VAR4,                           VAR1* VAR5,                           nsFrameState VAR6)  
{
  FUN2(VAR2, "");
  FUN2(!VAR5 ||
                  (!VAR5->FUN3(VAR1::VAR7) ||
                   VAR5->FUN3(VAR1::VAR7) == VAR4) ||
                  (!VAR5->FUN3(VAR1::VAR8) ||
                   VAR5->FUN3(VAR1::VAR8) == VAR4),
                  "");

  if (!VAR5 || VAR5 == VAR2) {
    VAR2->FUN4(VAR6);
  } else {
    do {
      FUN5(VAR2->FUN6() == VAR9::VAR10, "");
      VAR2 = static_cast<VAR1*>(VAR2->FUN7());
    } while (VAR2 && VAR2 != VAR5);
  }
  bool VAR11 = VAR5 == VAR2;
  while (VAR2) {
    FUN5(VAR2->FUN6() == VAR9::VAR10, "");
    if (!VAR2->FUN8(VAR4)) {
      break;
    }
    VAR2 = static_cast<VAR1*>(VAR2->FUN7());
  }
  FUN9(!VAR11 || VAR5, "");
  return VAR11;
}