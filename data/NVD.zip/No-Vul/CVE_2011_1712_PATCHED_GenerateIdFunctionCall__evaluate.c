nsresult VAR1::FUN1(VAR2* VAR3,                                  VAR4** VAR5)  
{
    *VAR5 = VAR6;
    if (!FUN2(0, 1, VAR3))
        return VAR7;

    VAR8* VAR9 = 
        static_cast<VAR8*>(VAR3->FUN3());
    if (!VAR9) {
        FUN4(
            ""VAR10\"");
        return VAR11;
    }

    nsresult VAR12 = VAR13;
    if (VAR14.FUN5()) {
        VAR15* VAR16;
        VAR12 = VAR3->FUN6()->FUN7(&VAR16);
        FUN8(VAR12, VAR12);

        VAR17::FUN9(VAR3->FUN10(),
                                    VAR9->FUN11(),
                                    VAR16->VAR18);

        *VAR5 = VAR16;
 
        return VAR13;
    }

    VAR19<VAR20> VAR21;
    VAR12 = FUN12(VAR14[0], VAR3,
                           FUN13(VAR21));
    FUN8(VAR12, VAR12);

    if (VAR21->FUN14()) {
        VAR3->FUN6()->FUN15(VAR5);

        return VAR13;
    }
    
    VAR15* VAR16;
    VAR12 = VAR3->FUN6()->FUN7(&VAR16);
    FUN8(VAR12, VAR12);

    VAR17::FUN9(VAR21->FUN16(0), VAR9->FUN11(),
                                VAR16->VAR18);

    *VAR5 = VAR16;
 
    return VAR13;
}