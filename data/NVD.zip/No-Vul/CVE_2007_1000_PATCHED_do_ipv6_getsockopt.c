static int FUN1(struct VAR1 *VAR2, int VAR3, int VAR4, 		    char VAR5 *VAR6, int VAR5 *VAR7)  
{
	struct VAR8 *VAR9 = FUN2(VAR2);
	int VAR10;
	int VAR11;

	if (FUN3(VAR10, VAR7))
		return -VAR12;
	switch (VAR4) {
	case VAR13:
		if (VAR2->VAR14 != VAR15 &&
		    VAR2->VAR14 != VAR16 &&
		    VAR2->VAR14 != VAR17)
			return -VAR18;
		if (VAR2->VAR19 != VAR20)
			return -VAR21;
		VAR11 = VAR2->VAR22;
		break;
	case VAR23:
	{
		struct group_filter VAR24;
		int VAR25;

		if (VAR10 < FUN4(0))
			return -VAR18;
		if (FUN5(&VAR24, VAR6, FUN4(0)))
			return -VAR12;
		FUN6(VAR2);
		VAR25 = FUN7(VAR2, &VAR24,
			(struct group_filter VAR5 *)VAR6, VAR7);
		FUN8(VAR2);
		return VAR25;
	}

	case VAR26:
	{
		struct msghdr VAR27;
		struct VAR28 *VAR29;

		if (VAR2->VAR30 != VAR31)
			return -VAR32;

		VAR27.VAR33 = VAR6;
		VAR27.VAR34 = VAR10;
		VAR27.VAR35 = 0;

		FUN6(VAR2);
		VAR29 = VAR9->VAR36;
		if (VAR29)
			FUN9(&VAR29->VAR37);
		FUN8(VAR2);

		if (VAR29) {
			int VAR25 = FUN10(VAR2, &VAR27, VAR29);
			FUN11(VAR29);
			if (VAR25)
				return VAR25;
		} else {
			if (VAR9->VAR38.VAR39.VAR40) {
				struct in6_pktinfo VAR41;
				VAR41.VAR42 = VAR9->VAR43;
				FUN12(&VAR41.VAR44, &VAR9->VAR45);
				FUN13(&VAR27, VAR46, VAR47, sizeof(VAR41), &VAR41);
			}
			if (VAR9->VAR38.VAR39.VAR48) {
				int VAR49 = VAR9->VAR50;
				FUN13(&VAR27, VAR46, VAR51, sizeof(VAR49), &VAR49);
			}
			if (VAR9->VAR38.VAR39.VAR52) {
				struct in6_pktinfo VAR41;
				VAR41.VAR42 = VAR9->VAR43;
				FUN12(&VAR41.VAR44, &VAR9->VAR45);
				FUN13(&VAR27, VAR46, VAR53, sizeof(VAR41), &VAR41);
			}
			if (VAR9->VAR38.VAR39.VAR54) {
				int VAR49 = VAR9->VAR50;
				FUN13(&VAR27, VAR46, VAR55, sizeof(VAR49), &VAR49);
			}
		}
		VAR10 -= VAR27.VAR34;
		return FUN14(VAR10, VAR7);
	}
	case VAR56:
	{
		struct VAR57 *VAR58;
		VAR11 = 0;	
		FUN6(VAR2);
		VAR58 = FUN15(VAR2);
		if (VAR58) {
			VAR11 = FUN16(VAR58);
			FUN17(VAR58);
		}
		FUN8(VAR2);
		if (!VAR11)
			return -VAR21;
		break;
	}

	case VAR59:
		VAR11 = VAR9->VAR60;
		break;

	case VAR61:
		VAR11 = VAR9->VAR38.VAR39.VAR40;
		break;

	case VAR53:
		VAR11 = VAR9->VAR38.VAR39.VAR52;
		break;

	case VAR62:
		VAR11 = VAR9->VAR38.VAR39.VAR48;
		break;

	case VAR55:
		VAR11 = VAR9->VAR38.VAR39.VAR54;
		break;

	case VAR63:
		VAR11 = VAR9->VAR38.VAR39.VAR64;
		break;

	case VAR65:
		VAR11 = VAR9->VAR38.VAR39.VAR66;
		break;

	case VAR67:
	case VAR68:
	case VAR69:
	case VAR70:
	{

		FUN6(VAR2);
		VAR10 = FUN18(VAR2, VAR9->VAR71, VAR6, VAR10);
		FUN8(VAR2);
		return FUN14(VAR10, VAR7);
	}

	case VAR72:
		VAR11 = VAR9->VAR38.VAR39.VAR73;
		break;

	case VAR74:
		VAR11 = VAR9->VAR38.VAR39.VAR75;
		break;

	case VAR76:
		VAR11 = VAR9->VAR38.VAR39.VAR77;
		break;

	case VAR78:
		VAR11 = VAR9->VAR38.VAR39.VAR79;
		break;

	case VAR80:
		VAR11 = VAR9->VAR81;
		if (VAR11 < 0)
			VAR11 = 0;
		break;

	case VAR82:
		VAR11 = VAR9->VAR38.VAR39.VAR83;
		break;

	case VAR84:
		VAR11 = VAR9->VAR38.VAR39.VAR85;
		break;

	case VAR86:
	case VAR87:
	{
		struct VAR57 *VAR58;

		if (VAR4 == VAR86)
			VAR11 = VAR9->VAR88;
		else
			VAR11 = VAR9->VAR50;

		VAR58 = FUN15(VAR2);
		if (VAR58) {
			if (VAR11 < 0)
				VAR11 = FUN19(VAR58, VAR89);
			if (VAR11 < 0)
				VAR11 = FUN20(VAR58->VAR90);
			FUN17(VAR58);
		}
		if (VAR11 < 0)
			VAR11 = VAR91.VAR88;
		break;
	}

	case VAR92:
		VAR11 = VAR9->VAR93;
		break;

	case VAR94:
		VAR11 = VAR9->VAR43;
		break;

	case VAR95:
		VAR11 = VAR9->VAR96;
		break;

	case VAR97:
		VAR11 = VAR9->VAR98;
		break;

	case VAR99:
		VAR11 = VAR9->VAR100;
		break;

	default:
		return -VAR18;
	}
	VAR10 = FUN21(unsigned int, sizeof(int), VAR10);
	if(FUN14(VAR10, VAR7))
		return -VAR12;
	if(FUN22(VAR6,&VAR11,VAR10))
		return -VAR12;
	return 0;
}