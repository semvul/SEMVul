NS_IMETHODIMP VAR1::FUN1(VAR2 *VAR3,                                    VAR2 *VAR4,                                    PRUint32 VAR5,                                    VAR6 *VAR7)  
{
  VAR8 FUN2(VAR7);

  
  VAR9<VAR10> VAR11;
  VAR9<VAR12> FUN3(FUN4(VAR3));
  if (!VAR13)
    return VAR14;

  VAR13->FUN5(VAR15,
                                FUN6(VAR10),
                                FUN7(VAR11));

  
  VAR9<VAR16> FUN8(FUN4(VAR11));
  if (!VAR17)
    return VAR14;

  VAR9<VAR18> VAR19;
  VAR17->FUN9(FUN7(VAR19));
  PRUint32 VAR20;
  VAR17->FUN10(&VAR20);

  
  if (!VAR19)
    return VAR14;

  

  
  
  VAR9<VAR21> VAR22;
  VAR4->FUN11(FUN7(VAR22));
  VAR9<VAR21> VAR23;
  VAR3->FUN12(FUN7(VAR23));
  PRInt16 VAR24 = VAR25::VAR26;
  VAR19->FUN13(VAR20,        
                  VAR22,          
                  VAR27,          
                  VAR27,          
                  FUN14(),  
                  VAR23,     
                  &VAR24);

#ifdef VAR28
  if (VAR22) {
    VAR29 FUN15("");
    VAR22->FUN16(VAR30);
    FUN17(VAR31, VAR32,
           ("",
            VAR30.FUN18()));
  }
  if (VAR24 == 1)
    FUN17(VAR31, VAR32,
           (""));
  else
    FUN17(VAR31, VAR32,
           (""));
#endif

  
  if (VAR24 != 1) {
    VAR33.FUN19();
    return VAR34;
  }

  
  
  nsresult VAR35;
  VAR9<VAR36> VAR37 = FUN4(VAR4, &VAR35);
  if (VAR37)
    VAR37->FUN20(VAR15,
                                   VAR17);

  return VAR14;
}