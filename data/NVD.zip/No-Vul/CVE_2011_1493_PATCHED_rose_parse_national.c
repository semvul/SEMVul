static int FUN1(unsigned char *VAR1, struct VAR2 *VAR3, int VAR4)  
{
	unsigned char *VAR5;
	unsigned char VAR6, VAR7, VAR8 = 0;
	int VAR9 = 0;

	do {
		switch (*VAR1 & 0xC0) {
		case 0x00:
			VAR1   += 2;
			VAR8   += 2;
			VAR4 -= 2;
			break;

		case 0x40:
			if (*VAR1 == VAR10)
				VAR3->rand = ((VAR1[1] << 8) & 0xFF00) + ((VAR1[2] << 0) & 0x00FF);
			VAR1   += 3;
			VAR8   += 3;
			VAR4 -= 3;
			break;

		case 0x80:
			VAR1   += 4;
			VAR8   += 4;
			VAR4 -= 4;
			break;

		case 0xC0:
			VAR6 = VAR1[1];
			if (*VAR1 == VAR11) {
				if (!VAR9) {
					memcpy(&VAR3->VAR12[0], VAR1 + 2, VAR13);
					VAR3->VAR14 = 1;
				}
			}
			else if (*VAR1 == VAR15) {
				if (!VAR9) {
					memcpy(&VAR3->VAR16[0], VAR1 + 2, VAR13);
					VAR3->VAR17 = 1;
				}
			}
			else if (*VAR1 == VAR18) {
				memcpy(&VAR3->VAR19, VAR1 + 2, VAR13);
			}
			else if (*VAR1 == VAR20) {
				memcpy(&VAR3->VAR21, VAR1 + 3, VAR22);
			}
			else if (*VAR1 == VAR23) {
				VAR9 = 1;
				VAR3->VAR14 = 0;
				VAR3->VAR17   = 0;
				for (VAR5 = VAR1 + 2, VAR7 = 0 ; VAR7 < VAR6 ; VAR5 += VAR13, VAR7 += VAR13) {
					if (VAR5[6] & VAR24) {
						if (VAR3->VAR17 >= VAR25)
							return -1;
						memcpy(&VAR3->VAR16[VAR3->VAR17++], VAR5, VAR13);
					} else {
						if (VAR3->VAR14 >= VAR25)
							return -1;
						memcpy(&VAR3->VAR12[VAR3->VAR14++], VAR5, VAR13);
					}
				}
			}
			VAR1   += VAR6 + 2;
			VAR8   += VAR6 + 2;
			VAR4 -= VAR6 + 2;
			break;
		}
	} while (*VAR1 != 0x00 && VAR4 > 0);

	return VAR8;
}