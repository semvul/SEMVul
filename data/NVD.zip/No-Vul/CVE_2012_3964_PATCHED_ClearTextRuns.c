void FUN1()  
{
    FUN2(VAR1, VAR2::VAR3);
    if (FUN3()) {
      FUN2(VAR1, VAR2::VAR4);
    }
  }