static int FUN1(struct VAR1 *VAR1, unsigned int VAR2, void *VAR3)  
{
	struct VAR4 *VAR5 = VAR1->VAR6;
	struct VAR7 *VAR7 = VAR5->VAR8;
	unsigned long VAR9 = (unsigned long) VAR3;

	FUN2(8, "",VAR7);

	switch (VAR2) {
	case VAR10:
		return FUN3(&VAR7->VAR11, VAR1, VAR9, &VAR7->VAR12[0]);
		break;
	case VAR13:
	{
		ca_caps_t VAR14;

		VAR14.VAR15 = 2;
		VAR14.VAR16 = (FUN4(VAR7->VAR17) ?
				 VAR18 : VAR19) | VAR20;
		VAR14.VAR21 = 16;
		VAR14.VAR22 = VAR23;
		memcpy(VAR3, &VAR14, sizeof(VAR14));
		break;
	}

	case VAR24:
	{
		VAR25 *VAR26=(VAR25 *)VAR3;

		if (VAR26->VAR27 < 0 || VAR26->VAR27 > 1)
			return -VAR28;
		VAR7->VAR12[VAR26->VAR27].VAR27 = VAR26->VAR27;
		VAR7->VAR12[VAR26->VAR27].VAR29 = FUN4(VAR7->VAR17) ?
							VAR18 : VAR19;
		memcpy(VAR26, &VAR7->VAR12[VAR26->VAR27], sizeof(VAR25));
		break;
	}

	case VAR30:
		break;

	case VAR31:
		break;

	case VAR32:
	{
		ca_descr_info_t VAR26;

		VAR26.VAR27 = 16;
		VAR26.VAR29 = VAR23;
		memcpy(VAR3, &VAR26, sizeof (VAR26));
		break;
	}

	case VAR33:
	{
		VAR34 *VAR35 = (VAR34*) VAR3;

		if (VAR35->VAR36 >= 16)
			return -VAR28;
		if (VAR35->VAR37 > 1)
			return -VAR28;
		FUN5(VAR7, VAR38, VAR39, 5,
			      (VAR35->VAR36<<8)|VAR35->VAR37,
			      (VAR35->VAR40[0]<<8)|VAR35->VAR40[1],
			      (VAR35->VAR40[2]<<8)|VAR35->VAR40[3],
			      (VAR35->VAR40[4]<<8)|VAR35->VAR40[5],
			      (VAR35->VAR40[6]<<8)|VAR35->VAR40[7]);
		break;
	}

	default:
		return -VAR28;
	}
	return 0;
}