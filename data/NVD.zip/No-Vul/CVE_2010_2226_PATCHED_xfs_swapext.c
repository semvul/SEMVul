int FUN1( 	VAR1	*VAR2)  
{
	VAR3     *VAR4, *VAR5;
	struct VAR6	*VAR6, *VAR7;
	int		VAR8 = 0;

	
	VAR6 = FUN2((int)VAR2->VAR9);
	if (!VAR6) {
		VAR8 = FUN3(VAR10);
		goto VAR11;
	}

	if (!(VAR6->VAR12 & VAR13) ||
	    !(VAR6->VAR12 & VAR14) ||
	    (VAR6->VAR15 & VAR16)) {
		VAR8 = FUN3(VAR17);
		goto VAR18;
	}

	VAR7 = FUN2((int)VAR2->VAR19);
	if (!VAR7) {
		VAR8 = FUN3(VAR10);
		goto VAR18;
	}

	if (!(VAR7->VAR12 & VAR13) ||
	    !(VAR7->VAR12 & VAR14) ||
	    (VAR7->VAR15 & VAR16)) {
		VAR8 = FUN3(VAR17);
		goto VAR20;
	}

	if (FUN4(VAR6->VAR21.VAR22->VAR23) ||
	    FUN4(VAR7->VAR21.VAR22->VAR23)) {
		VAR8 = FUN3(VAR10);
		goto VAR20;
	}

	VAR4 = FUN5(VAR6->VAR21.VAR22->VAR23);
	VAR5 = FUN5(VAR7->VAR21.VAR22->VAR23);

	if (VAR4->VAR24 != VAR5->VAR24) {
		VAR8 = FUN3(VAR10);
		goto VAR20;
	}

	if (VAR4->VAR25 == VAR5->VAR25) {
		VAR8 = FUN3(VAR10);
		goto VAR20;
	}

	if (FUN6(VAR4->VAR24)) {
		VAR8 = FUN3(VAR26);
		goto VAR20;
	}

	VAR8 = FUN7(VAR4, VAR5, VAR2);

 VAR20:
	FUN8(VAR7);
 VAR18:
	FUN8(VAR6);
 VAR11:
	return VAR8;
}