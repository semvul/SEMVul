void CWE122_Heap_Based_Buffer_Overflow__c_CWE806_char_snprintf_22_bad()
{
    char * data;
    data = (char *)malloc(100*sizeof(char));
    CWE122_Heap_Based_Buffer_Overflow__c_CWE806_char_snprintf_22_badGlobal = 1; /* true */
    data = CWE122_Heap_Based_Buffer_Overflow__c_CWE806_char_snprintf_22_badSource(data);
    {
        char dest[50] = "";
        /* POTENTIAL FLAW: Possible buffer overflow if data is larger than dest */
        SNPRINTF(dest, strlen(data), "%s", data);
        printLine(data);
        free(data);
    }
}
