static VAR1 FUN1(VAR2 *VAR3, int *VAR4, VAR5 **VAR6,     VAR7 *VAR8)  
{
	int			VAR9;
	guint32			VAR10;
	guint8			VAR11[VAR12];
	VAR13			*VAR14;
	iptrace_1_0_phdr	VAR15;
	guint8			VAR16[3];

	
	*VAR8 = VAR3->VAR8;
	VAR9 = FUN2(VAR3->VAR17, VAR11, VAR12,
	    VAR4, VAR6);
	if (VAR9 <= 0) {
		
		return VAR18;
	}
	VAR3->VAR8 += VAR12;

	
	VAR15.VAR19 = VAR11[28];
	VAR3->VAR20.VAR21 = FUN3(VAR15.VAR19);

	
	VAR10 = FUN4(&VAR11[0]);
	if (VAR10 < VAR22) {
		
		*VAR4 = VAR23;
		*VAR6 = FUN5("",
		    VAR10);
		return VAR18;
	}
	VAR10 -= VAR22;

	
	if (VAR3->VAR20.VAR21 == VAR24) {
		
		if (VAR10 < 3) {
			
			*VAR4 = VAR23;
			*VAR6 = FUN5("",
			    VAR10 + VAR22);
			return VAR18;
		}
		VAR10 -= 3;
		VAR3->VAR8 += 3;

		
		if (!FUN6(VAR3->VAR17, VAR16, 3, VAR4,
		    VAR6))
			return VAR18;	
	}
	if (VAR10 > VAR25) {
		
		*VAR4 = VAR23;
		*VAR6 = FUN5("",
		    VAR10, VAR25);
		return VAR18;
	}

	FUN7( VAR3->VAR26, VAR10 );
	VAR14 = FUN8( VAR3->VAR26 );
	if (!FUN6(VAR3->VAR17, VAR14, VAR10, VAR4,
	    VAR6))
		return VAR18;	
	VAR3->VAR8 += VAR10;

	VAR3->VAR20.VAR27 = VAR10;
	VAR3->VAR20.VAR28 = VAR10;
	VAR3->VAR20.VAR29.VAR30 = FUN4(&VAR11[4]);
	VAR3->VAR20.VAR29.VAR31 = 0;

	if (VAR3->VAR20.VAR21 == VAR32) {
		*VAR4 = VAR33;
		*VAR6 = FUN5("",
		    VAR15.VAR19);
		return VAR18;
	}

	
	FUN9(VAR3->VAR20.VAR21, VAR14, VAR3->VAR20.VAR28,
	    &VAR3->VAR34, VAR11);

	
	if (VAR3->VAR35 == VAR32)
		VAR3->VAR35 = VAR3->VAR20.VAR21;
	else {
		if (VAR3->VAR35 != VAR3->VAR20.VAR21)
			VAR3->VAR35 = VAR36;
	}

	return VAR37;
}