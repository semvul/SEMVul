nsresult VAR1::FUN1(const VAR2 **VAR3,                                           VAR4         *VAR5,                                           char            **VAR6,                                           VAR4         *VAR7)  
{
    size_t VAR8 = 0;
    size_t VAR9 = (VAR10) *VAR5 * 2;
    size_t VAR11 = (VAR10) *VAR7;

    if (VAR12 != VAR13) {
        VAR8 = FUN2(VAR12, (const char **) VAR3, &VAR9, VAR6, &VAR11);

        *VAR5 = VAR9 / 2;
        *VAR7 = VAR11;
        if (VAR8 != (VAR10) -1) {
            return VAR14;
        }

        FUN3("");

        
        FUN4(VAR12);
    }
#if FUN5(VAR15)
    else if ((VAR16 != VAR13) &&
             (VAR17 != VAR13)) {
        const char *VAR18 = (const char *) *VAR3;

        char VAR19[6]; 

        
        while (VAR9 && VAR11) {
            char *VAR20 = VAR19;
            size_t VAR21 = sizeof(VAR19), VAR22 = sizeof(VAR2);
            VAR8 = FUN2(VAR16, &VAR18, &VAR22, &VAR20, &VAR21);
            if (VAR8 == (VAR10) -1) {
                FUN3("");
                break;
            }
            VAR20 = VAR19;
            VAR21 = sizeof(VAR19) - VAR21;
            VAR8 = FUN2(VAR17, (const char **) &VAR20, &VAR21, VAR6, &VAR11);
            if (VAR8 == (VAR10) -1) {
                if (VAR23 == VAR24) {
                    
                    VAR18 -= sizeof(VAR2);
                    VAR8 = 0;
                }
                else
                    FUN3("");
                break;
            }
            VAR9 -= sizeof(VAR2);
        }

        (*VAR3) += (*VAR5 - VAR9 / 2);
        *VAR5 = VAR9 / 2;
        *VAR7 = VAR11;
        if (VAR8 != (VAR10) -1) {
            return VAR14;
        }

        
        FUN4(VAR16);
        FUN4(VAR17);
    }
#endif

    
    
    FUN6(VAR3, VAR5, VAR6, VAR7);

    return VAR14;
}