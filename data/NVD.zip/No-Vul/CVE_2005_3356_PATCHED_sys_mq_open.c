asmlinkage long FUN1(const char VAR1 *VAR2, int VAR3, mode_t VAR4, 				struct mq_attr VAR1 *VAR5)  
{
	struct VAR6 *VAR6;
	struct VAR7 *VAR8;
	char *VAR9;
	int VAR10, VAR11;

	if (FUN2(VAR9 = FUN3(VAR2)))
		return FUN4(VAR9);

	VAR10 = FUN5();
	if (VAR10 < 0)
		goto VAR12;

	FUN6(&VAR13->VAR14->VAR15->VAR16);
	VAR6 = FUN7(VAR9, VAR13->VAR14, strlen(VAR9));
	if (FUN2(VAR6)) {
		VAR11 = FUN4(VAR6);
		goto VAR17;
	}
	FUN8(VAR13);

	if (VAR3 & VAR18) {
		if (VAR6->VAR15) {	
			VAR11 = -VAR19;
			if (VAR3 & VAR20)
				goto VAR21;
			VAR8 = FUN9(VAR6, VAR3);
		} else {
			VAR8 = FUN10(VAR13->VAR14, VAR6,
						VAR3, VAR4, VAR5);
		}
	} else {
		VAR11 = -VAR22;
		if (!VAR6->VAR15)
			goto VAR21;
		VAR8 = FUN9(VAR6, VAR3);
	}

	if (FUN2(VAR8)) {
		VAR11 = FUN4(VAR8);
		goto VAR23;
	}

	FUN11(VAR10, 1);
	FUN12(VAR10, VAR8);
	goto VAR24;

VAR21:
	FUN13(VAR6);
	FUN14(VAR13);
VAR23:
	FUN15(VAR10);
VAR17:
	VAR10 = VAR11;
VAR24:
	FUN16(&VAR13->VAR14->VAR15->VAR16);
VAR12:
	FUN17(VAR9);
	return VAR10;
}