static void setup_rt_frame(int sig, struct target_sigaction *ka,

                           target_siginfo_t *info,

			   target_sigset_t *set, CPUState *env)

{

    fprintf(stderr, "setup_rt_frame: not implemented\n");

}
