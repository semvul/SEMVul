static void FUN1(struct VAR1 *VAR2, int VAR3)  
{
	FUN2("",
		VAR4->VAR5, FUN3(VAR4), VAR3);

#if FUN4(VAR6) && !FUN4(VAR7)
	FUN2("", VAR2->VAR8);
	{
		int VAR9;
		for (VAR9 = 0; VAR9 < 16; VAR9++) {
			unsigned char VAR10;

			if (FUN5(VAR10, (unsigned char *)(VAR2->VAR8 + VAR9)))
				break;
			FUN2("", VAR10);
		}
	}
#endif
	FUN2("");
	FUN6();
	FUN7(VAR2);
	FUN8();
}