int FUN1(struct VAR1 *VAR2, off_t VAR3, int VAR4)  
{
	size_t VAR5;
	struct VAR6 *VAR7;
	int VAR8, VAR9;

	VAR7 = VAR2->VAR7;
	if (!VAR7)
		return -VAR10;

	if (VAR2->VAR11 == 0)
		return 0;

	if (VAR4 != VAR2->VAR4)
		return -VAR10;

	VAR9 = FUN2();
	if (((VAR3 + VAR2->VAR11) > VAR9) ||
	    ((VAR3 + VAR2->VAR11) < VAR3))
		return -VAR10;

	VAR8 = VAR7->VAR12->FUN3(VAR7, VAR4);
	if (VAR8 != 0) {
		
		return -VAR10;
	}

	
	for (VAR5 = VAR3; VAR5 < (VAR2->VAR11 + VAR3); VAR5++) {
		FUN4(VAR7->VAR13, VAR7->VAR14+VAR5);
	}
	FUN5(VAR7->VAR14+VAR5-1);	

	VAR7->VAR12->FUN6(VAR2);
	return 0;
}