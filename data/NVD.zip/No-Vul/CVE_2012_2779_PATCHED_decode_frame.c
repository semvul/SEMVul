static int FUN1(VAR1 *VAR2, void *VAR3, int *VAR4,                         VAR5 *VAR6)  
{
    VAR7  *VAR8 = VAR2->VAR9;
    const VAR10   *VAR11 = VAR6->VAR3;
    int             VAR12 = VAR6->VAR13;
    int             VAR14, VAR15, VAR16;

    FUN2(&VAR8->VAR17, VAR11, VAR12 * 8);
    VAR8->VAR18 = VAR11;
    VAR8->VAR19 = VAR12;

    VAR14 = FUN3(VAR8, VAR2);
    if (VAR14 || VAR8->VAR20) {
        FUN4(VAR2, VAR21,
               "", VAR14);
        return -1;
    }

    if (VAR8->VAR22 & VAR23) {
        FUN4(VAR2, VAR21, "");
        return -1;
    }

    FUN5(VAR8);

    

    if (VAR8->VAR24 != VAR25) {
        for (VAR15 = 0; VAR15 < 3; VAR15++) {
            for (VAR16 = 0; VAR16 < VAR8->VAR26[VAR15].VAR27; VAR16++) {
                VAR14 = FUN6(VAR8, VAR15, &VAR8->VAR26[VAR15].VAR28[VAR16], VAR2);
                if (VAR14) {
                    FUN4(VAR2, VAR21,
                           "", VAR16, VAR15);
                    return -1;
                }
            }
        }
    }

    

    if (VAR8->VAR29.VAR3[0])
        VAR2->FUN7(VAR2, &VAR8->VAR29);

    VAR8->VAR29.VAR30 = 0;
    if (VAR2->FUN8(VAR2, &VAR8->VAR29) < 0) {
        FUN4(VAR2, VAR21, "");
        return -1;
    }

    if (VAR8->VAR31) {
        FUN9 (&VAR8->VAR26[0], VAR8->VAR29.VAR3[0], VAR8->VAR29.VAR32[0], 4);
    } else {
        FUN10(&VAR8->VAR26[0], VAR8->VAR29.VAR3[0], VAR8->VAR29.VAR32[0]);
    }

    FUN10(&VAR8->VAR26[2], VAR8->VAR29.VAR3[1], VAR8->VAR29.VAR32[1]);
    FUN10(&VAR8->VAR26[1], VAR8->VAR29.VAR3[2], VAR8->VAR29.VAR32[2]);

    *VAR4 = sizeof(VAR33);
    *(VAR33*)VAR3 = VAR8->VAR29;

    return VAR12;
}