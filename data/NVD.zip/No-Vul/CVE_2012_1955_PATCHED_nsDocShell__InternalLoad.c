NS_IMETHODIMP VAR1::FUN1(VAR2 * VAR3,                          VAR2 * VAR4,                          VAR5 * VAR6,                          PRUint32 VAR7,                          const VAR8 *VAR9,                          const char* VAR10,                          VAR11 * VAR12,                          VAR11 * VAR13,                          PRUint32 VAR14,                          VAR15 * VAR16,                          bool VAR17,                          VAR18** VAR19,                          VAR20** VAR21)  
{
    nsresult VAR22 = VAR23;

#ifdef VAR24
    if (VAR25 && FUN2(VAR25, VAR26)) {
        nsCAutoString VAR27;
        if (VAR3)
            VAR3->FUN3(VAR27);
        FUN4("", this, VAR27.FUN5());
    }
#endif
    
    
    if (VAR19) {
        *VAR19 = VAR28;
    }
    if (VAR21) {
        *VAR21 = VAR28;
    }

    if (!VAR3) {
        return VAR29;
    }

    FUN6(FUN7(VAR14), VAR30);

    FUN6(!VAR31, VAR32);

    
    
    if (VAR14 & VAR33) {
        bool VAR34 = false;
        VAR22 = VAR3->FUN8("", &VAR34);   
        if ((VAR34 && FUN9(VAR22)) || FUN10(VAR22)) 
            return VAR35;
    }

    bool VAR36 = false;
    if (FUN10(VAR3->FUN8("", &VAR36))) {
        VAR36 = false;
    }

    
    
    
    
    VAR37<VAR38> VAR39;
    
    VAR37<VAR40> FUN11(FUN12(VAR41));
    if (VAR42)
        VAR39 = VAR42->FUN13();

    PRInt16 VAR43 = VAR44::VAR45;
    PRUint32 VAR46;
    if (FUN14()) {
        FUN15(VAR39, "");
        VAR46 = VAR44::VAR47;
    } else {
        VAR46 = VAR44::VAR48;
    }

    VAR5* VAR49 = VAR39;
    if (!VAR49) {
        VAR49 =  VAR41;
    }

    
    VAR37<VAR50> VAR51;
    if (VAR4) {
        VAR37<VAR52> VAR53 =
            FUN16(VAR54, &VAR22);
        FUN17(VAR22, VAR22);

        VAR22 = VAR53->FUN18(VAR4,
                                          FUN19(VAR51));
    }
    
    VAR22 = FUN20(VAR46,
                                   VAR3,
                                   VAR51,
                                   VAR49,
                                   FUN21(), 
                                   VAR28,         
                                   &VAR43);

    if (FUN10(VAR22) || FUN22(VAR43)) {
        if (FUN9(VAR22) && VAR43 == VAR44::VAR55) {
            return VAR56;
        }

        return VAR57;
    }

    VAR37<VAR5> FUN23(VAR6);
    
    
    
    
    
    
    
    
    
    
    {
        bool VAR58;
        
        if (VAR14 != VAR59 && !VAR60 &&
            (VAR7 & VAR61) &&
            FUN9(VAR62::FUN24(VAR3,
                                                                    &VAR58)) &&
            VAR58) {

            VAR60 = FUN25(true);
        }
    }

    
    
    {
        bool VAR63;
        
        
        
        
        
        VAR22 = VAR62::FUN24(VAR3, &VAR63);
        if (FUN10(VAR22) || VAR63 || FUN26(VAR3)) {
            VAR37<VAR64> VAR65 = this;
            do {
                VAR37<VAR18> VAR66 =
                    FUN12(VAR65);
                bool VAR67;
                if (VAR66 &&
                    FUN9(VAR66->FUN27(&VAR67)) &&
                    VAR67) {
                    return VAR68;
                }

                VAR37<VAR64> VAR69;
                VAR65->FUN28(FUN19(VAR69));
                VAR69.FUN29(VAR65);
            } while (VAR65);
        }
    }
    
    
    
    
    
    
    if (VAR9 && *VAR9) {
        
        
        
        VAR7 = VAR7 & ~VAR61;
        
        
        
        
        VAR37<VAR64> VAR70;
        FUN30(VAR9, VAR28, this,
                         FUN19(VAR70));

        VAR37<VAR18> VAR71 = FUN12(VAR70);
        
        bool VAR72 = false;
        if (!VAR71) {
            VAR37<VAR73> VAR74 =
                FUN31(FUN32(this));
            FUN6(VAR74, VAR32);

            VAR75 FUN33(VAR9);
            VAR37<VAR73> VAR76;
            VAR22 = VAR74->FUN34(FUN35(), 
                           VAR77,          
                           FUN35(), 
                           FUN19(VAR76));

            
            
            
            VAR37<VAR40> VAR78 = FUN12(VAR76);
            if (VAR78) {
                VAR37<VAR79> VAR80 =
                    FUN12(VAR78->FUN36());
                if (!VAR80 || VAR80->FUN37()) {
                    VAR72 = true;
                    VAR7 |= VAR81;
                }
            }

            VAR37<VAR82> VAR83 = FUN31(VAR76);
            VAR71 = FUN12(VAR83);
        }

        
        
        
        
        if (FUN9(VAR22) && VAR71) {
            VAR22 = VAR71->FUN1(VAR3,
                                              VAR4,
                                              VAR60,
                                              VAR7,
                                              VAR28,         
                                              VAR10,
                                              VAR12,
                                              VAR13,
                                              VAR14,
                                              VAR16,
                                              VAR17,
                                              VAR19,
                                              VAR21);
            if (VAR22 == VAR84) {
                
                if (VAR72) {
                    
                    
                    
                    
                    
                    
                    
                    VAR37<VAR73> VAR85 =
                        FUN31(VAR71);
                    if (VAR85) {
                        VAR85->FUN38();
                    }
                }
                
                
                
                
                
                
                VAR22 = VAR23;
            }
            else if (VAR72) {
                
                
                
            }
        }

        
        
        
        return VAR22;
    }

    
    
    
    
    if (VAR31) {
        return VAR35;
    }

    VAR22 = FUN39();
    if (FUN10(VAR22)) {
        return VAR22;
    }

    
    
    VAR37<VAR64> VAR69;
    FUN40(FUN19(VAR69));
    if (VAR69) {
      VAR37<VAR79> VAR86 = FUN31(VAR69);
      if (VAR86) {
        VAR86->FUN41(this);
      }
    }

    if (VAR87) {
        if (FUN42(VAR3)) {
            FUN43(!VAR9 || !*VAR9,
                            "");

            
            
            
            if (FUN44(VAR14, VAR88)) {
                VAR89 = VAR90;
            }
            
            
            VAR37<VAR91> VAR92 =
                new FUN45(this, VAR3, VAR4, VAR6, VAR7,
                                      VAR10, VAR12, VAR13,
                                      VAR14, VAR16, VAR17);
            return FUN46(VAR92);
        }

        
        return VAR23;
    }

    
    if (VAR14 == VAR59) {
        
        bool VAR93 = false;
        if (FUN9(VAR3->FUN8("", &VAR93)) && VAR93) {
            FUN47("");
            return VAR35;
        }

        
        VAR22 = FUN48(VAR28, VAR28);
        if (FUN10(VAR22))
            return VAR35;

        
        
        VAR14 = VAR94;
    }

    VAR95 =
      (VAR7 & VAR96) != 0;
    VAR97 = false;  

    if (VAR14 == VAR94 ||
        VAR14 == VAR98 ||
        FUN44(VAR14, VAR88) ||
        VAR14 == VAR99 ||
        VAR14 == VAR100) {

        
        
        
        nsCAutoString VAR101, VAR102, VAR103, VAR104;
        nsresult VAR105, VAR106;
        VAR105 = VAR107 ?
            VAR62::FUN49(VAR107,
                                           VAR101, VAR102) :
            VAR35;
        VAR106 = VAR62::FUN49(VAR3, VAR103, VAR104);

        bool VAR108 = FUN9(VAR105) &&
                                  FUN9(VAR106) &&
                                  VAR101.FUN50(VAR103);

        bool VAR109 = false;
        if (VAR110 && VAR16) {
            

            VAR110->FUN51(VAR16, &VAR109);

#ifdef VAR111
            if (VAR109) {
                VAR37<VAR11> VAR112;
                VAR110->FUN52(FUN19(VAR112));
                FUN15(VAR112 == VAR12,
                             "");
            }
#endif
        }

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        bool VAR113 =
          (VAR109 && VAR110 != VAR16) ||
          (!VAR16 && VAR12 == VAR28 &&
           VAR108 && !VAR104.FUN53());

        if (VAR113) {
            
            VAR37<VAR2> VAR114 = VAR107;

            
            nscoord VAR115 = 0, VAR116 = 0;
            FUN54(VAR117, &VAR115);
            FUN54(VAR118, &VAR116);

            
            
            
            
            
            VAR22 = FUN55(VAR102, VAR104, VAR14);
            FUN17(VAR22, VAR22);

            
            
            
            
            VAR119<VAR120> FUN56(VAR89);

            
            
            
            if (FUN57() && (VAR14 & VAR33)) {
                VAR89 = VAR90;
            }
            else {
                VAR89 = VAR14;
            }

            VAR97 = true;

            
            FUN58(&VAR121, VAR16);

            
            VAR37<VAR5> VAR60;
            if (VAR110) {
                VAR110->FUN59(FUN19(VAR60));
            }
            
            
            
            
            
            
            
            
            FUN60(VAR3, VAR28, VAR60, VAR89, true, true, true);

            VAR37<VAR11> VAR122;
            VAR37<VAR5> VAR123;

            if (VAR110) {
                
                VAR110->FUN61(VAR115, VAR116);
                
                
                
                
                
                
                if (VAR14 & VAR33) {
                    VAR110->FUN52(FUN19(VAR122));
                    VAR110->FUN62(FUN19(VAR123));

                    
                    
                    
                    if (VAR121)
                        VAR121->FUN63(VAR110);
                }
            }

            
            if (VAR121) {
                FUN58(&VAR110, VAR121);
                
                
                
                
                if (VAR122)
                    VAR110->FUN64(VAR122);

                
                
                if (VAR123)
                    VAR110->FUN65(VAR123);
            }

            
            if (VAR110 && (VAR14 == VAR99 || VAR14 == VAR124))
            {
                nscoord VAR125, VAR126;
                VAR110->FUN66(&VAR125, &VAR126);
                FUN67(VAR125, VAR126);
            }

            
            FUN58(&VAR121, VAR28);
            
            if (VAR127) {
                PRInt32 VAR128 = -1;
                VAR127->FUN68(&VAR128);
                VAR37<VAR129> VAR130;
                VAR127->FUN69(VAR128, false,
                                                 FUN19(VAR130));
                FUN6(VAR130, VAR35);
                VAR37<VAR15> FUN70(FUN12(VAR130));
                if (VAR131)
                    VAR131->FUN71(VAR132);
            }

            
            if (VAR133) {
                VAR37<VAR134> VAR135 = VAR136::FUN72();
                if (VAR135) {
                    VAR135->FUN73(VAR3, VAR132);
                }
                else if (VAR137) {
                    VAR137->FUN74(VAR3, VAR132);
                }
            }

            
            VAR37<VAR79> VAR86 =
              FUN31(FUN32(this));
            FUN6(VAR86, VAR35);
            VAR86->FUN75(VAR3);

            FUN76(VAR110);

            
            VAR37<VAR40> VAR138 = FUN12(VAR41);
            if (VAR138) {
                
                bool VAR139 = VAR108 && !VAR102.FUN50(VAR104);

                if (VAR109 || VAR139) {
                  VAR138->FUN77();
                }

                if (VAR139) {
                  
                  
                  VAR138->FUN78(VAR114, VAR3);
                }
            }

            
            
            FUN79(VAR114, VAR3);

            return VAR23;
        }
    }
    
    
    
    
    
    VAR37<VAR18> FUN80(this);

    VAR22 = FUN81();
    if (VAR140) {
      VAR140->FUN82();
    }
    
    
    if (!VAR36 && VAR141) {
        bool VAR142;
        VAR22 = VAR141->FUN83(false, &VAR142);

        if (FUN9(VAR22) && !VAR142) {
            
            
            return VAR23;
        }
    }

    if (VAR140) {
      VAR140->FUN84(VAR107);
    }

    
    
    
    
    
    
    bool VAR143 = FUN85(VAR14, VAR28, VAR28);

    
    
    
    
    
    if (!VAR36) {
        
        
        
        
        
        
        

        VAR37<VAR144> VAR145;
        if (VAR141) {
            VAR141->FUN86(FUN19(VAR145));
        }

        if (VAR145 ||
            FUN44(VAR14, VAR146)) {
            VAR22 = FUN87(VAR82::VAR147);
        } else {
            VAR22 = FUN87(VAR82::VAR148);
        }

        if (FUN10(VAR22)) 
            return VAR22;
    }

    VAR89 = VAR14;

    
    
    
    if (VAR89 != VAR149)
        FUN58(&VAR121, VAR16);

    VAR150 = VAR143;

    
    if (VAR16 && (VAR89 & VAR151)) {
        
        
        VAR16->FUN88(&VAR152);

        
        
        
        
        if (VAR141) {
            VAR37<VAR144> VAR153;
            VAR141->FUN86(FUN19(VAR153));
            if (VAR153) {
#ifdef VAR111
                VAR37<VAR144> VAR154;
                VAR153->FUN86(FUN19(VAR154));
                FUN15(!VAR154, "");
#endif
                VAR37<VAR15> VAR155;
                VAR153->FUN89(FUN19(VAR155));
                if (VAR155 == VAR16) {
                    
                    VAR141->FUN90(VAR28);
                    VAR153->FUN91();
                }
            }
        }
        VAR37<VAR15> VAR156 = VAR110;
        bool VAR157;
        VAR22 = FUN92(VAR16, &VAR157);
        if (VAR157)
            return VAR22;

        
        
        
        if (FUN10(VAR22)) {
            if (VAR156)
                VAR156->FUN93();

            VAR16->FUN93();
        }
    }

    VAR37<VAR20> VAR158;
    VAR22 = FUN94(VAR3, VAR4,
                   !(VAR7 & VAR159),
                   VAR60, VAR10, VAR12, VAR13, VAR17,
                   VAR19, FUN19(VAR158),
                   (VAR7 & VAR81) != 0,
                   (VAR7 & VAR160) != 0,
                   (VAR7 & VAR161) != 0);
    if (VAR158 && VAR21)
        FUN95(*VAR21 = VAR158);

    if (FUN10(VAR22)) {
        VAR37<VAR162> FUN96(FUN12(VAR158));
        FUN97(VAR22, VAR3, VAR28, VAR163);
    }

    return VAR22;
}