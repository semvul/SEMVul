static int FUN1(int VAR1, int VAR2, int VAR3, struct socket **VAR4, int VAR5)  
{
	int VAR6;
	int VAR7;
	struct socket *VAR8;

	
	if (VAR1 < 0 || VAR1 >= VAR9)
		return -VAR10;
	if (VAR2 < 0 || VAR2 >= VAR11)
		return -VAR12;

	
	if (VAR1 == VAR13 && VAR2 == VAR14) {
		static int VAR15; 
		if (!VAR15) {
			VAR15 = 1;
			FUN2(VAR16 "", VAR17->VAR18);
		}
		VAR1 = VAR19;
	}

	VAR7 = FUN3(VAR1, VAR2, VAR3, VAR5);
	if (VAR7)
		return VAR7;
		
#if FUN4(VAR20)
	
	if (VAR21[VAR1]==NULL)
	{
		FUN5("",VAR1);
	}
#endif

	FUN6();
	if (VAR21[VAR1] == NULL) {
		VAR6 = -VAR10;
		goto VAR22;
	}



	if (!(VAR8 = FUN7())) 
	{
		FUN2(VAR23 "");
		VAR6 = -VAR24;		
		goto VAR22;
	}

	VAR8->VAR2  = VAR2;

	
	VAR6 = -VAR10;
	if (!FUN8(VAR21[VAR1]->VAR25))
		goto VAR26;

	if ((VAR6 = VAR21[VAR1]->FUN9(VAR8, VAR3)) < 0) {
		VAR8->VAR27 = NULL;
		goto VAR28;
	}
	
	if (!FUN8(VAR8->VAR27->VAR25)) {
		VAR8->VAR27 = NULL;
		goto VAR28;
	}
	
	FUN10(VAR21[VAR1]->VAR25);
	*VAR4 = VAR8;
	FUN11(VAR8, VAR1, VAR2, VAR3, VAR5);

VAR22:
	FUN12();
	return VAR6;
VAR28:
	FUN10(VAR21[VAR1]->VAR25);
VAR26:
	FUN13(VAR8);
	goto VAR22;
}