static VAR1*   FUN1( FT_Stream  VAR2,                            VAR3   *VAR4 )    
{
    VAR1 *VAR5;
    FT_Int     VAR6;
    FT_Int     VAR7;
    FT_Int     VAR8;
    FT_Int     VAR9;
    FT_Int     VAR10;
    FT_Memory  VAR11 = VAR2->VAR11;
    FT_Error   VAR12  = VAR13;

    FUN2( VAR12 );


    *VAR4 = VAR6 = FUN3();
    if ( VAR6 == 0 )
      return VAR14;

    if ( VAR6 & VAR15 )
      VAR6 = FUN3() | ( ( VAR6 & VAR16 ) << 8 );

    if ( FUN4( VAR5, VAR6 ) )
      return NULL;

    VAR8 = 0;
    while ( VAR8 < VAR6 )
    {
      VAR7 = FUN3();
      if ( VAR7 & VAR15 )
      {
        VAR7 = VAR7 & VAR16;
        VAR10  = VAR5[VAR8++] = FUN5();

        if ( VAR7 < 1 || VAR8 + VAR7 >= VAR6 )
          goto VAR17;

        
        for ( VAR9 = 0; VAR9 < VAR7; ++VAR9 )
          VAR5[VAR8++] = (VAR1)( VAR10 += FUN5() );
      }
      else
      {
        VAR10 = VAR5[VAR8++] = FUN3();

        if ( VAR7 < 1 || VAR8 + VAR7 >= VAR6 )
          goto VAR17;

        for ( VAR9 = 0; VAR9 < VAR7; ++VAR9 )
          VAR5[VAR8++] = (VAR1)( VAR10 += FUN3() );
      }
    }

  VAR17:
    return VAR5;
  }