NS_IMETHODIMP VAR1::FUN1(VAR2* VAR3,                                      VAR4* VAR5,                                      PRUint32 VAR6,                                      nsresult VAR7)  
{
#ifdef VAR8
  VAR9 FUN2(VAR10);
  FUN3(VAR10 == 1,
               "");
#endif
  

  VAR11<VAR12> VAR13;
  VAR3->FUN4(FUN5(VAR13));

  VAR11<VAR12> VAR14;
  bool VAR15;

  VAR11<VAR16> VAR17;

  {
    VAR18 FUN6(VAR19);
    VAR14 = FUN7(VAR20);
    FUN3(VAR14, "");
    VAR15 = VAR21;
    VAR17 = VAR22;
  }

  if (!VAR17)
  {
    VAR17 = FUN8(VAR23);
    if (VAR17)
    {
      VAR18 FUN6(VAR19);
      VAR22 = VAR17;
    }
  }

  bool VAR24 = false;
  VAR11<VAR25> VAR26 = FUN9(VAR5);
  if (VAR26) 
  {
    PRUint32 VAR27;
    VAR24 = FUN10(VAR26->FUN11(&VAR27)) &&
        (VAR27 == 204 || VAR27 == 205);
  }
  const bool VAR28 = (VAR13.FUN12() == VAR14.FUN12()) && !VAR24;
  
#ifdef VAR29
  if (VAR13)
  {
    if (VAR28)
    {
      FUN13(VAR30, VAR31,
             ("", this));
    }
    else
    {
      FUN13(VAR30, VAR31,
             ("", this));
    }
  }
  else
  {
      FUN13(VAR30, VAR31,
             ("", this));
  }
#endif

  FUN13(VAR30, VAR31,
         ("", this));

  if (VAR15)
    return VAR32;

  if (!VAR5)
  {
    FUN13(VAR30, VAR31,
           ("", this));
    return VAR33;
  }

#ifdef VAR29
  if (FUN14(VAR30, VAR31)) {
    nsXPIDLCString VAR34;
    VAR5->FUN15(VAR34);
    FUN13(VAR30, VAR31,
           ("", this, VAR3,
            VAR5, VAR6, VAR34.FUN12()));
  }
#endif

  VAR11<VAR35> FUN16(FUN17(VAR5));

  VAR11<VAR36> VAR37;
  VAR11<VAR38> FUN18(FUN9(VAR5));
  if (VAR39) {
    VAR39->FUN19(FUN5(VAR37));
  }

  VAR11<VAR40> FUN20(FUN9(VAR5));
  if (VAR41) {
    FUN3(!VAR39, "");
    
    VAR41->FUN19(FUN5(VAR37));
  }
  
  if (VAR37) {
    bool VAR42;
    if (FUN10(VAR37->FUN21("", &VAR42)) && VAR42) {
      
      
      return VAR32;
    }
  }

  PRUint32 VAR43 = 0;
  VAR5->FUN22(&VAR43);

#ifdef VAR29
  if (VAR6 & VAR44
      &&
      VAR6 & VAR45
      &&
      VAR28
      &&
      VAR43 & VAR38::VAR46)
  {
    FUN13(VAR30, VAR31,
           ("", this));
  }

  if (VAR6 & VAR47
      &&
      VAR6 & VAR45
      &&
      VAR28
      &&
      VAR43 & VAR38::VAR46)
  {
    FUN13(VAR30, VAR31,
           ("", this));
  }
#endif

  bool VAR48 = true;

  
  if (!VAR41) { 
    VAR11<VAR25> FUN23(FUN9(VAR5));
    if (!VAR49) {
      VAR11<VAR50> FUN24(FUN9(VAR5));
      if (!VAR51) {
        VAR11<VAR52> FUN25(FUN9(VAR5));
        if (!VAR53) {
          VAR11<VAR54> FUN26(FUN9(VAR5));
          if (!VAR55) {
            FUN13(VAR30, VAR31,
                   ("", this));
            VAR48 = false;
          }
        }
      }
    }
  }

  
  
  if (VAR37 && VAR17) {
    bool VAR56;
    nsresult VAR57 = 
      VAR17->FUN27(VAR37, 
                                  VAR58::VAR59,
                                  &VAR56);
    if (FUN10(VAR57) && VAR56) {
      VAR48 = false;
    }
  }

#if FUN28(VAR8)
  nsCString VAR60;
  PRUint32 VAR61 = VAR43;

  if (VAR61 & VAR38::VAR46)
  {
    VAR61 -= VAR38::VAR46;
    VAR60.FUN29("");
  }
  if (VAR61 & VAR38::VAR62)
  {
    VAR61 -= VAR38::VAR62;
    VAR60.FUN29("");
  }
  if (VAR61 & VAR38::VAR63)
  {
    VAR61 -= VAR38::VAR63;
    VAR60.FUN29("");
  }

  const char *VAR64 = FUN10(VAR7) ? "" : "";

  nsCString VAR65;
  PRUint32 VAR66 = VAR6;
  if (VAR66 & VAR67::VAR44)
  {
    VAR66 -= VAR67::VAR44;
    VAR65.FUN29("");
  }
  if (VAR66 & VAR67::VAR68)
  {
    VAR66 -= VAR67::VAR68;
    VAR65.FUN29("");
  }
  if (VAR66 & VAR67::VAR69)
  {
    VAR66 -= VAR67::VAR69;
    VAR65.FUN29("");
  }
  if (VAR66 & VAR67::VAR70)
  {
    VAR66 -= VAR67::VAR70;
    VAR65.FUN29("");
  }
  if (VAR66 & VAR67::VAR47)
  {
    VAR66 -= VAR67::VAR47;
    VAR65.FUN29("");
  }
  if (VAR66 & VAR67::VAR45)
  {
    VAR66 -= VAR67::VAR45;
    VAR65.FUN29("");
  }
  if (VAR66 & VAR67::VAR71)
  {
    VAR66 -= VAR67::VAR71;
    VAR65.FUN29("");
  }
  if (VAR66 & VAR67::VAR72)
  {
    VAR66 -= VAR67::VAR72;
    VAR65.FUN29("");
  }
  if (VAR66 & VAR67::VAR73)
  {
    VAR66 -= VAR67::VAR73;
    VAR65.FUN29("");
  }
  if (VAR66 & VAR67::VAR74)
  {
    VAR66 -= VAR67::VAR74;
    VAR65.FUN29("");
  }
  if (VAR66 & VAR67::VAR75)
  {
    VAR66 -= VAR67::VAR75;
    VAR65.FUN29("");
  }
  if (VAR66 & VAR67::VAR76)
  {
    VAR66 -= VAR67::VAR76;
    VAR65.FUN29("");
  }
  if (VAR66 & VAR67::VAR77)
  {
    VAR66 -= VAR67::VAR77;
    VAR65.FUN29("");
  }
  if (VAR66 & VAR67::VAR78)
  {
    VAR66 -= VAR67::VAR78;
    VAR65.FUN29("");
  }
  if (VAR66 & VAR67::VAR79)
  {
    VAR66 -= VAR67::VAR79;
    VAR65.FUN29("");
  }
  if (VAR66 & VAR67::VAR80)
  {
    VAR66 -= VAR67::VAR80;
    VAR65.FUN29("");
  }

  if (VAR66 > 0)
  {
    VAR65.FUN29("");
  }

  FUN13(VAR30, VAR31,
         ("", this, VAR64, 
          VAR65.FUN12(), VAR60.FUN12()));

  if (VAR6 & VAR47
      &&
      VAR39)
  {
    FUN13(VAR30, VAR31,
           ("", this,
            FUN30(VAR81)
            ));
  }
#endif

  if (VAR6 & VAR69
      &&
      VAR6 & VAR45)
  {
    
    

    VAR18 FUN6(VAR19);
    FUN31(&VAR82, VAR5, VAR83);
    
    return VAR32;
  }

  bool VAR84 = false;

  if (VAR6 & VAR47
      &&
      VAR6 & VAR45)
  {
    { 
      VAR18 FUN6(VAR19);
      VAR85 *VAR86 = FUN31(&VAR82, VAR5, VAR87);
      if (FUN32(VAR86))
      {
        FUN31(&VAR82, VAR5, VAR88);

        VAR84 = true;
      }
    }

    if (!VAR84) {
      
      
      
      VAR11<VAR89> VAR90 =
        FUN9(VAR5);
      
      
      
      bool VAR91;
      VAR84 =
        VAR90 &&
        (FUN33(VAR90->FUN34(&VAR91)) ||
         VAR91);
    }
  }

  bool VAR92 = true;
  if (VAR43 & VAR38::VAR62)
  {
    
    
    
    VAR92 = false;
  }

  if (VAR6 & VAR44
      &&
      VAR6 & VAR45
      &&
      VAR28
      &&
      VAR43 & VAR38::VAR46)
  {
    bool VAR93;

    PRInt32 VAR94;
    PRInt32 VAR95;
    PRInt32 VAR96;
    PRInt32 VAR97;
    VAR11<VAR98> VAR99;

    PRInt32 VAR100 = 0;
    PRInt32 VAR101 = 0;
    PRInt32 VAR102 = 0;
    PRInt32 VAR103 = 0;

    {
      VAR18 FUN6(VAR19);
      VAR93 = (VAR104!=0);

      if (VAR92 && !VAR93)
      {
        VAR94 = VAR105;
        VAR95 = VAR106;
        VAR96 = VAR107;
        VAR97 = VAR108;
        VAR99 = FUN9(VAR109);
      }
    }

    if (VAR92 && !VAR93)
    {
      FUN13(VAR30, VAR31,
             ("", this
              ));

      if (VAR99)
      {
        FUN13(VAR30, VAR31,
               ("", this
                ));
  
        
        
        VAR99->FUN35(VAR94);
        VAR99->FUN36(VAR95);
        VAR99->FUN37(VAR96);
        VAR99->FUN38(VAR97);
        VAR99->FUN39();
        FUN13(VAR30, VAR31, ("", 
          this, VAR99.FUN12(), VAR94, VAR95, VAR96, VAR97));      
      }

      bool VAR110 = false;

      if (VAR81 &&
          (VAR6 & VAR67::VAR80) != 0) {
        VAR110 = true;
      } else {
        VAR11<VAR52> FUN25(FUN9(VAR5));
        if (VAR53) {
          VAR110 = true;
        }
      }

      if (VAR110)
      {
        
        
        
    
        VAR11<VAR98> 
          FUN40(FUN9(VAR81));
    
        if (VAR111)
        {
          FUN13(VAR30, VAR31,
                 ("", this
                  ));
    
          VAR111->FUN41(&VAR100);
          VAR111->FUN42(&VAR101);
          VAR111->FUN43(&VAR102);
          VAR111->FUN44(&VAR103);
          FUN13(VAR30, VAR31, ("", 
            this, VAR111.FUN12(), VAR100, VAR101, VAR102, VAR103));      
        }
      }
      else
      {
        
        
        
        
        
        VAR112 = true;
      }
    }

    {
      VAR18 FUN6(VAR19);

      if (VAR92 && !VAR93)
      {
        FUN45();
        VAR105 = VAR100;
        VAR106 = VAR101;
        VAR107 = VAR102;
        VAR108 = VAR103;
        VAR113 = false;
      }

      
      
      
      FUN13(VAR30, VAR31,
             ("", this
              ));
      ++VAR104;
    }

    return VAR32;
  }

  if (VAR6 & VAR47
      &&
      VAR6 & VAR45
      &&
      VAR28
      &&
      VAR43 & VAR38::VAR46)
  {
    PRInt32 VAR114;
    VAR11<VAR115> VAR116;

    {
      VAR18 FUN6(VAR19);
      VAR114 = VAR104;
      if (VAR92)
      {
        VAR116 = VAR117;
      }
    }

    if (VAR114 <= 0)
    {
      
      
      return VAR32;
    }

    FUN13(VAR30, VAR31,
           ("", this
            ));

    if (!VAR116 && VAR39)
    {
      if (VAR92)
      {
        FUN46(VAR39, VAR116);
      }
    }

    bool VAR118 = false;
    bool VAR93;
    {
      VAR18 FUN6(VAR19);
      if (VAR92)
      {
        VAR118 = (VAR117 != VAR116);
        VAR117 = VAR116;
      }
      --VAR104;
      VAR93 = VAR104 > 0;
    }

    if (VAR92 && VAR84) {
      
      

      
      
      
      

      if (VAR118 || VAR119)
        return FUN47(VAR5, VAR81, false);
    }
    VAR119 = false;

    if (VAR112 && !VAR93)
    {
      
      
      
      
      
      
      VAR11<VAR98> VAR120;
      {
        VAR18 FUN6(VAR19);
        VAR120 = FUN9(VAR109);

        
        
        VAR112 = false;

        
        VAR113 = true;
      }

      PRInt32 VAR121 = 0;
      PRInt32 VAR122 = 0;
      PRInt32 VAR123 = 0;
      PRInt32 VAR124 = 0;

      if (VAR120)
      {
        VAR120->FUN41(&VAR121);
        VAR120->FUN42(&VAR122);
        VAR120->FUN43(&VAR123);
        VAR120->FUN44(&VAR124);
        FUN13(VAR30, VAR31, ("", 
          this, VAR120.FUN12(), VAR121, VAR122, VAR123, VAR124));      
      }

      {
        VAR18 FUN6(VAR19);
        VAR105 = VAR121;
        VAR106 = VAR122;
        VAR107 = VAR123;
        VAR108 = VAR124;
      }
    }
    
    return VAR32;
  }
  
  if (VAR6 & VAR47
      &&
      VAR6 & VAR45)
  {
    if (!VAR48)
      return VAR32;
    
    
    
    

    if (VAR92 && VAR84)
    {  
      FUN48(VAR81);
      
      
      
      
      
      
      
      
      
      

      bool VAR125;
      {
        VAR18 FUN6(VAR19);
        VAR125 = VAR113;
      }

      if (VAR125)
        return FUN49(VAR5, false, false, false);
    }

    return VAR32;
  }

  return VAR32;
}