VAR1 FUN1(VAR2 *VAR3,               unsigned char *     VAR4,  	      unsigned int        VAR5,  	      unsigned char *     VAR6,  	      unsigned int        VAR7)  
{
    SECStatus       VAR8;
    unsigned int    VAR9 = FUN2(VAR3);
    unsigned int    VAR10;
    unsigned char * VAR11;

    VAR9 = FUN2(VAR3);
    if (VAR5 != VAR9) 
    	goto VAR12;
    if (VAR7 > VAR9 - 8) 
    	goto VAR12;
    FUN3(VAR3->VAR13 == VAR14);
    if (VAR3->VAR13 != VAR14)
    	goto VAR12;

    VAR11 = (unsigned char *)FUN4(VAR9 + 1);
    if (!VAR11)
    	goto VAR12;

    VAR8 = FUN5(&VAR3->VAR15.VAR16, VAR11, VAR4);
    if (VAR8 != VAR17)
	goto VAR18;

    
    if (VAR11[0] != 0 || VAR11[1] != 1) 
    	goto VAR18;
    for (VAR10 = 2; VAR10 < VAR9 - VAR7 - 1; VAR10++) {
	if (VAR11[VAR10] != 0xff) 
	    goto VAR18;
    }
    if (VAR11[VAR10] != 0) 
	goto VAR18;

    
    if (FUN6(VAR11 + VAR9 - VAR7, VAR6, VAR7) != 0)
	goto VAR18;

    FUN7(VAR11);
    return VAR17;

VAR18:
    FUN7(VAR11);
VAR12:
    return VAR19;
}