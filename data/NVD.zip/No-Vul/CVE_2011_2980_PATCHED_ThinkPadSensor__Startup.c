PRBool VAR1::FUN1()  
{
  WCHAR VAR2[VAR3 + sizeof("")];
  if (FUN2(VAR2, VAR3)) {
    wcscat(VAR2, VAR4"");
    VAR5 = LoadLibraryW(VAR2);
  }
  if (!VAR5)
    return VAR6;

  VAR7 = (VAR8)
    FUN3(VAR5, "");
  if (!VAR7) {
    FUN4(VAR5);
    VAR5 = VAR9;
    return VAR6;
  }
  return VAR10;
}