int FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4, size_t VAR5)  
{
	struct VAR6 * VAR6;
	int VAR7, VAR8 = -VAR9;

	for (VAR7 = 0; VAR7 < VAR5; VAR7++) {
		VAR6 = FUN2(VAR10 | VAR11 | VAR12);
		
		if (VAR6 == NULL)
			goto VAR13;

#ifndef VAR14
		FUN3(VAR6);
#endif
		FUN4(VAR6);
		FUN5(&VAR15->VAR16);

		
		VAR4->VAR17[VAR7] = (unsigned long)FUN6(VAR6);
		VAR4->VAR18++;
	}

#ifdef VAR14
	FUN7(VAR4->VAR17, VAR5);
#endif
	VAR8 = 0;
VAR13:
	for (VAR7 = 0; VAR7 < VAR4->VAR18; VAR7++)
		VAR4->VAR17[VAR7] = FUN8((void *)VAR4->VAR17[VAR7]);
	return VAR8;
}