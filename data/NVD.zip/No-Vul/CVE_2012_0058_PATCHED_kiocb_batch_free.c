static void FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4)    
{
	struct VAR5 *VAR6, *VAR7;

	if (FUN2(&VAR4->VAR8))  
		return;  
  
	FUN3(&VAR2->VAR9);  
	FUN4(VAR6, VAR7, &VAR4->VAR8, VAR10) {
		FUN5(&VAR6->VAR10);
		FUN5(&VAR6->VAR11);  
		FUN6(VAR12, VAR6);
		VAR2->VAR13--;  
	}
	FUN7(&VAR2->VAR9);  
}