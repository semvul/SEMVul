static VAR1 FUN1(struct VAR2 *VAR2, struct VAR3 *VAR3, 			     int VAR4, size_t VAR5, VAR6 *VAR7, int VAR8)  
{
	struct socket *VAR9;
	int VAR10;

	VAR9 = VAR2->VAR11;

	VAR10 = !(VAR2->VAR12 & VAR13) ? 0 : VAR14;
	if (VAR8)
		VAR10 |= VAR15;

	return FUN2(VAR9, VAR3, VAR4, VAR5, VAR10);
}