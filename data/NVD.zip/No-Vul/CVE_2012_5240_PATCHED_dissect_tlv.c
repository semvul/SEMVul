static int FUN1(VAR1 *VAR2, guint VAR3, VAR4 *VAR5, int VAR6)  
{
    guint16 VAR7, VAR8;
    int VAR9;

    VAR9=FUN2(VAR2, VAR3);
    VAR6=FUN3(VAR6, VAR9);

    if( VAR6 < 4 ) {
        if (VAR5) {
            FUN4(VAR5, VAR2, VAR3, VAR6,
                                "",
                                VAR6);
        }
        return VAR6;
    }
    VAR7 = FUN5(VAR2, VAR3) & 0x3FFF;

    VAR9 = FUN5(VAR2, VAR3 + 2);
    VAR6 -= 4; 
    VAR9 = FUN3(VAR9, VAR6);  

    if (VAR5) {
        VAR4 *VAR10 = NULL, *VAR11;
        
        if(VAR7>=VAR12 && VAR7<=VAR13){
            VAR8=VAR7;               
            VAR7=VAR12;
            VAR10 = FUN4(VAR5, VAR2, VAR3, VAR9 + 4, "");
            
        } else if(VAR7>=VAR14 && VAR7<=VAR15){
            VAR8=VAR7;               
            VAR7=VAR14;
            VAR10 = FUN4(VAR5, VAR2, VAR3, VAR9 + 4, "");
        } else {
            VAR8=0;
            VAR10 = FUN4(VAR5, VAR2, VAR3, VAR9 + 4, "",
                                     FUN6(VAR7, VAR16, ""));
        }

        VAR11 = FUN7(VAR10, VAR17);

        FUN8(VAR11, VAR18, VAR2, VAR3, 1, VAR19);

        switch (VAR7) {
        case VAR12:
            FUN9(VAR11, VAR20, VAR2, VAR3, 2,
                                       VAR8, "", VAR8);
            break;
        case VAR14:
            FUN9(VAR11, VAR20, VAR2, VAR3, 2,
                                       VAR8, "", VAR8);
            break;
        default:
            FUN9(VAR11, VAR20, VAR2, VAR3, 2,
                                       VAR7, "", FUN6(VAR7, VAR16, ""), VAR7 );
        }

        FUN8(VAR11, VAR21, VAR2, VAR3 + 2, 2, VAR19);

        switch (VAR7) {

        case VAR22:
            FUN10(VAR2, VAR3 + 4, VAR11, VAR9);
            break;

        case VAR23:
            FUN11(VAR2, VAR3 + 4, VAR11, VAR9);
            break;

        case VAR24:
            if( VAR9 != 1 ) 
                FUN4(VAR11, VAR2, VAR3 + 4,VAR9,
                                    "",
                                    VAR9);
            else
                FUN8(VAR11, VAR25, VAR2,VAR3 + 4, VAR9, VAR19);
            break;

        case VAR26:
            FUN12(VAR2, VAR3 + 4, VAR11, VAR9);
            break;

        case VAR27:
            if( VAR9 != 4 ) 
                FUN4(VAR11, VAR2, VAR3 + 4, VAR9,
                                    "",
                                    VAR9);
            else {
                guint32 VAR28=FUN13(VAR2, VAR3+4) & 0x000FFFFF;

                FUN9(VAR11, VAR29,
                                           VAR2, VAR3+4, VAR9, VAR28, "", VAR28);
            }
            break;

        case VAR30:
            FUN14(VAR2, VAR3 + 4, VAR11, VAR9);
            break;

        case VAR31:
            FUN15(VAR2, VAR3 + 4, VAR11, VAR9);
            break;

        case VAR32:
            if( VAR9 != 4 ) 
                FUN4(VAR11, VAR2, VAR3 + 4, VAR9,
                                    "",
                                    VAR9);
            else
                FUN8(VAR11, VAR33, VAR2,
                                    VAR3 + 4,VAR9, VAR19);
            break;

        case VAR34:
            FUN16(VAR2, VAR3 + 4, VAR11, VAR9);
            break;

        case VAR35:
            if( VAR9 != 4 ) 
                FUN4(VAR11, VAR2, VAR3 + 4, VAR9,
                                    "",
                                    VAR9);
            else {
                FUN8(VAR11, VAR36, VAR2, VAR3 + 4, VAR9, VAR19);
            }
            break;

        case VAR37:
            FUN17(VAR2, VAR3 + 4, VAR11, VAR9);
            break;

        case VAR38:
            FUN18(VAR2, VAR3 + 4, VAR11, VAR9);
            break;

        case VAR39:
#if 0
            FUN19(VAR2, VAR3 + 4, VAR11, VAR9);
#else
            FUN19(VAR2, VAR3 + 4, VAR11);
#endif
            break;

        case VAR40:
            if( VAR9 != 4 ) 
                FUN4(VAR11, VAR2, VAR3 + 4, VAR9,
                                    "",
                                    VAR9);
            else {
                FUN8(VAR11, VAR41, VAR2, VAR3 + 4, 4, VAR19);
            }
            break;

        case VAR42:
            if( VAR9 != 4 ) 
                FUN4(VAR11, VAR2, VAR3 + 4, VAR9,
                                    "",
                                    VAR9);
            else {
                FUN8(VAR11, VAR43, VAR2, VAR3 + 4, 4, VAR19);
            }
            break;

        case VAR44:
            if( VAR9 != 16 ) 
                FUN4(VAR11, VAR2, VAR3 + 4, VAR9,
                                    "",
                                    VAR9);
            else {
                FUN8(VAR11, VAR45, VAR2, VAR3 + 4, 16, VAR46);
            }
            break;

        case VAR47: 
            FUN20(VAR2, VAR3 + 4, VAR11, VAR9);
            break;

        case VAR48:
            FUN21(VAR2, VAR3 + 4, VAR11, VAR9);
            break;

        case VAR49:
            FUN22(VAR2, VAR3 + 4, VAR11, VAR9);
            break;

        case VAR50:
            FUN23(VAR2, VAR3 + 4, VAR11, VAR9);
            break;

        case VAR51:
            
            FUN24(VAR2, VAR3 + 4, VAR11, VAR9);
            break;

        case VAR52:
            if( VAR9 != 4 ) 
                FUN4(VAR11, VAR2, VAR3 + 4, VAR9,
                                    "",
                                    VAR9);
            else
                FUN8(VAR11, VAR53, VAR2,
                                    VAR3 + 4,VAR9, VAR19);
            break;

        case VAR54:
            if( VAR9 != 0 ) 
                FUN4(VAR11, VAR2, VAR3 + 4, VAR9,
                                    "",
                                    VAR9);
            break;

        case VAR55:
            if( VAR9 != 4 ) 
                FUN4(VAR11, VAR2, VAR3 + 4, VAR9,
                                    "",
                                    VAR9);
            else
                FUN8(VAR11, VAR56, VAR2,VAR3 + 4,VAR9, VAR19);
            break;

        case VAR57:
            FUN25(VAR2, VAR3 + 4, VAR11, VAR9);
            break;

        case VAR58:
            FUN26(VAR2, VAR3 + 4, VAR11, VAR9);
            break;

        case VAR59:
            FUN27(VAR2, VAR3 + 4, VAR11, VAR9);
            break;

        case VAR60:
            FUN28(VAR2, VAR3 +4, VAR11, VAR9);
            break;

        case VAR61:
            FUN29(VAR2, VAR3 + 4, VAR11, VAR9);
            break;

        case VAR62:
            FUN30(VAR2, VAR3 +4, VAR11, VAR9);
            break;

        case VAR63:
            FUN31(VAR2, VAR3 +4, VAR11, VAR9);
            break;

        case VAR64:
            FUN32(VAR2, VAR3 +4, VAR11, VAR9);
            break;

        case VAR65:
            FUN33(VAR2, VAR3 +4, VAR11, VAR9);
            break;

        case VAR66:
            FUN34(VAR2, VAR3 +4, VAR11, VAR9);
            break;

        case VAR67:
            FUN35(VAR2, VAR3 +4, VAR11, VAR9);
            break;

        case VAR12:
            if( VAR9 < 4 ) 
                FUN4(VAR11, VAR2, VAR3 + 4, VAR9,
                                    "",
                                    VAR9);
            else {
                FUN8(VAR11, VAR68, VAR2,VAR3 + 4, 4, VAR19);
                if( VAR9 > 4 )  
                    FUN4(VAR11, VAR2, VAR3 + 8, VAR9-4,"");
            }
            break;

        case VAR14:
            if( VAR9 < 4 ) 
                FUN4(VAR11, VAR2, VAR3 + 4, VAR9,
                                    "",
                                    VAR9);
            else {
                FUN8(VAR11, VAR69, VAR2,VAR3 + 4, 4, VAR19);
                if( VAR9 > 4 )  
                    FUN4(VAR11, VAR2, VAR3 + 8, VAR9-4,"");
            }
            break;

        case VAR70:
        {
            
            FUN36(VAR2, VAR3 +4, VAR11, VAR9);
            break;
        }
        case VAR71:
        {
            
            static int *VAR72[] = {
                &VAR73 ,
                &VAR74 ,
                &VAR75 ,
                &VAR76 ,
                &VAR77 ,
                &VAR78 ,
                &VAR79 ,
                &VAR80 ,
                &VAR81 ,
                &VAR82 ,
                &VAR83 ,
                &VAR84 ,
                &VAR85 ,
                &VAR86 ,
                &VAR87 ,
                &VAR88 ,
                &VAR89 ,
                &VAR90 ,
                &VAR91 ,
                &VAR92 ,
                &VAR93 ,
                &VAR94 ,
                &VAR95 ,
                &VAR96 ,
                &VAR97 ,
                &VAR98 ,
                &VAR99 ,
                &VAR100 ,
                &VAR101 ,
                &VAR102 ,
                &VAR103 ,
                &VAR104 ,
                &VAR105,
                &VAR106,
                &VAR107,
                &VAR108,
                &VAR109,
                &VAR110,
                &VAR111
            };
            int VAR112 = VAR9;
            VAR3 += 4;
            while ( (VAR112 > 1) && (VAR6 > 1) ) {       
                int VAR113 = FUN37(VAR2, VAR3+1);
                if (VAR113 < 2){ 
                    FUN4(VAR11, VAR2, VAR3 +1, 1, "");
                    break;
                }

                if ( (VAR112 -VAR113) <0 && (VAR6 -VAR113) <0 ) { 
                    FUN4(VAR11, VAR2, VAR3 +2, FUN3(VAR112,VAR6), "");
                    break;
                }
                FUN38(VAR2, VAR3, VAR11, VAR113, VAR72);

                VAR6 -= VAR113;
                VAR112 -= VAR113;
                VAR3 += VAR113;
            }
            break;
        }
        case VAR114:
        {
            
            FUN39(VAR2, VAR3 +4, VAR11, VAR9);
            break;
        }
        default:
            FUN8(VAR11, VAR115, VAR2, VAR3 + 4, VAR9, VAR46);
            break;
        }
    }

    return VAR9 + 4;  
}