static void FUN1(struct VAR1 *VAR2, 			    struct VAR3 *VAR4, struct VAR5 *VAR6)  
{
	struct VAR7 *VAR8;

	if (FUN2(VAR9->VAR10, VAR11, VAR2,
		           VAR2->VAR12+VAR2->VAR13,
		           VAR2->VAR13,
		           VAR4, VAR6, VAR14) < 0)
		FUN3(VAR9->VAR10);
	else if ((VAR8 = FUN4(&VAR9->VAR10->VAR15)) != NULL) {
		struct VAR16 *VAR17 = VAR8->VAR18.VAR17;
		unsigned int VAR19 = 0;
		struct VAR7 *VAR20;

		FUN5(&VAR9->VAR10->VAR15, VAR20) {
			VAR19 = FUN6(VAR19, VAR20->VAR19);
		}
		VAR19 = FUN7((void *)&VAR2->VAR21,
						 (char *)VAR17,
						 VAR2->VAR13, VAR19);
		VAR17->VAR22 = FUN8(VAR19);
		VAR8->VAR23 = VAR24;
		FUN9(VAR9->VAR10);
	}
}