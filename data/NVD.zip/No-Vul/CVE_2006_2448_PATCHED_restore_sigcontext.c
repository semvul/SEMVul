static long FUN1(struct VAR1 *VAR2, VAR3 *VAR4, int VAR5, 			      struct sigcontext VAR6 *VAR7)  
{
#ifdef VAR8
	elf_vrreg_t VAR6 *VAR9;
#endif
	unsigned long VAR10 = 0;
	unsigned long VAR11 = 0;
	VAR12 *VAR13 = (VAR12 *)VAR2;
#ifdef VAR8
	unsigned long VAR14;
#endif
	int VAR15;

	
	if (!VAR5)
		VAR11 = VAR2->VAR16[13];

	
	VAR10 |= FUN2(VAR2, &VAR7->VAR17,
				VAR18*sizeof(unsigned long));

	
	for (VAR15 = VAR18+1; VAR15 <= VAR19; VAR15++) {
		if (VAR15 == VAR20)
			continue;
		VAR10 |= FUN3(VAR13[VAR15], &VAR7->VAR17[VAR15]);
	}

	if (!VAR5)
		VAR2->VAR16[13] = VAR11;
	if (VAR4 != NULL)
		VAR10 |=  FUN3(VAR4->VAR5[0], &VAR7->VAR21);

	
	FUN4();

	VAR10 |= FUN2(&VAR22->VAR23.VAR24, &VAR7->VAR25, VAR26);

#ifdef VAR8
	VAR10 |= FUN3(VAR9, &VAR7->VAR9);
	VAR10 |= FUN3(VAR14, &VAR7->VAR17[VAR18]);
	if (VAR10)
		return VAR10;
	if (VAR9 && !FUN5(VAR27, VAR9, 34 * sizeof(VAR28)))
		return -VAR29;
	
	if (VAR9 != 0 && (VAR14 & VAR30) != 0)
		VAR10 |= FUN2(VAR22->VAR23.VAR31, VAR9,
					33 * sizeof(VAR28));
	else if (VAR22->VAR23.VAR32)
		memset(VAR22->VAR23.VAR31, 0, 33 * sizeof(VAR28));
	
	if (VAR9 != 0)
		VAR10 |= FUN3(VAR22->VAR23.VAR33, (u32 VAR6 *)&VAR9[33]);
	else
		VAR22->VAR23.VAR33 = 0;
#endif 

	
	VAR2->VAR14 &= ~(VAR34 | VAR35 | VAR36 | VAR30);

	return VAR10;
}