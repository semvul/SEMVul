static int FUN1(struct VAR1 *VAR2, int VAR3)  
{
	int VAR4;

	memset(VAR2, 0, sizeof(struct VAR1));
	VAR2->VAR5 = 1;
	
	VAR4 = sizeof(struct VAR6)
		+ VAR3*sizeof(struct VAR7);
	VAR2->VAR8 = FUN2(VAR4, VAR9);
	if (!VAR2->VAR8)
		return -VAR10;
	VAR2->VAR11 = FUN2(VAR4, VAR9);
	if (!VAR2->VAR11) {
		FUN3(VAR2->VAR8);
		return -VAR10;
	}
	return 0;
}