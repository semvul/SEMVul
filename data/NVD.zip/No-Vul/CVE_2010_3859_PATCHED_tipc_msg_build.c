int FUN1(struct VAR1 *VAR2, 			    struct iovec const *VAR3, u32 VAR4, 			    int VAR5, int VAR6, struct VAR7** VAR8)  
{
	int VAR9, VAR10, VAR11, VAR12, VAR13, VAR14;

	VAR9 = FUN2(VAR3, VAR4);
	if (FUN3(VAR9 > VAR15)) {
		*VAR8 = NULL;
		return -VAR16;
	}

	VAR12 = VAR11 = FUN4(VAR2);
	VAR10 = VAR11 + VAR9;
	FUN5(VAR2, VAR10);
	if (FUN3(VAR10 > VAR5)) {
		*VAR8 = NULL;
		return VAR9;
	}

	*VAR8 = FUN6(VAR10);
	if (!(*VAR8))
		return -VAR17;
	FUN7(*VAR8, VAR2, VAR11);
	for (VAR13 = 1, VAR14 = 0; VAR13 && (VAR14 < VAR4); VAR14++) {
		if (FUN8(VAR6))
			VAR13 = !FUN9((*VAR8)->VAR18 + VAR12,
					      VAR3[VAR14].VAR19,
					      VAR3[VAR14].VAR20);
		else
			FUN10(*VAR8, VAR12,
						       VAR3[VAR14].VAR19,
						       VAR3[VAR14].VAR20);
		VAR12 += VAR3[VAR14].VAR20;
	}
	if (FUN8(VAR13))
		return (int)VAR9;

	FUN11(*VAR8);
	*VAR8 = NULL;
	return -VAR21;
}