static void *FUN1(struct VAR1 *VAR2, VAR3 *VAR4)  
{
	struct VAR5 *VAR6 = VAR2->private;
	VAR6->VAR7 = VAR8;

	return *VAR4 ? FUN2(VAR2, *VAR4-1) : VAR9;
}