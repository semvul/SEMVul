static noinline_for_stack int FUN1(struct VAR1 *VAR2, 						u32 VAR3, void VAR4 *VAR5)  
{
	struct ethtool_rxnfc VAR6;
	size_t VAR7 = sizeof(VAR6);
	const struct VAR8 *VAR9 = VAR2->VAR8;
	int VAR10;
	void *VAR11 = NULL;

	if (!VAR9->VAR12)
		return -VAR13;

	
	if (VAR3 == VAR14)
		VAR7 = (FUN2(struct VAR15, VAR16) +
			     sizeof(VAR6.VAR16));

	if (FUN3(&VAR6, VAR5, VAR7))
		return -VAR17;

	if (VAR6.VAR3 == VAR18) {
		if (VAR6.VAR19 > 0) {
			if (VAR6.VAR19 <= VAR20 / sizeof(VAR21))
				VAR11 = FUN4(VAR6.VAR19 * sizeof(VAR21),
						   VAR22);
			if (!VAR11)
				return -VAR23;
		}
	}

	VAR10 = VAR9->FUN5(VAR2, &VAR6, VAR11);
	if (VAR10 < 0)
		goto VAR24;

	VAR10 = -VAR17;
	if (FUN6(VAR5, &VAR6, VAR7))
		goto VAR24;

	if (VAR11) {
		VAR5 += FUN2(struct VAR15, VAR25);
		if (FUN6(VAR5, VAR11,
				 VAR6.VAR19 * sizeof(VAR21)))
			goto VAR24;
	}
	VAR10 = 0;

VAR24:
	FUN7(VAR11);

	return VAR10;
}