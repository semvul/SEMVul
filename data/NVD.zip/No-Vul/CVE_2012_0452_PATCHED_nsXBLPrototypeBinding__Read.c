nsresult VAR1::FUN1(VAR2* VAR3,                             VAR4* VAR5,                             VAR6* VAR7,                             PRUint8 VAR8)  
{
  VAR9 = (VAR8 & VAR10) ? true : false;

  
  
  nsCAutoString VAR11;
  nsresult VAR12 = VAR3->FUN2(VAR11);

  FUN3(VAR12, VAR12);
  FUN4(!VAR11.FUN5(), VAR13);

  nsCAutoString VAR14;
  VAR12 = VAR3->FUN2(VAR14);
  FUN3(VAR12, VAR12);
  VAR15 = true;

  if (!VAR14.FUN5()) {
    VAR12 = FUN6(FUN7(VAR16), VAR14);
    FUN3(VAR12, VAR12);
  }

  VAR12 = FUN8(VAR3, VAR17);
  FUN3(VAR12, VAR12);

  nsAutoString VAR18;
  VAR12 = VAR3->FUN9(VAR18);
  FUN3(VAR12, VAR12);
  if (!VAR18.FUN5()) {
    VAR19 = FUN10(VAR18);
  }

  VAR7->FUN11(FUN12(""), VAR20, VAR21,
                        FUN7(VAR22));

  VAR23<VAR24> VAR25;
  VAR12 = FUN13(VAR3, VAR7, VAR7->FUN14(), FUN7(VAR25));
  FUN3(VAR12, VAR12);

  VAR26* VAR27 = VAR7->FUN15();
  if (VAR27)
    VAR27->FUN16(VAR22, false);

  if (VAR25) {
    VAR22->FUN16(VAR25, false);
  }

  PRUint32 VAR28;
  VAR12 = VAR3->FUN17(&VAR28);
  FUN3(VAR12, VAR12);

  if (VAR28 > 0) {
    FUN18(!VAR29, "");
    VAR29 = new FUN19(VAR28);
    FUN4(VAR29, VAR30);

    for (; VAR28 > 0; VAR28--) {
      nsIID VAR31;
      VAR3->FUN20(&VAR31);
      VAR32 FUN21(VAR31);
      VAR29->FUN22(&VAR33, VAR22);
    }
  }

  VAR23<VAR34> FUN23(FUN24(VAR5));
  VAR35* VAR36 = VAR37->FUN25();
  FUN4(VAR36, VAR38);

  VAR39 *VAR40 = VAR36->FUN26();
  FUN4(VAR40, VAR13);

  bool VAR41 = VAR8 & VAR42;
  VAR12 = FUN27(VAR11, VAR5, VAR20, VAR41);
  FUN3(VAR12, VAR12);

  
  
  VAR12 = VAR5->FUN28(VAR11, this);
  FUN3(VAR12, VAR12);

  VAR43 FUN29(VAR5, VAR11);  

  nsCAutoString VAR44;
  VAR12 = VAR3->FUN2(VAR44);
  FUN3(VAR12, VAR12);

  if (!VAR44.FUN5()) {
    VAR45* VAR46; 
    FUN30(this, FUN31(VAR44).FUN32(), &VAR46);

    
    
    
    
    VAR12 = VAR47->FUN1(VAR40, VAR3, this, VAR36);
    FUN3(VAR12, VAR12);
  }

  
  VAR48* VAR49 = VAR20;

  do {
    XBLBindingSerializeDetails VAR50;
    VAR12 = VAR3->FUN33(&VAR50);
    FUN3(VAR12, VAR12);

    if (VAR50 == VAR51)
      break;

    FUN18((VAR50 & VAR52) == VAR53,
                 "");

    VAR48* VAR54 = new FUN34(this);
    VAR12 = VAR54->FUN1(VAR40, VAR3);
    if (FUN35(VAR12)) {
      delete VAR54;
      return VAR12;
    }

    if (VAR49) {
      VAR49->FUN36(VAR54);
    }
    else {
      FUN37(VAR54);
    }
    VAR49 = VAR54;
  } while (1);

  
  do {
    XBLBindingSerializeDetails VAR50;
    VAR12 = VAR3->FUN33(&VAR50);
    FUN3(VAR12, VAR12);

    if (VAR50 == VAR51)
      break;

    FUN18((VAR50 & VAR52) == VAR55 ||
                 (VAR50 & VAR52) == VAR56, "");

    nsAutoString VAR57;
    VAR12 = VAR3->FUN9(VAR57);
    FUN3(VAR12, VAR12);

    FUN38(VAR50 == VAR55 ? VAR58::VAR59 :
                                                          VAR58::VAR60, VAR57);
  } while (1);

  if (VAR41) {
    VAR5->FUN39(this);
  }

  VAR61.FUN40();
  return VAR62;
}