static VAR1 *FUN1(struct VAR2 *VAR3, u32 VAR4)  
{
	
	unsigned int VAR5 = (char *)VAR3->VAR6 - (char *)VAR3->VAR7;
	VAR1 *VAR7;
	if (VAR5 + VAR3->VAR8 < VAR4)
		return NULL;
	if (VAR5 + VAR9 < VAR4) 
		return NULL;
	
	if (VAR4 <= sizeof(VAR3->VAR10))
		VAR7 = VAR3->VAR10;
	else {
		FUN2(VAR3->VAR11);
		VAR7 = VAR3->VAR11 = FUN3(VAR4, VAR12);
		if (!VAR7)
			return NULL;
		
	}
	
	memcpy(VAR7, VAR3->VAR7, VAR5);
	
	VAR3->VAR7 = FUN4(VAR3->VAR13[0]);
	VAR3->VAR13++;
	if (VAR3->VAR8 < VAR9) {
		VAR3->VAR6 = VAR3->VAR7 + (VAR3->VAR8>>2);
		VAR3->VAR8 = 0;
	} else {
		VAR3->VAR6 = VAR3->VAR7 + (VAR9>>2);
		VAR3->VAR8 -= VAR9;
	}
	memcpy(((char*)VAR7)+VAR5, VAR3->VAR7, (VAR4 - VAR5));
	VAR3->VAR7 += FUN5(VAR4 - VAR5);
	return VAR7;
}