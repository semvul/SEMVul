static int FUN1(struct VAR1 *VAR2, 			   const struct VAR3 *VAR4, 			   char *VAR5)  
{
	u_int32_t VAR6, VAR7;
	sctp_chunkhdr_t VAR8, *VAR9;
	int VAR10;

	FUN2(VAR11);
	FUN2("");

	VAR10 = 0;

	FUN3 (VAR4, VAR9, VAR8, VAR6, VAR7) {
		FUN2("", VAR7, VAR9->VAR12);

		if (VAR9->VAR12 == VAR13 
			|| VAR9->VAR12 == VAR14
			|| VAR9->VAR12 == VAR15) {
			VAR10 = 1;
		}

		
		if ((VAR9->VAR12 == VAR16 
			|| VAR9->VAR12 == VAR17
			|| VAR10)
		     && VAR7 !=0 ) {
			FUN2("");
			return 1;
		}

		if (VAR5) {
			FUN4(VAR9->VAR12, (void *)VAR5);
		}
	}

	FUN2("");
	return VAR7 == 0;
}