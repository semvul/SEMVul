FUN1( FT_Stream  VAR1,                         FT_ULong   VAR2 )    
{
    FT_Error  VAR3 = VAR4;
    FT_ULong  VAR5;


    
    FUN2( VAR1 && VAR1->VAR6 == 0 );

    if ( VAR1->read )
    {
      
      FT_Memory  VAR7 = VAR1->VAR7;


      
      if ( VAR2 > VAR1->VAR8 )
      {
        FUN3(( ""
                   "",
                   VAR2, VAR1->VAR8 ));

        VAR3 = VAR9;
        goto VAR10;
      }

#ifdef VAR11
      
      VAR1->VAR12 = (unsigned char*)FUN4( VAR7, VAR2, &VAR3 );
      if ( VAR3 )
        goto VAR10;
#else
      if ( FUN5( VAR1->VAR12, VAR2 ) )
        goto VAR10;
#endif
      
      VAR5 = VAR1->read( VAR1, VAR1->VAR13,
                                 VAR1->VAR12, VAR2 );
      if ( VAR5 < VAR2 )
      {
        FUN3(( ""
                   "",
                   VAR2, VAR5 ));

        FUN6( VAR1->VAR12 );
        VAR3 = VAR9;
      }
      VAR1->VAR6 = VAR1->VAR12;
      VAR1->VAR14  = VAR1->VAR6 + VAR2;
      VAR1->VAR13   += VAR5;
    }
    else
    {
      
      if ( VAR1->VAR13 >= VAR1->VAR8        ||
           VAR1->VAR8 - VAR1->VAR13 < VAR2 )
      {
        FUN3(( ""
                   "",
                   VAR1->VAR13, VAR2, VAR1->VAR8 ));

        VAR3 = VAR9;
        goto VAR10;
      }

      
      VAR1->VAR6 = VAR1->VAR12 + VAR1->VAR13;
      VAR1->VAR14  = VAR1->VAR6 + VAR2;
      VAR1->VAR13   += VAR2;
    }

  VAR10:
    return VAR3;
  }