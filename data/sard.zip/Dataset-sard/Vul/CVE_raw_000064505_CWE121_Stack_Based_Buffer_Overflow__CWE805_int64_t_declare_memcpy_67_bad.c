void FUN1()
{
    VAR1 * VAR2;
    CWE121_Stack_Based_Buffer_Overflow__CWE805_int64_t_declare_memcpy_67_structType VAR3;
    int64_t VAR4[50];
    int64_t VAR5[100];
    
    VAR2 = VAR4;
    VAR3.VAR6 = VAR2;
    FUN2(VAR3);
}