static int FUN1(struct VAR1 *VAR2, void VAR3 *VAR4)  
{
	int VAR5;
	struct VAR6 *VAR7;

	VAR5 = -VAR8;
	VAR7 = FUN2(VAR2);
	if (VAR7) {
		VAR5 = FUN3(VAR7, (void VAR3 * VAR3 *)VAR4);
		FUN4(VAR7);
	}
	return VAR5;
}