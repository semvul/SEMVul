NS_IMETHODIMP VAR1::FUN1(VAR2 *VAR3,                                             PRUint32 VAR4,                                             VAR2 **VAR5)  
{
  FUN2(VAR3, VAR5);

  if (VAR4 >= static_cast<VAR6>(VAR7.FUN3())) {
    return VAR8;
  }

  
  VAR9* VAR10 = static_cast<VAR9*>(VAR3);
  FUN4(VAR10);

  
  if (VAR4 >= static_cast<VAR6>(VAR7.FUN3())) {
    return VAR8;
  }

  FUN5();
  VAR7.FUN6(VAR10, VAR4);
  VAR10->FUN7(this);
  FUN8();

  FUN9(*VAR5 = VAR3);
  return VAR11;
}