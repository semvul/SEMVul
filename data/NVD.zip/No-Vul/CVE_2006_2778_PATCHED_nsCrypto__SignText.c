NS_IMETHODIMP VAR1::FUN1(const VAR2& VAR3, const VAR2& VAR4,                    VAR2& VAR5)  
{
  
  
  FUN2(VAR6, "");

  VAR5.FUN3();

  VAR7<VAR8> VAR9;
  VAR7<VAR10> FUN4(FUN5(VAR10::FUN6()));
  if (VAR11) {
    VAR11->FUN7(FUN8(VAR9));
  }

  if (!VAR9) {
    VAR5.FUN9(VAR6);

    return VAR12;
  }

  PRUint32 argc;
  VAR9->FUN10(&argc);

  VAR13 *VAR14;
  VAR9->FUN11(&VAR14);
  if (!VAR14) {
    VAR5.FUN9(VAR6);

    return VAR12;
  }

  if (!VAR4.FUN12(FUN13("")) &&
      !VAR4.FUN12(FUN13(""))) {
    FUN14(VAR14, "", VAR15, "");

    VAR5.FUN9(VAR6);

    return VAR12;
  }

  
  

  VAR7<VAR16> VAR17 = new VAR18;
  if (!VAR17) {
    VAR5.FUN9(VAR6);

    return VAR12;
  }

  PRBool VAR19 = VAR20;
  PRBool VAR21 = VAR20;
  VAR22* VAR23 =
    FUN15(FUN16(), VAR24,
                              VAR19, VAR21, VAR17);

  PRUint32 VAR25 = argc - 2;
  if (VAR25 > 0) {
    VAR26<char*> FUN17(new char*[VAR25]);
    if (!VAR27) {
      VAR5.FUN9(VAR6);

      return VAR12;
    }

    VAR28 *argv = VAR29;
    VAR9->FUN18(&argv);

    PRUint32 VAR30;
    for (VAR30 = 2; VAR30 < argc; ++VAR30) {
      VAR31 *VAR32 = FUN19(VAR14, argv[VAR30]);
      if (!VAR32) {
        VAR5.FUN9(VAR6);

        return VAR12;
      }
      VAR27[VAR30 - 2] = FUN20(VAR32);
    }

    if (VAR23 &&
        FUN21(VAR23, VAR25, VAR27,
                                     VAR24) != VAR33) {
      VAR5.FUN9(VAR6);

      return VAR12;
    }
  }

  if (!VAR23 || FUN22(VAR23)) {
    VAR5.FUN9(FUN13(""));

    return VAR12;
  }

  VAR7<VAR34> VAR35 =
    FUN23(VAR36);
  if (!VAR35) {
    VAR5.FUN9(VAR6);

    return VAR12;
  }

  VAR7<VAR37> VAR38 =
    FUN5(VAR39);
  if (!VAR38) {
    VAR5.FUN9(VAR6);

    return VAR12;
  }

  VAR7<VAR34> VAR40;
  nsresult VAR41 = VAR38->FUN24(VAR42,
                                            FUN25(VAR34), 
                                            VAR35, VAR43,
                                            FUN8(VAR40));
  if (FUN26(VAR41)) {
    VAR5.FUN9(VAR6);

    return VAR12;
  }

  VAR7<VAR44> VAR45;
  FUN27(VAR14, FUN8(VAR45));
  if (!VAR45) {
    VAR5.FUN9(VAR6);

    return VAR12;
  }

  
  VAR46* VAR47 = VAR45->FUN28();
  if (!VAR47) {
    VAR5.FUN9(VAR6);

    return VAR12;
  }

  nsCString VAR48;
  VAR41 = VAR47->FUN29(VAR48);
  if (FUN26(VAR41)) {
    VAR5.FUN9(VAR6);

    return VAR12;
  }

  PRInt32 VAR49 = 0;
  VAR50* VAR51;
  for (VAR51 = FUN30(VAR23); !FUN31(VAR51, VAR23);
       VAR51 = FUN32(VAR51)) {
    ++VAR49;
  }

  VAR52* VAR53 =
    FUN33(VAR23, VAR54,
                                     VAR55);
  if (!VAR53) {
    VAR5.FUN9(VAR6);

    return VAR12;
  }

  VAR56 FUN34(VAR53);

  FUN35(VAR53->VAR57 == VAR49,
               "");

  VAR26<VAR58*> FUN36(new VAR58*[VAR53->VAR57 * 2]);
  if (!VAR59) {
    VAR5.FUN9(VAR6);

    return VAR12;
  }

  VAR58** VAR60 = VAR59.FUN37() + VAR53->VAR57;

  PRInt32 VAR61;
  for (VAR51 = FUN30(VAR23), VAR61 = 0;
       !FUN31(VAR51, VAR23) && VAR61 < VAR53->VAR57;
       VAR51 = FUN32(VAR51)) {
    VAR62<VAR63> VAR64 = new FUN38(VAR51->VAR65);
    if (VAR64) {
      nsAutoString VAR66, VAR67;
      VAR41 = VAR64->FUN39(FUN40(VAR53->VAR53[VAR61]),
                                     VAR66, VAR67);
      if (FUN41(VAR41)) {
        VAR59[VAR61] = FUN42(VAR66);
        if (VAR59[VAR61]) {
          VAR60[VAR61] = FUN42(VAR67);
          if (!VAR60[VAR61]) {
            VAR68::FUN43(VAR59[VAR61]);
            continue;
          }
          ++VAR61;
        }
      }
    }
  }

  if (VAR61 == 0) {
    VAR5.FUN9(VAR6);

    return VAR12;
  }

  VAR69 FUN44(VAR48);

  VAR70 *VAR71 = VAR29;
  PRBool VAR72, VAR73;
  nsAutoString VAR74;
  do {
    
    
    PRInt32 VAR75 = -1;
    VAR41 = VAR40->FUN45(VAR17, VAR76, VAR3,
                                      FUN46(const VAR58**, VAR59.FUN37()),
                                      FUN46(const VAR58**, VAR60),
                                      VAR61, &VAR75, VAR74,
                                      &VAR73);
    if (FUN26(VAR41) || VAR73) {
      break; 
    }

    PRInt32 VAR77 = 0;
    for (VAR51 = FUN30(VAR23); !FUN31(VAR51, VAR23);
         VAR51 = FUN32(VAR51)) {
      if (VAR77 == VAR75) {
        VAR71 = FUN47(VAR51->VAR65);
        break; 
      }
      ++VAR77;
    }

    if (!VAR71) {
      VAR41 = VAR78;
      break; 
    }

    VAR79 FUN48(VAR74);

    VAR72 =
      FUN49(VAR71->VAR80,
                             FUN46(char *, VAR81.FUN37())) != VAR33;
    
  } while (VAR72);

  PRInt32 VAR82;
  for (VAR82 = 0; VAR82 < VAR61; ++VAR82) {
    VAR68::FUN43(VAR59[VAR82]);
    VAR68::FUN43(VAR60[VAR82]);
  }

  if (FUN26(VAR41)) { 
    VAR5.FUN9(VAR6);

    return VAR12;
  }

  if (VAR73) {
    VAR5.FUN9(FUN13(""));

    return VAR12;
  }

  VAR83* VAR84 = FUN50(VAR71, VAR17);
  if (!VAR84) {
    VAR5.FUN9(VAR6);

    return VAR12;
  }

  VAR85 FUN51(VAR45->FUN52());

  
  
  if (VAR86.FUN12(FUN53(""))) {
    VAR86.FUN54(FUN53(""));
  }

  VAR7<VAR87> VAR88 =
    FUN23(VAR89);
  if (VAR88) {
    VAR41 = VAR88->FUN55(VAR86.FUN37(),
                       (VAR87::VAR90 + 
                       VAR87::VAR91),
                       0);
  }

  nsXPIDLCString VAR92;
  if (VAR3.FUN56() > 0) {
    if (VAR88 && FUN41(VAR41)) {
      VAR41 = VAR88->FUN57(FUN58(VAR3).FUN37(),
                            FUN59(VAR92));
      if (FUN26(VAR41)) {
        VAR5.FUN9(VAR6);

        return VAR12;
      }
    }
    else {
      FUN60(VAR3, VAR92);
    }
  }

  VAR93 *VAR94 = FUN61(VAR95);
  if (!VAR94) {
    VAR5.FUN9(VAR6);

    return VAR12;
  }

  unsigned char VAR96[VAR97];

  SECItem VAR98;
  VAR98.VAR99 = VAR96;

  FUN62(VAR94);
  FUN63(VAR94, FUN64(const unsigned char*, VAR92.FUN37()),
              VAR92.FUN56());
  FUN65(VAR94, VAR98.VAR99, &VAR98.VAR100, VAR97);
  FUN66(VAR94);

  nsCString VAR101;
  SECStatus VAR102 = VAR103;

  VAR104 *VAR105 = FUN67(VAR71,
                                                       VAR24,
                                                       VAR29, VAR106,
                                                       &VAR98, VAR29, VAR17);
  if (VAR105) {
    VAR102 = FUN68(VAR105, VAR29);
    if (VAR102 == VAR33) {
      VAR102 = FUN69(VAR105);
      if (VAR102 == VAR33) {
        VAR102 = FUN70(VAR105, VAR107, &VAR101, VAR29, VAR29,
                              VAR17);
      }
    }

    FUN71(VAR105);
  }

  if (VAR102 != VAR33) {
    VAR5.FUN9(VAR6);

    return VAR12;
  }

  SECItem VAR108;
  VAR108.VAR99 = FUN64(unsigned char*,
                                         FUN46(char*, VAR101.FUN37()));
  VAR108.VAR100 = VAR101.FUN56();

  char *VAR109 = FUN72(VAR29, VAR29, 0, &VAR108);
  if (VAR109) {
    FUN73(VAR109, VAR5);
  }
  else {
    VAR5.FUN9(VAR6);
  }

  FUN74(VAR109);

  return VAR12;
}