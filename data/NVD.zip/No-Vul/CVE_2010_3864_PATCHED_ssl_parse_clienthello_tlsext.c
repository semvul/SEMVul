int FUN1(VAR1 *VAR2, unsigned char **VAR3, unsigned char *VAR4, int VAR5, int *VAR6) 	 
{
	unsigned short VAR7;
	unsigned short VAR8;
	unsigned short VAR9;
	unsigned char *VAR10 = *VAR3;
	int VAR11 = 0;

	VAR2->VAR12 = 0;
	VAR2->VAR13 = -1;

	if (VAR10 >= (VAR4+VAR5-2))
		goto VAR14;
	FUN2(VAR10,VAR9);

	if (VAR10 > (VAR4+VAR5-VAR9)) 
		goto VAR14;

	while (VAR10 <= (VAR4+VAR5-4))
		{
		FUN2(VAR10,VAR7);
		FUN2(VAR10,VAR8);

		if (VAR10+VAR8 > (VAR4+VAR5))
	   		goto VAR14;
#if 0
		fprintf(VAR15,"",VAR7,VAR8);
#endif
		if (VAR2->VAR16)
			VAR2->FUN3(VAR2, 0, VAR7, VAR10, VAR8,
						VAR2->VAR17);
      

		if (VAR7 == VAR18)
			{
			unsigned char *VAR19;
			int VAR20;
			int VAR21; 
		
			if (VAR8 < 2) 
				{
				*VAR6 = VAR22;
				return 0;
				}
			FUN2(VAR10,VAR21);  
			VAR8 -= 2;
			if (VAR21 > VAR8  ) 
				{
				*VAR6 = VAR22;
				return 0;
				} 

			VAR19 = VAR10;
			while (VAR21 > 3) 
				{
	 			VAR20 = *(VAR19++); 
				FUN2(VAR19,VAR9);
				VAR21 -= 3;

				if (VAR9 > VAR21) 
					{
					*VAR6 = VAR22;
					return 0;
					}
				if (VAR2->VAR12 == 0)
				switch (VAR20)
					{
				case VAR23:
					if (!VAR2->VAR24)
						{
						if(VAR2->VAR25->VAR26)
							{
							*VAR6 = VAR22;
							return 0;
							}
						if (VAR9 > VAR27)
							{
							*VAR6 = VAR28;
							return 0;
							}
						if ((VAR2->VAR25->VAR26 = FUN4(VAR9+1)) == NULL)
							{
							*VAR6 = VAR29;
							return 0;
							}
						memcpy(VAR2->VAR25->VAR26, VAR19, VAR9);
						VAR2->VAR25->VAR26[VAR9]='';
						if (strlen(VAR2->VAR25->VAR26) != VAR9) {
							FUN5(VAR2->VAR25->VAR26);
							VAR2->VAR25->VAR26 = NULL;
							*VAR6 = VAR28;
							return 0;
						}
						VAR2->VAR12 = 1; 

						}
					else 
						VAR2->VAR12 = VAR2->VAR25->VAR26
							&& strlen(VAR2->VAR25->VAR26) == VAR9 
							&& FUN6(VAR2->VAR25->VAR26, (char *)VAR19, VAR9) == 0;
					
					break;

				default:
					break;
					}
				 
				VAR21 -= VAR9;
				}
			if (VAR21 != 0) 
				{
				*VAR6 = VAR22;
				return 0;
				}

			}

#ifndef VAR30
		else if (VAR7 == VAR31 &&
	             VAR2->VAR32 != VAR33)
			{
			unsigned char *VAR19 = VAR10;
			int VAR34 = *(VAR19++);

			if (VAR34 != VAR8 - 1)
				{
				*VAR6 = VAR35;
				return 0;
				}
			if (!VAR2->VAR24)
				{
				if(VAR2->VAR25->VAR36)
					{
					*VAR6 = VAR35;
					return 0;
					}
				VAR2->VAR25->VAR37 = 0;
				if ((VAR2->VAR25->VAR36 = FUN4(VAR34)) == NULL)
					{
					*VAR6 = VAR29;
					return 0;
					}
				VAR2->VAR25->VAR37 = VAR34;
				memcpy(VAR2->VAR25->VAR36, VAR19, VAR34);
				}
#if 0
			fprintf(VAR15,"", VAR2->VAR25->VAR37);
			VAR19 = VAR2->VAR25->VAR36;
			for (VAR38 = 0; VAR38 < VAR2->VAR25->VAR37; VAR38++)
				fprintf(VAR15,"",*(VAR19++));
			fprintf(VAR15,"");
#endif
			}
		else if (VAR7 == VAR39 &&
	             VAR2->VAR32 != VAR33)
			{
			unsigned char *VAR19 = VAR10;
			int VAR40 = (*(VAR19++) << 8);
			VAR40 += (*(VAR19++));

			if (VAR40 != VAR8 - 2)
				{
				*VAR6 = VAR35;
				return 0;
				}
			if (!VAR2->VAR24)
				{
				if(VAR2->VAR25->VAR41)
					{
					*VAR6 = VAR35;
					return 0;
					}
				VAR2->VAR25->VAR42 = 0;
				if ((VAR2->VAR25->VAR41 = FUN4(VAR40)) == NULL)
					{
					*VAR6 = VAR29;
					return 0;
					}
				VAR2->VAR25->VAR42 = VAR40;
				memcpy(VAR2->VAR25->VAR41, VAR19, VAR40);
				}
#if 0
			fprintf(VAR15,"", VAR2->VAR25->VAR42);
			VAR19 = VAR2->VAR25->VAR41;
			for (VAR38 = 0; VAR38 < VAR2->VAR25->VAR42; VAR38++)
				fprintf(VAR15,"",*(VAR19++));
			fprintf(VAR15,"");
#endif
			}
#endif 
#ifdef VAR43
		else if (VAR7 == VAR43 &&
	             VAR2->VAR32 != VAR33)
			{
			unsigned char *VAR19 = VAR10;

			if (VAR8 < 2)
				{
				*VAR6 = VAR22;
				return 0;
				}
			FUN2(VAR19, VAR2->VAR44->VAR45);
			if (VAR2->VAR44->VAR45 != VAR8 - 2)
				{
				*VAR6 = VAR22;
				return 0;
				}

			if (VAR2->VAR44->VAR46 != NULL) 
				FUN5(VAR2->VAR44->VAR46);
			if (VAR2->VAR44->VAR45 == 0)
				VAR2->VAR44->VAR46 = FUN4(1); 
			else
				VAR2->VAR44->VAR46 = FUN7(VAR19, VAR2->VAR44->VAR45);
			if (VAR2->VAR44->VAR46 == NULL)
				{
				*VAR6 = VAR29;
				return 0;
				}
			}
#endif
		else if (VAR7 == VAR47)
			{
			if (VAR2->VAR48 &&
			    !VAR2->FUN8(VAR2, VAR10, VAR8, VAR2->VAR49))
				{
				*VAR6 = VAR29;
				return 0;
				}
			}
		else if (VAR7 == VAR50)
			{
			if(!FUN9(VAR2, VAR10, VAR8, VAR6))
				return 0;
			VAR11 = 1;
			}
		else if (VAR7 == VAR51 &&
		         VAR2->VAR32 != VAR33 && VAR2->VAR52->VAR53)
			{
		
			if (VAR8 < 5) 
				{
				*VAR6 = VAR22;
				return 0;
				}

			VAR2->VAR13 = *VAR10++;
			VAR8--;
			if (VAR2->VAR13 == VAR54)
				{
				const unsigned char *VAR19;
				int VAR21;
				
				FUN2(VAR10,VAR21);
				VAR8 -= 2;
				if (VAR21 > VAR8  ) 
					{
					*VAR6 = VAR22;
					return 0;
					}
				while (VAR21 > 0)
					{
					VAR55 *VAR56;
					int VAR57;
					if (VAR21 < 4)
						{
						*VAR6 = VAR22;
						return 0;
						}
					FUN2(VAR10, VAR57);
					VAR21 -= 2 + VAR57;
					if (VAR21 < 0)
						{
						*VAR6 = VAR22;
						return 0;
						}
					VAR19 = VAR10;
					VAR10 += VAR57;
					VAR56 = FUN10(NULL,
								&VAR19, VAR57);
					if (!VAR56)
						{
						*VAR6 = VAR22;
						return 0;
						}
					if (VAR10 != VAR19)
						{
						FUN11(VAR56);
						*VAR6 = VAR22;
						return 0;
						}
					if (!VAR2->VAR58
						&& !(VAR2->VAR58 =
						FUN12()))
						{
						FUN11(VAR56);
						*VAR6 = VAR59;
						return 0;
						}
					if (!FUN13(
							VAR2->VAR58, VAR56))
						{
						FUN11(VAR56);
						*VAR6 = VAR59;
						return 0;
						}
					}

				
				FUN2(VAR10,VAR21);
				VAR8 -= 2;
				if (VAR21 > VAR8) 
					{
					*VAR6 = VAR22;
					return 0;
					}
				VAR19 = VAR10;
				if (VAR21 > 0)
					{
					VAR2->VAR60 =
						FUN14(NULL,
							&VAR19, VAR21);
					if (!VAR2->VAR60
						|| (VAR10 + VAR21 != VAR19))
						{
						*VAR6 = VAR22;
						return 0;
						}
					}
				}
				
				else
					VAR2->VAR13 = -1;
			}

		
		VAR10+=VAR8;
		}
				
	*VAR3 = VAR10;

	VAR14:

	

	if (!VAR11 && VAR2->VAR61 &&
		!(VAR2->VAR62 & VAR63))
		{
		*VAR6 = VAR64;
	 	FUN15(VAR65,
				VAR66);
		return 0;
		}

	return 1;
	}