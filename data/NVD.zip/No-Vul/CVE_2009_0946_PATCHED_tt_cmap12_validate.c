FUN1( VAR1*      VAR2,                       FT_Validator  VAR3 )    
{
    VAR1*   VAR4;
    FT_ULong   VAR5;
    FT_ULong   VAR6;


    if ( VAR2 + 16 > VAR3->VAR7 )
      VAR8;

    VAR4      = VAR2 + 4;
    VAR5 = FUN2( VAR4 );

    VAR4          = VAR2 + 12;
    VAR6 = FUN2( VAR4 );

    if ( VAR5 > (VAR9)( VAR3->VAR7 - VAR2 ) ||
         VAR5 < 16 + 12 * VAR6               )
      VAR8;

    
    {
      FT_ULong  VAR10, VAR11, VAR12, VAR13, VAR14 = 0;


      for ( VAR10 = 0; VAR10 < VAR6; VAR10++ )
      {
        VAR11    = FUN2( VAR4 );
        VAR12      = FUN2( VAR4 );
        VAR13 = FUN2( VAR4 );

        if ( VAR11 > VAR12 )
          VAR15;

        if ( VAR10 > 0 && VAR11 <= VAR14 )
          VAR15;

        if ( VAR3->VAR16 >= VAR17 )
        {
          if ( VAR13 + VAR12 - VAR11 >= FUN3( VAR3 ) )
            VAR18;
        }

        VAR14 = VAR12;
      }
    }

    return VAR19;
  }