static int FUN1(struct VAR1 *VAR2, void VAR3 *VAR4)  
{
	struct VAR5 *VAR6 = FUN2(VAR2);
	if (VAR6) {
		int VAR7 = FUN3(VAR6, (void VAR3 * VAR3 *)VAR4);
		FUN4(VAR6);
		return VAR7;
	}
	if (FUN5(VAR8))
		return -VAR9;
	return -VAR10;
}