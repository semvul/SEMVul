static int FUN1(VAR1 *VAR2, int VAR3, VAR4 *VAR5)  
{
    VAR4 *VAR6;
    int VAR7;
    ulong VAR8;

    FUN2(("", VAR3));
    FUN3(&VAR2->VAR9, VAR8);
    if (VAR3 == -1)
        VAR7 = VAR10;
    else
        VAR7 = VAR3;
    VAR5->VAR11 = 0;

    if (VAR7 < 0 || VAR7 >= VAR12) {
        FUN4(&VAR2->VAR9, VAR8);
        return VAR7;
    }
    VAR6 = &VAR13[VAR7];
    if (VAR6->VAR11 != 0) {
        if (VAR7 != VAR14) {
            if (++VAR7 == VAR12)
                VAR7 = 0;
        } else {
            VAR7 = -1;
        }
        memcpy(VAR5, VAR6, sizeof(VAR4));
    }
    FUN4(&VAR2->VAR9, VAR8);
    return VAR7;
}