static void FUN1(struct VAR1 *VAR2,                             struct VAR3 *VAR4,                             u16 VAR5)  
{
	struct VAR6 *VAR7 = VAR2->VAR7;

	if (VAR5 && VAR7->VAR8)
		FUN2(&VAR2->VAR9, VAR7->VAR8,
		                 VAR5, VAR4);
	else
		FUN3(&VAR2->VAR9, VAR4);
}