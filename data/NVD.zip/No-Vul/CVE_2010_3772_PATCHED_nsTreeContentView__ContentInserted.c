void VAR1::FUN1(VAR2 *VAR3,                                    VAR4* VAR5,                                    VAR4* VAR6,                                    PRInt32 VAR7)  
{
  FUN2(VAR6, "");

  
  
  VAR8 *VAR9 = VAR6->FUN3();

  if (VAR6->FUN4(VAR10::VAR11)) {
    if (VAR9 != VAR12::VAR13 &&
        VAR9 != VAR12::VAR14)
      return;
  }
  else if (VAR6->FUN4(VAR10::VAR15)) {
    if (VAR9 != VAR12::VAR16 &&
        VAR9 != VAR12::VAR17 &&
        VAR9 != VAR12::VAR18 &&
        VAR9 != VAR12::VAR19 &&
        VAR9 != VAR12::VAR20)
      return;
    
    if (!VAR5->FUN4(VAR10::VAR15))
      return;
  }
  else {
    return;
  }

  
  

  for (VAR4* VAR21 = VAR5; VAR21 != VAR22; VAR21 = VAR21->FUN5()) {
    if (!VAR21)
      return; 
    VAR8 *VAR23 = VAR21->FUN3();
    if ((VAR21->FUN4(VAR10::VAR15) && VAR23 == VAR12::VAR24) ||
        (VAR21->FUN4(VAR10::VAR11) && VAR23 == VAR12::VAR25))
      return; 
  }

  if (VAR9 == VAR12::VAR18) {
    PRInt32 VAR26 = FUN6(VAR5);
    if (VAR26 >= 0) {
      VAR27* VAR28 = VAR29[VAR26];
      VAR28->FUN7(VAR30);
      if (VAR31)
        VAR31->FUN8(VAR26);
      if (VAR28->FUN9() && VAR28->FUN10()) {
        PRInt32 VAR32 = FUN11(VAR26);
        if (VAR31)
          VAR31->FUN12(VAR26 + 1, VAR32);
      }
    }
  }
  else if (VAR9 == VAR12::VAR16 ||
           VAR9 == VAR12::VAR17) {
    FUN13(VAR5, VAR6);
  }
  else if (VAR9 == VAR12::VAR19) {
    PRInt32 VAR26 = FUN6(VAR5);
    if (VAR26 >= 0 && VAR31)
      VAR31->FUN8(VAR26);
  }
  else if (VAR9 == VAR12::VAR20) {
    VAR33<VAR4> VAR34 = VAR5->FUN5();
    if (VAR34) {
      PRInt32 VAR26 = FUN6(VAR34);
      if (VAR26 >= 0 && VAR31)
        VAR31->FUN8(VAR26);
    }
  }
  else if (VAR9 == VAR12::VAR14) {
    FUN13(VAR5, VAR6);
  }
  else if (VAR9 == VAR12::VAR13) {
    PRInt32 VAR35 = FUN6(VAR5);

    if (VAR35 >= 0) {
      PRInt32 VAR26 = 0;
      FUN14(VAR5, VAR6, &VAR26);
      PRInt32 VAR32 = FUN15(VAR35, VAR26, VAR6);
      if (VAR31)
        VAR31->FUN12(VAR35 + VAR26 + 1, VAR32);
    }
  }
}