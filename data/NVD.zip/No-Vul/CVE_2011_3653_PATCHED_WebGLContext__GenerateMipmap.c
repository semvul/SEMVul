NS_IMETHODIMP VAR1::FUN1(WebGLenum VAR2)  
{
    if (!FUN2(VAR2, ""))
        return VAR3;

    VAR4 *VAR5 = FUN3(VAR2);

    if (!VAR5)
        return FUN4("");

    if (!VAR5->FUN5()) {
        return FUN4("");
    }

    if (!VAR5->FUN6()) {
        return FUN4("");
    }

    VAR5->FUN7();

    FUN8();

#ifdef VAR6
    
    
    
    
    
    
    if (VAR5->FUN9()) {
        VAR7->FUN10(VAR2);
    } else {
        
        
        
        VAR7->FUN11(VAR2, VAR8, VAR9);
        VAR7->FUN10(VAR2);
        VAR7->FUN11(VAR2, VAR8, VAR5->FUN12());
    }
#else
    VAR7->FUN10(VAR2);
#endif
    
    return VAR3;
}