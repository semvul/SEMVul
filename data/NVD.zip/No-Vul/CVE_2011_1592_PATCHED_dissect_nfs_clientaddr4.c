static int FUN1(VAR1 *VAR2, int VAR3, VAR4 *VAR5)  
{
	char *VAR6 = NULL;
	char *VAR7 = NULL;
	guint VAR8, VAR9, VAR10, VAR11, VAR12, VAR13, VAR14, VAR15, VAR16, VAR17;
	guint16 VAR18;
	int VAR19;

	VAR3 = FUN2(VAR2, VAR5, VAR20, VAR3, &VAR7);
	VAR19 = VAR3;
	VAR3 = FUN2(VAR2, VAR5, VAR21, VAR3, &VAR6);

	if(strlen(VAR7) == 3 && FUN3(VAR7,"",3) == 0) {
		if (VAR6 && sscanf(VAR6, "",
						   &VAR8, &VAR9, &VAR10, &VAR11, &VAR12, &VAR13) == 6) {
			
			VAR18 = (VAR12<<8) | VAR13;
		     FUN4(VAR5, VAR2, VAR19, VAR3,
				"",
				VAR8, VAR9, VAR10, VAR11, VAR7, VAR18);
		} else if (VAR6 && sscanf(VAR6, "",
						   &VAR8, &VAR9) == 2) {
		     
			VAR18 = (VAR8<<8) | VAR9;
			FUN4(VAR5, VAR2, VAR19, VAR3-VAR19, 
				"", VAR7, VAR18);
		} else if (VAR6 && sscanf(VAR6,
						"",
						&VAR8, &VAR9, &VAR10, &VAR11, &VAR12, &VAR13, &VAR14, &VAR15, &VAR16, &VAR17) == 10) {
			VAR18 = (VAR16<<8) | VAR17;
			FUN4(VAR5, VAR2, VAR19, VAR3,
				"",
				VAR8, VAR9, VAR10, VAR11, VAR12, VAR13, VAR14, VAR15, VAR7, VAR18);
		} else {
			FUN4(VAR5, VAR2, VAR19, VAR3-VAR19, "");
		}
	}
	return VAR3;
}