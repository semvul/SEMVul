static void * FUN1(struct VAR1 *VAR1, struct VAR2 *VAR3)  
{
	VAR4 *VAR5 = FUN2(VAR1->VAR6);
	char *VAR7;

	if (VAR5->VAR8 & VAR9) {
		struct VAR10 *VAR11 = VAR1->VAR12;
		VAR13 *VAR14 = &VAR5->VAR15.VAR16;
		befs_off_t VAR17 = VAR14->VAR18;

		if (VAR17 == 0) {
			FUN3(VAR11, "");
			VAR7 = FUN4(-VAR19);
		} else {
			FUN5(VAR11, "");

			VAR7 = FUN6(VAR17, VAR20);
			if (!VAR7) {
				VAR7 = FUN4(-VAR21);
			} else if (FUN7(VAR11, VAR14, VAR7, VAR17) != VAR17) {
				FUN8(VAR7);
				FUN3(VAR11, "");
				VAR7 = FUN4(-VAR19);
			} else {
				VAR7[VAR17 - 1] = '';
			}
		}
	} else {
		VAR7 = VAR5->VAR15.VAR22;
	}

	FUN9(VAR3, VAR7);
	return NULL;
}