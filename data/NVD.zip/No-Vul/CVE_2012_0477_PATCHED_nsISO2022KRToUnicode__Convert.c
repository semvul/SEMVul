NS_IMETHODIMP VAR1::FUN1(const char * VAR2, VAR3 * VAR4, VAR5 * VAR6, VAR3 * VAR7)  
{
  const unsigned char* VAR8 = (unsigned char*)VAR2 + *VAR4;
  const unsigned char* VAR9 =(unsigned char*) VAR2;
  VAR5* VAR10 = VAR6 + *VAR7;
  VAR5* VAR11 = VAR6;
  while((VAR9 < VAR8))
  {
    
    if ( *VAR9 == 0x0a || *VAR9 == 0x0d )
      VAR12 = VAR13;

    switch(VAR12)
    {
      case VAR13:
        if(0x1b == *VAR9) {
          VAR14 = VAR15;
          VAR12 = VAR16;
          break;
        }
        VAR12 = VAR15;
        

      case VAR15:
        if(0x0e == *VAR9) { 
          VAR12 = VAR17;
          VAR18 = 0;
        } 
        else if(*VAR9 & 0x80) {
          if (FUN2(VAR11, VAR10, 1))
            goto VAR19;
          *VAR11++ = 0xFFFD;
        } 
        else {
          if (FUN2(VAR11, VAR10, 1))
            goto VAR19;
          *VAR11++ = (VAR5) *VAR9;
        }
        break;
          
      case VAR16:
        if('' == *VAR9) {
          VAR12 = VAR20;
        } 
        else  {
          if (FUN2(VAR11, VAR10, 2))
            goto VAR19;
          *VAR11++ = (VAR5) 0x1b;
          *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;
          VAR12 =  VAR14;
        }
        break;

      case VAR20: 
        if('' == *VAR9) {
          VAR12 = VAR21;
        } 
        else  {
          if (FUN2(VAR11, VAR10, 3))
            goto VAR19;
          *VAR11++ = (VAR5) 0x1b;
          *VAR11++ = (VAR5) '';
          *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;
          VAR12 = VAR14;
        }
        break;

      case VAR21: 
        VAR12 = VAR14;
        if('' == *VAR9) {
          VAR12 = VAR15;
          VAR18 = 0;
        } 
        else  {
          if (FUN2(VAR11, VAR10, 4))
            goto VAR19;
          *VAR11++ = (VAR5) 0x1b;
          *VAR11++ = (VAR5) '';
          *VAR11++ = (VAR5) '';
          *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;
          VAR12 = VAR14;
        }
        break;

      case VAR17:
        if (0x20 < (VAR22) *VAR9  && (VAR22) *VAR9 < 0x7f) {
          VAR23 = (VAR22) *VAR9;
          VAR12 = VAR24;
        } 
        else if (0x0f == *VAR9) { 
          VAR12 = VAR15;
          if (VAR18 == 0) {
            if (FUN2(VAR11, VAR10, 1))
              goto VAR19;
            *VAR11++ = 0xFFFD;
          }
          VAR18 = 0;
        } 
        else if ((VAR22) *VAR9 == 0x20 || (VAR22) *VAR9 == 0x09) {
          
          if (FUN2(VAR11, VAR10, 1))
            goto VAR19;
          VAR12 = VAR17;
          *VAR11++ = (VAR5) *VAR9;
          ++VAR18;
        } 
        else {         
          if (FUN2(VAR11, VAR10, 1))
            goto VAR19;
          *VAR11++ = 0xFFFD;
        }
        break;

      case VAR24:
        if ( 0x20 < (VAR22) *VAR9 && (VAR22) *VAR9 < 0x7f  ) {
          if (!VAR25) {
            
            nsresult VAR26;
            VAR27<VAR28> VAR29 = 
                  FUN3(VAR30, &VAR26);
            if (FUN4(VAR26)) {
              VAR26 = VAR29->FUN5("", &VAR25);
            }
          }

          if (!VAR25) {
           *VAR11++ = 0xFFFD;
          } 
          else {              
            if (FUN2(VAR11, VAR10, 1))
              goto VAR19;
            unsigned char VAR31[2];
            PRUnichar VAR32;
            PRInt32 VAR33 = 2, VAR34 = 1;
            
            
            
            VAR31[0] = VAR23 | 0x80;
            VAR31[1] = *VAR9 | 0x80;
            
            VAR25->FUN1((const char *)VAR31, &VAR33, &VAR32, &VAR34);
            *VAR11++ = VAR32;
            ++VAR18;
          }
          VAR12 = VAR17;
        } 
        else {        
          if ( 0x0f == *VAR9 ) {   
            VAR12 = VAR15;
          } 
          else {
            VAR12 = VAR17;
          }
          if (FUN2(VAR11, VAR10, 1))
            goto VAR19;
          *VAR11++ = 0xFFFD;
        }
        break;

      case VAR35:
        VAR12 = VAR14;
        if (FUN2(VAR11, VAR10, 1))
          goto VAR19;
        *VAR11++ = 0xFFFD;
        break;

    } 
    VAR9++;
  }
  *VAR7 = VAR11 - VAR6;
  return VAR36;

VAR19:
  *VAR7 = VAR11-VAR6;
  *VAR4 = VAR9-(unsigned char*)VAR2;
  return VAR37;
}