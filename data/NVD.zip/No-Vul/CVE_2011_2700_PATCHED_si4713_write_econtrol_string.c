static int FUN1(struct VAR1 *VAR2, 				struct VAR3 *VAR4)  
{
	struct v4l2_queryctrl VAR5;
	int VAR6;
	s32 VAR7 = 0;

	VAR5.VAR8 = VAR4->VAR8;
	VAR7 = FUN2(&VAR2->VAR9, &VAR5);
	if (VAR7 < 0)
		goto VAR10;

	switch (VAR4->VAR8) {
	case VAR11: {
		char VAR12[VAR13 + 1];

		VAR6 = VAR4->VAR14 - 1;
		if (VAR6 < 0 || VAR6 > VAR13) {
			VAR7 = -VAR15;
			goto VAR10;
		}
		VAR7 = FUN3(VAR12, VAR4->VAR16, VAR6);
		if (VAR7 < 0)
			goto VAR10;
		VAR12[VAR6] = '';

		if (strlen(VAR12) % VAR5.VAR17) {
			VAR7 = -VAR15;
			goto VAR10;
		}

		VAR7 = FUN4(VAR2, VAR12);
	}
		break;

	case VAR18: {
		char VAR19[VAR20 + 1];

		VAR6 = VAR4->VAR14 - 1;
		if (VAR6 < 0 || VAR6 > VAR20) {
			VAR7 = -VAR15;
			goto VAR10;
		}
		VAR7 = FUN3(VAR19, VAR4->VAR16, VAR6);
		if (VAR7 < 0)
			goto VAR10;
		VAR19[VAR6] = '';

		if (strlen(VAR19) % VAR5.VAR17) {
			VAR7 = -VAR15;
			goto VAR10;
		}

		VAR7 = FUN5(VAR2, VAR19);
	}
		break;

	default:
		VAR7 = -VAR21;
		break;
	};

VAR10:
	return VAR7;
}