struct VAR1 *FUN1(struct VAR2 *VAR3, 					size_t VAR4, u32 VAR5)  
{
	int VAR6;
	struct VAR1 *new;
	size_t VAR7;
	int VAR8;

	if (!VAR3)
		return NULL;

	VAR8 = FUN2(&VAR3->VAR9);
	if ((VAR8 + VAR4 > VAR3->VAR10) ||
	    (VAR8 + VAR4 < VAR4))
		return NULL;

	if (VAR5 >= VAR11) {
		new = FUN3(VAR4, VAR5);
		if (new)
			new->VAR3 = VAR3;
		return new;
	}

	if (VAR5 != 0) {
		new = VAR3->VAR12->FUN4(VAR4, VAR5);
		if (new)
			new->VAR3 = VAR3;
		return new;
	}

	VAR6 = (VAR4 + VAR13 - 1) / VAR13;

	new = FUN5(VAR6);

	if (new == NULL)
		return NULL;

	if (VAR3->VAR12->VAR14) {
		if (VAR3->VAR12->FUN6(VAR3, new, VAR4)) {
			FUN7(new);
			return NULL;
		}
		new->VAR3 = VAR3;
		return new;
	}

	for (VAR7 = 0; VAR7 < VAR4; VAR7++) {
		struct VAR15 *VAR15 = VAR3->VAR12->FUN8(VAR3);

		if (VAR15 == NULL) {
			FUN7(new);
			return NULL;
		}
		new->VAR16[VAR7] = VAR15;
		new->VAR4++;
	}
	new->VAR3 = VAR3;

	return new;
}