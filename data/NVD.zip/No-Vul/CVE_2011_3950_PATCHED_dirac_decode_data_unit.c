static int FUN1(VAR1 *VAR2, const VAR3 *VAR4, int VAR5)  
{
    VAR6 *VAR7   = VAR2->VAR8;
    VAR9 *VAR10   = NULL;
    int VAR11, VAR12 = VAR4[4];
    unsigned VAR13;

    if (VAR5 < VAR14)
        return -1;

    FUN2(&VAR7->VAR15, &VAR4[13], 8*(VAR5 - VAR14));

    if (VAR12 == VAR16) {
        if (VAR7->VAR17)
            return 0;

        
        if (FUN3(VAR2, &VAR7->VAR15, &VAR7->VAR18))
            return -1;

        FUN4(VAR2->VAR19, &VAR7->VAR20, &VAR7->VAR21);

        if (FUN5(VAR7))
            return -1;

        VAR7->VAR17 = 1;
    } else if (VAR12 == VAR22) { 
        FUN6(VAR7);
        VAR7->VAR17 = 0;
    } else if (VAR12 == VAR23) {
        if (VAR4[13] == 1) {     
            int VAR24[3];
            
            if (sscanf(VAR4+14, "", VAR24, VAR24+1, VAR24+2) == 3)
                if (VAR24[0] == 1 && VAR24[1] == 0 && VAR24[2] <= 7)
                    VAR7->VAR25 = 1;
        }
    } else if (VAR12 & 0x8) {  
        if (!VAR7->VAR17) {
            FUN7(VAR2, VAR26, "");
            return -1;
        }

        
        for (VAR11 = 0; VAR11 < VAR27; VAR11++)
            if (VAR7->VAR28[VAR11].VAR29.VAR30[0] == NULL)
                VAR10 = &VAR7->VAR28[VAR11];
        if (!VAR10) {
            FUN7(VAR2, VAR31, "");
            return -1;
        }

        FUN8(&VAR10->VAR29);

        
        VAR13            =  VAR12 & 0x03;                   
        if (VAR13 > 2) {
            FUN7(VAR2, VAR31, "");
            return -1;
        }
        VAR7->VAR32    = VAR13;
        VAR7->VAR33    = (VAR12 & 0x48) == 0x08;          
        VAR7->VAR34   = (VAR12 & 0x88) == 0x88;          
        VAR10->VAR29.VAR35 = (VAR12 & 0x0C) == 0x0C;  
        VAR10->VAR29.VAR36 = VAR7->VAR32 == 0;             
        VAR10->VAR29.VAR37 = VAR7->VAR32 + 1;              

        if (VAR2->FUN9(VAR2, &VAR10->VAR29) < 0) {
            FUN7(VAR2, VAR31, "");
            return -1;
        }
        VAR7->VAR38 = VAR10;
        VAR7->VAR39[0].VAR40 = VAR10->VAR29.VAR41[0];
        VAR7->VAR39[1].VAR40 = VAR10->VAR29.VAR41[1];
        VAR7->VAR39[2].VAR40 = VAR10->VAR29.VAR41[2];

        
        if (FUN10(VAR7))
            return -1;

        
        if (FUN11(VAR7))
            return -1;
    }
    return 0;
}