int FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4, const int VAR5)  
{
	int VAR6 = VAR7;

	if (FUN2(VAR2, VAR4))
		goto VAR8;

	VAR4->VAR9 = NULL;

	if (FUN3(VAR2, VAR4)) {
		FUN4(&VAR2->VAR10);
		goto VAR8;
	}
	if (VAR5)
		FUN5(VAR2);
	else
		FUN6(VAR2);
	if (!FUN7(VAR2)) {
		
		FUN8(&VAR2->VAR11.VAR12, 0, 1, VAR13);

		VAR6 = FUN9(VAR2, VAR4);

		FUN10(&VAR2->VAR11.VAR12, 1, VAR13);
	} else if (FUN11(VAR2, VAR4)) {
		FUN12(VAR2);
		FUN4(&VAR2->VAR10);
		goto VAR8;
	}

	FUN12(VAR2);
VAR14:
	FUN13(VAR2);
	return VAR6;
VAR8:
	FUN14(VAR4);
	goto VAR14;
}