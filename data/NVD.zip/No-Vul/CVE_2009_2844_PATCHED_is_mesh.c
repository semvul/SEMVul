static bool FUN1(struct VAR1 *VAR2, 		    const VAR3 *VAR4, size_t VAR5, 		    const VAR3 *VAR6)  
{
	const VAR3 *VAR7;

	if (!FUN2(VAR2->VAR8))
		return false;

	VAR7 = FUN3(VAR9,
		     VAR2->VAR10,
		     VAR2->VAR11);
	if (!VAR7)
		return false;
	if (VAR7[1] != VAR5)
		return false;
	if (memcmp(VAR7 + 2, VAR4, VAR5))
		return false;

	VAR7 = FUN3(VAR12,
		     VAR2->VAR10,
		     VAR2->VAR11);
	if (!VAR7)
		return false;
	if (VAR7[1] != VAR13)
		return false;

	
	return memcmp(VAR7 + 2, VAR6, VAR13 - 2) == 0;
}