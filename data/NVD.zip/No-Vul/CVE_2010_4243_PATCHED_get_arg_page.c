static struct VAR1 *FUN1(struct VAR2 *VAR3, unsigned long VAR4, 		int write)  
{
	struct VAR1 *VAR1;
	int VAR5;

#ifdef VAR6
	if (write) {
		VAR5 = FUN2(VAR3->VAR7, VAR4);
		if (VAR5 < 0)
			return NULL;
	}
#endif
	VAR5 = FUN3(VAR8, VAR3->VAR9, VAR4,
			1, write, 1, &VAR1, NULL);
	if (VAR5 <= 0)
		return NULL;

	if (write) {
		unsigned long VAR10 = VAR3->VAR7->VAR11 - VAR3->VAR7->VAR12;
		struct VAR13 *VAR14;

		FUN4(VAR3, VAR10 / VAR15);

		
		if (VAR10 <= VAR16)
			return VAR1;

		
		VAR14 = VAR8->signal->VAR14;
		if (VAR10 > FUN5(VAR14[VAR17].VAR18) / 4) {
			FUN6(VAR1);
			return NULL;
		}
	}

	return VAR1;
}