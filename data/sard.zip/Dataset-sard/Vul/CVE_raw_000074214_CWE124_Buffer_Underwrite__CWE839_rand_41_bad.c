void CWE124_Buffer_Underwrite__CWE839_rand_41_bad()
{
    int data;
    /* Initialize data */
    data = -1;
    /* POTENTIAL FLAW: Set data to a random value */
    data = RAND32();
    badSink(data);
}
