static int FUN1(struct VAR1 *VAR2, int VAR3, 		int VAR4, char VAR5 *VAR6, unsigned int VAR7)  
{
	struct VAR8 *VAR9 = FUN2(VAR2);
	struct VAR10 *VAR11 = FUN3(VAR2);
	int VAR12;
	int VAR13 = 0;

	
	switch (VAR4) {
	case VAR14: {
		char VAR15[VAR16];

		if (VAR7 < 1)
			return -VAR17;

		VAR12 = FUN4(VAR15, VAR6,
					FUN5(long, VAR16-1, VAR7));
		if (VAR12 < 0)
			return -VAR18;
		VAR15[VAR12] = 0;

		FUN6(VAR2);
		VAR13 = FUN7(VAR2, VAR15);
		FUN8(VAR2);
		return VAR13;
	}
	case VAR19: {
		struct tcp_cookie_transactions VAR20;
		struct VAR21 *VAR22 = NULL;

		if (sizeof(VAR20) > VAR7)
			return -VAR17;
		if (FUN9(&VAR20, VAR6, sizeof(VAR20)))
			return -VAR18;

		if (VAR20.VAR23 > sizeof(VAR20.VAR24) ||
		    VAR20.VAR25 > VAR26)
			return -VAR17;

		if (VAR20.VAR27 == 0) {
			
		} else if ((0x1 & VAR20.VAR27) ||
			   VAR20.VAR27 > VAR28 ||
			   VAR20.VAR27 < VAR29) {
			return -VAR17;
		}

		if (VAR30 & VAR20.VAR31) {
			
			FUN6(VAR2);
			if (VAR9->VAR32 != NULL) {
				FUN10(&VAR9->VAR32->VAR33,
					 VAR34);
				VAR9->VAR32 = NULL;
			}
			VAR9->VAR35.VAR36 = 0; 
			VAR9->VAR35.VAR37 = 1; 
			FUN8(VAR2);
			return VAR13;
		}

		
		if (VAR20.VAR23 > 0 ||
		    (VAR9->VAR32 == NULL &&
		     (VAR38 > 0 ||
		      VAR20.VAR27 > 0 ||
		      VAR20.VAR25 > 0))) {
			VAR22 = FUN11(sizeof(*VAR22) + VAR20.VAR23,
				      VAR39);
			if (VAR22 == NULL)
				return -VAR40;
		}
		FUN6(VAR2);
		VAR9->VAR35.VAR36 =
			(VAR41 & VAR20.VAR31);
		VAR9->VAR35.VAR37 = 0; 

		if (VAR9->VAR32 != NULL) {
			if (VAR22 != NULL) {
				
				FUN10(&VAR9->VAR32->VAR33,
					 VAR34);
				FUN12(&VAR22->VAR33);
				VAR9->VAR32 = VAR22;
			} else {
				VAR22 = VAR9->VAR32;
			}
		}
		if (VAR22 != NULL) {
			VAR22->VAR42 = VAR20.VAR27;

			if (VAR20.VAR23 > 0) {
				memcpy(VAR22->VAR43, VAR20.VAR24,
				       VAR20.VAR23);
				VAR22->VAR44 = VAR20.VAR23;
				VAR22->VAR45 = 1; 
			} else {
				
				VAR22->VAR44 = VAR20.VAR25;
				VAR22->VAR45 = 0; 
			}
		}
		FUN8(VAR2);
		return VAR13;
	}
	default:
		
		break;
	}

	if (VAR7 < sizeof(int))
		return -VAR17;

	if (FUN13(VAR12, (int VAR5 *)VAR6))
		return -VAR18;

	FUN6(VAR2);

	switch (VAR4) {
	case VAR46:
		
		if (VAR12 < 64 || VAR12 > VAR47) {
			VAR13 = -VAR17;
			break;
		}
		VAR9->VAR35.VAR48 = VAR12;
		break;

	case VAR49:
		if (VAR12) {
			
			VAR9->VAR50 |= VAR51|VAR52;
			FUN14(VAR2);
		} else {
			VAR9->VAR50 &= ~VAR51;
		}
		break;

	case VAR53:
		if (VAR12 < 0 || VAR12 > 1)
			VAR13 = -VAR17;
		else
			VAR9->VAR54 = VAR12;
		break;

	case VAR55:
		if (VAR12 < 0 || VAR12 > 1)
			VAR13 = -VAR17;
		else
			VAR9->VAR56 = VAR12;
		break;

	case VAR57:
		
		if (VAR12) {
			VAR9->VAR50 |= VAR58;
		} else {
			VAR9->VAR50 &= ~VAR58;
			if (VAR9->VAR50&VAR51)
				VAR9->VAR50 |= VAR52;
			FUN14(VAR2);
		}
		break;

	case VAR59:
		if (VAR12 < 1 || VAR12 > VAR60)
			VAR13 = -VAR17;
		else {
			VAR9->VAR61 = VAR12 * VAR62;
			if (FUN15(VAR2, VAR63) &&
			    !((1 << VAR2->VAR64) &
			      (VAR65 | VAR66))) {
				u32 VAR67 = FUN16(VAR9);
				if (VAR9->VAR61 > VAR67)
					VAR67 = VAR9->VAR61 - VAR67;
				else
					VAR67 = 0;
				FUN17(VAR2, VAR67);
			}
		}
		break;
	case VAR68:
		if (VAR12 < 1 || VAR12 > VAR69)
			VAR13 = -VAR17;
		else
			VAR9->VAR70 = VAR12 * VAR62;
		break;
	case VAR71:
		if (VAR12 < 1 || VAR12 > VAR72)
			VAR13 = -VAR17;
		else
			VAR9->VAR73 = VAR12;
		break;
	case VAR74:
		if (VAR12 < 1 || VAR12 > VAR75)
			VAR13 = -VAR17;
		else
			VAR11->VAR76 = VAR12;
		break;

	case VAR77:
		if (VAR12 < 0)
			VAR9->VAR78 = -1;
		else if (VAR12 > VAR79 / VAR62)
			VAR9->VAR78 = 0;
		else
			VAR9->VAR78 = VAR12 * VAR62;
		break;

	case VAR80:
		
		VAR11->VAR81.VAR82 =
			FUN18(VAR12, VAR83 / VAR62,
					VAR84 / VAR62);
		break;

	case VAR85:
		if (!VAR12) {
			if (VAR2->VAR64 != VAR86) {
				VAR13 = -VAR17;
				break;
			}
			VAR9->VAR87 = 0;
		} else
			VAR9->VAR87 = VAR12 < VAR88 / 2 ?
						VAR88 / 2 : VAR12;
		break;

	case VAR89:
		if (!VAR12) {
			VAR11->VAR90.VAR91 = 1;
		} else {
			VAR11->VAR90.VAR91 = 0;
			if ((1 << VAR2->VAR64) &
			    (VAR92 | VAR93) &&
			    FUN19(VAR2)) {
				VAR11->VAR90.VAR94 |= VAR95;
				FUN20(VAR2, 1);
				if (!(VAR12 & 1))
					VAR11->VAR90.VAR91 = 1;
			}
		}
		break;

#ifdef VAR96
	case VAR97:
		
		VAR13 = VAR9->VAR98->FUN21(VAR2, VAR6, VAR7);
		break;
#endif

	default:
		VAR13 = -VAR99;
		break;
	}

	FUN8(VAR2);
	return VAR13;
}