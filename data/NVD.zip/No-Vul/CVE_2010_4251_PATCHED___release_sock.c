static void FUN1(struct VAR1 *VAR2)  
{
	struct VAR3 *VAR4 = VAR2->VAR5.VAR6;

	do {
		VAR2->VAR5.VAR6 = VAR2->VAR5.VAR7 = NULL;
		FUN2(VAR2);

		do {
			struct VAR3 *VAR8 = VAR4->VAR8;

			VAR4->VAR8 = NULL;
			FUN3(VAR2, VAR4);

			
			FUN4();

			VAR4 = VAR8;
		} while (VAR4 != NULL);

		FUN5(VAR2);
	} while ((VAR4 = VAR2->VAR5.VAR6) != NULL);

	
	VAR2->VAR5.VAR9 = 0;
}