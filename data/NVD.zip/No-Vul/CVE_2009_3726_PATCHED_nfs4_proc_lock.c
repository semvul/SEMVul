static int FUN1(struct VAR1 *VAR2, int VAR3, struct VAR4 *VAR5)  
{
	struct VAR6 *VAR7;
	struct VAR8 *VAR9;
	unsigned long VAR10 = VAR11;
	int VAR12;

	
	VAR7 = FUN2(VAR2);
	VAR9 = VAR7->VAR9;

	if (VAR5->VAR13 < 0 || VAR5->VAR14 < 0)
		return -VAR15;

	if (FUN3(VAR3)) {
		if (VAR9 != NULL)
			return FUN4(VAR9, VAR16, VAR5);
		return 0;
	}

	if (!(FUN5(VAR3) || FUN6(VAR3)))
		return -VAR15;

	if (VAR5->VAR17 == VAR18) {
		if (VAR9 != NULL)
			return FUN7(VAR9, VAR3, VAR5);
		return 0;
	}

	if (VAR9 == NULL)
		return -VAR19;
	do {
		VAR12 = FUN8(VAR9, VAR3, VAR5);
		if ((VAR12 != -VAR20) || FUN5(VAR3))
			break;
		VAR10 = FUN9(VAR10);
		VAR12 = -VAR21;
		if (FUN10())
			break;
	} while(VAR12 < 0);
	return VAR12;
}