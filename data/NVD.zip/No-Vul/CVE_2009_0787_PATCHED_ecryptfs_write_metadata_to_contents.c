static int FUN1(struct VAR1 *VAR2, 				    char *VAR3, size_t VAR4)  
{
	int VAR5;

	VAR5 = FUN2(VAR2->VAR6, VAR3,
				  0, VAR4);
	if (VAR5)
		FUN3(VAR7 ""
		       "", VAR8,
		       VAR5);
	return VAR5;
}