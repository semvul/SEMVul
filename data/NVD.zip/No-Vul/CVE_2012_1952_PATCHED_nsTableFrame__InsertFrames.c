NS_IMETHODIMP VAR1::FUN1(ChildListID     VAR2,                            VAR3*       VAR4,                            VAR5&    VAR6)  
{
  
  
  
  
  

  FUN2(!VAR4 || VAR4->FUN3() == this,
               "");

  if ((VAR4 && !VAR4->FUN4()) ||
      (!VAR4 && FUN5(VAR2).FUN6())) {
    
    return FUN7(VAR2, VAR6);
  }

  
  
  ChildListInsertions VAR7[2]; 
  const VAR8* VAR9 = VAR6.FUN8()->FUN9();
  VAR5::VAR10 FUN10(VAR6);
  for (; !VAR6.FUN6(); VAR11.FUN11()) {
    VAR3* VAR12 = VAR11.FUN12();
    if (!VAR12 || VAR12->FUN9()->VAR13 != VAR9->VAR13) {
      nsFrameList VAR14 = VAR6.FUN13(VAR11);
      if (VAR9->VAR13 == VAR15) {
        VAR7[0].VAR16 = VAR17;
        VAR7[0].VAR18.FUN7(VAR19, VAR14);
      } else {
        VAR7[1].VAR16 = VAR20;
        VAR7[1].VAR18.FUN7(VAR19, VAR14);
      }
      if (!VAR12) {
        break;
      }
      VAR9 = VAR12->FUN9();
    }
  }
  for (PRUint32 VAR21 = 0; VAR21 < FUN14(VAR7); ++VAR21) {
    
    
    
    if (!VAR7[VAR21].VAR18.FUN6()) {
      FUN15(VAR7[VAR21].VAR16, VAR4,
                             VAR7[VAR21].VAR18);
    }
  }
  return VAR22;
}