static int FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4, 			 struct VAR5 *VAR6, 			 struct VAR7 *VAR8)  
{
	struct VAR9 *VAR10 = FUN2(VAR4);
	VAR11 *VAR12 = VAR2->VAR13;
	ssize_t VAR14;
	loff_t VAR15, VAR16;
	char VAR17 *VAR18;
	int VAR19, VAR20;
	int VAR21;

	VAR18 = (char VAR17 *) (VAR22) VAR6->VAR23;
	VAR14 = VAR6->VAR24;


	FUN3(&VAR2->VAR25);
	VAR21 = FUN4(VAR4, 0);
	if (VAR21) {
		FUN5(&VAR2->VAR25);
		return VAR21;
	}
	VAR21 = FUN6(VAR4, 1);
	if (VAR21)
		goto VAR26;

	VAR10 = FUN2(VAR4);
	VAR15 = VAR10->VAR27 + VAR6->VAR15;

	while (VAR14 > 0) {
		
		VAR16 = (VAR15 & ~(VAR28-1));
		VAR19 = VAR15 & (VAR28-1);
		VAR20 = VAR14;
		if ((VAR19 + VAR14) > VAR28)
			VAR20 = VAR28 - VAR19;

		VAR21 = FUN7 (VAR12->VAR29.VAR30, VAR16,
				       VAR19, VAR18, VAR20);

		
		if (VAR21)
			goto VAR26;

		VAR14 -= VAR20;
		VAR18 += VAR20;
		VAR15 += VAR20;
	}

VAR26:
	FUN8(VAR4);
	FUN5(&VAR2->VAR25);

	return VAR21;
}