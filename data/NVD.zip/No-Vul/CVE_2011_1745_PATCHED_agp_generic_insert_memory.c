int FUN1(struct VAR1 * VAR2, off_t VAR3, int VAR4)  
{
	int VAR5;
	size_t VAR6;
	off_t VAR7;
	void *VAR8;
	struct VAR9 *VAR10;
	int VAR11;

	VAR10 = VAR2->VAR10;
	if (!VAR10)
		return -VAR12;

	if (VAR2->VAR13 == 0)
		return 0;

	VAR8 = VAR10->VAR14;

	switch (VAR10->VAR15->VAR16) {
	case VAR17:
		VAR5 = FUN2(VAR8)->VAR5;
		break;
	case VAR18:
		VAR5 = FUN3(VAR8)->VAR5;
		break;
	case VAR19:
		VAR5 = FUN4(VAR8)->VAR5;
		break;
	case VAR20:
		VAR5 = FUN5(VAR8)->VAR5;
		break;
	case VAR21:
		
		return -VAR12;
		break;
	default:
		VAR5 = 0;
		break;
	}

	VAR5 -= VAR22/VAR23;
	if (VAR5 < 0) VAR5 = 0;

	if (VAR4 != VAR2->VAR4)
		return -VAR12;

	VAR11 = VAR10->VAR15->FUN6(VAR10, VAR4);
	if (VAR11 != 0) {
		
		return -VAR12;
	}

	if (((VAR3 + VAR2->VAR13) > VAR5) ||
	    ((VAR3 + VAR2->VAR13) < VAR3))
		return -VAR12;

	VAR7 = VAR3;

	while (VAR7 < (VAR3 + VAR2->VAR13)) {
		if (!FUN7(VAR10, FUN8(VAR10->VAR24+VAR7)))
			return -VAR25;
		VAR7++;
	}

	if (!VAR2->VAR26) {
		VAR10->VAR15->FUN9();
		VAR2->VAR26 = true;
	}

	for (VAR6 = 0, VAR7 = VAR3; VAR6 < VAR2->VAR13; VAR6++, VAR7++) {
		FUN10(VAR10->VAR15->FUN11(VAR10,
						   FUN12(VAR2->VAR27[VAR6]),
						   VAR11),
		       VAR10->VAR24+VAR7);
	}
	FUN8(VAR10->VAR24+VAR7-1);	

	VAR10->VAR15->FUN13(VAR2);
	return 0;
}