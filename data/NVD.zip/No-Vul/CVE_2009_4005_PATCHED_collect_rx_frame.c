static void FUN1(VAR1 * VAR2, VAR3 * VAR4, int VAR5, int VAR6)  
{
	VAR7 *VAR8 = VAR2->VAR8;
	int VAR9, VAR10;

	VAR10 = VAR2->VAR11;
	VAR9 = 0;
	if (VAR10 < 4 && VAR8->VAR12[VAR10 / 2] == VAR13)
		VAR9 = 1;

	if (!VAR2->VAR14) {
		VAR2->VAR14 = FUN2(VAR2->VAR15 + 3);
		if (!VAR2->VAR14) {
			FUN3(VAR16
			       "",
			       VAR10);
			return;
		}
	}
	if (VAR5) {
		if (VAR2->VAR14->VAR5 + VAR5 < VAR2->VAR15) {
			memcpy(FUN4(VAR2->VAR14, VAR5), VAR4, VAR5);
		} else {
			FUN5(VAR17,
			       "",
			       VAR2->VAR15, VAR10);
			FUN6(VAR18, VAR2->VAR14);
			FUN7(VAR2->VAR14, 0);
		}
	}
	if (VAR9 && VAR2->VAR14->VAR5 >= 128) {
		VAR2->VAR19->FUN8(VAR2->VAR19, VAR20 | VAR21,
				VAR2->VAR14);
		VAR2->VAR14 = NULL;
		return;
	}
	
	if (VAR6) {
		if (VAR2->VAR14->VAR5 > 3 &&
				!VAR2->VAR14->VAR4[VAR2->VAR14->VAR5 - 1]) {

			if (VAR10 == VAR22) {
				FUN5(VAR23,
				    "", VAR2->VAR14->VAR5);
				FUN6(VAR23, VAR2->VAR14);
			}

			
			FUN7(VAR2->VAR14, VAR2->VAR14->VAR5 - 3);
			if (VAR10 == VAR24) {
				VAR2->VAR19->FUN8(VAR2->VAR19,
						VAR25 | VAR21,
						VAR2->VAR14);
			} else
				VAR2->VAR19->FUN8(VAR2->VAR19,
						VAR20 | VAR21,
						VAR2->VAR14);
			VAR2->VAR14 = NULL;	
		} else {
			FUN5(VAR17,
			    "",
			    VAR2->VAR14->VAR5, VAR10);
			FUN6(VAR18, VAR2->VAR14);
			FUN7(VAR2->VAR14, 0);
		}
	}
}