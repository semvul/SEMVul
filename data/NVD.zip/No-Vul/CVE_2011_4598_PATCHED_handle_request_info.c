static void FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4)  
{
	char VAR5[1024];
	unsigned int VAR6;
	const char *VAR7 = FUN2(VAR4, "");

	
	if (!FUN3(VAR7, "") ||
	    !FUN3(VAR7, "")) {
		unsigned int VAR8 = 0;

		if (!VAR2->VAR9) {	
			FUN4(VAR2, "", VAR4);
			FUN5(VAR2, VAR10);
			return;
		}

		
		if (FUN6(VAR7 = FUN7(VAR4, "", '')) && FUN6(VAR7 = FUN7(VAR4, "", ''))) {
			FUN8(VAR11, "", VAR2->VAR12);
			FUN4(VAR2, "", VAR4); 
			return;
		} else {
			FUN9(VAR5, VAR7, sizeof(VAR5));
		}

		if (!FUN6((VAR7 = FUN7(VAR4, "", ''))))
			VAR8 = FUN10(VAR7);
		if (!VAR8)
			VAR8 = 100; 


		if (FUN6(VAR5)) {
			FUN4(VAR2, "", VAR4);
			return;
		}

		if (VAR5[0] == '')
			VAR6 = 10;
		else if (VAR5[0] == '')
			VAR6 = 11;
		else if ((VAR5[0] >= '') && (VAR5[0] <= ''))
			VAR6 = 12 + VAR5[0] - '';
		else if (VAR5[0] == '')
			VAR6 = 16;
		else
			VAR6 = FUN10(VAR5);
		if (VAR6 == 16) {
			
			struct ast_frame VAR13 = { VAR14, { VAR15, } };
			FUN11(VAR2->VAR9, &VAR13);
			if (VAR16)
				FUN12("");
		} else {
			
			struct ast_frame VAR13 = { VAR17, };
			if (VAR6 < 10) {
				VAR13.VAR18.VAR19 = '' + VAR6;
			} else if (VAR6 == 10) {
				VAR13.VAR18.VAR19 = '';
			} else if (VAR6 == 11) {
				VAR13.VAR18.VAR19 = '';
			} else if (VAR6 < 16) {
				VAR13.VAR18.VAR19 = '' + (VAR6 - 12);
			}
			VAR13.VAR20 = VAR8;
			FUN11(VAR2->VAR9, &VAR13);
			if (VAR16)
				FUN12("", (int) VAR13.VAR18.VAR19);
		}
		FUN4(VAR2, "", VAR4);
		return;
	} else if (!FUN3(VAR7, "")) {
		
		unsigned int VAR8 = 0;

		if (!VAR2->VAR9) {	
			FUN4(VAR2, "", VAR4);
			FUN5(VAR2, VAR10);
			return;
		}

		FUN13(VAR5, sizeof(VAR5), VAR4, VAR21);
		VAR8 = 100; 

		if (FUN6(VAR5)) {
			FUN4(VAR2, "", VAR4);
			return;
		}
		VAR6 = FUN10(VAR5);
		if (VAR6 == 16) {
			
			struct ast_frame VAR13 = { VAR14, { VAR15 }, };
			FUN11(VAR2->VAR9, &VAR13);
			if (VAR16)
				FUN12("");
		} else {
			
			struct ast_frame VAR13 = { VAR17, };
			if (VAR6 < 10) {
				VAR13.VAR18.VAR19 = '' + VAR6;
			} else if (VAR6 == 10) {
				VAR13.VAR18.VAR19 = '';
			} else if (VAR6 == 11) {
				VAR13.VAR18.VAR19 = '';
			} else if (VAR6 < 16) {
				VAR13.VAR18.VAR19 = '' + (VAR6 - 12);
			}
			VAR13.VAR20 = VAR8;
			FUN11(VAR2->VAR9, &VAR13);
			if (VAR16)
				FUN12("", (int) VAR13.VAR18.VAR19);
		}
		FUN4(VAR2, "", VAR4);
		return;

	} else if (!FUN3(VAR7, "")) {
		
		if (VAR2->VAR9)
			FUN14(VAR2->VAR9, VAR22);
		FUN4(VAR2, "", VAR4);
		return;
	} else if (!FUN6(VAR7 = FUN2(VAR4, ""))) {
		
		if (FUN15(&VAR2->VAR23[0], VAR24)) {
			if (VAR2->VAR9 && VAR2->VAR9->VAR25)
				FUN16(VAR2->VAR9, VAR7);
			if (VAR2->VAR9 && FUN17(VAR2->VAR9) && FUN17(VAR2->VAR9)->VAR25)
				FUN16(FUN17(VAR2->VAR9), VAR7);
			FUN4(VAR2, "", VAR4);
		} else {
			FUN4(VAR2, "", VAR4);
		}
		return;
	} else if (!FUN6(VAR7 = FUN2(VAR4, ""))) {
		
		
		struct VAR26 *VAR27;
		int VAR28;
		struct ast_frame VAR13 = { VAR17, };

		if (!VAR2->VAR9) {        
			FUN4(VAR2, "", VAR4);
			FUN5(VAR2, VAR10);
			return;
		}

		
		FUN18();
		VAR27 = FUN19("");
		if (!VAR27 || FUN6(VAR27->VAR29)) {
			FUN8(VAR11, "");
			
			FUN4(VAR2, "", VAR4);
			FUN20();
			return;
		}
		
		VAR13.VAR20 = 100;
		for (VAR28=0; VAR28 < strlen(VAR27->VAR29); VAR28++) {
			VAR13.VAR18.VAR19 = VAR27->VAR29[VAR28];
			FUN11(VAR2->VAR9, &VAR13);
			if (VAR16)
				FUN12("", VAR13.VAR18.VAR19);
		}
		FUN20();

		FUN21(1, "", VAR7);
		FUN4(VAR2, "", VAR4);
		return;
	} else if (FUN6(VAR7 = FUN2(VAR4, "")) || !FUN3(VAR7, "")) {
		
		FUN4(VAR2, "", VAR4);
		return;
	}

	
	

	FUN8(VAR11, "", VAR2->VAR12, VAR5);
	FUN4(VAR2, "", VAR4);
	return;
}