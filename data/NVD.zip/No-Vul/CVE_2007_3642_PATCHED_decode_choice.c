int FUN1(VAR1 * VAR2, VAR3 * VAR4, char *VAR5, int VAR6)  
{
	unsigned VAR7, VAR8, VAR9 = 0;
	int VAR10;
	VAR3 *VAR11;
	unsigned char *VAR12 = NULL;

	FUN2("", VAR6 * VAR13, "", VAR4->VAR14);

	
	VAR5 = (VAR5 && (VAR4->VAR15 & VAR16)) ? VAR5 + VAR4->VAR17 : NULL;

	
	if ((VAR4->VAR15 & VAR18) && FUN3(VAR2)) {
		VAR8 = 1;
		VAR7 = FUN4(VAR2, 7) + VAR4->VAR19;
	} else {
		VAR8 = 0;
		VAR7 = FUN4(VAR2, VAR4->VAR20);
		if (VAR7 >= VAR4->VAR19)
			return VAR21;
	}

	
	if (VAR5)
		*(unsigned *) VAR5 = VAR7;

	
	if (VAR7 >= VAR4->VAR22) {	
		FUN5(VAR2);
		VAR9 = FUN6(VAR2);
		FUN7(VAR2, VAR9);
		VAR2->VAR23 += VAR9;
		return VAR24;
	}

	
	VAR11 = &VAR4->VAR25[VAR7];
	if (VAR11->VAR15 & VAR26) {
		FUN2("", (VAR6 + 1) * VAR13, "", VAR11->VAR14);
		return VAR27;
	}

	if (VAR8 || (VAR11->VAR15 & VAR28)) {
		FUN5(VAR2);
		VAR9 = FUN6(VAR2);
		FUN7(VAR2, VAR9);
		if (!VAR5 || !(VAR11->VAR15 & VAR16)) {
			FUN2("", (VAR6 + 1) * VAR13, "",
			      VAR11->VAR14);
			VAR2->VAR23 += VAR9;
			return VAR24;
		}
		VAR12 = VAR2->VAR23;

		if ((VAR10 = (VAR29[VAR11->VAR7]) (VAR2, VAR11, VAR5, VAR6 + 1)) <
		    VAR24)
			return VAR10;

		VAR2->VAR23 = VAR12 + VAR9;
		VAR2->VAR30 = 0;
	} else if ((VAR10 = (VAR29[VAR11->VAR7]) (VAR2, VAR11, VAR5, VAR6 + 1)) <
		   VAR24)
		return VAR10;

	return VAR24;
}