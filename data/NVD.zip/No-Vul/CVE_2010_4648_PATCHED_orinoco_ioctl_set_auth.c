static int FUN1(struct VAR1 *VAR2, 				  struct VAR3 *VAR4, 				  union VAR5 *VAR6, char *VAR7)  
{
	struct VAR8 *VAR9 = FUN2(VAR2);
	VAR10 *VAR11 = &VAR9->VAR11;
	struct VAR12 *VAR13 = &VAR6->VAR13;
	unsigned long VAR14;
	int VAR15 = -VAR16;

	if (FUN3(VAR9, &VAR14) != 0)
		return -VAR17;

	switch (VAR13->VAR14 & VAR18) {
	case VAR19:
	case VAR20:
	case VAR21:
	case VAR22:
	case VAR23:
	case VAR24:
		
		break;

	case VAR25:
		
		VAR9->VAR26 = VAR13->VAR27;
		break;

	case VAR28:
		
		if (VAR13->VAR27) {
			VAR9->VAR29 = 1;
			VAR15 = FUN4(VAR11, 0);
		} else {
			VAR9->VAR29 = 0;
			VAR15 = FUN5(VAR11, 0);
		}
		break;

	case VAR30:
		if (VAR13->VAR27 & VAR31)
			VAR9->VAR32 = 1;
		else if (VAR13->VAR27 & VAR33)
			VAR9->VAR32 = 0;
		else
			VAR15 = -VAR34;
		break;

	case VAR35:
		if (VAR9->VAR36) {
			VAR9->VAR37 = VAR13->VAR27 ? 1 : 0;
		} else {
			if (VAR13->VAR27)
				VAR15 = -VAR38;
			
			VAR9->VAR37 = 0;
		}
		break;

	default:
		VAR15 = -VAR38;
	}

	FUN6(VAR9, &VAR14);
	return VAR15;
}