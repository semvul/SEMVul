static int FUN1(struct VAR1 *VAR1, struct VAR2 *VAR2, uint VAR3, ulong VAR4)  
{
	uint VAR5 = FUN2(VAR1);
	isdn_ctrl VAR6;
	int VAR7;
	int VAR8;
	int VAR9;
	int VAR10;
	char VAR11 *VAR12;
	char *VAR13;
	union VAR14 {
		char VAR15[10];
		char VAR16[22];
		isdn_ioctl_struct VAR17;
		isdn_net_ioctl_phone VAR18;
		isdn_net_ioctl_cfg VAR19;
	} VAR14;
	void VAR11 *VAR20 = (void VAR11 *)VAR4;

#define name  VAR14.VAR15
#define bname VAR14.VAR16
#define iocts VAR14.VAR17
#define phone VAR14.VAR18
#define cfg   VAR14.VAR19

	if (VAR5 == VAR21) {
		switch (VAR3) {
			case VAR22:
				return (VAR23 +
					(VAR24 << 8) +
					(VAR25 << 16));
			case VAR26:
				if (VAR4) {
					ulong VAR11 *VAR12 = VAR20;
					int VAR10;
					if (!FUN3(VAR27, VAR12,
							sizeof(VAR28) * VAR29 * 2))
						return -VAR30;
					for (VAR10 = 0; VAR10 < VAR29; VAR10++) {
						FUN4(VAR31->VAR32[VAR10], VAR12++);
						FUN4(VAR31->VAR33[VAR10], VAR12++);
					}
					return 0;
				} else
					return -VAR34;
				break;
#ifdef VAR35
			case VAR36:
				
				if (VAR4) {
					if (FUN5(&VAR18, VAR20, sizeof(VAR18)))
						return -VAR30;
					return FUN6(&VAR18, VAR20);
				} else
					return -VAR34;
#endif
			default:
				return -VAR34;
		}
	}
	if (!VAR31->VAR37)
		return -VAR38;
	if (VAR5 <= VAR39) {
		VAR7 = FUN7(VAR5);
		if (VAR7 < 0)
			return -VAR38;
		VAR8 = FUN8(VAR5);
		if (!(VAR31->VAR40[VAR7]->VAR41 & VAR42))
			return -VAR38;
		return 0;
	}
	if (VAR5 <= VAR43) {

		switch (VAR3) {
			case VAR44:
				FUN9(VAR45 "");
				return(-VAR34);
			case VAR46:
				FUN9(VAR45 "");
				return -VAR38;
#ifdef VAR35
			case VAR47:
				
				if (VAR4) {
					if (FUN5(VAR15, VAR20, sizeof(VAR15)))
						return -VAR30;
					VAR13 = VAR15;
				} else {
					VAR13 = NULL;
				}
				VAR9 = FUN10(&VAR31->VAR48);
				if( VAR9 ) return VAR9;
				if ((VAR13 = FUN11(VAR13, NULL))) {
					if (FUN12(VAR20, VAR13, strlen(VAR13) + 1)){
						VAR9 = -VAR30;
					} else {
						VAR9 = 0;
					}
				} else
					VAR9 = -VAR38;
				FUN13(&VAR31->VAR48);
				return VAR9;
			case VAR49:
				
				if (VAR4) {
					if (FUN5(VAR16, VAR20, sizeof(VAR16) - 1))
						return -VAR30;
				} else
					return -VAR34;
				VAR9 = FUN10(&VAR31->VAR48);
				if( VAR9 ) return VAR9;
				if ((VAR13 = FUN14(VAR16))) {
					if (FUN12(VAR20, VAR13, strlen(VAR13) + 1)){
						VAR9 = -VAR30;
					} else {
						VAR9 = 0;
					}
				} else
					VAR9 = -VAR38;
				FUN13(&VAR31->VAR48);
				return VAR9;
			case VAR50:
				
				if (VAR4) {
					if (FUN5(VAR15, VAR20, sizeof(VAR15)))
						return -VAR30;
					VAR9 = FUN10(&VAR31->VAR48);
					if( VAR9 ) return VAR9;
					VAR9 = FUN15(VAR15);
					FUN13(&VAR31->VAR48);
					return VAR9;
				} else
					return -VAR34;
			case VAR51:
				
				if (VAR4) {
					if (FUN5(&VAR19, VAR20, sizeof(VAR19)))
						return -VAR30;
					return FUN16(&VAR19);
				} else
					return -VAR34;
			case VAR52:
				
				if (VAR4) {
					if (FUN5(&VAR19, VAR20, sizeof(VAR19)))
						return -VAR30;
					if (!(VAR9 = FUN17(&VAR19))) {
						if (FUN12(VAR20, &VAR19, sizeof(VAR19)))
							return -VAR30;
					}
					return VAR9;
				} else
					return -VAR34;
			case VAR53:
				
				if (VAR4) {
					if (FUN5(&VAR18, VAR20, sizeof(VAR18)))
						return -VAR30;
					VAR9 = FUN10(&VAR31->VAR48);
					if( VAR9 ) return VAR9;
					VAR9 = FUN18(&VAR18);
					FUN13(&VAR31->VAR48);
					return VAR9;
				} else
					return -VAR34;
			case VAR54:
				
				if (VAR4) {
					if (FUN5(&VAR18, VAR20, sizeof(VAR18)))
						return -VAR30;
					VAR9 = FUN10(&VAR31->VAR48);
					if( VAR9 ) return VAR9;
					VAR9 = FUN19(&VAR18, VAR20);
					FUN13(&VAR31->VAR48);
					return VAR9;
				} else
					return -VAR34;
			case VAR55:
				
				if (VAR4) {
					if (FUN5(&VAR18, VAR20, sizeof(VAR18)))
						return -VAR30;
					VAR9 = FUN10(&VAR31->VAR48);
					if( VAR9 ) return VAR9;
					VAR9 = FUN20(&VAR18);
					FUN13(&VAR31->VAR48);
					return VAR9;
				} else
					return -VAR34;
			case VAR56:
				
				if (VAR4) {
					if (FUN5(VAR15, VAR20, sizeof(VAR15)))
						return -VAR30;
					return FUN21(VAR15);
				} else
					return -VAR34;
#ifdef VAR57
			case VAR58:
				if (!VAR4)
					return -VAR34;
				if (FUN5(VAR15, VAR20, sizeof(VAR15)))
					return -VAR30;
				return FUN22(VAR15);
			case VAR59:
				if (!VAR4)
					return -VAR34;
				if (FUN5(VAR15, VAR20, sizeof(VAR15)))
					return -VAR30;
				return FUN23(VAR15);
#endif
			case VAR60:
				
				if (!VAR4)
					return -VAR34;
				if (FUN5(VAR15, VAR20, sizeof(VAR15)))
					return -VAR30;
				return FUN24(VAR15);
				break;
#endif                          
			case VAR61:
				VAR31->VAR62 = VAR4;
				FUN9(VAR45 "", VAR31->VAR62);
				return 0;
			case VAR63:
				if (VAR4)
					VAR31->VAR64 |= VAR65;
				else
					VAR31->VAR64 &= ~VAR65;
				FUN9(VAR45 "",
				       (VAR31->VAR64 & VAR65) ? "" : "");
				return 0;
			case VAR66:
				VAR7 = -1;
				if (VAR4) {
					int VAR10;
					char *VAR12;
					if (FUN5(&VAR17, VAR20,
					     sizeof(VAR67)))
						return -VAR30;
					VAR17.VAR68[sizeof(VAR17.VAR68)-1] = 0;
					if (strlen(VAR17.VAR68)) {
						if ((VAR12 = strchr(VAR17.VAR68, '')))
							*VAR12 = 0;
						VAR7 = -1;
						for (VAR10 = 0; VAR10 < VAR69; VAR10++)
							if (!(strcmp(VAR31->VAR68[VAR10], VAR17.VAR68))) {
								VAR7 = VAR10;
								break;
							}
					}
				}
				if (VAR7 == -1)
					return -VAR38;
				if (VAR17.VAR4)
					VAR31->VAR40[VAR7]->VAR41 |= VAR70;
				else
					VAR31->VAR40[VAR7]->VAR41 &= ~VAR70;
				return 0;
			case VAR71:
				VAR31->VAR72 = VAR73;
				return 0;
				break;
			case VAR74:
				
				if (VAR4) {
					char VAR11 *VAR12 = VAR20;
					int VAR10;

					if (!FUN3(VAR27, VAR20,
					(VAR75 + VAR76 + VAR77)
						   * VAR29))
						return -VAR30;

					for (VAR10 = 0; VAR10 < VAR29; VAR10++) {
						if (FUN12(VAR12, VAR31->VAR78.VAR79[VAR10].VAR80.VAR81,
						      VAR75))
							return -VAR30;
						VAR12 += VAR75;
						if (FUN12(VAR12, VAR31->VAR78.VAR79[VAR10].VAR80.VAR82, VAR76))
							return -VAR30;
						VAR12 += VAR76;
						if (FUN12(VAR12, VAR31->VAR78.VAR79[VAR10].VAR80.VAR83, VAR77))
							return -VAR30;
						VAR12 += VAR77;
					}
					return (VAR75 + VAR76 + VAR77) * VAR29;
				} else
					return -VAR34;
				break;
			case VAR84:
				
				if (VAR4) {
					char VAR11 *VAR12 = VAR20;
					int VAR10;

					if (!FUN3(VAR85, VAR20,
					(VAR75 + VAR76 + VAR77)
						   * VAR29))
						return -VAR30;

					for (VAR10 = 0; VAR10 < VAR29; VAR10++) {
						if (FUN5(VAR31->VAR78.VAR79[VAR10].VAR80.VAR81, VAR12,
						     VAR75))
							return -VAR30;
						VAR12 += VAR75;
						if (FUN5(VAR31->VAR78.VAR79[VAR10].VAR80.VAR83, VAR12, VAR77))
							return -VAR30;
						VAR12 += VAR77;
						if (FUN5(VAR31->VAR78.VAR79[VAR10].VAR80.VAR82, VAR12, VAR76))
							return -VAR30;
						VAR12 += VAR76;
					}
					return 0;
				} else
					return -VAR34;
				break;
			case VAR86:
			case VAR87:
				
				if (VAR4) {

					if (FUN5(&VAR17, VAR20,
					     sizeof(VAR67)))
						return -VAR30;
					VAR17.VAR68[sizeof(VAR17.VAR68)-1] = 0;
					if (strlen(VAR17.VAR68)) {
						VAR7 = -1;
						for (VAR10 = 0; VAR10 < VAR69; VAR10++)
							if (!(strcmp(VAR31->VAR68[VAR10], VAR17.VAR68))) {
								VAR7 = VAR10;
								break;
							}
					} else
						VAR7 = 0;
					if (VAR7 == -1)
						return -VAR38;
					if (VAR3 == VAR86) {
						int VAR88 = 1;

						VAR12 = (char VAR11 *) VAR17.VAR4;
						VAR10 = 0;
						while (VAR88) {
							int VAR89 = 0;

							while (1) {
								if (!FUN3(VAR85, VAR12, 1))
									return -VAR30;
								FUN25(VAR16[VAR89], VAR12++);
								switch (VAR16[VAR89]) {
									case '':
										VAR88 = 0;
										
									case '':
										VAR16[VAR89] = '';
										strcpy(VAR31->VAR40[VAR7]->VAR90[VAR10], VAR16);
										VAR89 = VAR76;
										break;
									default:
										VAR89++;
								}
								if (VAR89 >= VAR76)
									break;
							}
							if (++VAR10 > 9)
								break;
						}
					} else {
						VAR12 = (char VAR11 *) VAR17.VAR4;
						for (VAR10 = 0; VAR10 < 10; VAR10++) {
							snprintf(VAR16, sizeof(VAR16), "",
								strlen(VAR31->VAR40[VAR7]->VAR90[VAR10]) ?
								VAR31->VAR40[VAR7]->VAR90[VAR10] : "",
								(VAR10 < 9) ? "" : "");
							if (FUN12(VAR12, VAR16, strlen(VAR16) + 1))
								return -VAR30;
							VAR12 += strlen(VAR16);
						}
					}
					return 0;
				} else
					return -VAR34;
			case VAR91:
				if (VAR4) {
					if (FUN12(VAR20, &VAR31, sizeof(VAR28)))
						return -VAR30;
					return 0;
				} else
					return -VAR34;
				break;
			default:
				if ((VAR3 & VAR92) == VAR92)
					VAR3 = ((VAR3 >> VAR93) & VAR94) & VAR95;
				else
					return -VAR34;
				if (VAR4) {
					int VAR10;
					char *VAR12;
					if (FUN5(&VAR17, VAR20, sizeof(VAR67)))
						return -VAR30;
					VAR17.VAR68[sizeof(VAR17.VAR68)-1] = 0;
					if (strlen(VAR17.VAR68)) {
						if ((VAR12 = strchr(VAR17.VAR68, '')))
							*VAR12 = 0;
						VAR7 = -1;
						for (VAR10 = 0; VAR10 < VAR69; VAR10++)
							if (!(strcmp(VAR31->VAR68[VAR10], VAR17.VAR68))) {
								VAR7 = VAR10;
								break;
							}
					} else
						VAR7 = 0;
					if (VAR7 == -1)
						return -VAR38;
					if (!FUN3(VAR27, VAR20,
					     sizeof(VAR67)))
						return -VAR30;
					VAR6.VAR96 = VAR7;
					VAR6.VAR97 = VAR98;
					VAR6.VAR4 = VAR3;
					memcpy(VAR6.VAR99.VAR100, &VAR17.VAR4, sizeof(VAR28));
					VAR9 = FUN26(&VAR6);
					memcpy(&VAR17.VAR4, VAR6.VAR99.VAR100, sizeof(VAR28));
					if (FUN12(VAR20, &VAR17, sizeof(VAR67)))
						return -VAR30;
					return VAR9;
				} else
					return -VAR34;
		}
	}
#ifdef VAR57
	if (VAR5 <= VAR101)
		return (FUN27(VAR5 - VAR102, VAR2, VAR3, VAR4));
#endif
	return -VAR38;

#undef VAR15
#undef VAR16
#undef VAR17
#undef VAR18
#undef VAR19
}