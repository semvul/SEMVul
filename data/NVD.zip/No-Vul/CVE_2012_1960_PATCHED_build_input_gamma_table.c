float *FUN1(struct VAR1 *VAR2)  
{
	float *VAR3;

	if (!VAR2) return NULL;
	VAR3 = malloc(sizeof(float)*256);
	if (VAR3) {
		if (VAR2->VAR4 == VAR5) {
			FUN2(VAR3, VAR2->VAR6, VAR2->VAR7);
		} else {
			if (VAR2->VAR7 == 0) {
				FUN3(VAR3);
			} else if (VAR2->VAR7 == 1) {
				FUN4(VAR3, VAR2->VAR8[0]);
			} else {
				FUN5(VAR3, VAR2->VAR8, VAR2->VAR7);
			}
		}
	}
        return VAR3;
}