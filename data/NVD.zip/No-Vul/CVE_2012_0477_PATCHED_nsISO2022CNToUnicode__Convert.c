NS_IMETHODIMP VAR1::FUN1(const char * VAR2, VAR3 * VAR4, VAR5 * VAR6, VAR3 * VAR7)  
{
  const unsigned char * VAR8 = (unsigned char *)VAR2 + *VAR4;
  const unsigned char * VAR9 = (unsigned char *) VAR2;
  VAR5* VAR10 = VAR6 + *VAR7;
  VAR5* VAR11 = VAR6;
  nsresult VAR12;
  PRInt32 VAR13; 

  while ((VAR9 < VAR8))
  {
    switch (VAR14)
    {
      case VAR15:
        if(VAR16 == *VAR9) {
           VAR14 = VAR17;
        } else {
           if (FUN2(VAR11, VAR10, 1))
              goto VAR18;
           *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;

           VAR14 = VAR15;
        }
        break;

      case VAR17:    
        if('' == *VAR9) {
           VAR14 = VAR19;
        } else {
           if (FUN2(VAR11, VAR10, 2))
              goto VAR18;
           *VAR11++ = (VAR5) VAR16;
           *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;

           VAR14 = VAR15;
        }
        break;

      case VAR19: 
        if('' == *VAR9) {
           VAR14 = VAR20;
        } else if('' == *VAR9) {
           VAR14 = VAR21;
        } else if('' == *VAR9) {
           VAR14 = VAR22;
        } else {
           if (FUN2(VAR11, VAR10, 3))
              goto VAR18;
           *VAR11++ = (VAR5) VAR16;
           *VAR11++ = (VAR5) '';
           *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;

           VAR14 = VAR15;
        }
        break;

      case VAR20: 
        if('' == *VAR9) {
           VAR14 = VAR23;
        } else if('' == *VAR9) {
           VAR14 = VAR24;
        } else {
           if (FUN2(VAR11, VAR10, 4))
              goto VAR18;
           *VAR11++ = (VAR5) VAR16;
           *VAR11++ = (VAR5) '';
           *VAR11++ = (VAR5) '';
           *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;

           VAR14 = VAR15;
        }
        break;

      case VAR23:  
        if(VAR25 == *VAR9) {
           VAR14 = VAR26;
           VAR27 = 0;
        } else {
           if (FUN2(VAR11, VAR10, 5))
              goto VAR18;
           *VAR11++ = (VAR5) VAR16;
           *VAR11++ = (VAR5) '';
           *VAR11++ = (VAR5) '';
           *VAR11++ = (VAR5) '';
           *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;

           VAR14 = VAR15;
        }
        break;

      case VAR26:   
        if(VAR28 == *VAR9) { 
           VAR14 = VAR29;
           if (VAR27 == 0) {
              if (FUN2(VAR11, VAR10, 1))
                 goto VAR18;
              *VAR11++ = 0xFFFD;
           }
           VAR27 = 0;
        } else if(VAR16 == *VAR9) {
           VAR14 = VAR17;
        } else {
           if(0x20 < *VAR9 && *VAR9 < 0x7f) {
              VAR30 = *VAR9;
              VAR14 = VAR31;
           } else {
              if (FUN2(VAR11, VAR10, 1))
                 goto VAR18;
              *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;
           }
        }
        break; 

      case VAR31:  
        if(0x20 < *VAR9 && *VAR9 < 0x7f) {
           unsigned char VAR32[2];
           PRInt32 VAR33 = 2;

           VAR32[0] = VAR30 | 0x80;
           VAR32[1] = *VAR9 | 0x80;

           VAR13 = VAR10 - VAR11;
           VAR12 = FUN3(VAR32, VAR33, VAR11, &VAR13);
           ++VAR27;
           if(VAR12 == VAR34) {
              goto VAR18;
           } else if(FUN4(VAR12)) {
              goto VAR35;
           }

           VAR11 += VAR13;
        } else {
           if (FUN2(VAR11, VAR10, 2))
              goto VAR18;
           *VAR11++ = (VAR5) VAR30;
           *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;
        }
        VAR14 = VAR26;
        break;

      case VAR29:  
        if(VAR25 == *VAR9) {
           VAR14 = VAR26;
           VAR27 = 0;
        } else if(VAR16 == *VAR9) {
           VAR14 = VAR17;
        } else {
           if (FUN2(VAR11, VAR10, 1))
              goto VAR18;
           *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;

           VAR14 = VAR29;
        }
        break;

      case VAR24:   
        if(VAR25 == *VAR9) {
           VAR14 = VAR36;
           VAR27 = 0;
        } else {
           if (FUN2(VAR11, VAR10, 5))
              goto VAR18;
           *VAR11++ = (VAR5) VAR16;
           *VAR11++ = (VAR5) '';
           *VAR11++ = (VAR5) '';
           *VAR11++ = (VAR5) '';
           *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;

           VAR14 = VAR15;
        }
        break;

      case VAR36:   
        if(VAR28 == *VAR9) { 
           VAR14 = VAR37;
           if (VAR27 == 0) {
              if (FUN2(VAR11, VAR10, 1))
                 goto VAR18;
              *VAR11++ = 0xFFFD;
           }
           VAR27 = 0;
        } else if(VAR16 == *VAR9) {
           VAR14 = VAR17;
        } else {
           if(0x20 < *VAR9 && *VAR9 < 0x7f) {
              VAR30 = *VAR9;
              VAR14 = VAR38;
           } else {
              if (FUN2(VAR11, VAR10, 1))
                 goto VAR18;
              *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;
           }
        }
        break;

      case VAR38:  
        if(0x20 < *VAR9 && *VAR9 < 0x7f) {
           unsigned char VAR39[4];
           PRInt32 VAR40 = 2;

           VAR39[0] = VAR30 | 0x80;
           VAR39[1] = *VAR9 | 0x80;

           VAR13 = VAR10 - VAR11;
           VAR12 = FUN5(VAR39, VAR40, VAR11, &VAR13);
           ++VAR27;
           if(VAR12 == VAR34) {
              goto VAR18;
           } else if(FUN4(VAR12)) {
              goto VAR35;
           }

           VAR11 += VAR13;
        } else {
           if (FUN2(VAR11, VAR10, 2))
              goto VAR18;
           *VAR11++ = (VAR5) VAR30;
           *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;
        }
        VAR14 = VAR36;
        break;

      case VAR37: 
        if(VAR25 == *VAR9) {
           VAR14 = VAR36;
           VAR27 = 0;
        } else if(VAR16 == *VAR9) {
           VAR14 = VAR17;
        } else {
           if (FUN2(VAR11, VAR10, 1))
              goto VAR18;
           *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;

           VAR14 = VAR37;
        }
        break;

      case VAR21: 
        if('' == *VAR9) {
           VAR14 = VAR41;
        } else {
           if (FUN2(VAR11, VAR10, 4))
              goto VAR18;
           *VAR11++ = (VAR5) VAR16;
           *VAR11++ = (VAR5) '';
           *VAR11++ = (VAR5) '';
           *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;

           VAR14 = VAR15;
        }
        break;

      case VAR41:  
        if(VAR16 == *VAR9) {
           VAR14 = VAR42;
        } else {
           if (FUN2(VAR11, VAR10, 5))
              goto VAR18;
           *VAR11++ = (VAR5) VAR16;
           *VAR11++ = (VAR5) '';
           *VAR11++ = (VAR5) '';
           *VAR11++ = (VAR5) '';
           *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;

           VAR14 = VAR15;
        } 
        break;

      case VAR42:  
        if(VAR43 == *VAR9) {
           VAR14 = VAR44;
           VAR27 = 0;
        } else if('' == *VAR9) {
           VAR14 = VAR19;
        } else {
           if (FUN2(VAR11, VAR10, 6))
              goto VAR18;
           *VAR11++ = (VAR5) VAR16;
           *VAR11++ = (VAR5) '';
           *VAR11++ = (VAR5) '';
           *VAR11++ = (VAR5) '';
           *VAR11++ = (VAR5) VAR16;
           *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;

           VAR14 = VAR15;
        }
        break;

      case VAR44:  
        if(VAR28 == *VAR9) { 
           VAR14 = VAR45;
           if (VAR27 == 0) {
              if (FUN2(VAR11, VAR10, 1))
                 goto VAR18;
              *VAR11++ = 0xFFFD;
           }
           VAR27 = 0;
        } else if(VAR16 == *VAR9) {
           VAR14 = VAR42;
        } else {
           if(0x20 < *VAR9 && *VAR9 < 0x7f) {
              VAR30 = *VAR9;
              VAR14 = VAR46;
           } else {
              if (FUN2(VAR11, VAR10, 1))
                 goto VAR18;
              *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;
           }
        }
        break;

      case VAR46:   
        if(0x20 < *VAR9 && *VAR9 < 0x7f) {
           unsigned char VAR39[4];
           PRInt32 VAR40 = 4;
 
           VAR39[0] = (unsigned char) VAR47;
           VAR39[1] = (unsigned char) (VAR48 + 2);
           VAR39[2] = VAR30 | 0x80;
           VAR39[3] = *VAR9 | 0x80;
 
           VAR13 = VAR10 - VAR11;
           VAR12 = FUN5(VAR39, VAR40, VAR11, &VAR13);
           ++VAR27;
           if(VAR12 == VAR34) {
              goto VAR18;
           } else if(FUN4(VAR12)) {
              goto VAR35;
           }

           VAR11 += VAR13;
        } else {
           if (FUN2(VAR11, VAR10, 2))
              goto VAR18;
           *VAR11++ = (VAR5) VAR30;
           *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;
        }
        VAR14 = VAR44;
        break;

      case VAR45:  
        if(VAR16 == *VAR9) {
           VAR14 = VAR49;
        } else {
           if (FUN2(VAR11, VAR10, 1))
              goto VAR18;
           *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;

           VAR14 = VAR45;
        }
        break;

      case VAR49:  
        if(VAR43 == *VAR9) {
           VAR14 = VAR44;
           VAR27 = 0;
        } else if('' == *VAR9) {
           VAR14 = VAR19;
        } else {
           if (FUN2(VAR11, VAR10, 1))
              goto VAR18;
           *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;

           VAR14 = VAR45;
        }
        break;

      case VAR22: 
        if('' <= *VAR9 && *VAR9 <= '') {
            VAR14 = VAR50;
            VAR51 = *VAR9 - '' + 3;
        } else {
           if (FUN2(VAR11, VAR10, 4))
              goto VAR18;
           *VAR11++ = (VAR5) VAR16;
           *VAR11++ = (VAR5) '';
           *VAR11++ = (VAR5) '';
           *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;

           VAR14 = VAR15;
        }
        break;

      case VAR50:  
        if(VAR16 == *VAR9) {
           VAR14 = VAR52;
        } else {
           if (FUN2(VAR11, VAR10, 5))
              goto VAR18;
           *VAR11++ = (VAR5) VAR16;
           *VAR11++ = (VAR5) '';
           *VAR11++ = (VAR5) '';
           *VAR11++ = (VAR5) '' + VAR51 - 3;
           *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;

           VAR14 = VAR15;
        }
        break;

      case VAR52:  
        if(VAR53 == *VAR9) {
           VAR14 = VAR54;
           VAR27 = 0;
        } else if('' == *VAR9) {
           VAR14 = VAR19;
        } else {
           if (FUN2(VAR11, VAR10, 6))
              goto VAR18;
           *VAR11++ = (VAR5) VAR16;
           *VAR11++ = (VAR5) '';
           *VAR11++ = (VAR5) '';
           *VAR11++ = (VAR5) '' + VAR51 - 3;
           *VAR11++ = (VAR5) VAR16;
           *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;

           VAR14 = VAR15;
        }
        break;

      case VAR54:   
        if(VAR28 == *VAR9) { 
           VAR14 = VAR55;
           if (VAR27 == 0) {
              if (FUN2(VAR11, VAR10, 1))
                 goto VAR18;
              *VAR11++ = 0xFFFD;
           }
           VAR27 = 0;
        } else if(VAR16 == *VAR9) {
           VAR14 = VAR52;
        } else {
           if(0x20 < *VAR9 && *VAR9 < 0x7f) {
              VAR30 = *VAR9;
              VAR14 = VAR56;
           } else {
              if (FUN2(VAR11, VAR10, 1))
                 goto VAR18;
              *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;
           }
        }

        break;

      case VAR56:  
        if(0x20 < *VAR9 && *VAR9 < 0x7f) {
           unsigned char VAR39[4];
           PRInt32 VAR40 = 4;

           VAR39[0] = (unsigned char) VAR47;
           VAR39[1] = (unsigned char) (VAR48 + VAR51);
           VAR39[2] = VAR30 | 0x80;
           VAR39[3] = *VAR9 | 0x80;

           VAR13 = VAR10 - VAR11;
           VAR12 = FUN5(VAR39, VAR40, VAR11, &VAR13);
           ++VAR27;
           if(VAR12 == VAR34) {
              goto VAR18;
           } else if(FUN4(VAR12)) {
              goto VAR35;
           }

           VAR11 += VAR13;
        } else {
           if (FUN2(VAR11, VAR10, 2))
              goto VAR18;
           *VAR11++ = (VAR5) VAR30;
           *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;
        }
        VAR14 = VAR54;
        break;

      case VAR55:  
        if(VAR16 == *VAR9) {
           VAR14 = VAR57;
        } else {
           if (FUN2(VAR11, VAR10, 1))
              goto VAR18;
           *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;

           VAR14 = VAR55;
        }
        break;

      case VAR57:  
        if(VAR53 == *VAR9) {
           VAR14 = VAR54;
           VAR27 = 0;
        } else if('' == *VAR9) {
           VAR14 = VAR19;
        } else {
           if (FUN2(VAR11, VAR10, 1))
              goto VAR18;
           *VAR11++ = (0x80 & *VAR9) ? 0xFFFD : (VAR5) *VAR9;

           VAR14 = VAR55;
        }
        break;

      case VAR58:
        FUN6("");
        goto VAR35;

    } 
    VAR9++;
  }

  *VAR7 = VAR11- VAR6;
  return VAR59;

VAR18:
  *VAR7 = VAR11-VAR6;
  *VAR4 = VAR9 - (const unsigned char*)VAR2;
  return VAR34;

VAR35:
  *VAR4 = VAR9 - (const unsigned char*)VAR2;
  *VAR7 = VAR11-VAR6;
  VAR14 = VAR15;
  return VAR60;
}