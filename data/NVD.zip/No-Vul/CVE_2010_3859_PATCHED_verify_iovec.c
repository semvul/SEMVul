int FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4, struct VAR5 *VAR6, int VAR7)  
{
	int VAR8, VAR9, VAR10;

	if (VAR2->VAR11) {
		if (VAR7 == VAR12) {
			VAR10 = FUN2(VAR2->VAR13, VAR2->VAR11,
						  VAR6);
			if (VAR10 < 0)
				return VAR10;
		}
		VAR2->VAR13 = VAR6;
	} else {
		VAR2->VAR13 = NULL;
	}

	VAR8 = VAR2->VAR14 * sizeof(struct VAR3);
	if (FUN3(VAR4, VAR2->VAR15, VAR8))
		return -VAR16;

	VAR2->VAR15 = VAR4;
	VAR10 = 0;

	for (VAR9 = 0; VAR9 < VAR2->VAR14; VAR9++) {
		size_t VAR17 = VAR4[VAR9].VAR18;

		if (VAR17 > VAR19 - VAR10) {
			VAR17 = VAR19 - VAR10;
			VAR4[VAR9].VAR18 = VAR17;
		}
		VAR10 += VAR17;
	}

	return VAR10;
}