static void * FUN1(struct VAR1 *VAR2, void *VAR3, VAR4 *VAR5)  
{
	struct VAR6 * VAR7 = VAR2->private;

	*VAR5 = ++VAR7->VAR8;
	return (VAR7->VAR8 < VAR7->VAR9) ? VAR7 : NULL;
}