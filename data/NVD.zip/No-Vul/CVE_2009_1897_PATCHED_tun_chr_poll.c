static unsigned int FUN1(struct VAR1 *VAR1, VAR2 * VAR3)  
{
	struct VAR4 *VAR5 = VAR1->VAR6;
	struct VAR7 *VAR8 = FUN2(VAR5);
	struct VAR9 *VAR10;
	unsigned int VAR11 = 0;

	if (!VAR8)
		return VAR12;

	VAR10 = VAR8->VAR10;

	FUN3(VAR13 "", VAR8->VAR14->VAR15);

	FUN4(VAR1, &VAR8->socket.VAR3, VAR3);

	if (!FUN5(&VAR8->VAR16))
		VAR11 |= VAR17 | VAR18;

	if (FUN6(VAR10) ||
	    (!FUN7(VAR19, &VAR10->VAR20->VAR21) &&
	     FUN6(VAR10)))
		VAR11 |= VAR22 | VAR23;

	if (VAR8->VAR14->VAR24 != VAR25)
		VAR11 = VAR12;

	FUN8(VAR8);
	return VAR11;
}