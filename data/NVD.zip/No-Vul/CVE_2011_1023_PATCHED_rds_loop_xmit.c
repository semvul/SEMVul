static int FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4, 			 unsigned int VAR5, unsigned int VAR6, 			 unsigned int VAR7)  
{
	struct VAR8 *VAR9 = &VAR4->VAR10.VAR11[VAR6];
	int VAR12 = sizeof(struct VAR13) +
			FUN2(VAR4->VAR14.VAR15.VAR16);

	
	if (VAR4->VAR14.VAR15.VAR17 & VAR18) {
		FUN3(VAR2->VAR19, ~(VAR20) 0);
		VAR12 = FUN4(int, VAR12, VAR9->VAR21 - VAR2->VAR22);
		goto VAR23;
	}

	FUN5(VAR5 || VAR6 || VAR7);

	FUN6(&VAR4->VAR14, VAR2, VAR2->VAR24);
	
	FUN7(VAR4);

	FUN8(VAR2, VAR2->VAR24, VAR2->VAR25, &VAR4->VAR14,
			  VAR26, VAR27);

	FUN9(VAR2, FUN10(VAR4->VAR14.VAR15.VAR28),
			    NULL);

	FUN11(&VAR4->VAR14);
VAR23:
	return VAR12;
}