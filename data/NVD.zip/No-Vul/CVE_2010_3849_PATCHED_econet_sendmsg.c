static int FUN1(struct VAR1 *VAR2, struct socket *VAR3, 			  struct VAR4 *VAR5, size_t VAR6)  
{
	struct VAR3 *VAR7 = VAR3->VAR7;
	struct VAR8 *VAR9=(struct VAR8 *)VAR5->VAR10;
	struct VAR11 *VAR12;
	struct ec_addr VAR13;
	int VAR14;
	unsigned char VAR15, VAR16;
#if FUN2(VAR17) || FUN2(VAR18)
	struct VAR19 *VAR20;
	struct VAR21 *VAR22;
#endif
#ifdef VAR17
	struct msghdr VAR23;
	struct iovec VAR24[VAR5->VAR25+1];
	struct aunhdr VAR26;
	struct sockaddr_in VAR27;
	__kernel_size_t VAR28;
	int VAR29;
	mm_segment_t VAR30;
#endif

	

	if (VAR5->VAR31 & ~(VAR32|VAR33))
		return -VAR34;

	

	FUN3(&VAR35);

        if (VAR9 == NULL || VAR5->VAR36 < sizeof(struct VAR8)) {
                FUN4(&VAR35);
                return -VAR34;
        }
        VAR13.VAR37 = VAR9->VAR13.VAR37;
        VAR13.VAR38 = VAR9->VAR13.VAR38;
        VAR15 = VAR9->VAR15;
        VAR16 = VAR9->VAR16;

	
	VAR12 = VAR39[VAR13.VAR38];

	
	if (VAR12 == NULL) {
		VAR12 = VAR39[0];
		
		if (VAR12 == NULL) {
			FUN4(&VAR35);
			return -VAR40;
		}
	}

	if (VAR6 + 15 > VAR12->VAR41) {
		FUN4(&VAR35);
		return -VAR42;
	}

	if (VAR12->VAR43 == VAR44) {
		
#ifdef VAR18
		unsigned short VAR45 = 0;
		int VAR46;

		FUN5(VAR12);

		VAR20 = FUN6(VAR7, VAR6+FUN7(VAR12),
					  VAR5->VAR31 & VAR32, &VAR14);
		if (VAR20==NULL)
			goto VAR47;

		FUN8(VAR20, FUN9(VAR12));
		FUN10(VAR20);

		VAR22 = (struct VAR21 *)&VAR20->VAR16;

		VAR22->VAR48 = VAR9->VAR48;
		VAR22->VAR49 = *VAR9;
		VAR22->VAR50 = VAR51;

		VAR14 = -VAR34;
		VAR46 = FUN11(VAR20, VAR12, FUN12(VAR45), &VAR13, NULL, VAR6);
		if (VAR46 < 0)
			goto VAR52;
		if (VAR46 > 0) {
			struct VAR53 *VAR54;
			
			VAR54 = (struct VAR53 *)(VAR20->VAR55);
			VAR54->VAR16 = VAR16;
			VAR54->VAR15 = VAR15;
			if (VAR3->VAR43 != VAR56) {
				FUN13(VAR20);
				VAR20->VAR6 = 0;
			}
		}

		
		VAR14 = FUN14(FUN15(VAR20,VAR6), VAR5->VAR57, VAR6);
		VAR20->VAR58 = VAR45;
		VAR20->VAR12 = VAR12;
		VAR20->VAR59 = VAR7->VAR60;
		if (VAR14)
			goto VAR52;

		VAR14 = -VAR40;
		if (!(VAR12->VAR61 & VAR62))
			goto VAR52;

		

		FUN16(VAR20);
		FUN17(VAR12);
		FUN4(&VAR35);
		return(VAR6);

	VAR52:
		FUN18(VAR20);
	VAR47:
		if (VAR12)
			FUN17(VAR12);
#else
		VAR14 = -VAR63;
#endif
		FUN4(&VAR35);

		return VAR14;
	}

#ifdef VAR17
	

	if (VAR64 == NULL) {
		FUN4(&VAR35);
		return -VAR40;		
	}

	

	memset(&VAR27, 0, sizeof(VAR27));
	VAR27.VAR65 = VAR66;
	VAR27.VAR67 = FUN19(VAR68);

	
	{
		struct VAR69 *VAR70;
		unsigned long VAR71 = 0;

		FUN20();
		VAR70 = FUN21(VAR12);
		if (VAR70) {
			if (VAR70->VAR72)
				VAR71 = FUN22(VAR70->VAR72->VAR73) &
					0xffffff00;		
		}
		FUN23();
		VAR27.VAR74.VAR75 = FUN24(VAR71 | VAR13.VAR37);
	}

	VAR26.VAR15 = VAR15;
	VAR26.VAR16 = VAR16 & 0x7f;
	VAR26.VAR76 = 2;		
	VAR26.VAR77 = 0;

	
	VAR28 = sizeof(struct VAR78);
	
	VAR24[0].VAR79 = (void *)&VAR26;
	VAR24[0].VAR80 = VAR28;
	for (VAR29 = 0; VAR29 < VAR5->VAR25; VAR29++) {
		void VAR81 *VAR82 = VAR5->VAR57[VAR29].VAR79;
		size_t VAR80 = VAR5->VAR57[VAR29].VAR80;
		
		if (!FUN25(VAR83, VAR82, VAR80)) {
			FUN4(&VAR35);
			return -VAR84;
		}
		VAR24[VAR29+1].VAR79 = VAR82;
		VAR24[VAR29+1].VAR80 = VAR80;
		VAR28 += VAR80;
	}

	
	if ((VAR20 = FUN6(VAR7, 0,
				       VAR5->VAR31 & VAR32,
				       &VAR14)) == NULL) {
		FUN4(&VAR35);
		return VAR14;
	}

	VAR22 = (struct VAR21 *)&VAR20->VAR16;

	VAR22->VAR48 = VAR9->VAR48;
	VAR22->VAR85 = (5*VAR86);
	VAR22->VAR87 = VAR88;
	VAR26.VAR89 = VAR90;
	VAR22->VAR91 = (VAR90++);
	VAR22->VAR49 = *VAR9;

	FUN26(&VAR92, VAR20);

	VAR23.VAR10 = (void *)&VAR27;
	VAR23.VAR36 = sizeof(VAR27);
	VAR23.VAR57 = &VAR24[0];
	VAR23.VAR25 = VAR5->VAR25 + 1;
	VAR23.VAR93 = NULL;
	VAR23.VAR94 = 0;
	VAR23.VAR31=0;

	VAR30 = FUN27(); FUN28(VAR95);	
	VAR14 = FUN29(VAR64, &VAR23, VAR28);
	FUN28(VAR30);
#else
	VAR14 = -VAR63;
#endif
	FUN4(&VAR35);

	return VAR14;
}