VAR1 * FUN1(const VAR2 *VAR3, int VAR4)  
{
  VAR1 *VAR5;
  VAR1 *VAR6;
  int VAR7 = 0;

  if (!VAR3)
    FUN2("");

  VAR5=FUN3(VAR8+3+1);
  if (VAR4 <= 0) { VAR5[0] = ''; return VAR5; }

  if (VAR4 > VAR8/2) {	
    VAR7 = 1;
    VAR4 = VAR8/2;
  }

  VAR6 = FUN4(VAR5, VAR3, VAR4);	

  if (VAR7)
    VAR6 = FUN5(VAR6, "");		

  *VAR6 = '';				
  return VAR5;
}