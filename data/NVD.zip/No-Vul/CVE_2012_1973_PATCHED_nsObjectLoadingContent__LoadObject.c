nsresult VAR1::FUN1(VAR2* VAR3,                                    bool VAR4,                                    const VAR5& VAR6,                                    bool VAR7)  
{
  FUN2(("",
       this, VAR3, VAR4, VAR6.FUN3(), VAR7));

  if (VAR8 && VAR3 && !VAR7) {
    bool VAR9;
    nsresult VAR10 = VAR8->FUN4(VAR3, &VAR9);
    if (FUN5(VAR10) && VAR9) {
      
      return VAR11;
    }
  }

  
  if (VAR12 == VAR13 && VAR14) {
    FUN2(("", this));
    VAR14 = VAR15;
  }

  VAR16 FUN6(this, VAR4);

  
  
  
  FUN7(!VAR17, "");
  VAR17 = true;
  VAR18 FUN8(this);

  VAR19 = VAR20 = false;

  VAR8 = VAR3;
  VAR21 = VAR6;

  VAR22<VAR23> VAR24 = 
    FUN9(static_cast<VAR25*>(this));
  FUN7(VAR24, "");

  VAR26* VAR27 = VAR24->FUN10();
  if (VAR27->FUN11()) {
    return VAR11;
  }

  
  
  if (VAR28) {
    FUN2(("", this));
    VAR22<VAR29> VAR30 = VAR28;
    VAR28 = VAR15;
    VAR22<VAR31> VAR32;
    VAR32.FUN12(VAR33);

    
    
    
    
    VAR30->FUN13(VAR34);
    if (VAR32) {
      
      
      
      VAR32->FUN14(VAR30, VAR15, VAR34);
    }
  }

  
  if (VAR27->FUN15()) {
    if (!VAR27->FUN16()) {
      FUN17(false);
    }
    return VAR11;
  }

  
  
  
  
  if (VAR3) {
    VAR35* VAR36 = VAR37::FUN18();
    FUN7(VAR36, "");
    nsresult VAR10 =
      VAR36->FUN19(VAR24->FUN20(), VAR3, 0);
    if (FUN21(VAR10)) {
      FUN17(false);
      return VAR11;
    }

    PRInt16 VAR38 = VAR39::VAR40; 
    VAR10 =
      FUN22(VAR39::VAR41,
                                VAR3,
                                VAR27->FUN20(),
                                static_cast<VAR25*>(this),
                                VAR6,
                                VAR15, 
                                &VAR38,
                                VAR37::FUN23(),
                                VAR36);
    if (FUN21(VAR10) || FUN24(VAR38)) {
      FUN25(VAR10, VAR38);
      return VAR11;
    }
  }

  nsresult VAR10 = VAR42;
  
  
  VAR43 FUN26(this, &VAR10);

  PRUint32 VAR44 = FUN27();
  FUN2(("", this, VAR44));

  nsCAutoString VAR45;
  if ((VAR44 & VAR46) &&
      ((!VAR6.FUN28() && FUN29(VAR6)) ||
       (VAR3 && FUN30(VAR3, VAR45)))) {
    ObjectType VAR47;
    if (VAR45.FUN28()) {
      VAR47 = FUN31(VAR6);
    } else {
      VAR21 = VAR45;
      VAR47 = VAR13;
    }

    if (VAR47 != VAR12) {
      FUN2(("", this, VAR12, VAR47));

      FUN32();

      
      
      if (!VAR48 && VAR47 == VAR49) {
        VAR48 = VAR50::FUN33(VAR24->FUN34(),
                                             VAR51);
        if (!VAR48) {
          VAR8 = VAR15;
          return VAR11;
        }
      }

      
      
      
      
      VAR12 = VAR47;
      if (VAR4)
        VAR52.FUN35();
    }
    switch (VAR47) {
      case VAR53:
        
        if (VAR3) {
          VAR10 = FUN36(VAR3, VAR7, false);
        } else {
          VAR10 = VAR54;
        }
        break;
      case VAR13:
        VAR10 = FUN37(VAR21, VAR8);
        break;
      case VAR49:
        if (VAR3) {
          VAR10 = VAR48->FUN38(VAR3);
        } else {
          VAR10 = VAR54;
        }
        break;
      case VAR55:
        FUN39("");
      case VAR56:
        
        FUN40(VAR24, VAR57, VAR6);
        break;
    };
    return VAR11;
  }

  
  
  bool VAR58 = false;
  nsCAutoString VAR59; 
  bool VAR60 = false;
  if (VAR44 & VAR61) {
    nsAutoString VAR62;
    VAR24->FUN41(VAR63, VAR64::VAR62, VAR62);
    if (!VAR62.FUN28()) {
      VAR60 = true;
      VAR58 = FUN5(FUN42(VAR62, VAR59));
    }
  }

  if (VAR60 && !VAR58) {
    
    FUN2(("", this));
    VAR10 = VAR54;
    return VAR11;
  }

  if (VAR58 ||
      (!VAR3 && !VAR6.FUN28() &&
       FUN31(VAR6) == VAR13)) {
    
    
    FUN2(("", this, VAR12));
    VAR12 = VAR13;

    
    
    
    
    
    FUN7(VAR21.FUN4(VAR6), "");
    FUN7(VAR8 == VAR3, "");

    if (VAR58) {
      
      FUN7(!VAR59.FUN28(), "");
      VAR21 = VAR59;
      
      
      
      FUN43(VAR24, FUN44(VAR8));
      if (!VAR8) {
        VAR8 = VAR3;
      }
    }

    VAR10 = FUN37(VAR21, VAR8);
    return VAR11;
  }

  if (!VAR3) {
    
    FUN2(("", this));
    VAR10 = VAR54;

    
    
    if (!VAR6.FUN28() && FUN31(VAR6) == VAR56) {
      FUN40(VAR24, VAR57, VAR6);
    }

    return VAR11;
  }

  
  if (!FUN45(VAR3)) {
    FUN2(("", this));
    if (VAR6.FUN28()) {
      VAR10 = VAR54;
      return VAR11;
    }

    if (FUN29(VAR6)) {
      VAR12 = VAR13;

      VAR10 = FUN37(VAR6, VAR3);
    } else {
      VAR10 = VAR54;
      
      FUN40(VAR24, VAR57, VAR6);
    }

    return VAR11;
  }

  VAR22<VAR65> VAR66 = VAR27->FUN46();
  VAR22<VAR29> VAR67;
  VAR22<VAR68> VAR69;
  VAR22<VAR70> VAR71;
  VAR10 = VAR27->FUN20()->FUN47(FUN44(VAR71));
  FUN48(VAR10, VAR10);
  if (VAR71) {
    VAR69 = FUN49("");
    VAR69->FUN50(VAR71);
    VAR69->FUN51(VAR39::VAR41);
  }
  VAR10 = FUN52(FUN44(VAR67), VAR3, VAR15, VAR66, this,
                     VAR29::VAR72 |
                     VAR29::VAR73,
                     VAR69);
  FUN48(VAR10, VAR10);

  
  VAR22<VAR74> FUN53(FUN9(VAR67));
  if (VAR75) {
    VAR75->FUN54(VAR27->FUN55());
  }

  
  if (!VAR6.FUN28()) {
    nsCAutoString VAR76, VAR77;
    FUN56(VAR6, VAR76, VAR77);
    if (!VAR76.FUN28()) {
      VAR67->FUN57(VAR76);
    }
  }

  
  VAR37::FUN58(VAR24->FUN20(),
                                    VAR67, VAR3, true);

  VAR22<VAR78> VAR79 = FUN9(VAR67);
  if (VAR79) {
    
    VAR79->
      FUN59(VAR78::VAR80);
  }

  
  
  VAR10 = VAR67->FUN60(this, VAR15);
  if (FUN5(VAR10)) {
    FUN2(("", this));

    VAR28 = VAR67;
    VAR12 = VAR55;
  }
  return VAR11;
}