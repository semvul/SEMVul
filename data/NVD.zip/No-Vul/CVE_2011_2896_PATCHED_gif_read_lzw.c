*/  static int				 FUN1(VAR1 *VAR2,			 	     int  VAR3,		  	     int  VAR4)	  
{
  int			VAR5,		
			VAR6,		
			VAR7;		
  static short		VAR8 = 0,	
			VAR9,	
			VAR10,	
			VAR11,	
			VAR12,	
			VAR13,	
			VAR14,	
			VAR15,	
			VAR16,	
			*VAR17 = NULL,	
			*VAR18;		
  static VAR19	*VAR20 = NULL;	


  if (VAR3)
  {
   

    VAR10 = VAR4;
    VAR9     = VAR10 + 1;
    VAR15    = 1 << VAR10;
    VAR16      = VAR15 + 1;
    VAR12 = 2 * VAR15;
    VAR11      = VAR15 + 2;

   

    if (VAR20 == NULL)
      VAR20 = calloc(2, sizeof(VAR19));

    if (VAR20 == NULL)
      return (-1);

    if (VAR17 == NULL)
      VAR17 = calloc(8192, sizeof(short));

    if (VAR17 == NULL)
      return (-1);

   

    FUN2(VAR2, 0, 1);

   

    VAR8 = 1;

    for (VAR5 = 1; VAR5 < VAR15; VAR5 ++)
      VAR20[1][VAR5] = VAR5;

    VAR18 = VAR17;

    return (0);
  }
  else if (VAR8)
  {
    VAR8 = 0;

    do
    {
      VAR13 = VAR14 = FUN2(VAR2, VAR9, 0);
    }
    while (VAR13 == VAR15);

    return (VAR13 & 255);
  }
  else if (!VAR20)
    return (0);

  if (VAR18 > VAR17)
    return ((*--VAR18) & 255);

  while ((VAR6 = FUN2(VAR2, VAR9, 0)) >= 0)
  {
    if (VAR6 == VAR15)
    {
     

      memset(VAR20, 0, 2 * sizeof(VAR19));
      for (VAR5 = 1; VAR5 < VAR15; VAR5 ++)
	VAR20[1][VAR5] = VAR5;

      VAR9     = VAR10 + 1;
      VAR12 = 2 * VAR15;
      VAR11      = VAR15 + 2;

      VAR18 = VAR17;

      VAR13 = VAR14 = FUN2(VAR2, VAR9, 0);

      return (VAR13 & 255);
    }
    else if (VAR6 == VAR16 || VAR6 > VAR11)
    {
      unsigned char	VAR21[260];	

      if (!VAR22)
        while (FUN3(VAR2, VAR21) > 0);

      return (-2);
    }

    VAR7 = VAR6;

    if (VAR6 == VAR11)
    {
      *VAR18++ = VAR13;
      VAR6  = VAR14;
    }

    while (VAR6 >= VAR15)
    {
      *VAR18++ = VAR20[1][VAR6];
      if (VAR6 == VAR20[0][VAR6])
	return (255);

      VAR6 = VAR20[0][VAR6];
    }

    *VAR18++ = VAR13 = VAR20[1][VAR6];
    VAR6  = VAR11;

    if (VAR6 < 4096)
    {
      VAR20[0][VAR6] = VAR14;
      VAR20[1][VAR6] = VAR13;
      VAR11 ++;

      if (VAR11 >= VAR12 && VAR12 < 4096)
      {
	VAR12 *= 2;
	VAR9 ++;
      }
    }

    VAR14 = VAR7;

    if (VAR18 > VAR17)
      return ((*--VAR18) & 255);
  }

  return (VAR6 & 255);
}