void VAR1::FUN1()  
{
  HANDLE VAR2[] = { VAR3, VAR4 };
  
  while (true) {
    DWORD VAR5 = ::FUN2(2, VAR2, VAR6, VAR7);
    if (VAR5 != VAR8) {
      return;
    }

    ::EnterCriticalSection(&VAR9);
    if (VAR10.FUN3() == 0) {
      FUN4("");
    }
    VAR11 *VAR12 = VAR10[0].FUN5();
    VAR10.FUN6(0);
    ::LeaveCriticalSection(&VAR9);

    
    
    D3D10_MAPPED_TEXTURE2D VAR13;
    VAR12->VAR14->FUN7(0, VAR15, 0, &VAR13);
    VAR12->VAR14->FUN8(0);

    
    
    
    VAR16<VAR17> VAR18 = FUN9();
    VAR18->FUN10(new FUN11(VAR12),
                     VAR19::VAR20);
  }
}