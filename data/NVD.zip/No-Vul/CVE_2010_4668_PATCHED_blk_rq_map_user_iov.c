int FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4, 			struct VAR5 *VAR6, struct VAR7 *VAR8, 			int VAR9, unsigned int VAR10, gfp_t VAR11)  
{
	struct VAR12 *VAR12;
	int VAR13, read = FUN2(VAR4) == VAR14;
	int VAR15 = 0;

	if (!VAR8 || VAR9 <= 0)
		return -VAR16;

	for (VAR13 = 0; VAR13 < VAR9; VAR13++) {
		unsigned long VAR17 = (unsigned long)VAR8[VAR13].VAR18;

		if (!VAR8[VAR13].VAR19)
			return -VAR16;

		if (VAR17 & FUN3(VAR2)) {
			VAR15 = 1;
			break;
		}
	}

	if (VAR15 || (VAR2->VAR20 & VAR10) || VAR6)
		VAR12 = FUN4(VAR2, VAR6, VAR8, VAR9, read,
					VAR11);
	else
		VAR12 = FUN5(VAR2, NULL, VAR8, VAR9, read, VAR11);

	if (FUN6(VAR12))
		return FUN7(VAR12);

	if (VAR12->VAR21 != VAR10) {
		
		FUN8(VAR12);
		FUN9(VAR12, 0);
		FUN10(VAR12);
		return -VAR16;
	}

	if (!FUN11(VAR12, VAR22))
		VAR4->VAR23 |= VAR24;

	FUN12(VAR2, &VAR12);
	FUN8(VAR12);
	FUN13(VAR2, VAR4, VAR12);
	VAR4->VAR25 = NULL;
	return 0;
}