VAR1 FUN1(struct VAR2 *VAR3, 			  const char VAR4 *VAR5, int VAR6, 			  int VAR7)  
{
	struct CVE_2010_4649_PATCHED_ib_uverbs_poll_cq       VAR8;
	struct ib_uverbs_poll_cq_resp  VAR9;
	u8 VAR4                     *VAR10;
	u8 VAR4                     *VAR11;
	struct VAR12                  *VAR13;
	struct ib_wc                   VAR14;
	int                            VAR15;

	if (FUN2(&VAR8, VAR5, sizeof VAR8))
		return -VAR16;

	VAR13 = FUN3(VAR8.VAR17, VAR3->VAR18, 0);
	if (!VAR13)
		return -VAR19;

	
	VAR10 = (void VAR4 *)(unsigned long) VAR8.VAR20;
	VAR11 = VAR10 + sizeof VAR9;

	memset(&VAR9, 0, sizeof VAR9);
	while (VAR9.VAR21 < VAR8.VAR22) {
		VAR15 = FUN4(VAR13, 1, &VAR14);
		if (VAR15 < 0)
			goto VAR23;
		if (!VAR15)
			break;

		VAR15 = FUN5(VAR11, &VAR14);
		if (VAR15)
			goto VAR23;

		VAR11 += sizeof(struct VAR24);
		++VAR9.VAR21;
	}

	if (FUN6(VAR10, &VAR9, sizeof VAR9)) {
		VAR15 = -VAR16;
		goto VAR23;
	}

	VAR15 = VAR6;

VAR23:
	FUN7(VAR13);
	return VAR15;
}