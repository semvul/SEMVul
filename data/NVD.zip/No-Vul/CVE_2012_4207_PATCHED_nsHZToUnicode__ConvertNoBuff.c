NS_IMETHODIMP VAR1::FUN1(   const char* VAR2,    VAR3 * VAR4,    VAR5 *VAR6,    VAR3 * VAR7)  
{
  PRInt32 VAR8=0;
  PRInt32 VAR9 = *VAR4;
  PRInt32 VAR10 = 0;
  *VAR4=0;
  nsresult VAR11 = VAR12;
  char VAR13 = VAR14;

  for (VAR8=0; VAR8<VAR9; VAR8++) {
    if (VAR10 >= (*VAR7)) {
      VAR11 = VAR15;
      break;
    }

    char VAR16 = *VAR2++;
    (*VAR4)++;
    
    if (!VAR17) {
      if (VAR16 == VAR18 || 
          (VAR19 == VAR20 && 
           (FUN2(0x21, VAR16, 0x7E) ||
            FUN2(0x81, VAR16, 0xFE)))) {
        VAR13 = VAR16;
        VAR21 |= VAR22;
      } else {
        *VAR6++ = (VAR16 & 0x80) ? VAR23 :
                                      FUN3(VAR16);
        VAR10++;
      }
    } else {
      if (VAR13 & 0x80) {
        
        FUN4(VAR19 == VAR20,
                     "");                    
        *VAR6++ = (FUN2(0x81, VAR13, 0xFE) &&
                    FUN2(0x40, VAR16, 0xFE)) ?
                     VAR24.FUN5(VAR13, VAR16) : VAR23;
        VAR25++;
        VAR10++;
      
      
      } else if (VAR13 == VAR18) { 
        switch (VAR16) {
          case VAR26: 
            
            
            VAR21 = VAR20;
            VAR25 = 0;
            break;

          case VAR27: 
            
            
            VAR21 = VAR28;
            if (VAR25 == 0) {
              *VAR6++ = VAR23;
              VAR10++;
            }
            VAR25 = 0;
            break;

          case VAR18: 
            
            *VAR6++ = FUN3(VAR16);
            VAR10++;
            VAR25++;
            break;

          default:
            
            
            
            
            
            
            
            
            if (VAR16 > 0x20 || VAR19 == VAR28) {
              *VAR6++ = VAR23;
              VAR10++;
            }
            VAR2--;
            (*VAR4)--;
            VAR8--;
            break;
        }
      } else if (VAR19 == VAR20) {
        *VAR6++ = (FUN2(0x21, VAR13, 0x7E) &&
                    FUN2(0x21, VAR16, 0x7E)) ?
                     VAR24.FUN5(VAR13|0x80, VAR16|0x80) :
                     VAR23;
        VAR25++;
        VAR10++;
      } else {
        FUN6("");
        *VAR6++ = VAR23;
        VAR10++;
      }
      VAR13 = 0;
      VAR21 &= ~VAR22;
    }
  } 
  VAR14 = VAR17 ? VAR13 : 0;
  *VAR7 = VAR10;
  return VAR11;
}