static int FUN1(VAR1 * VAR2,void *VAR3, int *VAR4,                              VAR5 *VAR6)  
{
    const VAR7 *VAR8 = VAR6->VAR3;
    int VAR9 = VAR6->VAR10;
    VAR11 *VAR12 = VAR2->VAR13;
    VAR14 *VAR15 = &VAR12->VAR15;
    int VAR16;
    const VAR7 *VAR17;
    const VAR7 *VAR18;
    VAR19 *VAR20 = VAR3;
    uint32_t VAR21 = -1;

    VAR15->VAR2 = VAR2;

    if (VAR9 == 0) {
        if(!VAR15->VAR22 && VAR12->VAR23[0].VAR3[0]) {
            *VAR4 = sizeof(VAR24);
            *VAR20 = *(VAR19 *) &VAR12->VAR23[0];
        }
        return 0;
    }

    VAR18 = VAR8;
    VAR17 = VAR8 + VAR9;
    for(;;) {
        VAR18 = FUN2(VAR18,VAR17, &VAR21);
        if((VAR21 & 0xFFFFFE00) || VAR18 == VAR17)
            return FUN3(0, VAR18 - VAR8 - VAR15->VAR25.VAR26);
        VAR16 = (VAR17 - VAR18)*8;
        switch(VAR21) {
        case VAR27:
            FUN4(&VAR15->VAR28, VAR18, VAR16);
            FUN5(VAR12);
            break;
        case VAR29:
            if(!VAR12->VAR30) {
                if(VAR12->VAR23[0].VAR3[0])
                    VAR2->FUN6(VAR2, (VAR19 *)&VAR12->VAR23[0]);
                if(VAR12->VAR23[1].VAR3[0])
                    VAR2->FUN6(VAR2, (VAR19 *)&VAR12->VAR23[1]);
                VAR12->VAR30 = 1;
            }
        case VAR31:
            *VAR4 = 0;
            if(!VAR12->VAR30)
                break;
            FUN4(&VAR15->VAR28, VAR18, VAR16);
            VAR12->VAR21 = VAR21;
            if(FUN7(VAR12))
                break;
            *VAR4 = sizeof(VAR24);
            if(VAR12->VAR32 != VAR33) {
                if(VAR12->VAR23[1].VAR3[0]) {
                    *VAR20 = *(VAR19 *) &VAR12->VAR23[1];
                } else {
                    *VAR4 = 0;
                }
            } else
                *VAR20 = *(VAR19 *) &VAR12->VAR20;
            break;
        case VAR34:
            
            break;
        case VAR35:
            
            break;
        default:
            if (VAR21 <= VAR36) {
                FUN4(&VAR15->VAR28, VAR18, VAR16);
                FUN8(VAR12, &VAR15->VAR28);
            }
            break;
        }
    }
}