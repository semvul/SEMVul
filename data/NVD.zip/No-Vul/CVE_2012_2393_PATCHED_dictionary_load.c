static int FUN1(void)  
{
	VAR1* VAR2;
	VAR3* VAR4;
	VAR5* VAR6;
	VAR7* VAR8;
	VAR9* VAR10;
	VAR11* VAR12;
	gboolean VAR13 = getenv("") ? VAR14 : VAR15;
	gboolean VAR16 = getenv("") ? VAR14 : VAR15;
	char* VAR17 = FUN2("" VAR18 "" VAR18, FUN3());
	const VAR19* VAR20;
	const VAR19* VAR21 = &VAR22[0];
	VAR23* VAR24;
	VAR25* VAR26 = FUN4(VAR27,VAR28);
	VAR29* VAR30;
	VAR31* VAR32 = FUN5(VAR14,VAR14,sizeof(VAR33));

	VAR34.VAR35 = FUN5(VAR15,VAR14,sizeof(VAR36));
	VAR34.VAR37 = FUN6();
	VAR34.VAR38 = FUN4(VAR27,VAR28);
	VAR34.VAR39 = FUN4(VAR27,VAR28);

	VAR40.VAR41 = FUN7(VAR42,"");
	VAR40.VAR39 = FUN7(VAR42,"");

	VAR43.VAR44 = FUN5(VAR14,VAR14,sizeof(VAR33));
	VAR43.VAR45 = FUN5(VAR14,VAR14,sizeof(VAR33));
	VAR46.VAR44 = FUN5(VAR14,VAR14,sizeof(VAR33));
	VAR46.VAR45 = FUN5(VAR14,VAR14,sizeof(VAR33));

	VAR47 = FUN5(VAR14,VAR14,sizeof(VAR33));

	FUN8(VAR40.VAR41,0,&VAR46);
	FUN9(VAR26,(VAR48 *)"",&VAR46);

	
	for (VAR20 = VAR22; VAR20->VAR49; VAR20++) {
		FUN9(VAR34.VAR38,(VAR48 *)VAR20->VAR49,(void*)VAR20);
	}

	
	VAR2 = FUN10(VAR17,"",VAR13);
	if (VAR2 == NULL) {
		return 0;
	}

	if (VAR16) FUN11(VAR50, VAR2);

	
	for (VAR10 = VAR2->VAR51; VAR10; VAR10 = VAR10->VAR52) {
		const VAR19* VAR53 = NULL;
		

		if (VAR10->VAR49 == NULL) {
			fprintf(VAR54,"",
				VAR10->VAR53 ? VAR10->VAR53 : "");
			continue;
		}


		if (FUN12(VAR34.VAR38,VAR10->VAR49))
			continue;

		if (VAR10->VAR53) {
			VAR53 = FUN12(VAR34.VAR38,VAR10->VAR53);
		}

		if (!VAR53) VAR53 = VAR21;

		
		FUN9(VAR34.VAR38,VAR10->VAR49,(void*)VAR53);
	}

	
	if ((VAR4 = VAR2->VAR55)) {
		VAR31* VAR56 = FUN5(VAR14,VAR14,sizeof(VAR33));

		for (; VAR4; VAR4 = VAR4->VAR52) {
			value_string VAR57 = {VAR4->VAR58,VAR4->VAR49};
			FUN13(VAR56,VAR57);
		}

		VAR40.VAR55 = (void*)VAR56->VAR59;
		FUN14(VAR56,VAR15);
	}

	if ((VAR6 = VAR2->VAR26)) {
		for ( ; VAR6; VAR6 = VAR6->VAR52) {
			value_string VAR57 = {VAR6->VAR58,VAR6->VAR49};

			if (VAR6->VAR49 == NULL) {
				fprintf(VAR54,"",VAR6->VAR58);
				continue;
			}

			if (FUN12(VAR26,VAR6->VAR49))
				continue;

			FUN13(VAR32,VAR57);

			VAR30 = FUN15(sizeof(VAR29));
			VAR30->VAR58 = VAR6->VAR58;
			VAR30->VAR44 = FUN5(VAR14,VAR14,sizeof(VAR33));
			VAR30->VAR45 = FUN5(VAR14,VAR14,sizeof(VAR33));
			VAR30->VAR60 = NULL;
			FUN8(VAR40.VAR41,VAR30->VAR58,VAR30);
			FUN9(VAR26,VAR6->VAR49,VAR30);
		}
	}

	VAR61 = (void*)VAR32->VAR59;
	FUN14(VAR32,VAR15);

	if ((VAR8 = VAR2->VAR62)) {
		for (; VAR8; VAR8 = VAR8->VAR52) {
			if (VAR8->VAR63 == NULL) {
				fprintf(VAR54,"",
					VAR8->VAR49 ? VAR8->VAR49 : "");
				continue;
			}

			if ((VAR30 = FUN12(VAR26,VAR8->VAR63))) {
				value_string VAR57 = {VAR8->VAR58,VAR8->VAR49};
				FUN13(VAR30->VAR44,VAR57);
				
				FUN13(VAR47,VAR57);
			} else {
				fprintf(VAR54,"",VAR8->VAR63);
			}
		}
	}


	for (VAR12 = VAR2->VAR39; VAR12; VAR12 = VAR12->VAR52) {
		VAR64* VAR65;
		VAR33* VAR66 = NULL;
		const char* VAR67 = VAR12->VAR63 ? VAR12->VAR63 : "";
		VAR68* VAR69;
		void* VAR70 = NULL;

		if (VAR12->VAR49 == NULL) {
			fprintf(VAR54,"");
			continue;
		}

		if ((VAR30 = FUN12(VAR26,VAR67))) {
			value_string VAR71 = {VAR12->VAR58,VAR12->VAR49};
			FUN13(VAR30->VAR45,VAR71);
		} else {
			fprintf(VAR54,"",VAR67);
			VAR30 = &VAR43;
		}

		if ((VAR65 = VAR12->VAR72)) {
			VAR31* VAR56 = FUN5(VAR14,VAR14,sizeof(VAR33));

			for (; VAR65; VAR65 = VAR65->VAR52) {
				value_string VAR57 = {VAR65->VAR58,VAR65->VAR49};
				FUN13(VAR56,VAR57);
			}
			FUN16(VAR56, VAR73);
			VAR66 = (void*)VAR56->VAR59;
		}

		VAR20 = NULL;

		for( VAR69 = VAR2->VAR74; VAR69; VAR69 = VAR69->VAR52 ) {
			if ( (FUN17(VAR69->VAR49,"") && FUN17(VAR69->VAR75,VAR12->VAR49))
				 || (VAR12->VAR20 && FUN17(VAR69->VAR49,"") && FUN17(VAR69->VAR75,VAR12->VAR20))
				 ) {
				static avp_type_t VAR76 = {"", VAR77, VAR77, VAR78, VAR79, VAR80};
				VAR20 =  &VAR76;

				VAR70 = VAR69->VAR81;
				break;
			}
		}

		if ( (!VAR20) && VAR12->VAR20 )
			VAR20 = FUN12(VAR34.VAR38,VAR12->VAR20);

		if (!VAR20) VAR20 = VAR21;

		VAR24 = VAR20->FUN18( VAR20, VAR12->VAR58, VAR30, VAR12->VAR49, VAR66, VAR70);
		if (VAR24 != NULL) {
			FUN9(VAR34.VAR39, VAR12->VAR49, VAR24);

			{
				emem_tree_key_t VAR82[] = {
					{ 1, &(VAR12->VAR58) },
					{ 1, &(VAR30->VAR58) },
					{ 0 , NULL }
				};
				FUN19(VAR40.VAR39,VAR82,VAR24);
			}
		}
	}
	FUN20(VAR34.VAR38);
	FUN20(VAR34.VAR39);
	FUN20(VAR26);

	return 1;
}