static VAR1 FUN1(VAR2 *VAR3, VAR4 *VAR5, JSBool VAR6,                    VAR7 *VAR8, VAR9 *VAR10)  
{
    static const jschar VAR11 = '';
    const VAR12 *VAR13;
    size_t VAR14;
    if (VAR8) {
        VAR14 = VAR8->FUN2();
        VAR13 = VAR8->FUN3(VAR3);
        if (!VAR13)
            return false;
    } else {
        VAR13 = &VAR11;
        VAR14 = 1;
    }

    VAR15 FUN4(VAR3, VAR5);
    if (!VAR16.FUN5())
        return false;

    if (VAR16.FUN6()) {
        VAR10->FUN7(VAR3->VAR17->VAR18.VAR19);
        return true;
    }

    jsuint VAR20;
    if (!FUN8(VAR3, VAR5, &VAR20))
        return false;

    VAR21 FUN9(VAR3);

    if (!VAR6 && !VAR14 && VAR5->FUN10() && !FUN11(VAR3, VAR5)) {
        const VAR9 *VAR22 = VAR5->FUN12();
        const VAR9 *VAR23 = VAR22 + VAR5->FUN13();
        const VAR9 *VAR24;
        for (VAR24 = VAR22; VAR24 < VAR23; VAR24++) {
            if (!FUN14(VAR3))
                return false;

            
            if (VAR24->FUN15())
                break;

            if (!VAR24->FUN16(VAR25) && !VAR24->FUN17()) {
                if (!FUN18(VAR3, *VAR24, VAR26))
                    return false;
            }
        }

        for (uint32_t VAR27 = FUN19(FUN20(VAR22, VAR24)); VAR27 < VAR20; VAR27++) {
            if (!FUN14(VAR3))
                return false;

            JSBool VAR28;
            Value VAR29;
            if (!FUN21(VAR3, VAR5, VAR27, &VAR28, &VAR29))
                return false;
            if (!VAR28 && !VAR29.FUN17()) {
                if (!FUN18(VAR3, VAR29, VAR26))
                    return false;
            }
        }
    } else {
        for (jsuint VAR30 = 0; VAR30 < VAR20; VAR30++) {
            if (!FUN14(VAR3))
                return false;

            JSBool VAR28;
            if (!FUN21(VAR3, VAR5, VAR30, &VAR28, VAR10))
                return false;

            if (!VAR28 && !VAR10->FUN17()) {
                if (VAR6) {
                    VAR4 *VAR31 = FUN22(VAR3, VAR10);
                    if (!VAR31)
                        return false;
                    jsid VAR32 = FUN23(VAR3->VAR17->VAR18.VAR33);
                    if (!VAR31->FUN24(VAR3, VAR32, 0, NULL, VAR10))
                        return false;
                }
                if (!FUN18(VAR3, *VAR10, VAR26))
                    return false;
            }

            if (VAR30 + 1 != VAR20) {
                if (!VAR26.FUN25(VAR13, VAR14))
                    return false;
            }
        }
    }

    VAR7 *VAR34 = VAR26.FUN26();
    if (!VAR34)
        return false;
    VAR10->FUN7(VAR34);
    return true;
}