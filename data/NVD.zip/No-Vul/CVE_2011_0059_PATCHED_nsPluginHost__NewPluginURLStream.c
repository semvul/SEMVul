nsresult VAR1::FUN1(const VAR2& VAR3,                                           VAR4 *VAR5,                                           VAR6* VAR7,                                           const char *VAR8,                                           PRBool VAR9,                                           PRUint32 VAR10,                                           const char *VAR11,                                           PRUint32 VAR12)  
{
  VAR13<VAR14> VAR15;
  nsAutoString VAR16;
  nsresult VAR17;

  if (VAR3.FUN2() <= 0)
    return VAR18;

  
  
  VAR13<VAR19> VAR20;
  VAR13<VAR21> VAR22;
  VAR5->FUN3(FUN4(VAR22));
  if (VAR22) {
    VAR17 = VAR22->FUN5(FUN4(VAR20));
    if (FUN6(VAR17) && VAR20) {
      
      VAR17 = FUN7(VAR16, VAR3, VAR20->FUN8());
    }
  }

  if (VAR16.FUN9())
    VAR16.FUN10(VAR3);

  VAR17 = FUN11(FUN4(VAR15), VAR16);

  if (FUN6(VAR17)) {
    VAR13<VAR23> VAR24 = FUN12(VAR22);
    VAR13<VAR25> VAR26;
    if (VAR24)
      VAR24->FUN13(FUN4(VAR26));

    PRInt16 VAR27 = VAR28::VAR29;
    VAR17 = FUN14(VAR28::VAR30,
                                   VAR15,
                                   (VAR20 ? VAR20->FUN15() : VAR31),
                                   VAR26,
                                   FUN16(), 
                                   VAR31,         
                                   &VAR27);
    if (FUN17(VAR17)) return VAR17;
    if (FUN18(VAR27)) {
      
      return VAR32;
    }

    VAR33<VAR34> VAR35 = new FUN19();
    if (VAR35 == NULL)
      return VAR36;

    VAR17 = VAR35->FUN20(VAR15, VAR5, VAR7);

    if (FUN6(VAR17)) {
      VAR13<VAR37> VAR38 = FUN21("");
      FUN22(VAR38, VAR36);

      VAR13<VAR39> VAR40 = VAR38->FUN23();
      FUN22(VAR40, VAR36);

      VAR13<VAR41> VAR42;
      VAR17 = FUN24(FUN4(VAR42), VAR15, VAR31,
        VAR31, 
        VAR40);
      if (FUN17(VAR17))
        return VAR17;

      if (VAR20) {
        
        VAR42->FUN25(VAR20->FUN15());

        
        
        VAR13<VAR43> FUN26(FUN12(VAR42));
        if (VAR44) {
          VAR44->FUN27(VAR43::VAR45);
          
          VAR44->FUN28(VAR46);
        }
      }

      
      VAR13<VAR47> FUN29(FUN12(VAR42));
      if (VAR48) {
        if (VAR8) {

          VAR13<VAR49> VAR50;
          VAR17 = FUN30(FUN4(VAR50), (const char*)VAR8,
                                          VAR10, VAR9);

          if (!VAR50) {
            FUN31(VAR5);
            return VAR51;
          }

          
          
          
          VAR13<VAR52>
          FUN32(FUN12(VAR50));
          if (VAR53)
            VAR53->FUN33(VAR52::VAR54, 0);

          VAR13<VAR55> FUN34(FUN12(VAR48));
          FUN35(VAR56, "");

          VAR56->FUN36(VAR50, FUN16(), -1);
        }

        if (VAR11)
          VAR17 = FUN37(VAR11, VAR12, VAR48);
      }
      VAR17 = VAR42->FUN38(VAR35, VAR31);
    }
  }
  return VAR17;
}