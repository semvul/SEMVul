static bool FUN1(struct VAR1 *VAR2, 			       struct VAR3 *VAR4, 			       int *VAR5, int VAR6)  
{
	struct VAR7 *VAR8 = &VAR2->VAR8;
	struct VAR9 *VAR10 = VAR2->VAR10;
	struct VAR11 *VAR12 = VAR2->VAR12;
	struct VAR13 *VAR14, *VAR15;
	struct VAR16 *VAR17, *VAR18;
	unsigned long VAR19;
	u32 VAR20;
	u8 VAR21;
	unsigned int VAR22;
	int VAR23 = 0;
	bool VAR24 = false;
	unsigned int VAR25=0, VAR26=0;

	VAR22 = VAR4->VAR27;
	VAR14 = FUN2(*VAR4, VAR22);
	VAR17 = &VAR4->VAR17[VAR22];

	while (VAR14->VAR28 & VAR29) {
		struct VAR30 *VAR31;
		u8 VAR28;

		if (*VAR5 >= VAR6)
			break;
		(*VAR5)++;

		VAR28 = VAR14->VAR28;
		VAR31 = VAR17->VAR31;
		VAR17->VAR31 = NULL;

		FUN3(VAR31->VAR32 - VAR33);

		if (++VAR22 == VAR4->VAR34) VAR22 = 0;
		VAR15 = FUN2(*VAR4, VAR22);
		FUN3(VAR15);

		VAR18 = &VAR4->VAR17[VAR22];

		VAR24 = true;
		VAR23++;
		FUN4(VAR12,
		                 VAR17->VAR35,
		                 VAR17->VAR20,
		                 VAR36);

		VAR20 = FUN5(VAR14->VAR20);
		
		if (FUN6(!(VAR28 & VAR37) || (VAR20 <= 4))) {
			
			FUN7(""
				  "", VAR10->VAR38);
			
			VAR17->VAR31 = VAR31;
			goto VAR39;
		}

		if (FUN6(VAR14->VAR40 & VAR41)) {
			VAR21 = *(VAR31->VAR32 + VAR20 - 1);
			if (FUN8(VAR8, VAR28, VAR14->VAR40, VAR20,
				       VAR21)) {
				FUN9(&VAR2->VAR42, VAR19);
				FUN10(VAR8, &VAR2->VAR43,
				                       VAR20, VAR31->VAR32);
				FUN11(&VAR2->VAR42,
				                       VAR19);
				VAR20--;
			} else {
				
				VAR17->VAR31 = VAR31;
				goto VAR39;
			}
		}

		
		VAR20 -= 4;

		
		VAR25 += VAR20;
		VAR26++;

		
		if (VAR20 < VAR44) {
			struct VAR30 *VAR45 =
			    FUN12(VAR10, VAR20 + VAR33);
			if (VAR45) {
				FUN13(VAR45, VAR33);
				FUN14(VAR45,
							       -VAR33,
							       (VAR31->VAR32 -
							        VAR33),
							       (VAR20 +
							        VAR33));
				
				VAR17->VAR31 = VAR31;
				VAR31 = VAR45;
			}
			
		}
		
		FUN15(VAR31, VAR20);

		
		FUN16(VAR2,
				  (VAR46)(VAR28) |
				  ((VAR46)(VAR14->VAR40) << 24),
				  FUN5(VAR14->VAR47), VAR31);

		VAR31->VAR48 = FUN17(VAR31, VAR10);

		if (FUN6(VAR2->VAR49 &&
			    (VAR28 & VAR50))) {
			FUN18(VAR31, VAR2->VAR49,
						 FUN5(VAR14->VAR51));
		} else {
			FUN19(VAR31);
		}

VAR39:
		VAR14->VAR28 = 0;

		
		if (FUN6(VAR23 >= VAR52)) {
			VAR2->FUN20(VAR2, VAR4, VAR23);
			VAR23 = 0;
		}

		
		VAR14 = VAR15;
		VAR17 = VAR18;
	}
	VAR4->VAR27 = VAR22;

	VAR23 = FUN21(VAR4);
	if (VAR23)
		VAR2->FUN20(VAR2, VAR4, VAR23);

	VAR2->VAR26 += VAR26;
	VAR2->VAR25 += VAR25;
	VAR2->VAR53.VAR54 += VAR25;
	VAR2->VAR53.VAR55 += VAR26;
	return VAR24;
}