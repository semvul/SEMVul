static int FUN1(struct socket *VAR1, struct VAR2 *VAR3, 	int *VAR4, int VAR5)  
{
	struct VAR6 *VAR7 = (struct VAR6 *)VAR3;
	struct VAR1 *VAR8 = VAR1->VAR8;
	unsigned char VAR9, VAR10;
	VAR11 *VAR12;
	int VAR13 = 0;

	memset(VAR7, 0, sizeof(VAR7));
	FUN2(VAR8);
	VAR12 = FUN3(VAR8);

	if (VAR5 != 0) {
		if (VAR8->VAR14 != VAR15) {
			VAR13 = -VAR16;
			goto VAR17;
		}

		VAR7->VAR18.VAR19 = VAR20;
		VAR7->VAR18.VAR21   = VAR12->VAR22;

		if (VAR12->VAR23 != NULL) {
			VAR9 = VAR12->VAR23->VAR9;
			VAR7->VAR18.VAR24 = VAR9;
			for (VAR10 = 0; VAR10 < VAR9; VAR10++)
				VAR7->VAR25[VAR10] =
						VAR12->VAR23->VAR26[VAR10];
		}
	} else {
		VAR7->VAR18.VAR19 = VAR20;
		VAR7->VAR18.VAR21   = VAR12->VAR27;
		VAR7->VAR18.VAR24 = 1;
		if (VAR12->VAR28 != NULL) {
			memcpy(&VAR7->VAR25[0],
			       VAR12->VAR28->VAR29->VAR30, VAR31);
		} else {
			VAR7->VAR25[0] = VAR32;
		}
	}
	*VAR4 = sizeof (struct VAR6);

VAR17:
	FUN4(VAR8);

	return VAR13;
}