VAR1::VAR2* VAR3::FUN1(VAR4* VAR5,                                   VAR6* VAR7,                                   PRBool VAR8,                                   PRBool VAR9)  
{
  nsCString VAR10;
  if (!FUN2(VAR5, VAR7, VAR8, VAR10)) {
    FUN3("");
    return VAR11;
  }

  VAR2* VAR12;

  if (VAR13.FUN4(VAR10, &VAR12)) {
    

    
    FUN5(VAR12);
    FUN6(VAR12, &VAR14);

    return VAR12;
  }

  if (!VAR9) {
    return VAR11;
  }

  
  
  VAR12 = new FUN7(VAR10);
  if (!VAR12) {
    FUN3("");
    return VAR11;
  }

  FUN8(VAR13.FUN9() <= VAR15,
               "");

  
  if (VAR13.FUN9() == VAR15) {
    
    PRTime VAR16 = FUN10();
    VAR13.FUN11(VAR17, &VAR16);

    
    
    if (VAR13.FUN9() == VAR15) {
      VAR2* VAR18 = static_cast<VAR2*>(FUN12(&VAR14));
      FUN5(VAR18);

      
      VAR13.FUN13(VAR18->VAR19);

      FUN8(VAR13.FUN9() == VAR15 - 1,
                   "");
    }
  }
  
  if (!VAR13.FUN14(VAR10, VAR12)) {
    
    delete VAR12;

    FUN3("");
    return VAR11;
  }

  FUN6(VAR12, &VAR14);

  return VAR12;
}