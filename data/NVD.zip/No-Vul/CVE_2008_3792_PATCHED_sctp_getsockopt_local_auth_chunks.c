static int FUN1(struct VAR1 *VAR2, int VAR3, 				    char VAR4 *VAR5, int VAR4 *VAR6)  
{
	struct sctp_authchunks VAR4 *VAR7 = (void VAR4 *)VAR5;
	struct sctp_authchunks VAR8;
	struct VAR9 *VAR10;
	struct VAR11 *VAR12;
	u32    VAR13 = 0;
	char VAR4 *VAR14;

	if (!VAR15)
		return -VAR16;

	if (VAR3 < sizeof(struct VAR17))
		return -VAR18;

	if (FUN2(&VAR8, VAR5, sizeof(struct VAR17)))
		return -VAR19;

	VAR14 = VAR7->VAR20;
	VAR10 = FUN3(VAR2, VAR8.VAR21);
	if (!VAR10 && VAR8.VAR21 && FUN4(VAR2, VAR22))
		return -VAR18;

	if (VAR10)
		VAR12 = (struct VAR11*)VAR10->VAR23.VAR24;
	else
		VAR12 = FUN5(VAR2)->VAR25->VAR26;

	if (!VAR12)
		goto VAR27;

	VAR13 = FUN6(VAR12->VAR28.VAR29) - sizeof(VAR30);
	if (VAR3 < sizeof(struct VAR17) + VAR13)
		return -VAR18;

	if (FUN7(VAR14, VAR12->VAR31, VAR13))
		return -VAR19;
VAR27:
	VAR3 = sizeof(struct VAR17) + VAR13;
	if (FUN8(VAR3, VAR6))
		return -VAR19;
	if (FUN8(VAR13, &VAR7->VAR32))
		return -VAR19;

	return 0;
}