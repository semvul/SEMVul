int FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4, 			  struct VAR5 *VAR6, unsigned VAR7)  
{
	struct VAR8 *VAR9 = FUN2(VAR2);
	struct VAR10 *VAR11 = FUN3(VAR2);
	int VAR12 = 0;

	VAR9->VAR13.VAR14 = 0;

	switch (VAR2->VAR15) {
	case VAR16:
		goto VAR17;

	case VAR18:
		if(VAR6->VAR19)
			return 1;

		if(VAR6->VAR20)
			goto VAR17;

		if(VAR6->VAR21) {
			if (VAR11->VAR22->FUN4(VAR2, VAR4) < 0)
				return 1;

			
			FUN5(VAR4);
			return 0;
		}
		goto VAR17;

	case VAR23:
		VAR12 = FUN6(VAR2, VAR4, VAR6, VAR7);
		if (VAR12 >= 0)
			return VAR12;

		
		FUN7(VAR2, VAR4, VAR6);
		FUN8(VAR4);
		FUN9(VAR2, VAR9);
		return 0;
	}

	if (FUN10(VAR4, VAR6, VAR9) && VAR9->VAR13.VAR14 &&
	    FUN11(VAR2, VAR4)) {
		if (!VAR6->VAR20) {
			FUN12(VAR24);
			FUN13(VAR2, VAR4);
			goto VAR17;
		}
		
	}

	
	if (!FUN14(VAR9, FUN15(VAR4)->VAR25, FUN15(VAR4)->VAR26)) {
		if (!VAR6->VAR20)
			FUN13(VAR2, VAR4);
		goto VAR17;
	}

	
	if(VAR6->VAR20) {
		FUN16(VAR2);
		goto VAR17;
	}

	FUN17(VAR9, FUN15(VAR4)->VAR25);

	

	
	if (VAR6->VAR21 && !FUN18(FUN15(VAR4)->VAR25, VAR9->VAR27)) {
		FUN12(VAR28);
		FUN16(VAR2);
		return 1;
	}

	
	if (VAR6->VAR19) {
		int VAR29 = FUN19(VAR2, VAR4, VAR30);

		switch(VAR2->VAR15) {
		case VAR31:
			if (VAR29) {
				VAR9->VAR32 = VAR9->VAR27;
				FUN20();
				FUN21(VAR2, VAR33);
				VAR2->FUN22(VAR2);

				
				if (VAR2->VAR34) {
					FUN23(VAR2,0,VAR35);
				}

				VAR9->VAR36 = FUN15(VAR4)->VAR37;
				VAR9->VAR38 = FUN24(VAR6->VAR39) <<
					      VAR9->VAR13.VAR40;
				FUN25(VAR9, FUN15(VAR4)->VAR37,
					    FUN15(VAR4)->VAR25);

				
				if (VAR9->VAR13.VAR14 && VAR9->VAR13.VAR41 &&
				    !VAR9->VAR42)
					FUN26(VAR2, 0);

				if (VAR9->VAR13.VAR43)
					VAR9->VAR44 -= VAR45;

				
				VAR11->VAR22->FUN27(VAR2);

				FUN28(VAR2);

				FUN29(VAR2);

				
				VAR9->VAR46 = VAR47;

				FUN30(VAR2);
				FUN31(VAR2);
				FUN32(VAR2);
				FUN33(VAR9);
			} else {
				return 1;
			}
			break;

		case VAR48:
			if (VAR9->VAR36 == VAR9->VAR49) {
				FUN21(VAR2, VAR50);
				VAR2->VAR51 |= VAR52;
				FUN34(VAR2->VAR53);

				if (!FUN35(VAR2, VAR54))
					
					VAR2->FUN22(VAR2);
				else {
					int VAR55;

					if (VAR9->VAR56 < 0 ||
					    (FUN15(VAR4)->VAR26 != FUN15(VAR4)->VAR25 &&
					     FUN36(FUN15(VAR4)->VAR26 - VAR6->VAR57, VAR9->VAR27))) {
						FUN37(VAR2);
						FUN12(VAR58);
						return 1;
					}

					VAR55 = FUN38(VAR2);
					if (VAR55 > VAR59) {
						FUN39(VAR2, VAR55 - VAR59);
					} else if (VAR6->VAR57 || FUN40(VAR2)) {
						
						FUN39(VAR2, VAR55);
					} else {
						FUN41(VAR2, VAR50, VAR55);
						goto VAR17;
					}
				}
			}
			break;

		case VAR60:
			if (VAR9->VAR36 == VAR9->VAR49) {
				FUN41(VAR2, VAR61, 0);
				goto VAR17;
			}
			break;

		case VAR62:
			if (VAR9->VAR36 == VAR9->VAR49) {
				FUN42(VAR2);
				FUN37(VAR2);
				goto VAR17;
			}
			break;
		}
	} else
		goto VAR17;

	
	FUN7(VAR2, VAR4, VAR6);

	
	switch (VAR2->VAR15) {
	case VAR63:
	case VAR60:
	case VAR62:
		if (!FUN18(FUN15(VAR4)->VAR25, VAR9->VAR27))
			break;
	case VAR48:
	case VAR50:
		
		if (VAR2->VAR51 & VAR64) {
			if (FUN15(VAR4)->VAR26 != FUN15(VAR4)->VAR25 &&
			    FUN36(FUN15(VAR4)->VAR26 - VAR6->VAR57, VAR9->VAR27)) {
				FUN12(VAR58);
				FUN16(VAR2);
				return 1;
			}
		}
		
	case VAR33: 
		FUN43(VAR2, VAR4);
		VAR12 = 1;
		break;
	}

	
	if (VAR2->VAR15 != VAR16) {
		FUN9(VAR2, VAR9);
		FUN44(VAR2);
	}

	if (!VAR12) { 
VAR17:
		FUN8(VAR4);
	}
	return 0;
}