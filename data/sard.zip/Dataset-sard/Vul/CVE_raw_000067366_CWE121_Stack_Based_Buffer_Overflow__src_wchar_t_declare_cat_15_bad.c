void FUN1()
{
    wchar_t * VAR1;
    wchar_t VAR2[100];
    VAR1 = VAR2;
    switch(6)
    {
    case 6:
        
        wmemset(VAR1, VAR3'', 100-1); 
        VAR1[100-1] = VAR3''; 
        break;
    default:
        
        FUN2("");
        break;
    }
    {
        wchar_t VAR4[50] = VAR3"";
        
        wcscat(VAR4, VAR1);
        FUN3(VAR1);
    }
}