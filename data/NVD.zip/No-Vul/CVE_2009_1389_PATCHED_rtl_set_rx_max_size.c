static void FUN1(void VAR1 *VAR2, unsigned int VAR3)  
{
	
	FUN2(VAR4, VAR3);
}