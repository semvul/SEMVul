NS_IMETHODIMP VAR1::FUN1(const char* VAR2,                                             VAR3 * VAR4,                                             VAR5 *VAR6,                                             VAR3 * VAR7)  
{
  PRInt32 VAR8=0;
  PRInt32 VAR9 = (*VAR4);
  PRInt32 VAR10 = 0;
  nsresult VAR11=VAR12;
  *VAR4 = 0;
  
  for (VAR8=0;VAR8<VAR9;VAR8++)
  {
    if ( VAR10 >= (*VAR7) )
    {
      VAR11 = VAR13;
      break;
    }
    
    if(FUN2(*VAR2))
    {
      if(VAR8+1 >= VAR9) 
      {
        VAR11 = VAR14;
        break;
      }
      
      
      if(FUN3(VAR2[1]))
      {
        
        *VAR6 = VAR15.FUN4(VAR2[0], VAR2[1]);
        if(VAR16 == *VAR6)
        { 
          
          
          
          if(! FUN5(VAR2, VAR6))
          {
            *VAR6 = VAR16;
          }
        }
        VAR2 += 2;
        VAR8++;
      }
      else if (FUN6(VAR2[1]))
      {
        
        if(VAR8+3 >= VAR9)  
        {
          VAR11 = VAR14;
          break;
        }
        
        
        
 
        if (FUN7(VAR2[2]) &&
            FUN8(VAR2[3]))
        {
           if ( ! FUN9(VAR2[0])) 
           {
             
             if(! FUN10(VAR2, VAR6))
               *VAR6 = VAR16;
           } else {
              
             if ( (VAR10+1) < (*VAR7) )
             {
               if(FUN11(VAR2, VAR6))
               {
                 
                 VAR10++;
                 VAR6++;
               }  else {
                 *VAR6 = VAR16;
              }
             } else {
               if (*VAR7 < 2) {
                 FUN12("");
                 *VAR6 = VAR16;
               } else {
                 VAR11 = VAR13;
                 break;
               }
             }
           }
           VAR2 += 4;
           VAR8 += 3;
        } else {
          *VAR6 = VAR16; 
          
          
          
          
          VAR2++;
        }
      }
      else if ((VAR17) VAR2[0] == (VAR17)0xA0 )
      {
        
        
        *VAR6 = FUN13(*VAR2);
        VAR2++;
      } else {
        
        *VAR6 = VAR16;
        VAR2++;
      }
    } else {
      if(FUN14(*VAR2))
      {
        
        *VAR6 = FUN13(*VAR2);
        VAR2++;
      } else {
        if(FUN15(*VAR2)) {
          *VAR6 = VAR18;
        } else {
          *VAR6 = VAR16;
        }
        VAR2++;
      }
    }
    VAR10++;
    VAR6++;
    *VAR4 = VAR8+1;
  }
  *VAR7 = VAR10;
  return VAR11;
}