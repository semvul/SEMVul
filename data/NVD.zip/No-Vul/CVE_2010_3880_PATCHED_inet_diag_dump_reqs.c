static int FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4, 			       struct VAR5 *VAR6)  
{
	struct inet_diag_entry VAR7;
	struct VAR8 *VAR9 = FUN2(VAR6->VAR10);
	struct VAR11 *VAR12 = FUN3(VAR4);
	struct VAR13 *VAR14;
	const struct VAR15 *VAR16 = NULL;
	struct VAR17 *VAR18 = FUN4(VAR4);
	int VAR19, VAR20;
	int VAR21, VAR22;
	int VAR23 = 0;

	VAR20 = VAR6->VAR24[3];
	VAR22 = VAR6->VAR24[4];

	if (VAR20 > 0)
		VAR20--;

	VAR7.VAR25 = VAR4->VAR26;

	FUN5(&VAR12->VAR27.VAR28);

	VAR14 = VAR12->VAR27.VAR29;
	if (!VAR14 || !VAR14->VAR30)
		goto VAR31;

	if (FUN6(VAR6->VAR10, sizeof(*VAR9))) {
		VAR16 = FUN7(VAR6->VAR10, sizeof(*VAR9),
				     VAR32);
		VAR7.VAR33 = VAR18->VAR34;
		VAR7.VAR35 = VAR4->VAR36;
	}

	for (VAR19 = VAR20; VAR19 < VAR14->VAR37; VAR19++) {
		struct VAR38 *VAR39, *VAR40 = VAR14->VAR41[VAR19];

		VAR21 = 0;
		for (VAR39 = VAR40; VAR39; VAR21++, VAR39 = VAR39->VAR42) {
			struct VAR43 *VAR44 = FUN8(VAR39);

			if (VAR21 < VAR22)
				continue;
			if (VAR9->VAR45.VAR46 != VAR44->VAR47 &&
			    VAR9->VAR45.VAR46)
				continue;

			if (VAR16) {
				VAR7.VAR48 =
#if FUN9(VAR49) || FUN9 (VAR50)
					(VAR7.VAR25 == VAR51) ?
					FUN10(VAR39)->VAR52.VAR53 :
#endif
					&VAR44->VAR52;
				VAR7.VAR54 =
#if FUN9(VAR49) || FUN9 (VAR50)
					(VAR7.VAR25 == VAR51) ?
					FUN10(VAR39)->VAR55.VAR53 :
#endif
					&VAR44->VAR55;
				VAR7.VAR56 = FUN11(VAR44->VAR47);

				if (!FUN12(FUN13(VAR16),
						      FUN14(VAR16), &VAR7))
					continue;
			}

			VAR23 = FUN15(VAR2, VAR4, VAR39,
					       FUN16(VAR6->VAR2).VAR57,
					       VAR6->VAR10->VAR58, VAR6->VAR10);
			if (VAR23 < 0) {
				VAR6->VAR24[3] = VAR19 + 1;
				VAR6->VAR24[4] = VAR21;
				goto VAR31;
			}
		}

		VAR22 = 0;
	}

VAR31:
	FUN17(&VAR12->VAR27.VAR28);

	return VAR23;
}