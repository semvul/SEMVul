*/ static unsigned int FUN1 (const VAR1 * VAR2, 				 int VAR3, 				 const VAR1 * VAR4, 				 int VAR5, 				 const VAR6 * VAR7, 				 int VAR8, unsigned int VAR9)  
{
  int VAR10 = 0, VAR11;
  unsigned int VAR12 = 0, VAR13;

  
  if (FUN2 (VAR2[VAR3 - 1],
				    VAR2[VAR3 - 1]) > 0
      && VAR3 > 0)
    {
      VAR3--;
    }

  
  VAR11 =
    FUN3 (VAR2[VAR3 - 1],
				 VAR4, VAR5, VAR9, &VAR13);

  if (VAR11 == 0)
    {
      
      FUN4 ();
      VAR12 |= VAR13;
      VAR12 |= VAR14;
      return VAR12;
    }

  
#ifdef VAR15
  for (VAR10 = 0; VAR10 < VAR3; VAR10++)
    {
      VAR11 = FUN5 (VAR2[VAR10],
					      VAR7, VAR8);
      if (VAR11 == 1)
	{			
	  VAR12 |= VAR16;
	  VAR12 |= VAR14;
	  return VAR12;
	}
    }
#endif

  
  for (VAR10 = VAR3 - 1; VAR10 > 0; VAR10--)
    {
      if (VAR10 - 1 < 0)
	break;

      
      if (!(VAR9 & VAR17))
	VAR9 ^= VAR18;
      if ((VAR11 =
	   FUN3 (VAR2[VAR10 - 1],
					&VAR2[VAR10], 1, VAR9,
					NULL)) == 0)
	{
	  VAR12 |= VAR14;
	  return VAR12;
	}
    }

  return 0;
}