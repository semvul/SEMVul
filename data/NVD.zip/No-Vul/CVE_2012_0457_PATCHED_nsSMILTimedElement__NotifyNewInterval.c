void VAR1::FUN1()  
{
  FUN2(VAR2,
      ""
      "");

  VAR3* VAR4 = FUN3();
  if (VAR4) {
    VAR4->FUN4();
  }

  NotifyTimeDependentsParams VAR5 = { this, VAR4 };
  VAR6.FUN5(VAR7, &VAR5);
}