VAR1* VAR2::FUN1(bool VAR3)  
{
    VAR4<VAR5> VAR6;
    bool VAR7 = false;

    if (VAR3 && VAR8) {
        VAR6 = VAR8->FUN2();
        VAR7 = true;
    }

    if (!VAR6) {
        VAR4<VAR9> VAR10;
        FUN3(FUN4(VAR10));
        if (VAR10) {
            VAR6 = FUN5(VAR10);
        }
    }

    if (!VAR6) {
        if (!VAR3) {
            return VAR11;
        }

        
        
        FUN6();  
                                

        if (!VAR8)
            return VAR11;
        VAR6 = VAR8->FUN2();
    }

    
    if (VAR6) {
        VAR1 *VAR12 = VAR6->FUN7();

        
        
        if (VAR7 &&
            VAR13 == VAR14 &&
            VAR15::FUN8(VAR12)) {
            return VAR11;
        }

        return VAR12;
    }

    return VAR11;
}