static VAR1 FUN1(VAR2 *VAR3, VAR4 *VAR5,                                VAR6 *VAR7, gint VAR8,                                struct VAR9 *VAR10,                                struct VAR11 *VAR12)  
{
    guint32 VAR13;
    int VAR14;
    VAR15 *VAR16;

    VAR13 = FUN2(VAR3, VAR8);
    VAR8 += 4;

    switch (VAR13) {
    case VAR17:
        VAR14 = 4;
        FUN3(VAR7, VAR10->VAR18, VAR3, VAR8, 4, VAR19);
        break;
    case VAR20:
        VAR14 = 16;
        FUN3(VAR7, VAR10->VAR21, VAR3, VAR8, 16, VAR22);
        break;
    default:
        
        VAR14 = 0;
        VAR16 = FUN4(VAR7, VAR3, VAR8 - 4, 4, "", VAR13);
        FUN5(VAR5, VAR16, VAR23, VAR24, "");
    }

    if (VAR12) {
        VAR12->VAR13 = VAR13;
        switch (VAR14) {
        case 4:
            FUN6(VAR3, VAR12->VAR25.VAR26, VAR8, VAR14);
            break;
        case 16:
            FUN6(VAR3, VAR12->VAR25.VAR27, VAR8, VAR14);
            break;
        }
    }

    return VAR8 + VAR14;
}