static void FUN1(VAR1 *VAR2, VAR3 *VAR4, VAR5 *VAR6)  
{

  VAR7 *VAR8;
  VAR5 *VAR9;
  guint VAR10 = 0, VAR11;

  FUN2(VAR4->VAR12, VAR13, "");

  if (VAR6) {

    VAR8 = FUN3(VAR6, VAR14, VAR2, 0, -1, VAR15);

    VAR9 = FUN4(VAR8, VAR16);

    FUN3(VAR9, VAR17, VAR2, VAR10, 4, VAR18);
    VAR10 += 4;

    FUN3(VAR9, VAR19, VAR2, VAR10, 4, VAR18);
    VAR10 += 4;

    FUN3(VAR9, VAR20, VAR2, VAR10, 4, VAR18);
    VAR10 += 4;

    FUN3(VAR9, VAR21, VAR2, VAR10, 4, VAR18);
    VAR11 = FUN5(VAR2, VAR10);
    VAR10 += 4;

    if(VAR11 == 1)
    {
      FUN2(VAR4->VAR12, VAR22, "");
    }
    else
    {
      FUN2(VAR4->VAR12, VAR22, "");

    }
    FUN6(VAR4->VAR12, VAR22, "", FUN7(VAR11, VAR23, ""));

    switch(VAR11){
    case VAR24:
      VAR10 = FUN8(VAR2, VAR4, VAR10, VAR9);
      break;
    case VAR25:
      VAR10 = FUN9(VAR2, VAR10, VAR9);
      break;
    case VAR26:
      VAR10 = FUN10(VAR2, VAR4, VAR10, VAR9);
      break;
    case VAR27:
      VAR10 = FUN11(VAR2, VAR4, VAR10, VAR9);
      break;
    case VAR28:
      VAR10 = FUN12(VAR2, VAR4, VAR10, VAR9);
      break;
    case VAR29:
      VAR10 = FUN13(VAR2, VAR10, VAR9);
      break;
    case VAR30:
      VAR10 = FUN14(VAR2, VAR4, VAR10, VAR9);
      break;
    case VAR31:
      VAR10 = FUN15(VAR2, VAR10, VAR9);
      break;
    default:
      
      break;
    }
    if(VAR10 < FUN16(VAR2))
    {
      VAR8 = FUN3(VAR9, VAR32, VAR2, VAR10, -1, VAR15);
      FUN17(VAR4, VAR8, VAR33, VAR34, "");
    }
  }

}