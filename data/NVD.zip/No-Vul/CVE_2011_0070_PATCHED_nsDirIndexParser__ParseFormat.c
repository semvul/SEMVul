nsresult VAR1::FUN1(const char* VAR2)  
{
  
  

  
  
  const char* VAR3 = VAR2;
  unsigned int VAR4 = 0;
  do {
    while (*VAR3 && VAR5::FUN2(FUN3(*VAR3)))
      ++VAR3;
    
    ++VAR4;
    
    
    if (VAR4 > (2 * FUN4(VAR6)))
      return VAR7;

    if (! *VAR3)
      break;

    while (*VAR3 && !VAR5::FUN2(FUN3(*VAR3)))
      ++VAR3;

  } while (*VAR3);

  delete[] VAR8;
  VAR8 = new int[VAR4+1];
  
  if (VAR8 == VAR9)
    return VAR10;
  VAR8[VAR4] = -1;
  
  int VAR11=0;
  do {
    while (*VAR2 && VAR5::FUN2(FUN3(*VAR2)))
      ++VAR2;
    
    if (! *VAR2)
      break;

    nsCAutoString VAR12;
    PRInt32     VAR13 = 0;
    while (VAR2[VAR13] && !VAR5::FUN2(FUN3(VAR2[VAR13])))
      ++VAR13;
    VAR12.FUN5(VAR13 + 1);
    VAR12.FUN6(VAR2, VAR13);
    VAR2 += VAR13;
    
    
    VAR12.FUN7(FUN8(VAR12.FUN9()));

    
    if (VAR12.FUN10(""))
      VAR14 = VAR15;
    
    for (VAR16* VAR17 = VAR6; VAR17->VAR18; ++VAR17) {
      if (VAR12.FUN11(VAR17->VAR18)) {
        VAR8[VAR11] = VAR17->VAR19;
        ++VAR11;
        break;
      }
    }

  } while (*VAR2);
  
  return VAR20;
}