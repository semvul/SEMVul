long FUN1(void)  
{
#ifdef VAR1
	struct VAR2 *VAR3, *VAR4;
	const struct VAR5 *VAR6, *VAR7;
	struct VAR5 *VAR5, *VAR8;
	key_ref_t VAR9;
	int VAR10;

	VAR9 = FUN2(VAR11, 0, VAR12);
	if (FUN3(VAR9))
		return FUN4(VAR9);

	
	VAR10 = -VAR13;
	VAR5 = FUN5();
	if (!VAR5)
		goto VAR14;

	VAR5->VAR15->VAR16 = FUN6(VAR9);
	VAR9 = NULL;

	VAR3 = VAR17;
	FUN7(&VAR18);

	VAR4 = VAR3->VAR19;
	VAR10 = -VAR20;

	
	if (VAR4->VAR21 <= 1 || !VAR4->VAR22)
		goto VAR23;

	
	if (!FUN8(VAR4))
		goto VAR23;

	
	VAR6 = FUN9();
	VAR7 = FUN10(VAR4);
	if (VAR6 == VAR7 ||
	    VAR6->VAR15->VAR16 == VAR7->VAR15->VAR16)
		goto VAR24;

	
	if (VAR7->VAR25	!= VAR6->VAR26	||
	    VAR7->VAR26	!= VAR6->VAR26	||
	    VAR7->VAR27	!= VAR6->VAR26	||
	    VAR7->VAR28	!= VAR6->VAR29	||
	    VAR7->VAR29	!= VAR6->VAR29	||
	    VAR7->VAR30	!= VAR6->VAR29)
		goto VAR23;

	
	if ((VAR7->VAR15->VAR16 &&
	     VAR7->VAR15->VAR16->VAR25 != VAR6->VAR26) ||
	    VAR6->VAR15->VAR16->VAR25 != VAR6->VAR26)
		goto VAR23;

	
	VAR8 = VAR4->VAR31;

	
	VAR4->VAR31 = VAR5;
	VAR5 = NULL;
	FUN11(FUN12(VAR4), VAR1);

	FUN13(&VAR18);
	if (VAR8)
		FUN14(VAR8);
	return 0;

VAR24:
	VAR10 = 0;
VAR23:
	FUN13(&VAR18);
	FUN14(VAR5);
	return VAR10;

VAR14:
	FUN15(VAR9);
	return VAR10;

#else 
	
#warning TIF_NOTIFY_RESUME not VAR32
	return -VAR33;
#endif 
}