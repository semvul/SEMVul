nsresult VAR1::FUN1(DocumentFlavor VAR2,                            const char* VAR3,                            const char* VAR4,                            VAR5** VAR6,                            VAR7** VAR8,                            VAR9** VAR10)  
{
  *VAR6 = VAR11;
  *VAR8 = VAR11;
  *VAR10 = VAR11;

  VAR12<VAR13> VAR14 =
    FUN2(VAR15);
  nsresult VAR16;
  if (!VAR17) {
    FUN3(!VAR18, VAR19);
    VAR20 FUN4(&VAR18);

    VAR12<VAR21> VAR22 =
      FUN5("", &VAR16);
    FUN6(VAR16, VAR16);

    VAR16 = FUN7(VAR22, VAR11, VAR11, VAR14);
    FUN6(VAR16, VAR16);
  }

  FUN8(VAR17, "");
  FUN8(VAR23, "");

  
  
  
  
  VAR16 = VAR24::FUN9(FUN10(), FUN10(), VAR11,
                                      VAR23, VAR25,
                                      VAR26,
                                      VAR14,
                                      VAR2,
                                      VAR6);

  FUN6(VAR16, VAR16);

  
  FUN11(VAR8, VAR23, VAR11,
                           FUN12(VAR4), VAR11);
  FUN13(*VAR8);

  
  (*VAR8)->FUN14(VAR26);

  if (VAR3) {
    (*VAR8)->FUN15(FUN12(VAR3));
  }

  VAR12<VAR27> FUN16(FUN17(*VAR6));
  FUN13(VAR28);

  if (VAR24::FUN18(VAR26)) {
    VAR28->FUN19();
  }

  VAR16 = VAR28->FUN20(VAR29, (*VAR8), 
                                   VAR11, VAR11, 
                                   VAR10,
                                   false);

  
  VAR28->FUN21(VAR25);

  
  VAR28->FUN22(VAR17);

  if (FUN23(VAR16) || !(*VAR10)) {
    return VAR30;
  }
  return VAR31;
}