FUN1( FT_Module    VAR1,                          const char*  VAR2 )    
{
    FT_Pointer  VAR3 = NULL;

    if ( VAR1 )
    {
      FUN2( VAR1->VAR4 && VAR1->VAR4->VAR5 );

     
      if ( VAR1->VAR4->VAR5 )
        VAR3 = VAR1->VAR4->FUN3( VAR1, VAR2 );

      if ( VAR3 == NULL )
      {
       
        FT_Library  VAR6 = VAR1->VAR6;
        VAR7*  VAR8     = VAR6->VAR9;
        VAR7*  VAR10   = VAR8 + VAR6->VAR11;

        for ( ; VAR8 < VAR10; VAR8++ )
        {
          if ( VAR8[0] != VAR1 )
          {
            FUN2( VAR8[0]->VAR4 );

            if ( VAR8[0] && VAR8[0]->VAR4 && VAR8[0]->VAR4->VAR5 )
            {
              VAR3 = VAR8[0]->VAR4->FUN3( VAR8[0], VAR2 );
              if ( VAR3 != NULL )
                break;
            }
          }
        }
      }
    }

    return VAR3;
  }