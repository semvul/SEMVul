static void FUN1(VAR1 *VAR2, VAR3 *VAR4, VAR5 *VAR6)  
{
    
    VAR7 *VAR8 = NULL;

    
    VAR5 *VAR9 = NULL;

    VAR7 *VAR10 = NULL;
    gint VAR11 = 0;                
    guint8 VAR12;                 

    
    if (!VAR13)
        VAR13 = FUN2(VAR14);

    if (!VAR15)
        VAR15 = FUN2(VAR14);

    VAR12 =  FUN3(VAR2, VAR11);
    VAR12 = (VAR12 & 0xF0) >> 4;

    
    
    FUN4(VAR4->VAR16, VAR17, "");
    FUN5(VAR4->VAR16, VAR18);
    FUN6(VAR4->VAR16, VAR18, "",
             FUN7(VAR12, VAR19, ""));

    
    if(VAR6 && VAR6->VAR20)
    {
        
        VAR6 = VAR6->VAR20;
        
        VAR21 = VAR6;
    }

    if(!VAR6)
    {
        
        
        FUN8(VAR2, VAR11, VAR4, VAR22);
        return;
    }

    
    VAR8 = FUN9(VAR6, VAR23, VAR2, VAR11, -1, VAR22);

    
    VAR9 = FUN10(VAR8, VAR24);

    VAR10 = FUN9(VAR9, VAR25, VAR2, VAR11, 2, VAR22);

    if (VAR12 > 1) {
        FUN11(VAR10, "", "");
        FUN12(VAR26, VAR2, VAR4, VAR9);
    } else {
        FUN9(VAR9, VAR27, VAR2, VAR11, 2, VAR22);
        VAR11 += 2;

        FUN9(VAR9, VAR28, VAR2, VAR11, 2, VAR22);
        FUN9(VAR9, VAR29, VAR2, VAR11, 2, VAR22);
        VAR11 += 2;

        FUN9(VAR9, VAR30, VAR2, VAR11, 2, VAR22);
        VAR11 += 2;
    }

}