static int FUN1(VAR1 *VAR2, VAR3 *VAR4, VAR5 *VAR6)  
{
	VAR1   *VAR7;
        gchar VAR8[16];

	
	if(VAR4->VAR9 != VAR10 && VAR4->VAR9 != VAR11)
		return 0;

        
	FUN2(&(VAR4->VAR8), VAR8, sizeof VAR8);

        if (VAR4->VAR8.VAR12 == VAR13 && strcmp(VAR8,VAR14) == 0) {
                
                guint8 VAR15, VAR16 = 0;

                FUN3(VAR4->VAR17, VAR18, "");

                VAR15 = FUN4(VAR2, 1);
                if (FUN5(VAR4->VAR17, VAR19)) {
                        FUN6(VAR4->VAR17, VAR19,
                                     FUN7(VAR15, VAR20, ""));
        	}
        	if (VAR15 < 3) {
                	VAR16 = FUN4(VAR2, 2);
        		if (FUN5(VAR4->VAR17, VAR19)) {
                        	FUN8(VAR4->VAR17, VAR19, "",
                               		     FUN7(VAR16, VAR21, ""));
        		}
                } else if (VAR15 == 3) {
                	VAR16 = FUN4(VAR2, 6);
        		if (FUN5(VAR4->VAR17, VAR19)) {
                        	FUN8(VAR4->VAR17, VAR19, "",
                               		     FUN7(VAR16, VAR22, ""));
        		}
        	}

                if (VAR6) {
                        VAR23 *VAR24;
                        VAR5 *VAR25;
                        gint VAR26;
                        guint8 VAR27, VAR28;
                        gchar VAR29[8 + 1];

                        VAR26 = 0;
                        VAR24 = FUN9(VAR6, VAR30, VAR2, VAR26, -1, VAR31);
                        VAR25 = FUN10(VAR24, VAR32);

                        FUN9(VAR25, VAR33, VAR2, VAR26, 1, VAR34);
                        VAR26++;
                        FUN11(VAR25, VAR35, VAR2, VAR26, 1, VAR15);
                        VAR26++;
        		if (VAR15 < 3) {
        			FUN11(VAR25, VAR36, VAR2, VAR26, 1, VAR16);
        			VAR26++;
        			VAR27 = FUN4(VAR2, VAR26);
        			FUN12(VAR25, VAR37, VAR2, VAR26, 1, VAR27,
                                                   "",
                                                   (VAR27 == VAR38) ? "" : "",
                                                   VAR27);
        			VAR26++;
        			VAR28 = FUN4(VAR2, VAR26);
        			FUN12(VAR25, VAR39, VAR2, VAR26, 1, VAR28,
                                                   "",
                                                   (VAR28 == VAR40) ? "" : "",
                                                   VAR28);
        			VAR26++;
        			FUN9(VAR25, VAR41, VAR2, VAR26, 1, VAR34);
        			VAR26++;
        			FUN9(VAR25, VAR42, VAR2, VAR26, 1, VAR34);
        			VAR26++;
        			FUN9(VAR25, VAR43, VAR2, VAR26, 1, VAR34);
        			VAR26++;
        			FUN13(VAR2, VAR29, VAR26, 8);
        			VAR29[sizeof VAR29 - 1] = '';
        			FUN14(VAR25, VAR44, VAR2, VAR26, 8, VAR29,
                                                     "",
                                                     (FUN15(VAR2, VAR26, "", strlen(""))) == 0 ? "" : "",
                                                     VAR29);
        			VAR26 += 8;
        			FUN9(VAR25, VAR45, VAR2, VAR26, 4, VAR34);
        			
        		} else if (VAR15 == 3) {
        			FUN9(VAR25, VAR46, VAR2, VAR26, 2, VAR34);
        			VAR26 += 2;
        			FUN9(VAR25, VAR47, VAR2, VAR26, 2, VAR34);
        			VAR26 += 2;
        			FUN9(VAR25, VAR48, VAR2, VAR26, 1, VAR34);
        			VAR26 += 1;
        			FUN9(VAR25, VAR49, VAR2, VAR26, 1, VAR34);
        			VAR26 += 1;
        			FUN9(VAR25, VAR50, VAR2, VAR26, 2, VAR34);
        			VAR26 += 2;
        			FUN9(VAR25, VAR51, VAR2, VAR26, 2, VAR34);
        			VAR26 += 2;
        			FUN9(VAR25, VAR52, VAR2, VAR26, 4, VAR34);
        			
        		} else {
        			VAR7 = FUN16(VAR2, VAR26);
        			FUN17(VAR53, VAR7, VAR4, VAR25);
        		}
                }
        } else if ((VAR4->VAR8.VAR12 == VAR13 && strcmp(VAR8,VAR54) == 0) ||
		   (VAR4->VAR8.VAR12 == VAR55 && VAR4->VAR9 == VAR11)) {
                
                guint VAR26 = 0, VAR56;
                VAR23 *VAR24 = NULL;
                VAR5 *VAR25 = NULL;
                guint8 VAR12,VAR57;

                FUN3(VAR4->VAR17, VAR18, "");

                if (VAR6) {
                        VAR24 = FUN9(VAR6, VAR30, VAR2, VAR26, -1, VAR31);
                        VAR25 = FUN10(VAR24, VAR32);
		}

                while (FUN18(VAR2, VAR26) > 0) {
                        VAR12 = FUN4(VAR2, VAR26);
                        VAR57 = FUN4(VAR2, VAR26+1);

                        VAR56 = VAR26;
                        if (VAR12 == 1 && VAR57 == 40) {
                                
                                guint8 VAR15, VAR16 = 0, VAR58;
                                guint32 VAR27, VAR28;
                                VAR5 *VAR59;

                                if (VAR6) {
                                        VAR24 = FUN12(VAR25, VAR60, VAR2, VAR26, 2, VAR12,
                                        "", VAR12, VAR57);
                                }
				VAR26+=2;

                                VAR15 = FUN4(VAR2, VAR26+1);
                                if (FUN5(VAR4->VAR17, VAR19)) {
                                        FUN19(VAR4->VAR17, VAR19, "",
                                                     FUN7(VAR15, VAR61, ""));
                        	}

                                VAR16 = FUN4(VAR2, VAR26+2);
                        	if (FUN5(VAR4->VAR17, VAR19)) {
                                       	FUN8(VAR4->VAR17, VAR19, "",
                                      	             FUN7(VAR16, VAR62, ""));
                                }

                                if (VAR6) {
                                        
                                        VAR59 = FUN10(VAR24, VAR63);
                                        FUN9(VAR59, VAR64, VAR2, VAR26, 1, VAR34);
                                        VAR26++;
                                        FUN11(VAR59, VAR65, VAR2, VAR26, 1, VAR15);
                                        VAR26++;
                                        FUN11(VAR59, VAR66, VAR2, VAR26, 1, VAR16);
                			VAR26++;
                			VAR58 = FUN4(VAR2, VAR26);
                                        FUN11(VAR59, VAR67, VAR2, VAR26, 1, VAR58);
                			VAR26++;
                			FUN9(VAR59, VAR68, VAR2, VAR26, 2, VAR34);
                			VAR26+=2;
                			FUN9(VAR59, VAR69, VAR2, VAR26, 6, VAR31);
                			VAR26+=6;
                			FUN9(VAR59, VAR70, VAR2, VAR26, 4, VAR34);
                			VAR26+=4;

                			VAR27 = FUN20(VAR2, VAR26);
                			FUN12(VAR59, VAR71, VAR2, VAR26, 4, VAR27,
                                                           "",
                                                           (VAR27 == VAR72) ? "" : "",
                                                           VAR27);
                			VAR26+=4;
                			VAR28 = FUN20(VAR2, VAR26);
                			FUN12(VAR59, VAR73, VAR2, VAR26, 4, VAR28,
                                                           "",
                                                           (VAR28 == VAR74) ? "" : "",
                                                           VAR28);
                			VAR26+=4;
                                        if (VAR58 == 4) {
                                                
                                                FUN9(VAR59, VAR75, VAR2, VAR26, 4, VAR34);
                                        } else if (VAR58 == 6) {
                                                
                                                FUN9(VAR59, VAR76, VAR2, VAR26, 16, VAR31);
                                        } else {
                                                
                        			VAR7 = FUN16(VAR2, VAR26);
                        			FUN17(VAR53, VAR7, VAR4, VAR25);
                                                break;
					}
					
				}
                        } else if (VAR12 == 2 && VAR57 == 4) {
                                
                                guint16 VAR77,VAR78;
                                VAR77 = FUN21(VAR2, VAR26+2);
                                VAR78 = FUN21(VAR2, VAR26+4);

                                if (FUN5(VAR4->VAR17, VAR19)) {
                                        FUN19(VAR4->VAR17, VAR19, "",VAR77,VAR78);
                                }

                                if (VAR6) {
                                        VAR5 *VAR79;
                                        VAR24 = FUN12(VAR25, VAR80, VAR2, VAR26, 1, VAR12,
                                        "", VAR12, VAR57);
                                        VAR26+=2;

                                        
                                        VAR79 = FUN10(VAR24, VAR81);
                			FUN9(VAR79, VAR82, VAR2, VAR26, 2, VAR34);
                                        VAR26+=2;
                			FUN9(VAR79, VAR83, VAR2, VAR26, 2, VAR34);
					
                                }
                        } else if (VAR12 == 3 && VAR57 == 8) {
                                
                                if (VAR6) {
                                        VAR5 *VAR84;
                                        gchar VAR29[8 + 1];

                                        VAR24 = FUN12(VAR25, VAR85, VAR2, VAR26, 1, VAR12,
                                        "", VAR12, VAR57);
                                        VAR26+=2;

                                        
                                        VAR84 = FUN10(VAR24, VAR86);

                			FUN13(VAR2, VAR29, VAR26, 8);
                			VAR29[sizeof VAR29 - 1] = '';
                			FUN14(VAR84, VAR87, VAR2, VAR26, 8, VAR29,
                                                             "",
                                                             (FUN15(VAR2, VAR26, "", strlen(""))) == 0 ? "" : "",
                                                             VAR29);
                			
                                }
                        } else if (VAR12 == 4 && VAR57 == 28) {
                                
                                if (VAR6) {
                                        VAR5 *VAR88;

                                        VAR24 = FUN12(VAR25, VAR85, VAR2, VAR26, 1, VAR12,
                                        "", VAR12, VAR57);
                                        VAR26+=2;

                                        
                                        VAR88 = FUN10(VAR24, VAR89);
                                        FUN9(VAR88, VAR90, VAR2, VAR26, 1, VAR34);
                                        VAR26++;
                                        
                                        VAR26++;
                                        FUN9(VAR88, VAR91, VAR2, VAR26, 2, VAR34);
                                        VAR26+=2;
                                        FUN9(VAR88, VAR92, VAR2, VAR26, 4, VAR34);
                                        VAR26+=4;
                                        FUN9(VAR88, VAR93, VAR2, VAR26, 4, VAR34);
                                        VAR26+=4;
                                        FUN9(VAR88, VAR94, VAR2, VAR26, 16, VAR34);
                                        
                                }
                        } else {
                                
				if (VAR6) {
        				VAR7 = FUN16(VAR2, VAR26);
        				FUN17(VAR53, VAR7, VAR4, VAR25);
				}
                                break;
			}
		        VAR26 = VAR56+VAR57+2;
		}
        }

        return FUN22(VAR2);
}