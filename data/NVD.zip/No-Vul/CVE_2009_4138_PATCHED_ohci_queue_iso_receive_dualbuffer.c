static int FUN1(struct VAR1 *VAR2, 					     struct VAR3 *VAR4, 					     struct VAR5 *VAR6, 					     unsigned long VAR7)  
{
	struct VAR8 *VAR9 = FUN2(VAR2, struct VAR8, VAR2);
	struct VAR10 *VAR11 = NULL;
	struct VAR12 *VAR13;
	struct VAR3 *VAR14;
	dma_addr_t VAR15, VAR16;
	u32 VAR17, VAR18, VAR19, VAR20;
	int VAR21, VAR22, VAR23, VAR24;

	

	VAR14 = VAR4;
	VAR17 = 2;

	
	VAR23 = VAR14->VAR25 / VAR9->VAR2.VAR24;
	VAR24 = VAR23 * FUN3(VAR9->VAR2.VAR24, (VAR26)8);

	
	VAR18 = FUN4(VAR24, sizeof(*VAR13));
	VAR21     = VAR7 >> VAR27;
	VAR22   = VAR7 & ~VAR28;
	VAR20     = VAR14->VAR29;
	
	if (VAR20 == 0)
		return -VAR30;

	
	while (VAR20 > 0) {
		VAR13 = FUN5(&VAR9->VAR31,
					    VAR17 + VAR18, &VAR15);
		if (VAR13 == NULL)
			return -VAR32;

		VAR11 = (struct VAR10 *) VAR13;
		VAR11->VAR33 = FUN6(VAR34 |
					  VAR35);
		VAR11->VAR36 =
		    FUN6(FUN3(VAR9->VAR2.VAR24, (VAR26)8));
		if (VAR14->VAR37 && VAR20 == VAR14->VAR29) {
			VAR11->VAR33 |= FUN6(VAR38);
			VAR11->VAR39 = VAR11->VAR36;
		} else {
			VAR11->VAR39 = FUN6(VAR24);
		}
		VAR11->VAR40 = VAR11->VAR39;
		VAR11->VAR41 = FUN7(VAR15 + sizeof(*VAR11));

		if (VAR14->VAR37 && VAR20 == VAR14->VAR29)
			VAR19 = 4;
		else if (VAR22 + VAR20 < VAR42)
			VAR19 = VAR20;
		else
			VAR19 = VAR42 - VAR22;

		VAR11->VAR43 = FUN6(VAR19);
		VAR11->VAR44 = VAR11->VAR43;
		VAR16 = FUN8(VAR6->VAR45[VAR21]);
		VAR11->VAR46 = FUN7(VAR16 + VAR22);

		if (VAR14->VAR47 && VAR19 == VAR20)
			VAR11->VAR33 |= FUN6(VAR48);

		FUN9(&VAR9->VAR31, VAR13, VAR17, VAR18);
		VAR22 = (VAR22 + VAR19) & ~VAR28;
		VAR20 -= VAR19;
		if (VAR22 == 0)
			VAR21++;
	}

	return 0;
}