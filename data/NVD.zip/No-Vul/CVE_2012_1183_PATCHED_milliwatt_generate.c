static int FUN1(struct VAR1 *VAR2, void *VAR3, int VAR4, int VAR5)  
{
	unsigned char VAR6[VAR7 + 640];
	const int VAR8 = FUN2(VAR6) - (VAR7 / sizeof(VAR6[0]));
	int VAR9, *VAR10 = (int *) VAR3;
	struct ast_frame VAR11 = {
		.VAR12 = VAR13,
		.VAR14 = VAR7,
		.VAR15 = VAR16,
	};
	FUN3(&VAR11.VAR17.VAR18, VAR19, 0);
	VAR11.VAR3.VAR20 = VAR6 + VAR7;

	
	if (VAR5 > VAR8) {
		FUN4(VAR21, "", VAR8, VAR5);
		VAR5 = VAR8;
	}

	VAR4 = VAR5 * sizeof (VAR6[0]);
	VAR11.VAR22 = VAR4;
	VAR11.VAR5 = VAR5;

	
	for (VAR9 = 0; VAR9 < VAR4; VAR9++) {
		VAR6[VAR7 + VAR9] = VAR23[(*VAR10)++];
		*VAR10 &= 7;
	}

	if (FUN5(VAR2,&VAR11) < 0) {
		FUN4(VAR21,"",VAR2->VAR24,strerror(VAR25));
		return -1;
	}

	return 0;
}