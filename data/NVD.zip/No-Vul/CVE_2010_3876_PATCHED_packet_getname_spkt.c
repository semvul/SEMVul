static int FUN1(struct socket *VAR1, struct VAR2 *VAR3, 			       int *VAR4, int VAR5)  
{
	struct VAR6 *VAR7;
	struct VAR1 *VAR8	= VAR1->VAR8;

	if (VAR5)
		return -VAR9;

	VAR3->VAR10 = VAR11;
	FUN2();
	VAR7 = FUN3(FUN4(VAR8), FUN5(VAR8)->VAR12);
	if (VAR7)
		strncpy(VAR3->VAR13, VAR7->VAR14, 14);
	else
		memset(VAR3->VAR13, 0, 14);
	FUN6();
	*VAR4 = sizeof(*VAR3);

	return 0;
}