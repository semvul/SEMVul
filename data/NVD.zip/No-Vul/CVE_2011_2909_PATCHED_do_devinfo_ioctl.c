static int FUN1(struct VAR1 *VAR2, 			    struct comedi_devinfo VAR3 *VAR4, 			    struct VAR5 *VAR5)  
{
	struct comedi_devinfo VAR6;
	const unsigned VAR7 = FUN2(VAR5->VAR8->VAR9);
	struct VAR10 *VAR11 =
	    FUN3(VAR7);
	struct VAR12 *VAR13 =
	    FUN4(VAR11);
	struct VAR12 *VAR14 =
	    FUN5(VAR11);

	memset(&VAR6, 0, sizeof(VAR6));

	
	VAR6.VAR15 = VAR16;
	VAR6.VAR17 = VAR2->VAR18;
	FUN6(VAR6.VAR19, VAR2->VAR20->VAR19, VAR21);
	FUN6(VAR6.VAR22, VAR2->VAR22, VAR21);

	if (VAR13)
		VAR6.VAR23 = VAR13 - VAR2->VAR24;
	else
		VAR6.VAR23 = -1;

	if (VAR14)
		VAR6.VAR25 = VAR14 - VAR2->VAR24;
	else
		VAR6.VAR25 = -1;

	if (FUN7(VAR4, &VAR6, sizeof(struct VAR26)))
		return -VAR27;

	return 0;
}