void CWE126_Buffer_Overread__malloc_char_memmove_22_bad()
{
    char * data;
    data = NULL;
    CWE126_Buffer_Overread__malloc_char_memmove_22_badGlobal = 1; /* true */
    data = CWE126_Buffer_Overread__malloc_char_memmove_22_badSource(data);
    {
        char dest[100];
        memset(dest, 'C', 100-1);
        dest[100-1] = '\0'; /* null terminate */
        /* POTENTIAL FLAW: using memmove with the length of the dest where data
         * could be smaller than dest causing buffer overread */
        memmove(dest, data, strlen(dest)*sizeof(char));
        dest[100-1] = '\0';
        printLine(dest);
        free(data);
    }
}
