asmlinkage long FUN1(unsigned int VAR1, struct rlimit VAR2 *VAR3)  
{
	struct rlimit VAR4, *VAR5;
	unsigned long VAR6;
	int VAR7;

	if (VAR1 >= VAR8)
		return -VAR9;
	if (FUN2(&VAR4, VAR3, sizeof(*VAR3)))
		return -VAR10;
	if (VAR4.VAR11 > VAR4.VAR12)
		return -VAR9;
	VAR5 = VAR13->signal->VAR3 + VAR1;
	if ((VAR4.VAR12 > VAR5->VAR12) &&
	    !FUN3(VAR14))
		return -VAR15;
	if (VAR1 == VAR16 && VAR4.VAR12 > VAR17)
		return -VAR15;

	VAR7 = FUN4(VAR1, &VAR4);
	if (VAR7)
		return VAR7;

	if (VAR1 == VAR18 && VAR4.VAR11 == 0) {
		
		VAR4.VAR11 = 1;
	}

	FUN5(VAR13->VAR19);
	*VAR5 = VAR4;
	FUN6(VAR13->VAR19);

	if (VAR1 != VAR18)
		goto VAR20;

	
	if (VAR4.VAR11 == VAR21)
		goto VAR20;

	VAR6 = FUN7(VAR13->signal->VAR22);
	if (VAR6 == 0 || VAR4.VAR11 <= VAR6) {
		unsigned long VAR11 = VAR4.VAR11;
		cputime_t VAR23;

		VAR23 = FUN8(VAR11);
		FUN9(&VAR24);
		FUN10(&VAR13->VAR25->VAR26);
		FUN11(VAR13, VAR27, &VAR23, NULL);
		FUN12(&VAR13->VAR25->VAR26);
		FUN13(&VAR24);
	}
VAR20:
	return 0;
}