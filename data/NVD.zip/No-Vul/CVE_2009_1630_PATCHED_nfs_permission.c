int FUN1(struct VAR1 *VAR1, int VAR2)  
{
	struct VAR3 *VAR4;
	int VAR5 = 0;

	FUN2(VAR1, VAR6);

	if ((VAR2 & (VAR7 | VAR8 | VAR9)) == 0)
		goto VAR10;
	
	if (VAR2 & VAR11)
		goto VAR12;

	switch (VAR1->VAR13 & VAR14) {
		case VAR15:
			goto VAR10;
		case VAR16:
			
			if (FUN3(VAR1, VAR17)
					&& (VAR2 & VAR18)
					&& !(VAR2 & VAR9))
				goto VAR10;
			break;
		case VAR19:
			
			if ((VAR2 & VAR8) && !(VAR2 & VAR7))
				goto VAR10;
	}

VAR12:
	if (!FUN4(VAR1)->VAR20)
		goto VAR21;

	VAR4 = FUN5();
	if (!FUN6(VAR4)) {
		VAR5 = FUN7(VAR1, VAR4, VAR2);
		FUN8(VAR4);
	} else
		VAR5 = FUN9(VAR4);
VAR10:
	if (!VAR5 && (VAR2 & VAR9) && !FUN10(VAR1))
		VAR5 = -VAR22;

	FUN11(VAR23, "",
		VAR1->VAR24->VAR25, VAR1->VAR26, VAR2, VAR5);
	return VAR5;
VAR21:
	VAR5 = FUN12(FUN13(VAR1), VAR1);
	if (VAR5 == 0)
		VAR5 = FUN14(VAR1, VAR2, NULL);
	goto VAR10;
}