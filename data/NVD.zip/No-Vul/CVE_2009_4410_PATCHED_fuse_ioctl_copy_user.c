static int FUN1(struct VAR1 **VAR2, struct VAR3 *VAR4, 			unsigned int VAR5, size_t VAR6, bool VAR7)  
{
	struct iov_iter VAR8;
	int VAR9 = 0;

	if (!VAR6)
		return 0;

	FUN2(&VAR8, VAR4, VAR5, VAR6, 0);

	while (FUN3(&VAR8)) {
		struct VAR1 *VAR1 = VAR2[VAR9++];
		size_t VAR10 = FUN4(VAR11, VAR12, FUN3(&VAR8));
		void *VAR13, *VAR14;

		VAR13 = VAR14 = FUN5(VAR1);

		while (VAR10) {
			char VAR15 *VAR16 = VAR8.VAR4->VAR17 + VAR8.VAR18;
			size_t VAR19 = VAR8.VAR4->VAR19 - VAR8.VAR18;
			size_t copy = FUN6(VAR10, VAR19);
			size_t VAR20;

			if (!VAR7)
				VAR20 = FUN7(VAR13, VAR16, copy);
			else
				VAR20 = FUN8(VAR16, VAR13, copy);

			if (FUN9(VAR20))
				return -VAR21;

			FUN10(&VAR8, copy);
			VAR10 -= copy;
			VAR13 += copy;
		}

		FUN11(VAR1);
	}

	return 0;
}