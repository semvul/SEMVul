static void   FUN1( T42_Face    VAR1,                    T42_Loader  VAR2 )    
{
    T42_Parser  VAR3 = &VAR2->VAR3;
    FT_Memory   VAR4 = VAR3->VAR5.VAR4;
    VAR6*    VAR7;
    VAR6*    VAR8  = VAR3->VAR5.VAR8;
    FT_Error    VAR9;
    FT_Int      VAR10 = 0;
    FT_ULong    VAR11, VAR12 = 0;

    FT_Long     VAR13, VAR14, VAR15, VAR16;
    VAR6*    VAR17 = NULL;
    FT_Bool     VAR18  = 0;

    T42_Load_Status  VAR19;


    
    
    
    
    
    
    
    
    
    
    
    
    

    FUN2( VAR3 );

    if ( VAR3->VAR5.VAR20 >= VAR8 || *VAR3->VAR5.VAR20++ != '' )
    {
      FUN3(( "" ));
      VAR9 = VAR21;
      goto VAR22;
    }

    FUN2( VAR3 );
    VAR19          = VAR23;
    VAR14     = 0;
    VAR15 = 0;
    VAR11           = 0;

    while ( VAR3->VAR5.VAR20 < VAR8 )
    {
      VAR7 = VAR3->VAR5.VAR20;

      if ( *VAR7 == '' )
      {
        VAR3->VAR5.VAR20++;
        goto VAR24;
      }

      else if ( *VAR7 == '' )
      {
        FUN4( VAR3 );
        if ( VAR3->VAR5.VAR9 )
          goto VAR24;

        
        VAR14 = (VAR25)( ( VAR3->VAR5.VAR20 - VAR7 - 2 + 1 ) / 2 );
        if ( FUN5( VAR17, VAR15, VAR14 ) )
          goto VAR22;

        VAR18 = 1;

        VAR3->VAR5.VAR20 = VAR7;
        (void)FUN6( VAR3, VAR17, VAR14, &VAR16, 1 );
        VAR15 = VAR14;
        VAR14 = VAR16;
      }

      else if ( FUN7( *VAR7 ) )
      {
        if ( VAR18 )
        {
          FUN3(( ""
                     "" ));
          VAR9 = VAR21;
          goto VAR22;
        }

        VAR14 = FUN8( VAR3 );
        if ( VAR14 < 0 )
        {
          FUN3(( "" ));
          VAR9 = VAR21;
          goto VAR22;
        }

        FUN4( VAR3 );             
        if ( VAR3->VAR5.VAR9 )
          return;

        VAR17 = VAR3->VAR5.VAR20 + 1;   

        if ( VAR8 - VAR3->VAR5.VAR20 < VAR14 )
        {
          FUN3(( "" ));
          VAR9 = VAR21;
          goto VAR22;
        }
        else
          VAR3->VAR5.VAR20 += VAR14 + 1;
      }

      if ( !VAR17 )
      {
        FUN3(( "" ));
        VAR9 = VAR21;
        goto VAR22;
      }

      
      if ( VAR17[VAR14 - 1] == 0 && ( VAR14 % 2 == 1 ) )
        VAR14--;

      if ( !VAR14 )
      {
        FUN3(( "" ));
        VAR9 = VAR21;
        goto VAR22;
      }

      for ( VAR13 = 0; VAR13 < VAR14; VAR13++ )
      {
        switch ( VAR19 )
        {
        case VAR23:
          
          if ( VAR11 < 12 )
          {
            VAR1->VAR26[VAR11++] = VAR17[VAR13];
            continue;
          }
          else
          {
            VAR10 = 16 * VAR1->VAR26[4] + VAR1->VAR26[5];
            VAR19     = VAR27;
            VAR12   = 12 + 16 * VAR10;

            if ( FUN5( VAR1->VAR26, 12, VAR12 ) )
              goto VAR22;
          }
          

        case VAR27:
          
          if ( VAR11 < VAR12 )
          {
            VAR1->VAR26[VAR11++] = VAR17[VAR13];
            continue;
          }
          else
          {
            int       VAR28;
            FT_ULong  VAR29;


            for ( VAR28 = 0; VAR28 < VAR10; VAR28++ )
            {
              VAR6*  VAR30 = VAR1->VAR26 + 12 + 16 * VAR28 + 12;


              VAR29 = FUN9( VAR30 );

              
              VAR12 += ( VAR29 + 3 ) & ~3;
            }

            VAR19         = VAR31;
            VAR1->VAR12 = VAR12;

            
            if ( FUN5( VAR1->VAR26, 12 + 16 * VAR10,
                             VAR12 + 1 ) )
              goto VAR22;
          }
          

        case VAR31:
          
          if ( VAR11 >= VAR12 )
          {
            FUN3(( "" ));
            VAR9 = VAR21;
            goto VAR22;
          }
          VAR1->VAR26[VAR11++] = VAR17[VAR13];
        }
      }

      FUN2( VAR3 );
    }

    
    VAR9 = VAR21;

  VAR22:
    VAR3->VAR5.VAR9 = VAR9;

  VAR24:
    if ( VAR18 )
      FUN10( VAR17 );
  }