VAR1 FUN1(VAR2 *VAR3, VAR4 *VAR5, const VAR6& VAR7,                   const char *VAR8, PRInt32 VAR9,                   JSVersion VAR10, bool VAR11, VAR12 *VAR13)  
{
    FUN2(FUN3(VAR3));

#ifdef VAR14
    
    {
        VAR15 *VAR16 = VAR17::FUN4();
        if (VAR16) {
            VAR18 *VAR19;
            VAR20 *VAR21 =
                VAR16->FUN5(VAR3, &VAR19);
            bool system;
            VAR16->FUN6(VAR21, &system);
            if (VAR19 && !system) {
                VAR16->FUN7("", &system);
                FUN8(system, "");
            }
        }
    }
#endif

    VAR5 = VAR17::FUN9(VAR5);
    if (!VAR5 || VAR22::FUN10(VAR5) != &VAR23) {
        return VAR24;
    }

    VAR25 *VAR26 =
        (VAR25*)FUN11(VAR5);
    FUN8(VAR26, "");
    VAR27<VAR20> VAR28 = VAR26->FUN12();

    if (!VAR28) {
        return VAR29;
    }

    nsCAutoString VAR30;
    if (!VAR8) {
        
        VAR31::FUN13(VAR28)->FUN14(VAR30);
        VAR8 = VAR30.FUN13();
        VAR9 = 1;
    }

    VAR4 *VAR32;
    {
        VAR33 FUN15(VAR3);

        VAR32 = FUN16(VAR3);
        if (!VAR32) {
            return VAR29;
        }
    }

    VAR34<VAR35> VAR36 = new FUN17(VAR3, VAR5);
    if (!VAR36 || !VAR36->FUN18()) {
        FUN19(VAR3, "");
        return VAR37;
    }

    if (VAR10 != VAR38)
        FUN20(VAR36->FUN18(), VAR10);

    VAR39 FUN21(VAR36->FUN18(), VAR28);
    if (!VAR40.FUN22())
        return VAR29;

    nsresult VAR41 = VAR42;

    {
        VAR33 FUN15(VAR36->FUN18());
        JSAutoEnterCompartment VAR43;

        if (!VAR43.FUN23(VAR36->FUN18(), VAR5)) {
            return VAR29;
        }

        jsval VAR44;
        VAR45 *VAR46 = VAR47;
        JSBool VAR48 =
            FUN24(VAR36->FUN18(), VAR5,
                                             VAR31::FUN13(VAR28),
                                             reinterpret_cast<const VAR49 *>
                                                             (FUN25(VAR7).FUN13()),
                                             VAR7.FUN26(), VAR8, VAR9,
                                             &VAR44);
        if (VAR48 && VAR11 && !(FUN27(VAR44))) {
            VAR48 = !!(VAR46 = FUN28(VAR36->FUN18(), VAR44));
        }

        if (!VAR48) {
            
            

            jsval VAR50;
            if (FUN29(VAR36->FUN18(), &VAR50)) {
                FUN30(VAR36->FUN18());

                if (VAR11) {
                    
                    
                    VAR46 = FUN28(VAR36->FUN18(), VAR50);

                    if (VAR46) {
                        
                        
                        VAR50 = FUN31(VAR46);
                        if (FUN32(VAR3, &VAR50)) {
                            FUN33(VAR3, VAR50);
                        } else {
                            FUN30(VAR3);
                            VAR41 = VAR29;
                        }
                    } else {
                        FUN30(VAR3);
                        VAR41 = VAR29;
                    }
                } else {
                    if (FUN32(VAR3, &VAR50)) {
                        FUN33(VAR3, VAR50);
                    }
                }


                
                VAR46 = VAR47;
            } else {
                VAR41 = VAR37;
            }
        } else {
            
            VAR33 FUN15(VAR3);
            JSAutoEnterCompartment VAR43;
            if (VAR46) {
                VAR44 = FUN31(VAR46);
            }

            VAR51::VAR52 *VAR53 =
                static_cast<VAR51::VAR52 *>
                           (FUN34(VAR22::FUN35(VAR5)));
            if (!VAR43.FUN23(VAR3, VAR32) ||
                !FUN36(VAR3, VAR53->VAR54, &VAR44)) {
                VAR41 = VAR29;
            }

            if (FUN37(VAR41)) {
                *VAR13 = VAR44;
            }
        }
    }

    return VAR41;
}