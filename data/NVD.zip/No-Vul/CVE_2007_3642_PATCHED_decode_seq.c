int FUN1(VAR1 * VAR2, VAR3 * VAR4, char *VAR5, int VAR6)  
{
	unsigned VAR7, VAR8, VAR9, VAR10, VAR11 = 0, VAR12, VAR13;
	int VAR14;
	VAR3 *VAR15;
	unsigned char *VAR16 = NULL;

	FUN2("", VAR6 * VAR17, "", VAR4->VAR18);

	
	VAR5 = (VAR5 && (VAR4->VAR19 & VAR20)) ? VAR5 + VAR4->VAR21 : NULL;

	
	VAR7 = (VAR4->VAR19 & VAR22) ? FUN3(VAR2) : 0;

	
	VAR8 = FUN4(VAR2, VAR4->VAR23);
	if (VAR5)
		*(unsigned *) VAR5 = VAR8;

	
	for (VAR9 = VAR10 = 0, VAR15 = VAR4->VAR24; VAR9 < VAR4->VAR25; VAR9++, VAR15++) {
		if (VAR15->VAR19 & VAR26) {
			FUN2("", (VAR6 + 1) * VAR17, "",
			      VAR15->VAR18);
			return VAR27;
		}

		if (VAR15->VAR19 & VAR28) {	
			if (!((0x80000000U >> (VAR10++)) & VAR8))	
				continue;
		}

		
		if (VAR15->VAR19 & VAR29) {	
			FUN5(VAR2, 2);
			VAR11 = FUN6(VAR2);
			FUN5(VAR2, VAR11);
			if (!VAR5 || !(VAR15->VAR19 & VAR20)) {
				FUN2("", (VAR6 + 1) * VAR17,
				      "", VAR15->VAR18);
				VAR2->VAR30 += VAR11;
				continue;
			}
			VAR16 = VAR2->VAR30;

			
			if ((VAR14 = (VAR31[VAR15->VAR32]) (VAR2, VAR15, VAR5,
							  VAR6 + 1)) <
			    VAR33)
				return VAR14;

			VAR2->VAR30 = VAR16 + VAR11;
			VAR2->VAR34 = 0;
		} else if ((VAR14 = (VAR31[VAR15->VAR32]) (VAR2, VAR15, VAR5,
							 VAR6 + 1)) <
			   VAR33)
			return VAR14;
	}

	
	if (!VAR7)
		return VAR33;

	
	VAR13 = FUN7(VAR2, 7) + 1;
	FUN5(VAR2, (VAR13 + 7) >> 3);
	VAR12 = FUN4(VAR2, VAR13);
	VAR8 |= VAR12 >> VAR4->VAR23;
	if (VAR5)
		*(unsigned *) VAR5 = VAR8;
	FUN8(VAR2);

	
	for (VAR10 = 0; VAR10 < VAR13; VAR10++, VAR9++, VAR15++) {
		if (VAR9 < VAR4->VAR35 && VAR15->VAR19 & VAR26) {
			FUN2("", (VAR6 + 1) * VAR17, "",
			      VAR15->VAR18);
			return VAR27;
		}

		if (!((0x80000000 >> VAR10) & VAR12))	
			continue;

		
		if (VAR9 >= VAR4->VAR35) {	
			FUN5(VAR2, 2);
			VAR11 = FUN6(VAR2);
			FUN5(VAR2, VAR11);
			VAR2->VAR30 += VAR11;
			continue;
		}

		FUN5(VAR2, 2);
		VAR11 = FUN6(VAR2);
		FUN5(VAR2, VAR11);
		if (!VAR5 || !(VAR15->VAR19 & VAR20)) {
			FUN2("", (VAR6 + 1) * VAR17, "",
			      VAR15->VAR18);
			VAR2->VAR30 += VAR11;
			continue;
		}
		VAR16 = VAR2->VAR30;

		if ((VAR14 = (VAR31[VAR15->VAR32]) (VAR2, VAR15, VAR5,
						  VAR6 + 1)) <
		    VAR33)
			return VAR14;

		VAR2->VAR30 = VAR16 + VAR11;
		VAR2->VAR34 = 0;
	}
	return VAR33;
}