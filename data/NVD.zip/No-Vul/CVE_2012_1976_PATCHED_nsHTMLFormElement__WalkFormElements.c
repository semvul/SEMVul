nsresult VAR1::FUN1(VAR2* VAR3)  
{
  VAR4<VAR5*> VAR6;
  nsresult VAR7 = VAR8->FUN2(VAR6);
  FUN3(VAR7, VAR7);

  PRUint32 VAR9 = VAR6.FUN4();

  
  
  for (PRUint32 VAR10 = 0; VAR10 < VAR9; ++VAR10) {
    static_cast<VAR11*>(VAR6[VAR10])->FUN5();
  }

  
  
  
  for (PRUint32 VAR10 = 0; VAR10 < VAR9; ++VAR10) {
    
    VAR6[VAR10]->FUN6(VAR3);
  }

  
  for (PRUint32 VAR10 = 0; VAR10 < VAR9; ++VAR10) {
    static_cast<VAR11*>(VAR6[VAR10])->FUN7();
  }

  return VAR12;
}