bool VAR1::FUN1(VAR2 *VAR3, VAR4 *VAR5, VAR4 *VAR6,                          jsid VAR7, VAR8::VAR9 *VAR10)  
{
    
    if (!VAR11::FUN1(VAR3, VAR5, VAR6, VAR7, VAR10))
        return false;

    
    VAR4 *VAR12 = FUN2(VAR5);
    if (!VAR10->FUN3() || !VAR12)
        return true;

    
    FUN4(VAR8::FUN5(VAR5, VAR3));
    return VAR8::FUN6(VAR3, VAR12, VAR6, VAR7, VAR10);
}