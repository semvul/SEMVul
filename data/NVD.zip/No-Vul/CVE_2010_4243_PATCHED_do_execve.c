int FUN1(char * VAR1, 	char VAR2 *VAR2 *argv, 	char VAR2 *VAR2 *VAR3, 	struct VAR4 * VAR5)  
{
	struct VAR6 *VAR7;
	struct VAR8 *VAR8;
	struct VAR9 *VAR10;
	bool VAR11;
	int VAR12;

	VAR12 = FUN2(&VAR10);
	if (VAR12)
		goto VAR13;

	VAR12 = -VAR14;
	VAR7 = FUN3(sizeof(*VAR7), VAR15);
	if (!VAR7)
		goto VAR16;

	VAR12 = FUN4(VAR7);
	if (VAR12)
		goto VAR17;

	VAR12 = FUN5(VAR7);
	if (VAR12 < 0)
		goto VAR17;
	VAR11 = VAR12;
	VAR18->VAR19 = 1;

	VAR8 = FUN6(VAR1);
	VAR12 = FUN7(VAR8);
	if (FUN8(VAR8))
		goto VAR20;

	FUN9();

	VAR7->VAR8 = VAR8;
	VAR7->VAR1 = VAR1;
	VAR7->VAR21 = VAR1;

	VAR12 = FUN10(VAR7);
	if (VAR12)
		goto VAR22;

	VAR7->argc = FUN11(argv, VAR23);
	if ((VAR12 = VAR7->argc) < 0)
		goto VAR24;

	VAR7->VAR25 = FUN11(VAR3, VAR23);
	if ((VAR12 = VAR7->VAR25) < 0)
		goto VAR24;

	VAR12 = FUN12(VAR7);
	if (VAR12 < 0)
		goto VAR24;

	VAR12 = FUN13(1, &VAR7->VAR1, VAR7);
	if (VAR12 < 0)
		goto VAR24;

	VAR7->VAR26 = VAR7->VAR27;
	VAR12 = FUN14(VAR7->VAR25, VAR3, VAR7);
	if (VAR12 < 0)
		goto VAR24;

	VAR12 = FUN14(VAR7->argc, argv, VAR7);
	if (VAR12 < 0)
		goto VAR24;

	VAR18->VAR28 &= ~VAR29;
	VAR12 = FUN15(VAR7,VAR5);
	if (VAR12 < 0)
		goto VAR24;

	
	VAR18->VAR30->VAR31 = 0;
	VAR18->VAR19 = 0;
	FUN16(VAR18);
	FUN17(VAR7);
	if (VAR10)
		FUN18(VAR10);
	return VAR12;

VAR24:
	if (VAR7->VAR32) {
		FUN19(VAR7, 0);
		FUN20(VAR7->VAR32);
	}

VAR22:
	if (VAR7->VAR8) {
		FUN21(VAR7->VAR8);
		FUN22(VAR7->VAR8);
	}

VAR20:
	if (VAR11)
		VAR18->VAR30->VAR31 = 0;
	VAR18->VAR19 = 0;

VAR17:
	FUN17(VAR7);

VAR16:
	if (VAR10)
		FUN23(VAR10);
VAR13:
	return VAR12;
}