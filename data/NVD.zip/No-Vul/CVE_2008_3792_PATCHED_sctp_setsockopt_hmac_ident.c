static int FUN1(struct VAR1 *VAR2, 				    char VAR3 *VAR4, 				    int VAR5)  
{
	struct VAR6 *VAR7;
	int VAR8;

	if (!VAR9)
		return -VAR10;

	if (VAR5 < sizeof(struct VAR6))
		return -VAR11;

	VAR7 = FUN2(VAR5, VAR12);
	if (!VAR7)
		return -VAR13;

	if (FUN3(VAR7, VAR4, VAR5)) {
		VAR8 = -VAR14;
		goto VAR15;
	}

	if (VAR7->VAR16 == 0 ||
	    VAR7->VAR16 > VAR17) {
		VAR8 = -VAR11;
		goto VAR15;
	}

	VAR8 = FUN4(FUN5(VAR2)->VAR18, VAR7);
VAR15:
	FUN6(VAR7);
	return VAR8;
}