static long FUN1(void VAR1 *VAR2, enum block_state VAR3)  
{
	struct mpt2_diag_read_buffer VAR4;
	struct mpt2_diag_read_buffer VAR1 *VAR5 = VAR2;
	struct VAR6 *VAR7;
	void *VAR8, *VAR9;
	VAR10 *VAR11;
	VAR12 *VAR13;
	int VAR14, VAR15;
	u8 VAR16;
	unsigned long VAR17, VAR18, VAR19;
	u16 VAR20;
	u16 VAR21;
	u8 VAR22 = 0;

	if (FUN2(&VAR4, VAR2, sizeof(VAR4))) {
		FUN3(VAR23 "",
		    VAR24, VAR25, VAR26);
		return -VAR27;
	}
	if (FUN4(VAR4.VAR28.VAR29, &VAR7) == -1 || !VAR7)
		return -VAR30;

	FUN5(VAR7, FUN3(VAR31 "", VAR7->VAR32,
	    VAR26));

	VAR16 = VAR4.VAR33 & 0x000000ff;
	if (!FUN6(VAR7, VAR16)) {
		FUN3(VAR34 ""
		    "", VAR7->VAR32, VAR26, VAR16);
		return -VAR35;
	}

	if (VAR4.VAR33 != VAR7->VAR33[VAR16]) {
		FUN3(VAR34 ""
		    "", VAR7->VAR32, VAR26, VAR4.VAR33);
		return -VAR36;
	}

	VAR8 = VAR7->VAR37[VAR16];
	if (!VAR8) {
		FUN3(VAR34 ""
		    "", VAR7->VAR32, VAR26, VAR16);
		return -VAR38;
	}

	VAR18 = VAR7->VAR39[VAR16];

	if ((VAR4.VAR40 % 4) || (VAR4.VAR41 % 4)) {
		FUN3(VAR34 ""
		    "", VAR7->VAR32,
		    VAR26);
		return -VAR36;
	}

	if (VAR4.VAR40 > VAR18)
		return -VAR36;

	VAR9 = (void *)(VAR8 + VAR4.VAR40);
	FUN5(VAR7, FUN3(VAR31 ""
	    "", VAR7->VAR32, VAR26,
	    VAR9, VAR4.VAR40, VAR4.VAR41));

	
	if ((VAR9 + VAR4.VAR41 < VAR9) ||
	    (VAR9 + VAR4.VAR41 > VAR8 + VAR18))
		VAR19 = VAR18 - VAR4.VAR40;
	else
		VAR19 = VAR4.VAR41;

	if (FUN7((void VAR1 *)VAR5->VAR42,
	    VAR9, VAR19)) {
		FUN3(VAR34 ""
		    "", VAR7->VAR32,
		    VAR26, VAR9);
		return -VAR27;
	}

	if ((VAR4.VAR43 & VAR44) == 0)
		return 0;

	FUN5(VAR7, FUN3(VAR31 ""
		"", VAR7->VAR32, VAR26, VAR16));
	if ((VAR7->VAR45[VAR16] &
	    VAR46) == 0) {
		FUN5(VAR7, FUN3(VAR31 ""
		    "", VAR7->VAR32,
		     VAR26, VAR16));
		return 0;
	}
	
	if (VAR3 == VAR47 && !FUN8(&VAR7->VAR48.mutex))
		return -VAR49;
	else if (FUN9(&VAR7->VAR48.mutex))
		return -VAR50;

	if (VAR7->VAR48.VAR51 != VAR52) {
		FUN3(VAR34 "",
		    VAR7->VAR32, VAR26);
		VAR14 = -VAR49;
		goto VAR53;
	}

	VAR20 = FUN10(VAR7, VAR7->VAR54);
	if (!VAR20) {
		FUN3(VAR34 "",
		    VAR7->VAR32, VAR26);
		VAR14 = -VAR49;
		goto VAR53;
	}

	VAR14 = 0;
	VAR7->VAR48.VAR51 = VAR55;
	memset(VAR7->VAR48.VAR56, 0, VAR7->VAR57);
	VAR11 = FUN11(VAR7, VAR20);
	VAR7->VAR48.VAR20 = VAR20;

	VAR11->VAR58 = VAR59;
	VAR11->VAR60 = VAR16;
	VAR11->VAR61 =
	    FUN12(VAR7->VAR39[VAR16]);
	VAR11->VAR62 =
	    FUN13(VAR7->VAR63[VAR16]);
	for (VAR15 = 0; VAR15 < VAR64; VAR15++)
		VAR11->VAR65[VAR15] =
			FUN12(VAR7->VAR66[VAR16][VAR15]);
	VAR11->VAR67 = 0; 
	VAR11->VAR68 = 0;

	FUN14(VAR7, VAR20);
	FUN15(&VAR7->VAR48.VAR69);
	VAR17 = FUN16(&VAR7->VAR48.VAR69,
	    VAR70*VAR71);

	if (!(VAR7->VAR48.VAR51 & VAR72)) {
		FUN3(VAR34 "", VAR7->VAR32,
		    VAR26);
		FUN17(VAR11,
		    sizeof(VAR10)/4);
		if (!(VAR7->VAR48.VAR51 & VAR73))
			VAR22 = 1;
		goto VAR74;
	}

	
	if ((VAR7->VAR48.VAR51 & VAR75) == 0) {
		FUN3(VAR34 "",
		    VAR7->VAR32, VAR26);
		VAR14 = -VAR27;
		goto VAR53;
	}

	VAR13 = VAR7->VAR48.VAR56;
	VAR21 = FUN18(VAR13->VAR76) & VAR77;

	if (VAR21 == VAR78) {
		VAR7->VAR45[VAR16] |=
		    VAR79;
		FUN5(VAR7, FUN3(VAR31 "",
		    VAR7->VAR32, VAR26));
	} else {
		FUN3(VAR31 ""
		    "", VAR7->VAR32, VAR26,
		    VAR21, FUN19(VAR13->VAR80));
		VAR14 = -VAR27;
	}

 VAR74:
	if (VAR22)
		FUN20(VAR7, VAR81,
		    VAR82);

 VAR53:

	VAR7->VAR48.VAR51 = VAR52;
	FUN21(&VAR7->VAR48.mutex);
	return VAR14;
}