static void FUN1(int VAR1, int VAR2, int VAR3)  
{

	if (VAR2 < 0 || VAR2 >= VAR4->VAR5)
		return;

	VAR4->VAR6[VAR2].VAR7 = VAR3;
}