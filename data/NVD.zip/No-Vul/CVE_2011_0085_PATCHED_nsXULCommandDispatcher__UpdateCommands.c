NS_IMETHODIMP VAR1::FUN1(const VAR2& VAR3)  
{
  VAR4* VAR5 = FUN2();
  FUN3(VAR5, VAR6);

  nsAutoString VAR7;
  VAR8<VAR9> VAR10;
  FUN4(FUN5(VAR10));
  if (VAR10) {
    nsresult VAR11 = VAR10->FUN6(FUN7(""), VAR7);
    FUN8(FUN9(VAR11), "");
    if (FUN10(VAR11)) return VAR11;
  }

  VAR12<VAR13> VAR14;

  for (VAR15* VAR16 = VAR17; VAR16 != VAR18; VAR16 = VAR16->VAR19) {
    
    
    if (! FUN11(VAR16->VAR20, VAR3))
      continue;

    if (! FUN11(VAR16->VAR21, VAR7))
      continue;

    VAR8<VAR13> VAR22 = FUN12(VAR16->VAR23);
    FUN8(VAR22 != VAR18, "");
    if (! VAR22)
      return VAR24;

    VAR14.FUN13(VAR22);
  }

  for (PRUint32 VAR25 = 0; VAR25 < VAR14.FUN14(); VAR25++) {
    VAR13* VAR22 = VAR14[VAR25];

    VAR8<VAR26> VAR27 = VAR22->FUN15();

    FUN8(VAR27 != VAR18, "");
    if (! VAR27)
      continue;

#ifdef VAR28
    if (FUN16(VAR29, VAR30)) {
      nsCAutoString VAR31; 
      FUN17(VAR3, VAR31);
      FUN18(VAR29, VAR30,
             ("",
              this, VAR22,
              VAR31.FUN19()));
    }
#endif

    VAR32 FUN20(VAR27);
    VAR8<VAR33> VAR34;
    while ((VAR34 = VAR35.FUN21())) {

      
      VAR8<VAR36> VAR37 = VAR34->FUN22();

      
      nsEventStatus VAR38 = VAR39;

      VAR40 FUN23(VAR41, VAR42);

      VAR43::FUN24(VAR22, VAR37, &VAR44, VAR18, &VAR38);
    }
  }
  return VAR45;
}