static inline void FUN1(VAR1 *VAR2, VAR1 *VAR3, VAR1 *VAR4)  
{
	
	FUN2(VAR2 == VAR3 || VAR3->VAR5 >= VAR6);
	VAR2->VAR7 = VAR3;
}