int FUN1(struct VAR1 *VAR2)  
{
	struct VAR3 *VAR4 =
		&FUN2(VAR2->VAR5)->VAR4;
	unsigned int VAR6;
	char *VAR7;
	size_t VAR8;
	size_t VAR9 = 0;
	int VAR10 = 0;

	if (FUN3(VAR4->VAR11 & VAR12)) {
		if (!(VAR4->VAR11 & VAR13)) {
			FUN4(VAR14 "");
			VAR10 = -VAR15;
			goto VAR16;
		}
	} else {
		FUN4(VAR17 "",
		       VAR18);
		VAR10 = -VAR15;
		goto VAR16;
	}
	VAR8 = VAR4->VAR19;
	VAR6 = FUN5(VAR8);
	
	VAR7 = (char *)FUN6(VAR20, VAR6);
	if (!VAR7) {
		FUN4(VAR14 "", VAR18);
		VAR10 = -VAR21;
		goto VAR16;
	}
	VAR10 = FUN7(VAR7, VAR8, &VAR9, VAR4,
					 VAR2);
	if (FUN8(VAR10)) {
		FUN4(VAR14 "",
		       VAR18, VAR10);
		goto VAR22;
	}
	if (VAR4->VAR11 & VAR23)
		VAR10 = FUN9(VAR2, VAR7,
						      VAR9);
	else
		VAR10 = FUN10(VAR2, VAR7,
							 VAR8);
	if (VAR10) {
		FUN4(VAR14 ""
		       "", VAR18, VAR10);
		goto VAR22;
	}
VAR22:
	FUN11((unsigned long)VAR7, VAR6);
VAR16:
	return VAR10;
}