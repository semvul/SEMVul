static int FUN1(struct VAR1 *VAR2, 				 const struct VAR3 *VAR4, 				 long VAR5, VAR6 *VAR7)  
{
	unsigned int VAR8;

	
	FUN2(&VAR2->VAR9, VAR2->VAR10, VAR5);
	(void) VAR4->VAR11[0].FUN3(VAR2->VAR10, &VAR4->VAR11[0],
				    0, sizeof(VAR2->VAR9.VAR12),
				    &VAR2->VAR9.VAR12, NULL);

	FUN4(&VAR2->VAR13[0], "", VAR14,
		  sizeof(VAR2->VAR9), &VAR2->VAR9);
	*VAR7 += FUN5(&VAR2->VAR13[0]);

	FUN6(VAR2->VAR10, &VAR4->VAR11[0]);

	
	for (VAR8 = 1; VAR8 < VAR4->VAR15; ++VAR8) {
		const struct VAR16 *VAR17 = &VAR4->VAR11[VAR8];
		FUN6(VAR2->VAR10, VAR17);
		if (VAR17->VAR18 && VAR17->VAR19 &&
		    (!VAR17->VAR20 || VAR17->FUN7(VAR2->VAR10, VAR17))) {
			int VAR21;
			size_t VAR22 = VAR17->VAR15 * VAR17->VAR22;
			void *VAR23 = FUN8(VAR22, VAR24);
			if (FUN9(!VAR23))
				return 0;
			VAR21 = VAR17->FUN3(VAR2->VAR10, VAR17,
					  0, VAR22, VAR23, NULL);
			if (FUN9(VAR21))
				FUN10(VAR23);
			else {
				if (VAR17->VAR18 != VAR25)
					FUN4(&VAR2->VAR13[VAR8], "",
						  VAR17->VAR18,
						  VAR22, VAR23);
				else {
					VAR2->VAR9.VAR26 = 1;
					FUN4(&VAR2->VAR13[VAR8], "",
						  VAR25, VAR22, VAR23);
				}
				*VAR7 += FUN5(&VAR2->VAR13[VAR8]);
			}
		}
	}

	return 1;
}