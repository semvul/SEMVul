static int FUN1(const void *VAR1, int VAR2)  
{
	const void *VAR3 = VAR1;
	int  VAR4 = VAR2;

	while (VAR4 > 0) {
		const struct VAR5 *VAR6 = VAR3;


		switch (VAR6->VAR7) {
		case VAR8:
		case VAR9:
		case VAR10:
		case VAR11:
		case VAR12:
		case VAR13:
		case VAR14:
		case VAR15:
			if (VAR6->VAR16 < 4 || VAR6->VAR16 > VAR4 + 4 || VAR6->VAR16 & 3)
				return -VAR17;
			if (VAR6->VAR16 < VAR4 &&
			    !FUN2(VAR1, VAR2, VAR4 - VAR6->VAR16))
				return -VAR17;
			break;
		case VAR18:
			break;
		default:
			return -VAR17;
		}
		if (VAR6->VAR19 < 4 || VAR6->VAR19 > VAR4 + 4 || VAR6->VAR19 & 3)
			return -VAR17;
		VAR3  += VAR6->VAR19;
		VAR4 -= VAR6->VAR19;
	}
	return VAR4 == 0 ? 0 : -VAR17;
}