VAR1 FUN1(struct VAR2 *VAR3, struct VAR4 *VAR5, 			  VAR6 *VAR7, size_t VAR8, unsigned int VAR9)  
{
	struct VAR10 *VAR11 = VAR5->VAR12;
	struct VAR13 *VAR13 = VAR11->VAR14;
	ssize_t VAR15;
	int VAR16;

	VAR16 = FUN2(VAR5->VAR17);
	if (FUN3(VAR16)) {
		FUN4(&VAR13->VAR18);
		VAR16 = FUN5(VAR5->VAR17, VAR16);
		FUN6(&VAR13->VAR18);
		if (VAR16)
			return VAR16;
	}

	VAR15 = FUN7(VAR3, VAR5, VAR7, VAR8, VAR9, VAR19);
	if (VAR15 > 0) {
		*VAR7 += VAR15;

		
		if (FUN3((VAR5->VAR20 & VAR21) || FUN8(VAR13))) {
			FUN4(&VAR13->VAR18);
			VAR16 = FUN9(VAR13, VAR11,
						  VAR22|VAR23);
			FUN6(&VAR13->VAR18);

			if (VAR16)
				VAR15 = VAR16;
		}
	}

	return VAR15;
}