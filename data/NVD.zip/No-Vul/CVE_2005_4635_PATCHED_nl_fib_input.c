static void FUN1(struct VAR1 *VAR2, int VAR3)  
{
	struct VAR4 *VAR5 = NULL;
        struct VAR6 *VAR7 = NULL;
	struct VAR8 *VAR9;
	u32 VAR10;     
	struct VAR11 *VAR12;
	
	VAR5 = FUN2(&VAR2->VAR13);
	VAR7 = (struct VAR6 *)VAR5->VAR14;
	if (VAR5->VAR3 < FUN3(0) || VAR5->VAR3 < VAR7->VAR15 ||
	    VAR7->VAR15 < FUN4(sizeof(*VAR9))) {
		FUN5(VAR5);
		return;
	}
	
	VAR9 = (struct VAR8 *) FUN6(VAR7);
	VAR12 = FUN7(VAR9->VAR16);

	FUN8(VAR9, VAR12);
	
	VAR10 = VAR7->VAR17;           
	FUN9(VAR5).VAR10 = 0;         
	FUN9(VAR5).VAR18 = VAR10;
	FUN9(VAR5).VAR19 = 0;  
	FUN10(VAR2, VAR5, VAR10, VAR20);
}