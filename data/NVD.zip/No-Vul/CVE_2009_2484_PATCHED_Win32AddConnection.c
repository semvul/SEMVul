static void FUN1( VAR1 *VAR2, char *VAR3,                                 char *VAR4, char *VAR5,                                 char *VAR6 )  
{
    FUN2 (*VAR7)( VAR8, VAR9, VAR9, VAR10 );
    char VAR11[VAR12], VAR13[VAR12], VAR14[VAR12];
    NETRESOURCE VAR15;
    DWORD VAR16;
    char *VAR17;
    FUN3( VAR6 );

    HINSTANCE VAR18 = LoadLibrary(FUN4(""));
    if( !VAR18 )
    {
        FUN5( VAR2, "" );
        return;
    }

    VAR7 =
      (void *)FUN6( VAR18, FUN4("") );
    if( !VAR7 )
    {
        FUN5( VAR2, "" );
        return;
    }

    memset( &VAR15, 0, sizeof(VAR15) );
    VAR15.VAR19 = VAR20;

    
    FUN7( VAR13, VAR3, sizeof( VAR13 ) );
    VAR14[0] = 0;
    VAR17 = strchr( VAR3, '' );
    if( VAR17 )
    {
        char *VAR21 = strchr( ++VAR17, '' );
        if( VAR21 )
            FUN7( VAR14, VAR17, sizeof( VAR14 ) );
   }

    snprintf( VAR11, sizeof( VAR11 ), "", VAR13, VAR14 );
    VAR15.VAR22 = VAR11;

    VAR16 = FUN8( &VAR15, VAR5, VAR4, 0 );

    if( VAR16 != VAR23 )
    {
        FUN9( VAR2, "", VAR11 );
    }
    else if( VAR16 != VAR24 &&
             VAR16 != VAR25 )
    {
        FUN9( VAR2, "", VAR11 );
    }
    else
    {
        FUN9( VAR2, "", VAR11 );
    }

    FUN10( VAR18 );
}