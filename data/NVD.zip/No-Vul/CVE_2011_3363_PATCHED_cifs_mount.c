int FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4, 		char *VAR5, const char *VAR6)  
{
	int VAR7;
	int VAR8;
	struct VAR9 *VAR10;
	struct VAR11 *VAR12;
	struct VAR13 *VAR14;
	struct VAR15 *VAR16;
	char   *VAR17;
	char *VAR18 = VAR5;
	struct VAR19 *VAR20;
#ifdef VAR21
	struct VAR22 *VAR23 = NULL;
	unsigned int VAR24 = 0;
	int VAR25 = 0;
VAR26:
#endif
	VAR7 = 0;
	VAR14 = NULL;
	VAR12 = NULL;
	VAR16 = NULL;
	VAR17 = NULL;
	VAR20 = NULL;

	VAR8 = FUN2();

	VAR10 = FUN3(sizeof(struct VAR9), VAR27);
	if (!VAR10) {
		VAR7 = -VAR28;
		goto VAR29;
	}

	if (FUN4(VAR18, VAR6, VAR10)) {
		VAR7 = -VAR30;
		goto VAR29;
	}

	if (VAR10->VAR31) {
		FUN5(1, "");
		VAR10->VAR32 = "";
	} else if (VAR10->VAR32) {
		
		FUN5(1, "", VAR10->VAR32);
	} else {
		FUN6("");
	
		VAR7 = -VAR30;
		goto VAR29;
	}

	
	if (VAR10->VAR33 == NULL) {
		
		VAR10->VAR34 = FUN7();
	} else {
		VAR10->VAR34 = FUN8(VAR10->VAR33);
		if (VAR10->VAR34 == NULL) {
			FUN9(1, "",
				 VAR10->VAR33);
			VAR7 = -VAR35;
			goto VAR29;
		}
	}
	VAR4->VAR34 = VAR10->VAR34;

	
	VAR16 = FUN10(VAR10);
	if (FUN11(VAR16)) {
		VAR7 = FUN12(VAR16);
		goto VAR29;
	}

	
	VAR12 = FUN13(VAR16, VAR10);
	if (FUN11(VAR12)) {
		VAR7 = FUN12(VAR12);
		VAR12 = NULL;
		goto VAR36;
	}

	FUN14(VAR10, VAR4);
	if (VAR12->VAR37 & VAR38)
		VAR2->VAR39 = VAR40;
	else
		VAR2->VAR39 = VAR41;

	
	VAR2->VAR42 = 100;

	
	VAR14 = FUN15(VAR12, VAR10);
	if (FUN11(VAR14)) {
		VAR7 = FUN12(VAR14);
		VAR14 = NULL;
		goto VAR43;
	}

	
	if (!VAR14->VAR44) {
		FUN16(VAR8, VAR14);
		FUN17(VAR8, VAR14);
	}

	
	if (VAR14->VAR45->VAR37 & VAR46)
		
		FUN18(VAR8, VAR14, VAR2, VAR10);
	else
		VAR14->VAR47 = 0; 

	
	if ((VAR4->VAR48 & VAR49) == 0)
		FUN19(VAR4->VAR50, FUN20(VAR4));

	if ((VAR14->VAR47 == 0) && (VAR4->VAR51 > (1024 * 127))) {
		VAR4->VAR51 = 1024 * 127;
		FUN5(VAR52, "");
	}
	if (!(VAR14->VAR45->VAR37 & VAR53))
		VAR4->VAR54 = FUN21(VAR4->VAR54,
			       (VAR14->VAR45->VAR55->VAR56 - VAR57));
	if (!(VAR14->VAR45->VAR37 & VAR58))
		VAR4->VAR51 = FUN21(VAR4->VAR51,
			       (VAR14->VAR45->VAR55->VAR56 - VAR57));

VAR43:
	
	if (!VAR7 && VAR14) {
		
		VAR17 = FUN22(VAR4, VAR14);
		if (VAR17 == NULL) {
			VAR7 = -VAR28;
			goto VAR36;
		}
		VAR7 = FUN23(VAR8, VAR14, VAR4, VAR17);
		if (VAR7 != 0 && VAR7 != -VAR59) {
			FUN24(VAR17);
			goto VAR36;
		}
		FUN24(VAR17);
	}

	
	if (VAR7 == -VAR59) {
#ifdef VAR21
		if (VAR25 > VAR60) {
			
			VAR7 = -VAR61;
			goto VAR36;
		}
		
		if ((VAR4->VAR48 & VAR49) == 0)
			FUN19(VAR4->VAR50,
					FUN20(VAR4));
		VAR17 = FUN25(VAR10, VAR4);
		if (FUN11(VAR17)) {
			VAR7 = FUN12(VAR17);
			goto VAR36;
		}

		FUN5(1, "", VAR17);
		VAR7 = FUN26(VAR8, VAR12 , VAR17 + 1,
			VAR4->VAR34, &VAR24, &VAR23,
			VAR4->VAR48 & VAR62);
		if (!VAR7 && VAR24 > 0) {
			char *VAR63 = NULL;

			if (VAR18 != VAR5)
				FUN24(VAR18);

			VAR18 = FUN27(
					VAR4->VAR64, VAR17 + 1,
					VAR23, &VAR63);

			FUN28(VAR23, VAR24);
			FUN24(VAR63);
			FUN24(VAR17);

			if (FUN11(VAR18)) {
				VAR7 = FUN12(VAR18);
				VAR18 = NULL;
				goto VAR36;
			}

			if (VAR14)
				FUN29(VAR14);
			else if (VAR12)
				FUN30(VAR12);

			FUN31(&VAR10);
			VAR25++;
			FUN32(VAR8);
			goto VAR26;
		}
#else 
		VAR7 = -VAR65;
#endif
	}

	if (VAR7)
		goto VAR36;

	
	VAR20 = FUN3(sizeof *VAR20, VAR27);
	if (VAR20 == NULL) {
		VAR7 = -VAR28;
		goto VAR36;
	}

	VAR20->VAR66 = VAR12->VAR67;
	VAR20->VAR68 = VAR14;
	VAR20->VAR69 = VAR70;
	FUN33(VAR71, &VAR20->VAR72);
	FUN33(VAR73, &VAR20->VAR72);

	VAR4->VAR74 = VAR20;
	FUN34(&VAR4->VAR75);
	FUN35(&VAR4->VAR76, VAR20);
	FUN36(&VAR4->VAR75);

	FUN37(VAR77, &VAR4->VAR78,
				VAR79);

VAR36:
	
	if (VAR7) {
		if (VAR18 != VAR5)
			FUN24(VAR18);
		
		
		if (VAR14)
			FUN29(VAR14);
		else if (VAR12)
			FUN30(VAR12);
		else
			FUN38(VAR16);
		goto VAR29;
	}

	
VAR29:
	
	FUN31(&VAR10);
	FUN32(VAR8);
	return VAR7;
}