NS_IMETHODIMP VAR1::FUN1(const VAR2& VAR3)  
{
  VAR4<VAR5> VAR6 = FUN2();
  if (!VAR6) {
    return VAR7;
  }

  if (VAR6->FUN3() == VAR8::VAR9) {
    return VAR10;
  }

  if (FUN4()->FUN5()) {
    VAR11* VAR12;
    PRInt32 VAR13;
    if (VAR6->FUN6()) {
      VAR12 = static_cast<VAR14*>(VAR6.FUN7())->FUN8();
      VAR13 = static_cast<VAR14*>(VAR6.FUN7())->FUN9();
    } else {
      FUN10(VAR6->FUN3() == VAR8::VAR15,
        "");
      VAR12 = VAR16::VAR17;
      VAR13 = VAR18;
    }
    VAR4<VAR19> VAR20;
    nsresult VAR21 = FUN11(FUN12(VAR20),
                                         FUN4()->FUN13());
    FUN14(VAR21, VAR21);
    VAR4<VAR14> VAR22 = FUN15(VAR20);
    VAR23::FUN16(VAR3,
                                      VAR22,
                                      VAR12,
                                      VAR13,
                                      FUN4()->FUN17() ==
                                        VAR24,
                                      VAR25);
    VAR6->FUN18(VAR22, this, &VAR21);
    return VAR21;
  }

  VAR4<VAR5> VAR26;
  if (VAR6->FUN6()) {
    VAR26 = VAR6;
  } else {
    FUN10(VAR6->FUN3() == VAR8::VAR15,
      "");
    VAR4<VAR27> VAR28 =
      FUN4()->FUN13()->FUN19(VAR16::VAR17,
                                                 VAR29,
                                                 VAR18,
                                                 VAR8::VAR30);
    VAR26 = FUN20(VAR28.FUN21(), VAR31);
  }

  VAR4<VAR19> VAR20;
  nsresult VAR21 = VAR23::FUN22(VAR26,
                                                         VAR3,
                                                         VAR25,
                                                         FUN12(VAR20));
  FUN14(VAR21, VAR21);
  VAR4<VAR5> VAR22 = FUN15(VAR20);
  VAR6->FUN18(VAR22, this, &VAR21);
  return VAR21;
}