static int FUN1(struct VAR1 *VAR2)  
{
	struct VAR3 *VAR4 = FUN2(VAR2);
	struct VAR5 *VAR6 = NULL;
	ext4_group_t VAR7;
	ext4_group_t VAR8;
	unsigned int VAR9 = 0;
	size_t VAR10;
	int VAR11;

	VAR4->VAR12 = VAR4->VAR13->VAR12;
	if (VAR4->VAR12 < 1 || VAR4->VAR12 > 31) {
		VAR4->VAR12 = 0;
		return 1;
	}
	VAR9 = 1 << VAR4->VAR12;

	
	VAR7 = ((VAR4->VAR14 + VAR9 - 1) +
			((FUN3(VAR4->VAR13->VAR15) + 1) <<
			      FUN4(VAR2))) / VAR9;
	VAR10 = VAR7 * sizeof(struct VAR16);
	VAR4->VAR17 = FUN5(VAR10, VAR18);
	if (VAR4->VAR17 == NULL) {
		VAR4->VAR17 = FUN6(VAR10);
		if (VAR4->VAR17)
			memset(VAR4->VAR17, 0, VAR10);
	}
	if (VAR4->VAR17 == NULL) {
		FUN7(VAR2, VAR19, ""
				"", VAR7);
		goto VAR20;
	}

	for (VAR11 = 0; VAR11 < VAR4->VAR14; VAR11++) {
		VAR6 = FUN8(VAR2, VAR11, NULL);

		VAR8 = FUN9(VAR4, VAR11);
		FUN10(FUN11(VAR2, VAR6),
			   &VAR4->VAR17[VAR8].VAR21);
		FUN10(FUN12(VAR2, VAR6),
			   &VAR4->VAR17[VAR8].VAR22);
		FUN10(FUN13(VAR2, VAR6),
			   &VAR4->VAR17[VAR8].VAR23);
	}

	return 1;
VAR20:
	return 0;
}