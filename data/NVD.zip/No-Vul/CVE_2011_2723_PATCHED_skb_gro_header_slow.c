static inline void *FUN1(struct VAR1 *VAR2, unsigned int VAR3, 					unsigned int VAR4)  
{
	if (!FUN2(VAR2, VAR3))
		return NULL;

	FUN3(VAR2)->VAR5 = NULL;
	FUN3(VAR2)->VAR6 = 0;
	return VAR2->VAR7 + VAR4;
}