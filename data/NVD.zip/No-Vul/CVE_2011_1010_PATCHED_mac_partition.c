int FUN1(struct VAR1 *VAR2)  
{
	Sector VAR3;
	unsigned char *VAR4;
	int VAR5, VAR6;
	unsigned VAR7;
#ifdef VAR8
	int VAR9 = 0;
	int VAR10 = 0;
#endif
	struct VAR11 *VAR12;
	struct VAR13 *VAR14;

	
	VAR14 = FUN2(VAR2, 0, &VAR3);
	if (!VAR14)
		return -1;
	if (FUN3(VAR14->VAR15) != VAR16) {
		FUN4(VAR3);
		return 0;
	}
	VAR7 = FUN3(VAR14->VAR17);
	FUN4(VAR3);
	VAR4 = FUN2(VAR2, VAR7/512, &VAR3);
	if (!VAR4)
		return -1;
	VAR12 = (struct VAR11 *) (VAR4 + VAR7%512);
	if (FUN3(VAR12->VAR15) != VAR18) {
		FUN4(VAR3);
		return 0;		
	}
	VAR6 = FUN5(VAR12->VAR19);
	if (VAR6 < 0 || VAR6 >= VAR20) {
		FUN4(VAR3);
		return 0;
	}
	FUN6(VAR2->VAR21, "", VAR22);
	for (VAR5 = 1; VAR5 <= VAR6; ++VAR5) {
		int VAR23 = VAR5 * VAR7;
		FUN4(VAR3);
		VAR4 = FUN2(VAR2, VAR23/512, &VAR3);
		if (!VAR4)
			return -1;
		VAR12 = (struct VAR11 *) (VAR4 + VAR23%512);
		if (FUN3(VAR12->VAR15) != VAR18)
			break;
		FUN7(VAR2, VAR5,
			FUN5(VAR12->VAR24) * (VAR7/512),
			FUN5(VAR12->VAR25) * (VAR7/512));

		if (!FUN8(VAR12->VAR26, "", 10))
			VAR2->VAR27[VAR5].VAR28 = VAR29;
#ifdef VAR8
		
		if (FUN9(VAR30)) {
			int VAR31 = 0;

			FUN10(VAR12->VAR32, 16);
			FUN10(VAR12->VAR33, 32);
			FUN10(VAR12->VAR26, 32);					
		    
			if ((FUN5(VAR12->VAR34) & VAR35)
			    && FUN11(VAR12->VAR32, "") == 0)
				VAR31++;

			if (FUN11(VAR12->VAR26, "") == 0
			    || (FUN8(VAR12->VAR26, "", 5) == 0
			        && FUN11(VAR12->VAR26, "") != 0)) {
				int VAR36, VAR37;

				VAR31++;
				VAR37 = strlen(VAR12->VAR33);
				if (strcmp(VAR12->VAR33, "") == 0)
					VAR31++;
				for (VAR36 = 0; VAR36 <= VAR37 - 4; ++VAR36) {
					if (FUN8(VAR12->VAR33 + VAR36, "",
						     4) == 0) {
						VAR31 += 2;
						break;
					}
				}
				if (FUN8(VAR12->VAR33, "", 4) == 0)
					VAR31--;
			}

			if (VAR31 > VAR10) {
				VAR9 = VAR5;
				VAR10 = VAR31;
			}
		}
#endif 
	}
#ifdef VAR8
	if (VAR10)
		FUN12(VAR2->VAR38->VAR39, VAR9,
				   VAR10);
#endif

	FUN4(VAR3);
	FUN6(VAR2->VAR21, "", VAR22);
	return 1;
}