static long FUN1(key_serial_t VAR1, 				      struct VAR2 *VAR3, 				      struct VAR4 **VAR5)  
{
	key_ref_t VAR6;

	*VAR5 = NULL;

	
	if (VAR1 == 0)
		return 0;

	
	if (VAR1 > 0) {
		VAR6 = FUN2(VAR1, 1, 0, VAR7);
		if (FUN3(VAR6))
			return FUN4(VAR6);
		*VAR5 = FUN5(VAR6);
		return 0;
	}

	if (VAR1 == VAR8)
		return -VAR9;

	
	if (VAR1 >= VAR10) {
		*VAR5 = FUN6(VAR3->VAR11);
		return 0;
	}

	return -VAR12;
}