float FUN1(double VAR1, VAR2 *VAR3, int VAR4)  
{
	int VAR5, VAR6;
	float VAR7;
	VAR1 = VAR1 * (VAR4 - 1); 
	VAR5 = FUN2(VAR8);
	VAR6 = FUN3(VAR1);
	
	VAR7 = VAR3[VAR5]*(1. - (VAR5 - VAR1)) + VAR3[VAR6]*(VAR5 - VAR1);
	
	return VAR7 * (1.VAR9/65535.VAR9);
}