int qemu_reset_requested_get(void)

{

    return reset_requested;

}
