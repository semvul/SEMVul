int VAR1 FUN1(void)  
{
	void *VAR2 = (void *)FUN2(VAR3);
	VAR4[0] = FUN3(VAR2);

#ifdef VAR5
	FUN4(VAR6, FUN5(VAR2), VAR7);
	FUN6("", FUN7(VAR6));
#endif

	if (!FUN8(VAR8)) {
		memcpy(VAR2,
		       &VAR9,
		       &VAR10 - &VAR9);
		return 0;
	}

	memcpy(VAR2,
	       &VAR11,
	       &VAR12 - &VAR11);

	return 0;
}