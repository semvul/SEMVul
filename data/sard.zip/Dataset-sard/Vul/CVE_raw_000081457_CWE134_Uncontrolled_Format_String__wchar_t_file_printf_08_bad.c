void FUN1()
{
    wchar_t * VAR1;
    wchar_t VAR2[100] = VAR3"";
    VAR1 = VAR2;
    if(FUN2())
    {
        {
            
            size_t VAR4 = wcslen(VAR1);
            VAR5 * VAR6;
            
            if (100-VAR4 > 1)
            {
                VAR6 = fopen(VAR7, "");
                if (VAR6 != NULL)
                {
                    
                    if (FUN3(VAR1+VAR4, (int)(100-VAR4), VAR6) == NULL)
                    {
                        FUN4("");
                        
                        VAR1[VAR4] = VAR3'';
                    }
                    fclose(VAR6);
                }
            }
        }
    }
    if(FUN2())
    {
        
        FUN5(VAR1);
    }
}