static char *FUN1(int VAR1, struct VAR2 *VAR3, const char *VAR4, struct VAR5 *VAR6, int *VAR7, char **VAR8, int *VAR9)  
{
	struct VAR10 *VAR11 = NULL;
	unsigned long VAR12 = 0;
	char VAR13[512];
	char VAR14[128];
	size_t VAR15 = sizeof(VAR13);
	int VAR16 = 0;
	char *VAR17 = VAR13;
	char *VAR18 = NULL;
	struct VAR5 *VAR19;

	for (VAR19 = VAR6; VAR19; VAR19 = VAR19->VAR20) {
		if (!FUN2(VAR19->VAR21, "")) {
			sscanf(VAR19->VAR22, "", &VAR12);
			break;
		}
	}
	
	if (!(VAR11 = FUN3(VAR12))) {
		
		if (!(VAR11 = FUN4(1, sizeof(*VAR11)))) {
			*VAR7 = 500;
			goto VAR23;
		}
		memcpy(&VAR11->VAR24, VAR3, sizeof(VAR11->VAR24));
		VAR11->VAR25 = -1;
		VAR11->VAR26 = VAR27;
		VAR11->VAR28 = 0;
		FUN5(&VAR11->VAR29);
		FUN6(&VAR11->VAR29);
		VAR11->VAR30 = 1;
		
		while ((VAR11->VAR31 = rand() ^ (unsigned long) VAR11) == 0);
		FUN7(&VAR32);
		FUN8(&VAR32, VAR11, VAR33);
		
		VAR11->VAR34 = VAR35;
		while (VAR11->VAR34->VAR20)
			VAR11->VAR34 = VAR11->VAR34->VAR20;
		FUN9(&VAR32);
		FUN10(&VAR11->VAR34->VAR36, 1);
		FUN10(&VAR37, 1);
	}

	
	FUN11(&VAR11->VAR38);
	if (!VAR11->VAR39 && (VAR40 > 5))
		VAR11->VAR38 += 5;
	else
		VAR11->VAR38 += VAR40;
	FUN12(&VAR11->VAR29);
	
	if (VAR11) {
		struct message VAR41 = { 0 };
		char VAR42[80];
		unsigned int VAR43;
		size_t VAR44;

		for (VAR43 = 0, VAR19 = VAR6; VAR19 && (VAR43 < VAR45); VAR43++, VAR19 = VAR19->VAR20) {
			VAR44 = strlen(VAR19->VAR21) + strlen(VAR19->VAR22) + 3;
			VAR41.VAR46[VAR41.VAR47] = alloca(VAR44);
			snprintf((char *) VAR41.VAR46[VAR41.VAR47], VAR44, "", VAR19->VAR21, VAR19->VAR22);
			VAR41.VAR47 = VAR43 + 1;
		}

		if (FUN13(VAR11, &VAR41)) {
			if (VAR11->VAR39) {
				if (VAR48 > 1) {
					if (VAR49) 
						FUN14(VAR50 "", VAR11->VAR51, FUN15(VAR11->VAR24.VAR52));    
				}
				FUN16(VAR53, "", VAR11->VAR51, FUN15(VAR11->VAR24.VAR52));
			} else {
				if (VAR48 > 1) {
					if (VAR49)
						FUN14(VAR50 "", FUN15(VAR11->VAR24.VAR52));
				}
				FUN16(VAR53, "", FUN15(VAR11->VAR24.VAR52));
			}
			VAR11->VAR54 = 1;
		}
		FUN17(&VAR17, &VAR15, "", VAR55[VAR1]);
		sprintf(VAR42, "", VAR11->VAR31);
		FUN17(&VAR17, &VAR15, "", FUN18("", VAR42, VAR40, VAR14, sizeof(VAR14)));
		if (VAR1 == VAR56)
			FUN17(&VAR17, &VAR15, "");
		if (VAR1 == VAR57) {
			FUN17(&VAR17, &VAR15, "");
		} else if (VAR1 == VAR56) {
			FUN17(&VAR17, &VAR15, ""#VAR58\""#VAR59\""500\"");
			FUN17(&VAR17, &VAR15, ""2\""#VAR60\"");
		}
		FUN6(&VAR11->VAR29);
		if (VAR11->VAR61) {
			char *VAR42;
			if (VAR1 == VAR57)
				VAR42 = FUN19(VAR11->VAR61->VAR62, VAR6);
			else if (VAR1 == VAR56)
				VAR42 = FUN20(VAR11->VAR61->VAR62);
			else
				VAR42 = VAR11->VAR61->VAR62;
			if (VAR42) {
				VAR18 = malloc(strlen(VAR13) + strlen(VAR42) + 128);
				if (VAR18) {
					strcpy(VAR18, VAR13);
					strcpy(VAR18 + strlen(VAR18), VAR42);
					VAR17 = VAR18 + strlen(VAR18);
					VAR15 = 120;
				}
			}
			if (VAR42 != VAR11->VAR61->VAR62)
				free(VAR42);
			free(VAR11->VAR61);
			VAR11->VAR61 = NULL;
		}
		FUN12(&VAR11->VAR29);
		
		if (VAR1 == VAR57) {
			FUN17(&VAR17, &VAR15, "");
		} else if (VAR1 == VAR56)
			FUN17(&VAR17, &VAR15, "");
	} else {
		*VAR7 = 500;
		*VAR8 = strdup("");
	}
	FUN6(&VAR11->VAR29);
	if (VAR11->VAR54) {
		if (VAR11->VAR30 == 1) {
			FUN16(VAR63, "");
			VAR16 = 1;
		} else {
			FUN16(VAR63, "");
			if (VAR11->VAR26 != VAR27)
				FUN21(VAR11->VAR26, VAR64);
			VAR11->VAR30--;
		}
	} else
		VAR11->VAR30--;
	FUN12(&VAR11->VAR29);
	
	if (VAR16)
		FUN22(VAR11);
VAR23:
	if (*VAR7 != 200)
		return FUN23(500, "", NULL, ""); 
	return VAR18;
}