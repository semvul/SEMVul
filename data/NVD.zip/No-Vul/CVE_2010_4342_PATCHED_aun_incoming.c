static void FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4, size_t VAR5)  
{
	struct VAR6 *VAR7 = FUN2(VAR2);
	unsigned char VAR8 = FUN3(VAR7->VAR9) & 0xff;
	struct VAR10 *VAR11 = FUN4(VAR2);
	struct VAR12 *VAR13 = NULL;
	struct VAR14 *VAR15 = NULL;
	struct VAR1 *VAR16;

	if (VAR11)
		VAR13 = VAR11->VAR17->VAR18;

	if (! VAR13)
		goto VAR19;

	if ((VAR15 = FUN5(VAR4->VAR20, VAR8, VAR13->VAR21)) == NULL)
		goto VAR19;		

	VAR16 = FUN6((VAR5 - sizeof(struct VAR3) + 15) & ~15,
			   VAR22);
	if (VAR16 == NULL)
	{
		FUN7(VAR23 "");
		
		goto VAR19;
	}

	memcpy(FUN8(VAR16, VAR5 - sizeof(struct VAR3)), (void *)(VAR4+1),
	       VAR5 - sizeof(struct VAR3));

	if (FUN9(VAR15, VAR16, VAR8, VAR13->VAR21, VAR4->VAR24, VAR4->VAR20))
	{
		
		FUN10(VAR16);
		goto VAR19;
	}

	FUN11(VAR7->VAR9, VAR4->VAR25, 3, 0);
	FUN12(VAR15);
	return;

VAR19:
	FUN11(VAR7->VAR9, VAR4->VAR25, 4, 0);
	if (VAR15)
		FUN12(VAR15);
}