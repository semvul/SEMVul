nsresult VAR1::FUN1(nsHttpAtom VAR2,                              const VAR3 &VAR4,                              PRBool VAR5, PRBool VAR6)  
{
    VAR7 *VAR8 = VAR9;
    PRInt32 VAR10;

    VAR10 = FUN2(VAR2, &VAR8);

    
    
    if (VAR4.FUN3()) {
        if (!VAR5 && VAR8 && VAR6)
            VAR11.FUN4(VAR10);
        return VAR12;
    }

    
    if (!VAR8) {
        VAR8 = VAR11.FUN5(); 
        if (!VAR8)
            return VAR13;
        VAR8->VAR2 = VAR2;
        VAR8->VAR4 = VAR4;
    }
    
    else if (VAR5 && FUN6(VAR2)) {
        if (VAR2 == VAR14::VAR15 ||
            VAR2 == VAR14::VAR16 ||
            VAR2 == VAR14::VAR17)
        {
            
            
            
            VAR8->VAR4.FUN7('');
        } else {
            
            VAR8->VAR4.FUN8("");
        }
        VAR8->VAR4.FUN7(VAR4);
    } else if (VAR6) {
        
        VAR8->VAR4 = VAR4;
    } 

    return VAR12;
}