static int FUN1(struct VAR1 *VAR2)  
{
	struct VAR3 *VAR4;
	struct VAR5 *VAR6;
	struct VAR7 *VAR8 = VAR2->VAR8;
	u32 VAR9;

	VAR6 = FUN2(VAR2);
	VAR4 = &(FUN3(VAR2)->VAR4);

	
	if (VAR6->VAR10 < 5 || VAR6->VAR11 != 4)
		goto VAR12;

	if (!FUN4(VAR2, VAR6->VAR10*4))
		goto VAR12;

	VAR6 = FUN2(VAR2);
	if (FUN5(FUN6((VAR13 *)VAR6, VAR6->VAR10)))
		goto VAR12;

	VAR9 = FUN7(VAR6->VAR14);
	if (VAR2->VAR9 < VAR9) {
		FUN8(FUN9(VAR8), VAR15);
		goto VAR16;
	} else if (VAR9 < (VAR6->VAR10*4))
		goto VAR12;

	if (FUN10(VAR2, VAR9)) {
		FUN8(FUN9(VAR8), VAR17);
		goto VAR16;
	}

	memset(FUN3(VAR2), 0, sizeof(struct VAR18));
	if (VAR6->VAR10 == 5)
		return 0;

	VAR4->VAR19 = VAR6->VAR10*4 - sizeof(struct VAR5);
	if (FUN11(FUN9(VAR8), VAR4, VAR2))
		goto VAR12;

	
	if (FUN5(VAR4->VAR20)) {
		struct VAR21 *VAR22 = FUN12(VAR8);
		if (VAR22 && !FUN13(VAR22))
			goto VAR16;

		if (FUN14(VAR2))
			goto VAR16;
	}

	return 0;

VAR12:
	FUN8(FUN9(VAR8), VAR23);
VAR16:
	return -1;
}