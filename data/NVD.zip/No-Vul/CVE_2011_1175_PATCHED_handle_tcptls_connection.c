static void *FUN1(void *VAR1)  
{
	struct VAR2 *VAR3 = VAR1;
#ifdef VAR4
	int (*VAR5)(VAR6 *) = (VAR3->VAR7) ? VAR8 : VAR9;
	int VAR10;
	char VAR11[256];
#endif

	
	if (!VAR3->VAR12->VAR13) {
		if ((VAR3->VAR14 = FUN2(VAR3->VAR15, ""))) {
			if(FUN3(VAR3->VAR14, NULL, VAR16, 0)) {
				fclose(VAR3->VAR14);
				VAR3->VAR14 = NULL;
			}
		}
	}
#ifdef VAR4
	else if ( (VAR3->VAR17 = FUN4(VAR3->VAR12->VAR13->VAR18)) ) {
		FUN5(VAR3->VAR17, VAR3->VAR15);
		if ((VAR10 = FUN6(VAR3->VAR17)) <= 0) {
			FUN7(2, "", FUN8(FUN9(), VAR11));
		} else {
#if FUN10(VAR19)	
			VAR3->VAR14 = FUN11(VAR3->VAR17, VAR20, VAR21, NULL, VAR22);

#VAR23 FUN10(VAR24)	
			static const cookie_io_functions_t VAR25 = {
				VAR20, VAR21, NULL, VAR22
			};
			VAR3->VAR14 = FUN12(VAR3->VAR17, "", VAR25);
#else
			
			FUN13(2, "");
#endif
			if ((VAR3->VAR7 && !FUN14(&VAR3->VAR12->VAR13->VAR26, VAR27))
				|| (!VAR3->VAR7 && FUN14(&VAR3->VAR12->VAR13->VAR26, VAR28))) {
				VAR29 *VAR30;
				long VAR31;
				VAR30 = FUN15(VAR3->VAR17);
				if (!VAR30)
					FUN16(VAR32, "");
				VAR31 = FUN17(VAR3->VAR17);
				if (VAR31 != VAR33)
					FUN16(VAR34, "", FUN18(VAR31));
				if (!FUN14(&VAR3->VAR12->VAR13->VAR26, VAR35)) {
					VAR36 *VAR37;
					unsigned char *VAR38;
					VAR39 *VAR40 = FUN19(VAR30);
					int VAR41 = -1;
					int VAR42 = 0;

					for (;;) {
						
						
						VAR41 = FUN20(VAR40, VAR43, VAR41);
						if (VAR41 < 0)
							break;
						VAR37 = FUN21(FUN22(VAR40, VAR41));
						FUN23(&VAR38, VAR37);
						if (VAR38) {
							if (!FUN24(VAR3->VAR12->VAR44, (char *) VAR38))
								VAR42 = 1;
							FUN13(3, "", VAR3->VAR12->VAR44, VAR38);
							FUN25(VAR38);
						}
						if (VAR42)
							break;
					}
					if (!VAR42) {
						FUN16(VAR34, "", VAR3->VAR12->VAR44);
						if (VAR30)
							FUN26(VAR30);
						close(VAR3->VAR15);
						fclose(VAR3->VAR14);
						FUN27(VAR3, -1);
						return NULL;
					}
				}
				if (VAR30)
					FUN26(VAR30);
			}
		}
		if (!VAR3->VAR14)	
			FUN28(VAR3->VAR17);
   }
#endif 

	if (!VAR3->VAR14) {
		close(VAR3->VAR15);
		FUN16(VAR32, "");
#ifndef VAR4
		if (VAR3->VAR12->VAR13) {
			FUN16(VAR32, "");
		}
#endif
		FUN27(VAR3, -1);
		return NULL;
	}

	if (VAR3 && VAR3->VAR12->VAR45)
		return VAR3->VAR12->FUN29(VAR3);
	else
		return VAR3;
}