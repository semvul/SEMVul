static int FUN1(struct VAR1 *VAR2, u32 VAR3, u64 VAR4)  
{
	struct VAR5 *VAR6 = FUN2(VAR2);
	struct VAR7 *VAR8;
	int VAR9 = 0;

	switch (VAR3) {
	case VAR10:
		FUN3(VAR6);
		VAR9 = FUN4(VAR2, VAR3, VAR4);
		break;
#ifdef VAR11
	case VAR12:
		FUN5(VAR13, VAR4);
		break;
	case VAR14:
		FUN5(VAR15, VAR4);
		break;
#endif
	case VAR16:
		FUN6(VAR17, VAR4);
		break;
	case VAR18:
		FUN5(VAR19, VAR4);
		break;
	case VAR20:
		FUN5(VAR21, VAR4);
		break;
	case VAR22:
		FUN7(VAR4);
		break;
	case VAR23:
	case VAR24:
	case VAR25:
	case VAR26:
		
		FUN8(VAR2, "", VAR3, VAR4);

		break;
	case VAR27:
		if (VAR28.VAR29 & VAR30) {
			FUN9(VAR31, VAR4);
			VAR2->VAR32.VAR33 = VAR4;
			break;
		}
		
	default:
		FUN3(VAR6);
		VAR8 = FUN10(VAR6, VAR3);
		if (VAR8) {
			VAR8->VAR4 = VAR4;
			break;
		}
		VAR9 = FUN4(VAR2, VAR3, VAR4);
	}

	return VAR9;
}