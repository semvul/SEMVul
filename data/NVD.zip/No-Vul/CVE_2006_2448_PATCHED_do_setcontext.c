static int FUN1(struct ucontext VAR1 *VAR2, struct VAR3 *VAR4, int VAR5)  
{
	sigset_t VAR6;
	struct mcontext VAR1 *VAR7;

	if (FUN2(&VAR6, &VAR2->VAR8))
		return -VAR9;
#ifdef VAR10
	{
		u32 VAR11;

		if (FUN3(VAR11, &VAR2->VAR12))
			return -VAR9;
		VAR7 = (struct mcontext VAR1 *)(VAR13)VAR11;
		
	}
#else
	if (FUN3(VAR7, &VAR2->VAR12))
		return -VAR9;
	if (!FUN4(VAR14, VAR7, sizeof(*VAR7)))
		return -VAR9;
#endif
	FUN5(&VAR6);
	if (FUN6(VAR4, VAR7, VAR5))
		return -VAR9;

	return 0;
}