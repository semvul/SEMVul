static void FUN1(struct VAR1 *VAR2, void *VAR3)  
{
	struct VAR4 *VAR5 = VAR2->private;
	struct VAR6 *VAR7 = VAR3;

	if (!FUN2(VAR7))
		FUN3(VAR5, VAR7);
	if (VAR5->VAR8)
		FUN4(VAR5->VAR8);
}