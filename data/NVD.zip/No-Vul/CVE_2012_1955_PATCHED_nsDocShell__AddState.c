NS_IMETHODIMP VAR1::FUN1(VAR2 *VAR3, const VAR4& VAR5,                      const VAR4& VAR6, bool VAR7, VAR8* VAR9)  
{
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    nsresult VAR10;

    
    VAR11<VAR12> FUN2(VAR13);

    
    
    
    if (FUN3()) {
        VAR7 = true;
    }

    VAR14<VAR15> VAR16 = FUN4(FUN5(this));
    FUN6(VAR16, VAR17);

    
    VAR14<VAR18> VAR19;

    
    
    
    
    {
        VAR14<VAR15> VAR20 =
            FUN4(FUN5(this));
        if (!VAR20)
            return VAR21;
        VAR14<VAR22> VAR23 = VAR20->FUN7();

        VAR19 = new FUN8();
        VAR8 *VAR24 = VAR9;
        if (!VAR24) {
            VAR24 = VAR25::FUN9(VAR16);
        }
        VAR10 = VAR19->FUN10(VAR3, VAR24);

        
        
        if (FUN11(VAR10) && !VAR9) {
            FUN12(VAR9);
        }
        FUN13(VAR10, VAR10);

        VAR14<VAR15> VAR26 =
            FUN4(FUN5(this));
        if (!VAR26)
            return VAR21;
        VAR14<VAR22> VAR27 = VAR26->FUN7();

        bool VAR28 = false;
        VAR23->FUN14(VAR27, &VAR28);
        FUN6(VAR28, VAR21);
    }

    
    
    PRInt32 VAR29 =
        VAR30::FUN15("", 0xA0000);
    if (VAR29 < 0) {
        VAR29 = 0;
    }

    PRUint64 VAR31;
    VAR10 = VAR19->FUN16(&VAR31);
    FUN13(VAR10, VAR10);

    FUN6(VAR31 <= (VAR12)VAR29,
                   VAR32);

    
    bool VAR33 = true;
    VAR14<VAR34> VAR35 = VAR36;
    VAR14<VAR34> VAR37;
    if (VAR6.FUN17() == 0) {
        VAR37 = VAR36;
    }
    else {
        

        VAR34* VAR38 = VAR16->FUN18();
        if (!VAR38)
            return VAR17;

        nsCAutoString VAR39;
        VAR38->FUN19(VAR39);

        nsCAutoString VAR40;
        VAR10 = VAR38->FUN20(VAR40);
        FUN13(VAR10, VAR17);

        VAR10 = FUN21(FUN22(VAR37), VAR6,
                       VAR40.FUN23(), VAR38);

        
        if (FUN11(VAR10)) {
            return VAR21;
        }

        
        if (!VAR25::FUN24(VAR37)) {
            
            
            
            
            
            
            
            

            VAR14<VAR41> VAR42 =
                FUN25(VAR43);
            FUN6(VAR42, VAR17);

            
            
            
            nsCAutoString VAR44, VAR45;
            FUN13(VAR36->FUN26(VAR44),
                              VAR17);
            FUN13(VAR37->FUN26(VAR45),
                              VAR17);
            if (FUN11(VAR42->FUN27(VAR36,
                                                     VAR37, true)) ||
                !VAR44.FUN14(VAR45)) {

                return VAR21;
            }
        }
        else {
            
            VAR14<VAR46> VAR47 =
                FUN28(VAR16);

            if (!VAR47) {
                return VAR21;
            }

            VAR14<VAR22> VAR48 = VAR47->FUN29();

            if (!VAR48 ||
                FUN11(VAR48->FUN30(VAR37, true))) {

                return VAR21;
            }
        }

        VAR36->FUN14(VAR37, &VAR33);

    } 

    VAR14<VAR49> VAR50 = VAR51;
    if (!VAR50) {
        
        FUN31(FUN22(VAR50));
    }
    FUN6(VAR50, VAR17);

    VAR14<VAR52> VAR53 =
        FUN28(VAR50, &VAR10);
    FUN13(VAR10, VAR10);

    
    
    
    
    FUN6(VAR54, VAR17);
    VAR14<VAR55> VAR56 = VAR54;

    VAR13 = VAR57;

    VAR14<VAR55> VAR58;
    if (!VAR7) {
        
        nscoord VAR24 = 0, VAR59 = 0;
        FUN32(VAR60, &VAR24);
        FUN32(VAR61, &VAR59);
        VAR54->FUN33(VAR24, VAR59);

        
        
        VAR10 = FUN34(VAR37, VAR62, VAR62, true,
                                 FUN22(VAR58));
        FUN13(VAR10, VAR10);

        FUN6(VAR58, VAR17);

        
        
        FUN13(VAR58->FUN35(VAR56),
                          VAR17);

        
        nsString VAR63;
        VAR54->FUN36(FUN37(VAR63));
        VAR58->FUN38(VAR63);

        
        
        VAR54 = VAR58;

    } else {
        VAR58 = VAR54;
        VAR58->FUN39(VAR37);
    }

    
    
    VAR58->FUN40(VAR19);
    VAR58->FUN41(VAR62);

    
    
    
    
    bool VAR64 = true, VAR65 = false;
    VAR37->FUN42(VAR36, &VAR64);
    VAR56->FUN43(&VAR65);
    VAR58->FUN44(!VAR64 || VAR65);

    
    
    
    if (!VAR7) {
        VAR14<VAR49> VAR66;
        FUN31(FUN22(VAR66));
        FUN6(VAR66, VAR67);

        VAR14<VAR52> VAR68 =
            FUN28(VAR66);
        FUN6(VAR68, VAR67);

        PRInt32 VAR69 = -1;
        VAR10 = VAR66->FUN45(&VAR69);
        if (FUN46(VAR10) && VAR69 > -1) {
            VAR68->FUN47(VAR69);
        }
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    if (!VAR33) {
        FUN48(VAR37, VAR62, true, VAR70);
        VAR16->FUN49(VAR37);

        FUN50(VAR37, VAR35, VAR35, 0);

        
        
        if (VAR71) {
            VAR14<VAR72> VAR73 = VAR74::FUN51();
            if (VAR73) {
                VAR73->FUN52(VAR37, VAR75);
            }
            else if (VAR76) {
                VAR76->FUN53(VAR37, VAR75);
            }
        }

        
        
        FUN54(VAR35, VAR37);
    }
    else {
        FUN55();
    }
    VAR16->FUN56(VAR19);

    return VAR77;
}