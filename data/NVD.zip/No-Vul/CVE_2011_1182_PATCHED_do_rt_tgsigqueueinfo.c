long FUN1(pid_t VAR1, pid_t VAR2, int VAR3, VAR4 *VAR5)  
{
	
	if (VAR2 <= 0 || VAR1 <= 0)
		return -VAR6;

	
	if (VAR5->VAR7 != VAR8) {
		
		FUN2(VAR5->VAR7 < 0);
		return -VAR9;
	}
	VAR5->VAR10 = VAR3;

	return FUN3(VAR1, VAR2, VAR3, VAR5);
}