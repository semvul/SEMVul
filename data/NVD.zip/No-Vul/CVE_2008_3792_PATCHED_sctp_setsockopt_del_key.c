static int FUN1(struct VAR1 *VAR2, 					char VAR3 *VAR4, 					int VAR5)  
{
	struct sctp_authkeyid VAR6;
	struct VAR7 *VAR8;

	if (!VAR9)
		return -VAR10;

	if (VAR5 != sizeof(struct VAR11))
		return -VAR12;
	if (FUN2(&VAR6, VAR4, VAR5))
		return -VAR13;

	VAR8 = FUN3(VAR2, VAR6.VAR14);
	if (!VAR8 && VAR6.VAR14 && FUN4(VAR2, VAR15))
		return -VAR12;

	return FUN5(FUN6(VAR2)->VAR16, VAR8,
				    VAR6.VAR17);

}