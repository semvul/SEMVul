static void FUN1( VAR1 *VAR2,                                     VAR3 *VAR4, unsigned int VAR5 )  
{
    VAR3 *VAR6;

    if( !VAR5 )
    {
        if FUN2()
            FUN3( VAR2, ""%4.4s\"",
                              (char*)&VAR4->VAR7 );
        else
            FUN3( VAR2, ""VAR8%3.3s\"",
                              (char*)&VAR4->VAR7+1 );
    }
    else
    {
        unsigned int VAR9;

        char VAR10[512];
        if( VAR5 * 5 + 1 >= sizeof(VAR10) )
            return;

        memset( VAR10, '', sizeof(VAR10) );
        for( VAR9 = 0; VAR9 < VAR5; VAR9++ )
        {
            VAR10[VAR9*5] = '';
        }
        if( FUN2() )
            snprintf( &VAR10[VAR5 * 5], sizeof(VAR10) - 5*VAR5,
                      "",
                        (char*)&VAR4->VAR7, (VAR11)VAR4->VAR12 );
        else
            snprintf( &VAR10[VAR5 * 5], sizeof(VAR10) - 5*VAR5,
                      "",
                        (char*)&VAR4->VAR7+1, (VAR11)VAR4->VAR12 );
        FUN3( VAR2, "", VAR10 );
    }
    VAR6 = VAR4->VAR13;
    while( VAR6 )
    {
        FUN1( VAR2, VAR6, VAR5 + 1 );
        VAR6 = VAR6->VAR14;
    }
}