static int FUN1(VAR1 * VAR2, VAR3 * VAR4, int VAR5)  
{
	int VAR6 = 0, VAR7, VAR8, VAR9, VAR10, VAR11;
	int VAR12 = VAR4->VAR13->VAR12;
	int VAR14 = VAR5, VAR15;
	gfp_t VAR16 = VAR17 | VAR18 | VAR19;

	if (VAR14 < 0)
		return -VAR20;
	if (0 == VAR14)
		++VAR14;	
	
	VAR14 = FUN2(VAR14, VAR21);
	FUN3(4, FUN4("",
				   VAR5, VAR14));

	
	VAR11 = FUN5(VAR2, VAR4, VAR12);
	if (VAR11 < 0)
		return VAR11;	

	VAR10 = VAR22;
	if (FUN6(VAR10 != VAR23)) {
		if (VAR10 < VAR24) {
			VAR22 = VAR24;
			VAR23 = VAR24;
		} else
			VAR23 = VAR10;
	}

	if (VAR4->VAR25)
		VAR16 |= VAR26;

	if (!FUN7(VAR27) || !FUN7(VAR28))
		VAR16 |= VAR29;

	VAR15 = FUN8(VAR10);
VAR30:
	VAR6 = 1 << (VAR31 + VAR15);

	for (VAR8 = 0, VAR9 = VAR14; VAR9 > 0 && VAR8 < VAR11;
	     VAR8++, VAR9 -= VAR6) {

		VAR10 = (VAR9 > VAR23) ?
			VAR23 : VAR9;

		VAR2->VAR32[VAR8] = FUN9(VAR16, VAR15);
		if (!VAR2->VAR32[VAR8])
			goto VAR33;

		if (VAR10 == VAR23) {
			if (FUN6(VAR6 > VAR23)) {
				VAR22 = VAR6;
				VAR23 = VAR6;
			}
		}

		FUN3(5, FUN4(""
				 "", VAR8, VAR10, VAR6));
	}		

	VAR2->VAR34 = VAR15;
	VAR2->VAR35 = VAR8;
	FUN3(5, FUN4(""
			 "", VAR8, VAR9));

	VAR2->VAR36 = VAR14;
	if (VAR9 > 0)	
		return -VAR37;
	return 0;
VAR33:
	for (VAR7 = 0; VAR7 < VAR8; VAR7++)
		FUN10(VAR2->VAR32[VAR7], VAR15);

	if (--VAR15 >= 0)
		goto VAR30;

	return -VAR37;
}