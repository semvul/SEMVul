static int FUN1 (struct VAR1 *VAR2, struct VAR3 *VAR4, int VAR5)  
{
	int VAR6;
	struct VAR7 *VAR8 = FUN2(VAR2);
	struct VAR9 *VAR10 = FUN3(VAR4);

	VAR6 = VAR8->VAR6;
	switch (VAR5) {
	case VAR11:
		VAR10->VAR12 = VAR6;
		break;
	case VAR13:
		VAR10->VAR14 = FUN4 (VAR2, VAR6, VAR10->VAR15);
		break;
	case VAR16:
		if (!FUN5(VAR17))
			return -VAR18;
		FUN6 (VAR2, VAR6, VAR10->VAR15, VAR10->VAR19);
		break;
	default:
		return -VAR20;
	}
	return 0;
}