static int FUN1(struct VAR1 *VAR2, int (*VAR3)(struct VAR1 *, 						     struct VAR4 *, int *))  
{
	unsigned int VAR5;
	struct VAR4 *VAR6;
	int VAR7;

	while (VAR2->VAR8 >= FUN2(0)) {
		VAR6 = (struct VAR4 *) VAR2->VAR9;

		if (VAR6->VAR10 < VAR11 || VAR2->VAR8 < VAR6->VAR10)
			return 0;

		VAR5 = FUN3(FUN4(VAR6->VAR10), VAR2->VAR8);

		if (FUN5(VAR2, VAR6, &VAR7) < 0) {
			
			if (VAR7 == 0)
				return -1;
			FUN6(VAR2, VAR6, VAR7);
		} else if (VAR6->VAR12 & VAR13)
			FUN6(VAR2, VAR6, 0);

		FUN7(VAR2, VAR5);
	}

	return 0;
}