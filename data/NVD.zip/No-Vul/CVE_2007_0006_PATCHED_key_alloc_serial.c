static inline void FUN1(struct VAR1 *VAR1)  
{
	struct VAR2 *VAR3, **VAR4;
	struct VAR1 *VAR5;

	
	do {
		FUN2(&VAR1->VAR6, sizeof(VAR1->VAR6));

		VAR1->VAR6 >>= 1; 
	} while (VAR1->VAR6 < 3);

	FUN3(&VAR7);

VAR8:
	VAR3 = NULL;
	VAR4 = &VAR9.VAR2;

	while (*VAR4) {
		VAR3 = *VAR4;
		VAR5 = FUN4(VAR3, struct VAR1, VAR10);

		if (VAR1->VAR6 < VAR5->VAR6)
			VAR4 = &(*VAR4)->VAR11;
		else if (VAR1->VAR6 > VAR5->VAR6)
			VAR4 = &(*VAR4)->VAR12;
		else
			goto VAR13;
	}

	
	FUN5(&VAR1->VAR10, VAR3, VAR4);
	FUN6(&VAR1->VAR10, &VAR9);

	FUN7(&VAR7);
	return;

	
VAR13:
	for (;;) {
		VAR1->VAR6++;
		if (VAR1->VAR6 < 3) {
			VAR1->VAR6 = 3;
			goto VAR8;
		}

		VAR3 = FUN8(VAR3);
		if (!VAR3)
			goto VAR8;

		VAR5 = FUN4(VAR3, struct VAR1, VAR10);
		if (VAR1->VAR6 < VAR5->VAR6)
			goto VAR8;
	}

}