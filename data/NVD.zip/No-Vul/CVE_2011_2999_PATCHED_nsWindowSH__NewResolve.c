NS_IMETHODIMP VAR1::FUN1(VAR2 *VAR3, VAR4 *VAR5,                        VAR6 *VAR7, jsid VAR8, PRUint32 VAR9,                        VAR6 **VAR10, VAR11 *VAR12)  
{
  VAR13 *VAR14 = VAR13::FUN2(VAR3);

  if (!FUN3(VAR8)) {
    if (FUN4(VAR8) && !(VAR9 & VAR15)) {
      
      
      
      

      VAR16<VAR17> VAR18 = FUN5(VAR14, VAR8);

      if (VAR18) {
        
        

        *VAR12 = ::FUN6(VAR5, VAR7, FUN7(VAR8), VAR19,
                                      VAR20, VAR20, VAR21);

        if (*VAR12) {
          *VAR10 = VAR7;
        }
      }
    }

    return VAR22;
  }

  VAR23 *VAR24 = VAR14->FUN8();

  nsresult VAR25 = VAR22;

  
  
  
  
  
  

  JSBool VAR26 = VAR27;
  VAR4 *VAR28;

  JSBool VAR29 = VAR30;
  jsval VAR31 = VAR19;
  if (!FUN9(VAR5, VAR7)) {
    JSAutoEnterCompartment VAR32;

    if (!VAR24) {
      VAR28 = VAR5;
    } else {
      VAR28 = (VAR4 *)VAR24->FUN10();

      if (VAR28 != VAR5) {
        if (!VAR32.FUN11(VAR28, VAR7)) {
          return VAR33;
        }
      }
    }

    VAR34 FUN12(VAR28);

    
    
    VAR29 = FUN13(VAR28, VAR7, VAR8, &VAR26);

    if (!VAR29) {
      
      

      if (!FUN14(VAR28, &VAR31)) {
        return VAR33;
      }

      
      
      
      

      FUN15(VAR28);
    }
  }

  if (!VAR29) {
    FUN16(VAR5, VAR31);
    *VAR12 = VAR27;
    return VAR22;
  }

  if (VAR26) {
    *VAR10 = VAR7;

    return VAR22;
  }

  if (!(VAR9 & VAR15)) {
    
    
    
    if (VAR8 == VAR35) {
      return FUN17(VAR5, VAR7, VAR10);
    }
  }

  if (!VAR24 || !VAR24->FUN18()) {
    
    

    return VAR22;
  }

  if (VAR8 == VAR36) {
    
    
    
    

    
    
    

    if (VAR14->FUN19()) {
      VAR14->FUN20();
    }

    VAR16<VAR37> VAR38;
    VAR25 = VAR14->FUN21(FUN22(VAR38));
    FUN23(VAR25, VAR25);

    
    
    VAR6 *VAR39 = VAR20;
    if (VAR14->FUN19()) {
      VAR13 *VAR40 = VAR14->FUN24();

      if (VAR40) {
        VAR39 = VAR40->FUN25();
      }
    }

    if (!VAR39) {
      VAR3->FUN26(&VAR39);
    }

    VAR16<VAR41> VAR42;
    jsval VAR43;
    VAR25 = FUN27(VAR5, VAR39, VAR38, &FUN28(VAR37), VAR44,
                    &VAR43, FUN22(VAR42));
    FUN23(VAR25, VAR25);

    JSBool VAR29 = FUN29(VAR5, &VAR43) &&
                FUN30(VAR5, VAR7, VAR8, VAR43, VAR20, VAR20,
                                      VAR45 | VAR46);

    if (!VAR29) {
      return VAR47;
    }

    *VAR10 = VAR7;

    return VAR22;
  }

  
  
  

  if (!FUN9(VAR5, VAR7)) {
    VAR16<VAR48> FUN31(FUN32(VAR14->FUN33()));

    PRInt32 VAR49 = 0;

    if (VAR50) {
      VAR50->FUN34(&VAR49);
    }

    if (VAR49 > 0) {
      VAR16<VAR51> VAR52;

      const VAR53 *VAR54 = ::FUN35(FUN36(VAR8));

      VAR50->FUN37(reinterpret_cast<const VAR55*>(VAR54),
                             VAR56, VAR44, VAR20, VAR20,
                             FUN22(VAR52));

      VAR16<VAR17> FUN38(FUN39(VAR52));

      if (VAR57) {
        
        
        

        VAR6 *VAR58;
        VAR3->FUN26(&VAR58);

        jsval VAR43;
        VAR16<VAR41> VAR42;
        VAR25 = FUN27(VAR5, VAR58, VAR57,
                        &FUN28(VAR59), VAR44, &VAR43,
                        FUN22(VAR42));
        FUN23(VAR25, VAR25);

        VAR34 FUN40(VAR5);

        PRBool VAR29 = FUN29(VAR5, &VAR43) &&
                    FUN30(VAR5, VAR7, VAR8, VAR43, VAR20, VAR20, 0);
        if (!VAR29) {
          return VAR47;
        }

        *VAR10 = VAR7;

        return VAR22;
      }
    }
  }

  
  
  
  if (!(VAR9 & VAR15)) {
    VAR34 FUN40(VAR5);

    
    
    

    JSBool VAR26 = VAR27;
    VAR25 = FUN41(VAR14, VAR5, VAR7, VAR8, &VAR26);
    FUN23(VAR25, VAR25);

    if (VAR26) {
      
      *VAR10 = VAR7;

      return VAR22;
    }
  }

  if (VAR8 == VAR60) {
    
    
    

    VAR6 *VAR61 = VAR14->FUN25();

    VAR34 FUN40(VAR5);

    VAR62 *VAR63 = ::FUN42(VAR5, VAR64, 0, 0,
                                       VAR61, "");
    if (!VAR63) {
      return VAR65;
    }

    VAR6 *VAR66 = ::FUN43(VAR63);

    if (!::FUN30(VAR5, VAR61, VAR8, VAR19,
                                 FUN44(VAR67, VAR66),
                                 VAR20,
                                 VAR46 | VAR68 |
                                 VAR21)) {
      return VAR47;
    }

    *VAR10 = VAR7;

    return VAR22;
  }

  if (VAR8 == VAR69) {
    
    if (!FUN30(VAR5, VAR7, VAR8, VAR19,
                                VAR20, VAR20, VAR46)) {
      *VAR12 = VAR56;
      return VAR47;
    }

    *VAR10 = VAR7;
    return VAR22;
  }

  if (VAR9 & VAR15) {
    if (FUN45(VAR8) ||
        (!(VAR9 & VAR70) && FUN46(VAR8))) {
      
      
      
      
      
      VAR34 FUN40(VAR5);

      if (!::FUN30(VAR5, VAR7, VAR8, VAR19, VAR71,
                                   VAR72, VAR46)) {
        return VAR47;
      }
      *VAR10 = VAR7;

      return VAR22;
    }
  } else {
    if (VAR8 == VAR73) {
      VAR16<VAR74> VAR75;
      VAR25 = VAR14->FUN47(FUN22(VAR75));
      FUN23(VAR25, VAR25);

      jsval VAR43;
      VAR16<VAR41> VAR42;
      VAR25 = FUN27(VAR5, VAR7, VAR75, &FUN28(VAR74), VAR44,
                      &VAR43, FUN22(VAR42));
      FUN23(VAR25, VAR25);

      if (!::FUN30(VAR5, VAR7, VAR8, VAR43, VAR20, VAR20,
                                   VAR76 | VAR45 |
                                   VAR46)) {
        return VAR47;
      }
      *VAR10 = VAR7;

      return VAR22;
    }

    if (VAR8 == VAR77) {
      VAR16<VAR78> VAR79;
      VAR25 = VAR14->FUN48(FUN22(VAR79));
      FUN23(VAR25, VAR25);

      
      
      jsval VAR43;
      VAR16<VAR41> VAR42;
      VAR25 = FUN27(VAR5, FUN49(VAR5), VAR79,
                      &FUN28(VAR78), VAR56, &VAR43,
                      FUN22(VAR42));
      FUN23(VAR25, VAR25);

      
      
      *VAR10 = VAR7;

      
      if (VAR80::VAR81::FUN50(VAR7)) {
        
        

        *VAR12 = FUN29(VAR5, &VAR43) &&
                   FUN51(VAR5, VAR7, "", VAR43, NULL, NULL,
                                     VAR76 | VAR46);
        if (!*VAR12) {
          return VAR33;
        }
      }

      return VAR22;
    }

    if (VAR8 == VAR82 || VAR8 == VAR83) {
      static PRBool VAR84;

      if (!VAR84) {
        VAR84 = VAR44;

        
        
        

        VAR14->FUN52(); 

        PRBool VAR85;
        PRBool VAR29 = ::FUN53(VAR5, VAR7, VAR8, &VAR85);

        VAR84 = VAR56;

        if (!VAR29) {
          return VAR47;
        }

        if (VAR85) {
          *VAR10 = VAR7;

          return VAR22;
        }
      }
    } else if (VAR8 == VAR86 && VAR14->FUN54()) {
      VAR16<VAR87> VAR88;
      ((VAR89 *)VAR14)->FUN55(FUN22(VAR88));

      VAR23 *VAR90 = VAR14->FUN56();
      if (VAR90) {
        VAR91 FUN57(VAR5);

        
        
        VAR25 = VAR90->FUN58(VAR7, "", VAR88);
        FUN23(VAR25, VAR25);

        *VAR10 = VAR7;
      }

      return VAR22;
    }
  }

  VAR6 *VAR92 = *VAR10;
  VAR25 = VAR93::FUN1(VAR3, VAR5, VAR7, VAR8, VAR9, VAR10,
                                     VAR12);

  if (FUN59(VAR25) || *VAR10 != VAR92) {
    
    return VAR25;
  }

  
  
  
  
  if ((VAR9 & VAR15) && !(VAR9 & VAR94)) {
    VAR6 *VAR95;
    VAR3->FUN26(&VAR95);

    if (VAR7 == VAR95) {
      VAR6 *VAR96 = VAR7->FUN60();
      if (VAR96) {
        VAR6 *VAR97 = NULL;
        jsval VAR98;

        if (!::FUN61(VAR5, VAR96, VAR8, VAR9,
                                              &VAR97, &VAR98)) {
          *VAR12 = VAR27;

          return VAR22;
        }

        if (VAR97) {
          
          *VAR10 = VAR97;
          return VAR22;
        }
      }

      
      
      
      
      
      
      
      
      
      
      
      VAR99 *VAR100 = FUN36(VAR8);
      if ((!(VAR9 & VAR70) &&
           !FUN62(VAR5, VAR100)) ||
          !::FUN30(VAR5, VAR7, VAR8, VAR19, VAR71,
                                   VAR72, VAR46)) {
        *VAR12 = VAR27;

        return VAR22;
      }

      *VAR10 = VAR7;
    }
  }

  return VAR22;
}