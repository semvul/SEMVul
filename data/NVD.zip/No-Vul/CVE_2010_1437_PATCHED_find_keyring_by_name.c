struct VAR1 *FUN1(const char *VAR2, bool VAR3)  
{
	struct VAR1 *VAR4;
	int VAR5;

	VAR4 = FUN2(-VAR6);
	if (!VAR2)
		goto VAR7;

	VAR5 = FUN3(VAR2);

	FUN4(&VAR8);

	if (VAR9[VAR5].VAR10) {
		
		FUN5(VAR4,
				    &VAR9[VAR5],
				    VAR11.VAR12
				    ) {
			if (VAR4->VAR13->VAR14 != FUN6())
				continue;

			if (FUN7(VAR15, &VAR4->VAR16))
				continue;

			if (strcmp(VAR4->VAR17, VAR2) != 0)
				continue;

			if (!VAR3 &&
			    FUN8(FUN9(VAR4, 0),
					   VAR18) < 0)
				continue;

			
			FUN10(&VAR19);
			if (FUN11(&VAR4->VAR20)) {
				
				FUN12(&VAR19);
				goto VAR21;
			}
			
			FUN13(&VAR4->VAR22);
			FUN12(&VAR19);
			FUN14(&VAR8);
			goto VAR7;
		}
	}

VAR21:
	FUN14(&VAR8);
	VAR4 = FUN2(-VAR23);

 VAR7:
	return VAR4;

}