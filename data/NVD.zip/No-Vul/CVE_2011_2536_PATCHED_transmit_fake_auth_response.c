wants to hide the names of local devices  from VAR1  */ static void FUN1(struct VAR2 *VAR3, int VAR4, struct VAR5 *VAR6, enum xmittype VAR7)  
{
	
	const char *VAR8 = "";
	const char *VAR9 = "";
	const char *VAR10 = "";
	const char *VAR11;
	struct VAR12 *VAR13;
	char *VAR14;

	
	enum VAR15 { VAR16, VAR17 };
	struct VAR18 {
		const char *VAR19;
		const char *VAR20;
	} *VAR21, VAR15[] = {
		[VAR16] = { "", "" },
		[VAR17] = { NULL, NULL}
	};

	VAR11 = FUN2(VAR6, VAR9);
	if (VAR6->VAR22 && !FUN3(VAR3->VAR23) && FUN3(VAR11)) {
		
		FUN4(VAR3, VAR8, VAR6, VAR3->VAR23, VAR7, VAR10, 0);
		
		FUN5(VAR3, VAR24);
		return;
	} else if (FUN3(VAR3->VAR23) || FUN3(VAR11)) {
		
		FUN6(VAR3, 1);
		FUN4(VAR3, VAR8, VAR6, VAR3->VAR23, VAR7, VAR10, 0);
		
		FUN5(VAR3, VAR24);
		return;
	}

	if (!(VAR13 = FUN7(&VAR25, VAR26))) {
		FUN8(VAR3, "", &VAR3->VAR27);
		return;
	}

	
	if (FUN9(&VAR13, 0, "", VAR11) == VAR28) {
		FUN8(VAR3, "", &VAR3->VAR27);
		return;
	}

	VAR14 = VAR13->VAR29;

	while (VAR14 && *(VAR14 = FUN10(VAR14))) { 
		for (VAR21 = VAR15; VAR21->VAR19 != NULL; VAR21++) {
			const char *VAR30 = "";	

			if (FUN11(VAR14, VAR21->VAR19, strlen(VAR21->VAR19)) != 0) {
				continue;
			}
			
			VAR14 += strlen(VAR21->VAR19);
			if (*VAR14 == '') { 
				VAR14++;
				VAR30 = """;
			}
			VAR21->VAR20 = VAR14;
			FUN12(&VAR14, VAR30);
			break;
		}
		if (VAR21->VAR19 == NULL) { 
			FUN12(&VAR14, "");
		}
	}

	
	if (FUN13(VAR3->VAR23, VAR15[VAR16].VAR20)) {
		if (!VAR6->VAR22) {
			FUN6(VAR3, 1);
		}
		FUN4(VAR3, VAR8, VAR6, VAR3->VAR23, VAR7, VAR10, VAR31);

		
		FUN5(VAR3, VAR24);
	} else {
		FUN8(VAR3, "", &VAR3->VAR27);
	}
}