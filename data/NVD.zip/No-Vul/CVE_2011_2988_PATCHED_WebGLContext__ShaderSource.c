NS_IMETHODIMP VAR1::FUN1(VAR2 *VAR3, const VAR4& VAR5)  
{
    VAR6 *VAR7;
    WebGLuint VAR8;
    if (!FUN2("", VAR3, &VAR7, &VAR8))
        return VAR9;
    
    const VAR10& VAR11 = FUN3(VAR5);

    if (!FUN4(VAR11.FUN5()))
        return FUN6("");

    const VAR12& VAR13 = FUN7(VAR11);
    
    const PRUint32 VAR14 = (FUN8(1)<<18) - 1;
    if (VAR13.FUN9() > VAR14)
        return FUN6("", VAR14);
    
    VAR7->FUN10(VAR13);

    VAR7->FUN11();

    return VAR9;
}