static void   FUN1( PSH_Glyph  VAR1,                                 FT_Int     VAR2 )    
{
    
    

    PSH_Hint_Table  VAR3     = &VAR1->VAR4[VAR2];
    PS_Mask         VAR5      = VAR3->VAR6->VAR7;
    FT_UInt         VAR8 = VAR3->VAR6->VAR8;
    FT_UInt         VAR9     = 0;
    FT_Int          VAR10 = VAR2 == 0 ? VAR11
                                               : VAR12;
    PSH_Dimension   VAR13       = &VAR1->VAR14->VAR2[VAR2];
    FT_Fixed        VAR15     = VAR13->VAR16;
    FT_Int          VAR17;


    VAR17 = (VAR18)FUN2( VAR19, VAR15 );
    if ( VAR17 > VAR20 )
      VAR17 = VAR20;

    
    if ( VAR8 > 1 && VAR1->VAR21 > 0 )
    {
      
      VAR9 = VAR5->VAR22 > VAR1->VAR21
                ? VAR1->VAR21
                : VAR5->VAR22;
      VAR5++;
      for ( ; VAR8 > 1; VAR8--, VAR5++ )
      {
        FT_UInt  VAR23;
        FT_Int   VAR24;


        VAR23  = VAR5->VAR22 > VAR1->VAR21
                  ? VAR1->VAR21
                  : VAR5->VAR22;
        VAR24 = VAR23 - VAR9;
        if ( VAR24 > 0 )
        {
          PSH_Point  VAR25 = VAR1->VAR26 + VAR9;


          FUN3( VAR3, VAR5 );

          FUN4( VAR3, VAR25, VAR24,
                                             VAR17, VAR10 );
        }
        VAR9 = VAR23;
      }
    }

    
    if ( VAR8 == 1 )
    {
      FT_UInt    VAR24 = VAR1->VAR21;
      PSH_Point  VAR25 = VAR1->VAR26;


      FUN3( VAR3, VAR3->VAR6->VAR7 );

      FUN4( VAR3, VAR25, VAR24,
                                         VAR17, VAR10 );
    }

    
    
    {
      FT_UInt    VAR24 = VAR1->VAR21;
      PSH_Point  VAR25 = VAR1->VAR26;


      for ( ; VAR24 > 0; VAR24--, VAR25++ )
        if ( VAR25->VAR27 && !FUN5( VAR25 ) )
          FUN6( VAR25 );
    }
  }