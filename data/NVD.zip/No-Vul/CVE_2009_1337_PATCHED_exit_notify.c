static void FUN1(struct VAR1 *VAR2, int VAR3)  
{
	int signal;
	void *VAR4;

	
	FUN2(VAR2);
	FUN3(VAR2);

	FUN4(&VAR5);
	if (VAR3)
		FUN5(VAR2->VAR6, NULL);

	
	if (VAR2->VAR7 != VAR8 && !FUN6(VAR2) &&
	    (VAR2->VAR9 != VAR2->VAR10->VAR11 ||
	     VAR2->VAR11 != VAR2->VAR9))
		VAR2->VAR7 = VAR8;

	signal = FUN7(VAR2, &VAR4, VAR3);
	if (signal >= 0)
		signal = FUN8(VAR2, signal);

	VAR2->VAR12 = signal == VAR13 ? VAR14 : VAR15;

	
	if (FUN9(VAR2) &&
	    VAR2->signal->VAR16 &&
	    VAR2->signal->VAR17 < 0)
		FUN10(VAR2->signal->VAR16);

	FUN11(&VAR5);

	FUN12(VAR2, signal, VAR4, VAR3);

	
	if (signal == VAR13)
		FUN13(VAR2);
}