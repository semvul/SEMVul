static JS_ALWAYS_INLINE VAR1 * FUN1(VAR2 *VAR3, VAR1 *VAR4)  
{
    VAR1 *VAR5 = NULL;
    VAR6 *VAR7;
    VAR8 *VAR9, *VAR10;
    REOp VAR11;
    VAR12 *VAR13;
    VAR14 *VAR15=NULL;
    const VAR16 *VAR17;
    size_t VAR18, VAR19;
    size_t VAR20 = 0;

    jschar VAR21, VAR22;
    VAR23 *VAR24;

    JSBool VAR25;
    VAR8 *VAR26 = VAR3->VAR27->VAR28;
    REOp VAR29 = (VAR30) *VAR26++;

    
    if (FUN2(VAR29) && !(VAR3->VAR27->VAR31 & VAR32)) {
        VAR25 = VAR33;
        while (VAR4->VAR34 <= VAR3->VAR35) {
            VAR9 = VAR26;    
            VAR5 = FUN3(VAR3, VAR4, VAR29, &VAR9, VAR36);
            if (VAR5) {
                VAR25 = VAR36;
                VAR4 = VAR5;
                VAR26 = VAR9;    
                VAR29 = (VAR30) *VAR26++;
                FUN4(VAR29 < VAR37);
                break;
            }
            VAR3->VAR38++;
            VAR4->VAR34++;
        }
        if (!VAR25)
            goto VAR39;
    }

    for (;;) {
#ifdef VAR40
        const char *VAR41 = VAR42[VAR29];
        FUN5("", VAR26 - VAR3->VAR27->VAR28,
                 VAR3->VAR43 * 2, "", VAR41);
#endif
        if (FUN2(VAR29)) {
            VAR5 = FUN3(VAR3, VAR4, VAR29, &VAR26, VAR36);
        } else {
            VAR15 = &VAR3->VAR44[VAR3->VAR43];
            switch (VAR29) {
              case VAR45:
                goto VAR46;
              case VAR47:
                VAR9 = VAR26 + FUN6(VAR26);   
                VAR26 += VAR48;
                VAR22 = FUN7(VAR26);
                VAR26 += VAR48;
                VAR19 = FUN7(VAR26);
                VAR26 += VAR48;

                if (VAR4->VAR34 != VAR3->VAR35) {
                    if (*VAR4->VAR34 == VAR22)
                        goto VAR49;

                    VAR24 = &VAR3->VAR27->VAR50[VAR19];
                    if (!VAR24->VAR51 && !FUN8(VAR3, VAR24))
                        goto VAR39;
                    VAR21 = *VAR4->VAR34;
                    VAR19 = VAR21 >> 3;
                    if ((VAR21 > VAR24->VAR52 ||
                         !(VAR24->VAR53.VAR54[VAR19] & (1 << (VAR21 & 0x7)))) ^
                        VAR24->VAR55) {
                        goto VAR49;
                    }
                }
                VAR5 = NULL;
                break;

              case VAR56:
                VAR9 = VAR26 + FUN6(VAR26);   
                VAR26 += VAR48;
                VAR21 = FUN7(VAR26);
                VAR26 += VAR48;
                VAR22 = FUN7(VAR26);
                VAR26 += VAR48;
                if (VAR4->VAR34 == VAR3->VAR35 ||
                    (*VAR4->VAR34 != VAR21 && *VAR4->VAR34 != VAR22)) {
                    VAR5 = NULL;
                    break;
                }
                

              case VAR57:
              VAR49:
                VAR9 = VAR26 + FUN6(VAR26);   
                VAR26 += VAR48;                  
                VAR15->VAR20 = VAR20;
                FUN9(VAR3);
                VAR29 = (VAR30) *VAR26++;
                VAR17 = VAR4->VAR34;
                if (FUN2(VAR29)) {
                    if (!FUN3(VAR3, VAR4, VAR29, &VAR26, VAR36)) {
                        VAR29 = (VAR30) *VAR9++;
                        VAR26 = VAR9;
                        continue;
                    }
                    VAR5 = VAR4;
                    VAR29 = (VAR30) *VAR26++;
                }
                VAR11 = (VAR30) *VAR9++;
                if (!FUN10(VAR3, VAR11, VAR9, VAR4, VAR17, 0, 0))
                    goto VAR39;
                continue;

              
              case VAR58:
                
                if (!VAR5)
                    VAR5 = VAR4;

                if(VAR3->VAR43)
                    --VAR3->VAR43;
                VAR26 += FUN6(VAR26);
                VAR29 = (VAR30) *VAR26++;
                continue;

              
              case VAR59:
                
                if (!VAR5)
                    VAR5 = VAR4;

                if(VAR3->VAR43)
                    --VAR3->VAR43;
                VAR29 = (VAR30) *VAR26++;
                continue;

              case VAR60:
                VAR26 = FUN11(VAR26, &VAR18);
                FUN5("", (unsigned long) VAR18);
                FUN4(VAR18 < VAR3->VAR27->VAR61);
                if (VAR18 + 1 > VAR20)
                    VAR20 = VAR18 + 1;
                VAR4->VAR62[VAR18].VAR63 = VAR4->VAR34 - VAR3->VAR64;
                VAR4->VAR62[VAR18].VAR52 = 0;
                VAR29 = (VAR30) *VAR26++;
                continue;

              case VAR65:
              {
                ptrdiff_t VAR66;

                VAR26 = FUN11(VAR26, &VAR18);
                FUN4(VAR18 < VAR3->VAR27->VAR61);
                VAR13 = &VAR4->VAR62[VAR18];
                VAR66 = VAR4->VAR34 - (VAR3->VAR64 + VAR13->VAR63);
                VAR13->VAR52 = (VAR66 < 0) ? 0 : (VAR67) VAR66;
                VAR29 = (VAR30) *VAR26++;

                if (!VAR5)
                    VAR5 = VAR4;
                continue;
              }
              case VAR68:
                VAR9 = VAR26 + FUN6(VAR26);  
                VAR26 += VAR48;                 
                VAR29 = (VAR30) *VAR26++;
                VAR10 = VAR26;
                if (FUN2(VAR29) &&
                    !FUN3(VAR3, VAR4, VAR29, &VAR10, VAR33)) {
                    VAR5 = NULL;
                    break;
                }
                VAR15->VAR53.VAR69.VAR70 =
                    (char *)VAR3->VAR71 - (char *)VAR3->VAR72;
                VAR15->VAR53.VAR69.VAR73 = VAR3->VAR74;
                VAR15->VAR63 = VAR4->VAR34 - VAR3->VAR64;
                VAR15->VAR20 = VAR20;
                FUN9(VAR3);
                if (!FUN10(VAR3, VAR75,
                                        VAR9, VAR4, VAR4->VAR34, 0, 0)) {
                    goto VAR39;
                }
                continue;

              case VAR76:
                VAR9 = VAR26 + FUN6(VAR26);
                VAR26 += VAR48;
                VAR29 = (VAR30) *VAR26++;
                VAR10 = VAR26;
                if (FUN2(VAR29)  &&
                    FUN3(VAR3, VAR4, VAR29, &VAR10, VAR33) &&
                    *VAR10 == VAR77) {
                    VAR5 = NULL;
                    break;
                }
                VAR15->VAR53.VAR69.VAR70
                    = (char *)VAR3->VAR71 -
                      (char *)VAR3->VAR72;
                VAR15->VAR53.VAR69.VAR73 = VAR3->VAR74;
                VAR15->VAR63 = VAR4->VAR34 - VAR3->VAR64;
                VAR15->VAR20 = VAR20;
                FUN9(VAR3);
                if (!FUN10(VAR3, VAR77,
                                        VAR9, VAR4, VAR4->VAR34, 0, 0)) {
                    goto VAR39;
                }
                continue;

              case VAR75:
                if(VAR3->VAR43)
                    --VAR3->VAR43;
                --VAR15;
                VAR4->VAR34 = VAR3->VAR64 + VAR15->VAR63;
                VAR3->VAR71 =
                    (VAR6 *) ((char *)VAR3->VAR72 +
                                         VAR15->VAR53.VAR69.VAR70);
                VAR3->VAR74 = VAR15->VAR53.VAR69.VAR73;
                if (VAR5)
                    VAR5 = VAR4;
                break;

              case VAR77:
                if(VAR3->VAR43)
                    --VAR3->VAR43;
                --VAR15;
                VAR4->VAR34 = VAR3->VAR64 + VAR15->VAR63;
                VAR3->VAR71 =
                    (VAR6 *) ((char *)VAR3->VAR72 +
                                         VAR15->VAR53.VAR69.VAR70);
                VAR3->VAR74 = VAR15->VAR53.VAR69.VAR73;
                VAR5 = (!VAR5) ? VAR4 : NULL;
                break;
              case VAR78:
                VAR15->VAR53.VAR79.VAR80 = 0;
                VAR15->VAR53.VAR79.VAR81 = (VAR82)-1;
                goto VAR83;
              case VAR84:
                VAR15->VAR53.VAR79.VAR80 = 1;
                VAR15->VAR53.VAR79.VAR81 = (VAR82)-1;
                goto VAR83;
              case VAR85:
                VAR15->VAR53.VAR79.VAR80 = 0;
                VAR15->VAR53.VAR79.VAR81 = 1;
                goto VAR83;
              case VAR86:
                VAR26 = FUN11(VAR26, &VAR19);
                VAR15->VAR53.VAR79.VAR80 = VAR19;
                VAR26 = FUN11(VAR26, &VAR19);
                
                VAR15->VAR53.VAR79.VAR81 = VAR19 - 1;
                FUN4(VAR15->VAR53.VAR79.VAR80
                          <= VAR15->VAR53.VAR79.VAR81);
              VAR83:
                if (VAR15->VAR53.VAR79.VAR81 == 0) {
                    VAR26 = VAR26 + FUN6(VAR26);
                    VAR29 = (VAR30) *VAR26++;
                    VAR5 = VAR4;
                    continue;
                }
                
                VAR9 = VAR26 + VAR48;
                VAR29 = (VAR30) *VAR9++;
                VAR17 = VAR4->VAR34;
                if (FUN2(VAR29)) {
                    if (!FUN3(VAR3, VAR4, VAR29, &VAR9, VAR36)) {
                        if (VAR15->VAR53.VAR79.VAR80 == 0)
                            VAR5 = VAR4;
                        else
                            VAR5 = NULL;
                        VAR26 = VAR26 + FUN6(VAR26);
                        break;
                    }
                    VAR29 = (VAR30) *VAR9++;
                    VAR5 = VAR4;
                }
                VAR15->VAR63 = VAR17 - VAR3->VAR64;
                VAR15->VAR87 = VAR88;
                VAR15->VAR89 = VAR26;
                VAR15->VAR20 = VAR20;
                FUN9(VAR3);
                if (VAR15->VAR53.VAR79.VAR80 == 0 &&
                    !FUN10(VAR3, VAR88, VAR26, VAR4, VAR17,
                                        0, 0)) {
                    goto VAR39;
                }
                VAR26 = VAR9;
                continue;

              case VAR90: 
                VAR26 = VAR15[-1].VAR89;
                VAR29 = (VAR30) VAR15[-1].VAR87;

                if (!VAR5)
                    VAR5 = VAR4;
                continue;

              case VAR88:
                --VAR15;
                do {
                    if(VAR3->VAR43)
                        --VAR3->VAR43;
                    if (!VAR5) {
                        
                        if (VAR15->VAR53.VAR79.VAR80 == 0)
                            goto VAR91;
                        goto VAR92;
                    }
                    if (VAR15->VAR53.VAR79.VAR80 == 0 &&
                        VAR4->VAR34 == VAR3->VAR64 + VAR15->VAR63) {
                        
                        VAR5 = NULL;
                        goto VAR92;
                    }
                    if (VAR15->VAR53.VAR79.VAR80 != 0)
                        VAR15->VAR53.VAR79.VAR80--;
                    if (VAR15->VAR53.VAR79.VAR81 != (VAR82) -1)
                        VAR15->VAR53.VAR79.VAR81--;
                    if (VAR15->VAR53.VAR79.VAR81 == 0)
                        goto VAR91;
                    VAR9 = VAR26 + VAR48;
                    VAR11 = (VAR30) *VAR9;
                    VAR17 = VAR4->VAR34;
                    if (FUN2(VAR11)) {
                        VAR9++;
                        if (!FUN3(VAR3, VAR4, VAR11, &VAR9, VAR36)) {
                            if (VAR15->VAR53.VAR79.VAR80 == 0)
                                goto VAR91;
                            VAR5 = NULL;
                            goto VAR92;
                        }
                        VAR5 = VAR4;
                    }
                    VAR15->VAR63 = VAR17 - VAR3->VAR64;
                    FUN9(VAR3);
                    if (VAR15->VAR53.VAR79.VAR80 == 0 &&
                        !FUN10(VAR3, VAR88,
                                            VAR26, VAR4, VAR17,
                                            VAR15->VAR20,
                                            VAR20 -
                                            VAR15->VAR20)) {
                        goto VAR39;
                    }
                } while (*VAR9 == VAR90);
                VAR26 = VAR9;
                VAR29 = (VAR30) *VAR26++;
                VAR20 = VAR15->VAR20;
                continue;

              VAR91:
                VAR5 = VAR4;
                VAR26 += FUN6(VAR26);
                goto VAR92;

              case VAR93:
                VAR15->VAR53.VAR79.VAR80 = 0;
                VAR15->VAR53.VAR79.VAR81 = (VAR82)-1;
                goto VAR94;
              case VAR95:
                VAR15->VAR53.VAR79.VAR80 = 1;
                VAR15->VAR53.VAR79.VAR81 = (VAR82)-1;
                goto VAR94;
              case VAR96:
                VAR15->VAR53.VAR79.VAR80 = 0;
                VAR15->VAR53.VAR79.VAR81 = 1;
                goto VAR94;
              case VAR97:
                VAR26 = FUN11(VAR26, &VAR19);
                VAR15->VAR53.VAR79.VAR80 = VAR19;
                VAR26 = FUN11(VAR26, &VAR19);
                
                VAR15->VAR53.VAR79.VAR81 = VAR19 - 1;
                FUN4(VAR15->VAR53.VAR79.VAR80
                          <= VAR15->VAR53.VAR79.VAR81);
              VAR94:
                VAR15->VAR63 = VAR4->VAR34 - VAR3->VAR64;
                VAR15->VAR20 = VAR20;
                FUN9(VAR3);
                if (VAR15->VAR53.VAR79.VAR80 != 0) {
                    VAR15->VAR87 = VAR98;
                    VAR15->VAR89 = VAR26;
                    
                    VAR26 += VAR99;
                    VAR29 = (VAR30) *VAR26++;
                } else {
                    if (!FUN10(VAR3, VAR98,
                                            VAR26, VAR4, VAR4->VAR34, 0, 0)) {
                        goto VAR39;
                    }
                    if(VAR3->VAR43)
                        --VAR3->VAR43;
                    VAR26 = VAR26 + FUN6(VAR26);
                    VAR29 = (VAR30) *VAR26++;
                }
                continue;

              case VAR98:
                if(VAR3->VAR43)
                    --VAR3->VAR43;
                --VAR15;

                FUN5("", VAR15->VAR53.VAR79.VAR80,
                         VAR15->VAR53.VAR79.VAR81);
#VAR100 FUN12()                                                      \
    VAR101                                                            \
        VAR15->VAR63 = VAR4->VAR34 - VAR3->VAR64;                             \
        VAR15->VAR87 = VAR98;                           \
        VAR15->VAR89 = VAR26;                                           \
        VAR26 += VAR48;                                                        \
        for (VAR19 = VAR15->VAR20; VAR19 < VAR20; VAR19++)                   \
            VAR4->VAR62[VAR19].VAR63 = -1;                                          \
        FUN9(VAR3);                                              \
        VAR29 = (VAR30) *VAR26++;                                                    \
        FUN4(VAR29 < VAR37);                                           \
    VAR102

                if (!VAR5) {
                    FUN5("");
                    
                    if (VAR15->VAR53.VAR79.VAR81 == (VAR82) -1 ||
                        VAR15->VAR53.VAR79.VAR81 > 0) {
                        FUN12();
                        continue;
                    }
                    
                    break;
                }
                if (VAR15->VAR53.VAR79.VAR80 == 0 &&
                    VAR4->VAR34 == VAR3->VAR64 + VAR15->VAR63) {
                    
                    VAR5 = NULL;
                    break;
                }
                if (VAR15->VAR53.VAR79.VAR80 != 0)
                    VAR15->VAR53.VAR79.VAR80--;
                if (VAR15->VAR53.VAR79.VAR81 != (VAR82) -1)
                    VAR15->VAR53.VAR79.VAR81--;
                if (VAR15->VAR53.VAR79.VAR80 != 0) {
                    FUN12();
                    continue;
                }
                VAR15->VAR63 = VAR4->VAR34 - VAR3->VAR64;
                VAR15->VAR20 = VAR20;
                FUN9(VAR3);
                if (!FUN10(VAR3, VAR98,
                                        VAR26, VAR4, VAR4->VAR34,
                                        VAR15->VAR20,
                                        VAR20 - VAR15->VAR20)) {
                    goto VAR39;
                }
                if(VAR3->VAR43)
                    --VAR3->VAR43;
                VAR26 = VAR26 + FUN6(VAR26);
                VAR29 = (VAR30) *VAR26++;
                FUN4(VAR29 < VAR37);
                continue;
              default:
                FUN4(VAR33);
                VAR5 = NULL;
            }
          VAR92:;
        }

        
        if (!VAR5) {
            if (VAR3->VAR74 == 0)
                return NULL;
            if (!FUN13(VAR3->VAR103)) {
                VAR3->VAR104 = VAR33;
                return NULL;
            }

            
            VAR3->VAR105++;
            if (VAR3->VAR106 &&
                VAR3->VAR105 >= VAR3->VAR106) {
                FUN14(VAR3->VAR103, VAR107, NULL,
                                     VAR108);
                VAR3->VAR104 = VAR33;
                return NULL;
            }

            VAR7 = VAR3->VAR71;
            VAR3->VAR74 = VAR7->VAR73;
            VAR3->VAR71 =
                (VAR6 *) ((char *)VAR7 - VAR7->VAR73);
            VAR4->VAR34 = VAR7->VAR34;
            VAR26 = VAR7->VAR109;
            VAR29 = (VAR30) VAR7->VAR110;
            FUN4(VAR29 < VAR37);
            VAR3->VAR43 = VAR7->VAR111;

            FUN4(VAR3->VAR43);

            memcpy(VAR3->VAR44, VAR7 + 1,
                   sizeof(VAR14) * VAR7->VAR111);
            VAR15 = &VAR3->VAR44[VAR3->VAR43 - 1];

            if (VAR7->VAR61) {
                memcpy(&VAR4->VAR62[VAR7->VAR18],
                       (char *)(VAR7 + 1) +
                       sizeof(VAR14) * VAR7->VAR111,
                       sizeof(VAR12) * VAR7->VAR61);
                VAR20 = VAR7->VAR18 + VAR7->VAR61;
            } else {
                for (VAR19 = VAR15->VAR20; VAR19 < VAR20; VAR19++)
                    VAR4->VAR62[VAR19].VAR63 = -1;
                VAR20 = VAR15->VAR20;
            }

            FUN5("",
                     (unsigned long) VAR7->VAR18,
                     (unsigned long) VAR7->VAR61);
            continue;
        }
        VAR4 = VAR5;

        
        VAR29 = (VAR30)*VAR26++;
        FUN4(VAR29 < VAR37);
    }

VAR39:
    FUN5("");
    return NULL;

VAR46:
    FUN5("");
    return VAR4;
}