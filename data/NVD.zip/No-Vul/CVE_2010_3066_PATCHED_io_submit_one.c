int VAR1 FUN1(struct VAR2 *VAR3, struct iocb VAR4 *VAR5, 			 struct VAR6 *VAR6)  
{
	struct VAR7 *VAR8;
	struct VAR9 *VAR9;
	ssize_t VAR10;

	
	if (FUN2(VAR6->VAR11 || VAR6->VAR12)) {
		FUN3("");
		return -VAR13;
	}

	
	if (FUN2(
	    (VAR6->VAR14 != (unsigned long)VAR6->VAR14) ||
	    (VAR6->VAR15 != (VAR16)VAR6->VAR15) ||
	    ((VAR17)VAR6->VAR15 < 0)
	   )) {
		FUN3("");
		return -VAR13;
	}

	VAR9 = FUN4(VAR6->VAR18);
	if (FUN2(!VAR9))
		return -VAR19;

	VAR8 = FUN5(VAR3);		
	if (FUN2(!VAR8)) {
		FUN6(VAR9);
		return -VAR20;
	}
	VAR8->VAR21 = VAR9;
	if (VAR6->VAR22 & VAR23) {
		
		VAR8->VAR24 = FUN7((int) VAR6->VAR25);
		if (FUN2(FUN8(VAR8->VAR24))) {
			VAR10 = FUN9(VAR8->VAR24);
			goto VAR26;
		}
	}

	VAR10 = FUN10(VAR8->VAR27, &VAR5->VAR28);
	if (FUN2(VAR10)) {
		FUN11("");
		goto VAR26;
	}

	VAR8->VAR29.VAR30 = VAR5;
	VAR8->VAR31 = VAR6->VAR32;
	VAR8->VAR33 = VAR6->VAR34;

	VAR8->VAR35 = (char VAR4 *)(unsigned long)VAR6->VAR14;
	VAR8->VAR36 = VAR8->VAR37 = VAR6->VAR15;
	VAR8->VAR38 = VAR6->VAR39;
	FUN12(&VAR8->VAR40, VAR41);
	FUN13(&VAR8->VAR40.VAR42);

	VAR10 = FUN14(VAR8);

	if (VAR10)
		goto VAR26;

	FUN15(&VAR3->VAR43);
	FUN16(VAR8);
	if (!FUN17(&VAR3->VAR44)) {
		
		while (FUN18(VAR3))
			;
	}
	FUN19(&VAR3->VAR43);
	FUN20(VAR8);	
	return 0;

VAR26:
	FUN20(VAR8);	
	FUN20(VAR8);	
	return VAR10;
}