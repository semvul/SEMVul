NS_IMETHODIMP VAR1::FUN1(    const char * VAR2, VAR3 * VAR4,      VAR5 * VAR6, VAR3 * VAR7)  
{
   static const PRUint8 VAR8[256] =
   {
     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  
     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  
     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  
     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  
     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  
     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  
     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  
     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  
        0,    1,    2,    3,    4,    5,    6,    7,  
        8,    9,   10,   11,   12,   13,   14,   15,  
       16,   17,   18,   19,   20,   21,   22,   23,  
       24,   25,   26,   27,   28,   29,   30,   31,  
       32,   33,   34,   35,   36,   37,   38,   39,  
       40,   41,   42,   43,   44,   45,   46,   47,  
       48,   49,   50,   51,   52,   53,   54,   55,  
       56,   57,   58,   59,   60,   61,   62, 0xFF,  
       63,   64,   65,   66,   67,   68,   69,   70,  
       71,   72,   73,   74,   75,   76,   77,   78,  
       79,   80,   81,   82,   83,   84,   85,   86,  
       87,   88,   89,   90,   91,   92,   93,   94,  
       95,   96,   97,   98,   99,  100,  101,  102,  
      103,  104,  105,  106,  107,  108,  109,  110,  
      111,  112,  113,  114,  115,  116,  117,  118,  
      119,  120,  121,  122,  123,  124,  125,  126,  
      127,  128,  129,  130,  131,  132,  133,  134,  
      135,  136,  137,  138,  139,  140,  141,  142,  
      143,  144,  145,  146,  147,  148,  149,  150,  
      151,  152,  153,  154,  155,  156,  157,  158,  
      159,  160,  161,  162,  163,  164,  165,  166,  
      167,  168,  169,  170,  171,  172,  173,  174,  
      175,  176,  177,  178,  179,  180,  181,  182,  
      183,  184,  185,  186,  187, 0xFF, 0xFF, 0xFF,  
   };

   const unsigned char* VAR9 = (unsigned char*)VAR2 + *VAR4;
   const unsigned char* VAR10 =(unsigned char*) VAR2;
   VAR5* VAR11 = VAR6 + *VAR7;
   VAR5* VAR12 = VAR6;
   while((VAR10 < VAR9))
   {
       switch(VAR13)
       {

          case 0:
          if(*VAR10 & 0x80)
          {
            VAR14 = VAR15[*VAR10 & 0x7F];
            if(VAR14 < 0xE000 )
            {
               VAR13 = 1; 
            } else {
               if( VAR14 > 0xFF00)
               {
                 if(0xFFFD == VAR14) {
                   
                   
                   
                   
                   
                   
                   switch (*VAR10) {
                     case 0x80:
                       *VAR12++ = (VAR5) *VAR10;
                       break;

                     case 0xa0:
                       *VAR12++ = (VAR5) 0xf8f0;
                       break;

                     case 0xfd:
                     case 0xfe:
                     case 0xff:
                       *VAR12++ = (VAR5) 0xf8f1 + 
                                   (*VAR10 - (unsigned char)(0xfd));
                       break;

                     default:
                       if (VAR16 == VAR17)
                         goto VAR18;
                       *VAR12++ = VAR19;
                   }
                   if(VAR12 >= VAR11)
                     goto VAR20;
                 } else {
                   *VAR12++ = VAR14; 
                   if(VAR12 >= VAR11)
                     goto VAR20;
                 }
               } else {
                 VAR13 = 2; 
               }
            }
          } else {
            
            *VAR12++ = (VAR5) *VAR10;
            if(VAR12 >= VAR11)
              goto VAR20;
          }
          break;

          case 1: 
          {
            PRUint8 VAR21 = VAR8[*VAR10];

            
            
            
            
            
            if(0xFF == VAR21) {
               VAR10--;
               if (VAR16 == VAR17)
                 goto VAR18;
               *VAR12++ = VAR22;
            } else {
               PRUnichar VAR23 = VAR24[VAR14+VAR21];
               if(VAR23 == 0xfffd) {
                 if (VAR16 == VAR17)
                   goto VAR18;
                 VAR23 = VAR19;
               }
               *VAR12++ = VAR23;
            }
            VAR13 = 0;
            if(VAR12 >= VAR11)
              goto VAR20;
          }
          break;

          case 2: 
          {
            PRUint8 VAR21 = VAR8[*VAR10];

            
            if(0xFF == VAR21) {
               VAR10--;
               if (VAR16 == VAR17)
                 goto VAR18;

               *VAR12++ = VAR22;
            } else {
               *VAR12++ = VAR14 + VAR21;
            }
            VAR13 = 0;
            if(VAR12 >= VAR11)
              goto VAR20;
          }
          break;

       }
       VAR10++;
   }
   *VAR7 = VAR12 - VAR6;
   return VAR25;
VAR18:
   *VAR7 = VAR12 - VAR6;
   *VAR4 = VAR10 - (const unsigned char*)VAR2;
   return VAR26;
VAR20:
   *VAR7 = VAR12 - VAR6;
   VAR10++;
   if ((VAR13 == 0) && (VAR10 == VAR9)) {
     return VAR25;
   }
   *VAR4 = VAR10 - (const unsigned char*)VAR2;
   return VAR27;
}