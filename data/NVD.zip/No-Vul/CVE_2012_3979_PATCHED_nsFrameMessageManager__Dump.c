NS_IMETHODIMP VAR1::FUN1(const VAR2& VAR3)  
{
#ifdef VAR4
  FUN2(VAR5, "", "", FUN3(VAR3).FUN4());
#endif
  fputs(FUN3(VAR3).FUN4(), VAR6);
  FUN5(VAR6);
  return VAR7;
}