void FUN1()  
{
    VAR1<VAR2> VAR3;
    FUN2(this, VAR3);
    FUN3(VAR4->VAR5, VAR3);
    
  }