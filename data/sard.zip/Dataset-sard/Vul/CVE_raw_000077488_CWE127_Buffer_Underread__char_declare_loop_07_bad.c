void FUN1()
{
    char * VAR1;
    char VAR2[100];
    memset(VAR2, '', 100-1);
    VAR2[100-1] = '';
    if(VAR3==5)
    {
        
        VAR1 = VAR2 - 8;
    }
    {
        size_t VAR4;
        char VAR5[100];
        memset(VAR5, '', 100-1); 
        VAR5[100-1] = ''; 
        
        for (VAR4 = 0; VAR4 < 100; VAR4++)
        {
            VAR5[VAR4] = VAR1[VAR4];
        }
        
        VAR5[100-1] = '';
        FUN2(VAR5);
    }
}