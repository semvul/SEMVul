NS_IMETHODIMP VAR1::FUN1(PRUint32 VAR2,                        VAR3 *VAR4,                        VAR3 *VAR5,                        VAR6 *VAR7,                        const VAR8 &VAR9,                        VAR6 *VAR10,                        VAR11 *VAR12)  
{
    if (!VAR4)
        return VAR13;

#ifdef VAR14
    {
        nsCAutoString VAR15;
        VAR4->FUN2(VAR15);
        FUN3(VAR16, VAR17,
            ("", VAR15.FUN4()));
    }
#endif
    
    *VAR12 = VAR18::VAR19;

    
    if (!VAR20)
        return VAR21;

    
    
    VAR22<VAR23> FUN5(FUN6(VAR7));
    VAR22<VAR24> VAR25;
    VAR22<VAR26> VAR27;
    if (VAR28) {
        VAR25 = VAR28->FUN7();
        VAR25->FUN8(FUN9(VAR27));

        if (VAR27) {
#ifdef VAR14
            nsAutoString VAR29;
            VAR27->FUN10(VAR29);
            FUN3(VAR16, VAR17,
                    ("",
                     FUN11(VAR29).FUN4()));
#endif
            
            
            VAR27->FUN1(VAR2,
                            VAR4,
                            VAR5,
                            VAR7,
                            VAR9,
                            VAR30,
                            VAR12);
        }
    }
#ifdef VAR14
    else {
        nsCAutoString VAR31;
        VAR4->FUN2(VAR31);
        FUN3(VAR16, VAR17,
            ("", VAR31.FUN4()));
    }
#endif

    return VAR21;
}