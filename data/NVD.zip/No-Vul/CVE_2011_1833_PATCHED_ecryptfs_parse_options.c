static int FUN1(struct VAR1 *VAR2, char *VAR3, 				  VAR4 *VAR5)  
{
	char *VAR6;
	int VAR7 = 0;
	int VAR8 = 0;
	int VAR9 = 0;
	int VAR10 = 0;
	int VAR11;
	int VAR12 = 0;
	int VAR13;
	int VAR14 = 0;
	struct VAR15 *VAR16 =
		&VAR2->VAR16;
	substring_t VAR17[VAR18];
	int VAR19;
	char *VAR20;
	char *VAR21;
	char *VAR22;
	char *VAR23;
	char *VAR24;
	char *VAR25;
	char *VAR26;
	char *VAR27;
	char *VAR28;

	*VAR5 = 0;

	if (!VAR3) {
		VAR7 = -VAR29;
		goto VAR30;
	}
	FUN2(VAR16);
	while ((VAR6 = FUN3(&VAR3, "")) != NULL) {
		if (!*VAR6)
			continue;
		VAR19 = FUN4(VAR6, VAR31, VAR17);
		switch (VAR19) {
		case VAR32:
		case VAR33:
			VAR20 = VAR17[0].VAR34;
			VAR7 = FUN5(VAR16,
							  VAR20, 0);
			if (VAR7) {
				FUN6(VAR35 ""
				       "", VAR7);
				goto VAR30;
			}
			VAR8 = 1;
			break;
		case VAR36:
		case VAR37:
			VAR22 = VAR17[0].VAR34;
			VAR21 =
				VAR16->
				VAR38;
			strncpy(VAR21, VAR22,
				VAR39);
			VAR21[VAR39] = '';
			VAR9 = 1;
			break;
		case VAR40:
			VAR27 = VAR17[0].VAR34;
			VAR11 =
				(int)FUN7(VAR27,
						   &VAR27, 0);
			VAR16->VAR41 =
				VAR11;
			VAR12 = 1;
			break;
		case VAR42:
			VAR16->VAR43 |=
				VAR44;
			break;
		case VAR45:
			VAR16->VAR43 |=
				VAR46;
			break;
		case VAR47:
			VAR16->VAR43 |=
				VAR46;
			VAR16->VAR43 |=
				VAR48;
			break;
		case VAR49:
			VAR26 = VAR17[0].VAR34;
			VAR25 =
				VAR16->VAR50;
			strncpy(VAR25, VAR26, VAR51);
			VAR16->VAR50[
				VAR51] = '';
			VAR7 = FUN5(
				VAR16,
				VAR16->VAR50,
				VAR52);
			if (VAR7) {
				FUN6(VAR35 ""
				       "",
				       VAR16->VAR50,
				       VAR7);
				goto VAR30;
			}
			VAR16->VAR43 |=
				(VAR53
				 | VAR54);
			break;
		case VAR55:
			VAR24 = VAR17[0].VAR34;
			VAR23 =
				VAR16->VAR56;
			strncpy(VAR23, VAR24,
				VAR39);
			VAR16->VAR56[
				VAR39] = '';
			VAR10 = 1;
			break;
		case VAR57:
			VAR28 = VAR17[0].VAR34;
			VAR13 =
				(int)FUN7(VAR28,
						   &VAR28, 0);
			VAR16->VAR58 =
				VAR13;
			VAR14 = 1;
			break;
		case VAR59:
			VAR16->VAR43 |= VAR60;
			break;
		case VAR61:
			VAR16->VAR43 |=
				VAR62;
			break;
		case VAR63:
			*VAR5 = 1;
			break;
		case VAR64:
		default:
			FUN6(VAR65
			       "",
			       VAR66, VAR6);
		}
	}
	if (!VAR8) {
		VAR7 = -VAR29;
		FUN8(VAR35, ""
				""
				"");
		goto VAR30;
	}
	if (!VAR9) {
		int VAR67 = strlen(VAR68);

		FUN9(VAR67 >= VAR39);
		strcpy(VAR16->VAR38,
		       VAR68);
	}
	if ((VAR16->VAR43 & VAR53)
	    && !VAR10)
		strcpy(VAR16->VAR56,
		       VAR16->VAR38);
	if (!VAR12)
		VAR16->VAR41 = 0;
	if ((VAR16->VAR43 & VAR53)
	    && !VAR14)
		VAR16->VAR58 =
			VAR16->VAR41;
	FUN10(&VAR69);
	if (!FUN11(VAR16->VAR38,
				 NULL)) {
		VAR7 = FUN12(
			NULL, VAR16->VAR38,
			VAR16->VAR41);
		if (VAR7) {
			FUN6(VAR35 ""
			       ""
			       "",
			       VAR16->VAR38,
			       VAR16->VAR41,
			       VAR7);
			VAR7 = -VAR29;
			FUN13(&VAR69);
			goto VAR30;
		}
	}
	if ((VAR16->VAR43 & VAR53)
	    && !FUN11(
		    VAR16->VAR56, NULL)) {
		VAR7 = FUN12(
			NULL, VAR16->VAR56,
			VAR16->VAR58);
		if (VAR7) {
			FUN6(VAR35 ""
			       ""
			       "",
			       VAR16->VAR56,
			       VAR16->VAR58,
			       VAR7);
			VAR7 = -VAR29;
			FUN13(&VAR69);
			goto VAR30;
		}
	}
	FUN13(&VAR69);
	VAR7 = FUN14(VAR16);
	if (VAR7)
		FUN6(VAR65 ""
		       "", VAR7);
VAR30:
	return VAR7;
}