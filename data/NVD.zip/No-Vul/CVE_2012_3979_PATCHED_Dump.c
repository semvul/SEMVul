static VAR1 FUN1(VAR2 *VAR3, unsigned argc, VAR4 *VAR5)  
{
    VAR6 *VAR7;
    if (!argc)
        return true;

    VAR7 = FUN2(VAR3, FUN3(VAR3, VAR5)[0]);
    if (!VAR7)
        return false;

    size_t VAR8;
    const VAR9 *VAR10 = FUN4(VAR3, VAR7, &VAR8);
    if (!VAR10)
        return false;

    VAR11 FUN5(reinterpret_cast<const VAR12*>(VAR10));
#ifdef VAR13
    FUN6(VAR14, "", "", VAR15.FUN7());
#endif
    fputs(VAR15.FUN7(), VAR16);
    FUN8(VAR16);
    return true;
}