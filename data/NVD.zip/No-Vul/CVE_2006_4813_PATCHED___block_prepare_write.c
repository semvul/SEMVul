static int FUN1(struct VAR1 *VAR1, struct VAR2 *VAR2, 		unsigned VAR3, unsigned VAR4, VAR5 *VAR6)  
{
	unsigned VAR7, VAR8;
	sector_t VAR9;
	int VAR10 = 0;
	unsigned VAR11, VAR12;
	struct VAR13 *VAR14, *VAR15, *VAR16[2], **VAR17=VAR16;

	FUN2(!FUN3(VAR2));
	FUN2(VAR3 > VAR18);
	FUN2(VAR4 > VAR18);
	FUN2(VAR3 > VAR4);

	VAR11 = 1 << VAR1->VAR19;
	if (!FUN4(VAR2))
		FUN5(VAR2, VAR11, 0);
	VAR15 = FUN6(VAR2);

	VAR12 = VAR1->VAR19;
	VAR9 = (VAR20)VAR2->VAR21 << (VAR22 - VAR12);

	for(VAR14 = VAR15, VAR7 = 0; VAR14 != VAR15 || !VAR7;
	    VAR9++, VAR7=VAR8, VAR14 = VAR14->VAR23) {
		VAR8 = VAR7 + VAR11;
		if (VAR8 <= VAR3 || VAR7 >= VAR4) {
			if (FUN7(VAR2)) {
				if (!FUN8(VAR14))
					FUN9(VAR14);
			}
			continue;
		}
		if (FUN10(VAR14))
			FUN11(VAR14);
		if (!FUN12(VAR14)) {
			VAR10 = FUN13(VAR1, VAR9, VAR14, 1);
			if (VAR10)
				break;
			if (FUN10(VAR14)) {
				FUN14(VAR14->VAR24,
							VAR14->VAR25);
				if (FUN7(VAR2)) {
					FUN9(VAR14);
					continue;
				}
				if (VAR8 > VAR4 || VAR7 < VAR3) {
					void *VAR26;

					VAR26 = FUN15(VAR2, VAR27);
					if (VAR8 > VAR4)
						memset(VAR26+VAR4, 0,
							VAR8-VAR4);
					if (VAR7 < VAR3)
						memset(VAR26+VAR7,
							0, VAR3-VAR7);
					FUN16(VAR2);
					FUN17(VAR26, VAR27);
				}
				continue;
			}
		}
		if (FUN7(VAR2)) {
			if (!FUN8(VAR14))
				FUN9(VAR14);
			continue; 
		}
		if (!FUN8(VAR14) && !FUN18(VAR14) &&
		     (VAR7 < VAR3 || VAR8 > VAR4)) {
			FUN19(VAR28, 1, &VAR14);
			*VAR17++=VAR14;
		}
	}
	
	while(VAR17 > VAR16) {
		FUN20(*--VAR17);
		if (!FUN8(*VAR17))
			VAR10 = -VAR29;
	}
	if (!VAR10) {
		VAR14 = VAR15;
		do {
			if (FUN10(VAR14))
				FUN11(VAR14);
		} while ((VAR14 = VAR14->VAR23) != VAR15);
		return 0;
	}
	
	
	VAR14 = VAR15;
	VAR7 = 0;
	do {
		VAR8 = VAR7+VAR11;
		if (VAR8 <= VAR3)
			goto VAR30;
		if (VAR7 >= VAR4)
			break;
		if (FUN10(VAR14)) {
			void *VAR26;

			FUN11(VAR14);
			VAR26 = FUN15(VAR2, VAR27);
			memset(VAR26+VAR7, 0, VAR14->VAR31);
			FUN17(VAR26, VAR27);
			FUN9(VAR14);
			FUN21(VAR14);
		}
VAR30:
		VAR7 = VAR8;
		VAR14 = VAR14->VAR23;
	} while (VAR14 != VAR15);
	return VAR10;
}