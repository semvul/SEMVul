bool VAR1::FUN1(VAR2 *VAR3, VAR4 *VAR5, jsid VAR6, bool *VAR7)  
{
    
    if (!VAR8::FUN1(VAR3, VAR5, VAR6, VAR7))
        return false;

    
    VAR4 *VAR9 = FUN2(VAR5);
    if (*VAR7 || !VAR9)
        return true;

    
    FUN3(VAR10::FUN4(VAR5, VAR3));
    JSPropertyDescriptor VAR11;
    if (!FUN5(VAR3, VAR9, VAR6, 0, &VAR11))
    {
        return false;
    }
    *VAR7 = !!VAR11.VAR12;
    return true;
}