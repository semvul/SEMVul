static int FUN1(struct VAR1 *VAR2, 				  struct VAR3 *VAR4, 				  struct VAR5 *VAR6)  
{
	struct VAR7 *VAR8;
	struct VAR9 *VAR10;
	struct VAR9 **VAR11;
	unsigned long VAR12 = VAR13;
	int VAR14;

	FUN2(&VAR2->VAR15);
	if (!FUN3(VAR2->VAR16) ||
	    (VAR4 && VAR4->VAR17 == VAR18))
		goto VAR19;

	VAR8 = FUN4(VAR2, VAR4, VAR6);
	VAR14 = FUN5(VAR8);
	if (FUN6(FUN7(VAR8) || !VAR8))
		goto VAR14;

	if (!VAR4) {
		if (FUN8(&VAR8->VAR20))
			FUN9(&VAR8->VAR20, &VAR2->VAR20);
		FUN10(&VAR8->VAR21, VAR12 + VAR2->VAR22);
		goto VAR19;
	}

	for (VAR11 = &VAR8->VAR23; (VAR10 = *VAR11); VAR11 = &VAR10->VAR24) {
		if (VAR10->VAR4 == VAR4)
			goto VAR25;
		if ((unsigned long)VAR10->VAR4 < (unsigned long)VAR4)
			break;
	}

	VAR10 = FUN11(sizeof(*VAR10), VAR26);
	VAR14 = -VAR27;
	if (FUN6(!VAR10))
		goto VAR14;

	VAR10->VAR28 = *VAR6;
	VAR10->VAR4 = VAR4;
	VAR10->VAR24 = *VAR11;
	FUN9(&VAR10->VAR20, &VAR4->VAR20);
	FUN12(&VAR10->VAR21, VAR29,
		    (unsigned long)VAR10);
	FUN12(&VAR10->VAR30, VAR31,
		    (unsigned long)VAR10);

	FUN13(*VAR11, VAR10);

VAR25:
	FUN10(&VAR10->VAR21, VAR12 + VAR2->VAR22);
VAR19:
	VAR14 = 0;

VAR14:
	FUN14(&VAR2->VAR15);
	return VAR14;
}