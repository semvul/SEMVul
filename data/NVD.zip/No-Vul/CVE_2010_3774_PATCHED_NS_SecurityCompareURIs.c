inline VAR1 FUN1(VAR2* VAR3,                        VAR2* VAR4,                        PRBool VAR5)  
{
    
    
    
    
    
    if (VAR3 && VAR3 == VAR4)
    {
        return VAR6;
    }

    if (!VAR4 || !VAR3)
    {
        return VAR7;
    }

    
    VAR8<VAR2> VAR9 = FUN2(VAR3);
    VAR8<VAR2> VAR10 = FUN2(VAR4);

    if (!VAR9 || !VAR10)
        return VAR7;

    
    nsCAutoString VAR11;
    PRBool VAR12 = VAR7;
    if (FUN3( VAR10->FUN4(VAR11) ) ||
        FUN3( VAR9->FUN5(VAR11.FUN6(), &VAR12) ) ||
        !VAR12)
    {
        
        return VAR7;
    }

    
    if (VAR11.FUN7(""))
    {
        
        if (!VAR5)
            return VAR6;

        VAR8<VAR13> FUN8(FUN9(VAR9));
        VAR8<VAR13> FUN10(FUN9(VAR10));

        if (!VAR14 || !VAR15)
            return VAR7;

        VAR8<VAR16> VAR17, VAR18;

        VAR14->FUN11(FUN12(VAR17));
        VAR15->FUN11(FUN12(VAR18));

        if (!VAR17 || !VAR18)
            return VAR7;

        
        PRBool VAR19 = VAR7;
        nsresult VAR20 = VAR17->FUN13(VAR18, &VAR19);
        return FUN14(VAR20) && VAR19;
    }

    
    if (VAR11.FUN7("") ||
        VAR11.FUN7("") ||
        VAR11.FUN7(""))
    {
        
        
        nsCAutoString VAR21;
        nsCAutoString VAR22;
        return ( FUN14( VAR10->FUN15(VAR21) ) &&
                 FUN14( VAR9->FUN15(VAR22) ) &&
                 VAR21.FUN13(VAR22) );
    }

    
    nsCAutoString VAR23;
    nsCAutoString VAR24;
    if (FUN3( VAR10->FUN16(VAR23) ) ||
        FUN3( VAR9->FUN16(VAR24) ))
    {
        return VAR7;
    }

    VAR8<VAR25> FUN17(FUN9(VAR10));
    VAR8<VAR25> FUN18(FUN9(VAR9));
    if (!VAR26 || !VAR27)
    {
        return VAR7;
    }

#ifdef VAR28
    if (!VAR23.FUN13(VAR24, FUN19() ))
#else
    if (!VAR23.FUN13(VAR24, VAR29))
#endif
    {
        return VAR7;
    }

    return FUN20(VAR10) == FUN20(VAR9);
}