int FUN1(struct VAR1 *VAR2, char VAR3 *VAR4, int VAR5)  
{
	int VAR6;
	struct VAR7 *VAR8 = FUN2(VAR2);
	struct in6_flowlabel_req VAR9;
	struct VAR10 *VAR11=NULL;
	struct VAR10 *VAR12, **VAR13;
	struct VAR14 *VAR15;

	if (VAR5 < sizeof(VAR9))
		return -VAR16;

	if (FUN3(&VAR9, VAR4, sizeof(VAR9)))
		return -VAR17;

	switch (VAR9.VAR18) {
	case VAR19:
		FUN4(&VAR20);
		for (VAR13 = &VAR8->VAR21; (VAR12=*VAR13)!=NULL; VAR13 = &VAR12->VAR22) {
			if (VAR12->VAR15->VAR23 == VAR9.VAR24) {
				if (VAR9.VAR24 == (VAR8->VAR25&VAR26))
					VAR8->VAR25 &= ~VAR26;
				*VAR13 = VAR12->VAR22;
				FUN5(&VAR20);
				FUN6(VAR12->VAR15);
				FUN7(VAR12);
				return 0;
			}
		}
		FUN5(&VAR20);
		return -VAR27;

	case VAR28:
		FUN8(&VAR20);
		for (VAR12 = VAR8->VAR21; VAR12; VAR12 = VAR12->VAR22) {
			if (VAR12->VAR15->VAR23 == VAR9.VAR24) {
				VAR6 = FUN9(VAR12->VAR15, VAR9.VAR29, VAR9.VAR30);
				FUN10(&VAR20);
				return VAR6;
			}
		}
		FUN10(&VAR20);

		if (VAR9.VAR31 == VAR32 && FUN11(VAR33)) {
			VAR15 = FUN12(VAR9.VAR24);
			if (VAR15) {
				VAR6 = FUN9(VAR15, VAR9.VAR29, VAR9.VAR30);
				FUN6(VAR15);
				return VAR6;
			}
		}
		return -VAR27;

	case VAR34:
		if (VAR9.VAR24 & ~VAR26)
			return -VAR16;

		VAR15 = FUN13(&VAR9, VAR4, VAR5, &VAR6);
		if (VAR15 == NULL)
			return VAR6;
		VAR11 = FUN14(sizeof(*VAR11), VAR35);

		if (VAR9.VAR24) {
			struct VAR14 *VAR36 = NULL;

			VAR6 = -VAR37;
			FUN8(&VAR20);
			for (VAR12 = VAR8->VAR21; VAR12; VAR12 = VAR12->VAR22) {
				if (VAR12->VAR15->VAR23 == VAR9.VAR24) {
					if (VAR9.VAR38&VAR39) {
						FUN10(&VAR20);
						goto VAR40;
					}
					VAR36 = VAR12->VAR15;
					FUN15(&VAR36->VAR41);
					break;
				}
			}
			FUN10(&VAR20);

			if (VAR36 == NULL)
				VAR36 = FUN12(VAR9.VAR24);
			if (VAR36) {
				VAR6 = -VAR37;
				if (VAR9.VAR38&VAR39)
					goto VAR42;
				VAR6 = -VAR43;
				if (VAR36->VAR44 == VAR45 ||
				    VAR36->VAR44 != VAR15->VAR44 ||
				    VAR36->VAR46 != VAR15->VAR46)
					goto VAR42;

				VAR6 = -VAR16;
				if (!FUN16(&VAR36->VAR47, &VAR15->VAR47) ||
				    FUN17(VAR36->VAR48, VAR15->VAR48))
					goto VAR42;

				VAR6 = -VAR49;
				if (VAR11 == NULL)
					goto VAR42;
				if (VAR15->VAR50 > VAR36->VAR50)
					VAR36->VAR50 = VAR15->VAR50;
				if ((long)(VAR15->VAR51 - VAR36->VAR51) > 0)
					VAR36->VAR51 = VAR15->VAR51;
				FUN4(&VAR20);
				VAR11->VAR15 = VAR36;
				VAR11->VAR22 = VAR8->VAR21;
				VAR8->VAR21 = VAR11;
				FUN5(&VAR20);
				FUN18(VAR15);
				return 0;

VAR42:
				FUN6(VAR36);
				goto VAR40;
			}
		}
		VAR6 = -VAR52;
		if (!(VAR9.VAR38&VAR53))
			goto VAR40;

		VAR6 = -VAR49;
		if (VAR11 == NULL || (VAR6 = FUN19(VAR2)) != 0)
			goto VAR40;

		VAR6 = FUN20(VAR15, VAR9.VAR24);
		if (VAR6)
			goto VAR40;

		if (!VAR9.VAR24) {
			if (FUN21(&((struct in6_flowlabel_req VAR3 *) VAR4)->VAR24,
					 &VAR15->VAR23, sizeof(VAR15->VAR23))) {
				
			}
		}

		VAR11->VAR15 = VAR15;
		VAR11->VAR22 = VAR8->VAR21;
		VAR8->VAR21 = VAR11;
		return 0;

	default:
		return -VAR16;
	}

VAR40:
	FUN18(VAR15);
	FUN7(VAR11);
	return VAR6;
}