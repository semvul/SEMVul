int FUN1(unsigned int VAR1, struct VAR2 *VAR3, 	 const char *VAR4, struct VAR5 *VAR6, 	 const struct VAR7 *VAR8)  
{
	struct VAR9 *VAR10;
	struct VAR9 *VAR11;
	VAR12 *VAR13;
	VAR14 *VAR15;
	unsigned char *VAR16;
	int VAR17 = 0;
	int VAR18;
	__u16 VAR19;

	if (VAR3 == NULL)
		return -VAR20;

	VAR10 = FUN2();
	if (VAR10 == NULL) {
		return -VAR21;
	}
	VAR11 = VAR10;

	FUN3(VAR10, VAR22,
			NULL  , 4  );

	VAR10->VAR23 = FUN4(VAR3->VAR24);
	VAR10->VAR25 = VAR3->VAR26;
	VAR13 = (VAR12 *) VAR10;
	VAR15 = (VAR14 *) VAR11;

	VAR13->VAR27 = 0xFF;
	VAR13->VAR28 = FUN5(VAR29);
	VAR16 = &VAR13->VAR30[0];
	if ((VAR3->VAR24->VAR31) & VAR32) {
		VAR13->VAR33 = FUN5(1);	
		*VAR16 = 0; 
		VAR16++;              
		
	} else {
		VAR13->VAR33 = FUN5(VAR34);
		
#ifdef VAR35
		if ((VAR36 & VAR37) &&
		    (VAR3->VAR24->VAR38 == VAR39))
			FUN6(VAR6->VAR40, VAR3->VAR24->VAR41,
					 VAR3->VAR24->VAR31 &
					    VAR42 ? true : false,
					 VAR16);
		else
#endif 
		FUN7(VAR6->VAR40, VAR3->VAR24->VAR41,
			     VAR16);

		VAR16 += VAR34;
		if (VAR3->VAR43 & VAR44) {
			
			*VAR16 = 0; 
			VAR16++;
		}
	}

	if (VAR3->VAR24->VAR31 &
			(VAR45 | VAR46))
		VAR10->VAR47 |= VAR48;

	if (VAR3->VAR43 & VAR49) {
		VAR10->VAR47 |= VAR50;
	}
	if (VAR3->VAR43 & VAR51) {
		VAR10->VAR47 |= VAR52;
	}
	if (VAR3->VAR43 & VAR44) {
		VAR10->VAR47 |= VAR53;
		VAR18 =
		    FUN8((VAR54 *) VAR16, VAR4,
			6  *
			( + 256 ), VAR8);
		VAR16 += 2 * VAR18;	
		VAR16 += 2;	
	} else {		
		strcpy(VAR16, VAR4);
		VAR16 += strlen(VAR4) + 1;
	}
	strcpy(VAR16, "");
	VAR16 += strlen("");
	VAR16 += 1;
	VAR19 = VAR16 - &VAR13->VAR30[0];
	VAR13->VAR55.VAR56 += VAR19;
	VAR13->VAR57 = FUN5(VAR19);

	VAR17 = FUN9(VAR1, VAR3, VAR10, VAR11, &VAR18,
			 VAR58);

	
	
	if ((VAR17 == 0) && (VAR6 != NULL)) {
		VAR6->VAR59 = VAR60;
		VAR6->VAR61 = false;
		VAR6->VAR62 = VAR11->VAR63;
		VAR16 = FUN10(VAR11);
		VAR18 = FUN11(VAR16, FUN12(VAR11) - 2);
		
		if (VAR18 == 3) {
			if ((VAR16[0] == '') && (VAR16[1] == '') &&
			    (VAR16[2] == '')) {
				FUN13(1, (""));
				VAR6->VAR64 = 1;
			}
		} else if (VAR18 == 2) {
			if ((VAR16[0] == '') && (VAR16[1] == '')) {
				
				FUN13(1, (""));
			}
		}
		VAR16 += VAR18 + 1;
		strncpy(VAR6->VAR65, VAR4, VAR66);
		if (VAR10->VAR47 & VAR53) {
			VAR18 = FUN14((wchar_t *) VAR16, 512);
			if ((VAR16 + (2 * VAR18)) -
			     FUN10(VAR11) <=
			    FUN12(VAR11)) {
				FUN15(VAR6->VAR67);
				VAR6->VAR67 =
				    FUN16(2*(VAR18 + 1), VAR68);
				if (VAR6->VAR67)
					FUN17(
						VAR6->VAR67,
						(VAR54 *) VAR16,
						VAR18, VAR8);
				VAR16 += 2 * VAR18;
				VAR16[0] = 0;	
				VAR16[1] = 0;
				VAR16 += 2;
			}
			
		} else {
			VAR18 = FUN11(VAR16, 1024);
			if ((VAR16 + VAR18) -
			    FUN10(VAR11) <=
			    FUN12(VAR11)) {
				FUN15(VAR6->VAR67);
				VAR6->VAR67 =
				    FUN16(VAR18 + 1, VAR68);
				if (VAR6->VAR67)
					strncpy(VAR6->VAR67, VAR16,
						VAR18);
			}
			
		}
		if ((VAR11->VAR69 == 3) ||
			 (VAR11->VAR69 == 7))
			
			VAR6->VAR28 = FUN18(VAR15->VAR70);
		else
			VAR6->VAR28 = 0;
		FUN13(1, ("", VAR6->VAR28));
	} else if ((VAR17 == 0) && VAR6 == NULL) {
		
		VAR3->VAR71 = VAR11->VAR63;
	}

	FUN19(VAR10);
	return VAR17;
}