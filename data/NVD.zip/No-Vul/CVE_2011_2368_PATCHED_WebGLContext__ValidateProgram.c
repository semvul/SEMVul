NS_IMETHODIMP VAR1::FUN1(VAR2 *VAR3)  
{
    WebGLuint VAR4;
    if (!VAR5<VAR6>("", VAR3, &VAR4))
        return VAR7;

    FUN2();

#ifdef VAR8
    
    FUN3("");
    return VAR7;
#endif

    VAR9->FUN4(VAR4);

    return VAR7;
}