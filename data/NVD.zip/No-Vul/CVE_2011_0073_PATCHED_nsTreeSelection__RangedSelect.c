NS_IMETHODIMP VAR1::FUN1(PRInt32 VAR2, PRInt32 VAR3, PRBool VAR4)  
{
  PRBool VAR5;
  nsresult VAR6 = FUN2(&VAR5);
  if (FUN3(VAR6))
    return VAR6;

  if ((VAR7 || (VAR2 != VAR3)) && VAR5)
    return VAR8;

  if (!VAR4) {
    
    if (VAR7) {
        VAR7->FUN4();
        delete VAR7;
        VAR7 = VAR9;
    }
  }

  if (VAR2 == -1) {
    if (VAR10 != -1)
      VAR2 = VAR10;
    else if (VAR11 != -1)
      VAR2 = VAR11;
    else
      VAR2 = VAR3;
  }

  VAR10 = VAR2;
  VAR6 = FUN5(VAR3);
  if (FUN3(VAR6))
    return VAR6;
  
  PRInt32 VAR12 = VAR2 < VAR3 ? VAR2 : VAR3;
  PRInt32 VAR13 = VAR2 < VAR3 ? VAR3 : VAR2;

  if (VAR4 && VAR7) {
    
    
    nsresult VAR6 = VAR7->FUN6(VAR12, VAR13);
    if (FUN3(VAR6))
      return VAR6;
  }

  VAR14* VAR15 = new FUN7(this, VAR12, VAR13);
  if (!VAR15)
    return VAR16;

  VAR15->FUN4();

  if (VAR4 && VAR7)
    VAR7->FUN8(VAR15);
  else
    VAR7 = VAR15;

  FUN9();

  return VAR8;
}