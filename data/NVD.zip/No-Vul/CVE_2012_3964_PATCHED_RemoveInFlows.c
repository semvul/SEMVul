static void FUN1(VAR1* VAR2, VAR1* VAR3)  
{
  FUN2(VAR2 != VAR3, "");
  
  
  
  
  
  

  
  
  
  
  FUN3(VAR3->FUN4() ==
               VAR3->FUN5() &&
               VAR3->FUN5() != VAR4,
               "");
  FUN3(VAR2->FUN4() ==
               VAR2->FUN5() &&
               VAR2->FUN5() != VAR4,
               "");
  
  VAR5* VAR6 = VAR2->FUN4();
  VAR5* VAR7 = VAR3->FUN4();
  VAR5* VAR8 = VAR2->FUN6();
  VAR9* VAR10 = VAR11::FUN7(VAR8);
  if (!VAR10) {
    
    
    
    
    
    
    VAR2->FUN8();
    if (VAR2 != VAR7) {
      
      static_cast<VAR1*>(VAR7)->FUN8();
    }
  }

  VAR6->FUN9(VAR3);
  VAR3->FUN10(VAR6);

  VAR2->FUN10(VAR4);
  VAR7->FUN9(VAR4);

  if (VAR10) {
    
    
    
    VAR10->FUN11(VAR2, VAR9::VAR12);
  } else {
    
    
    VAR8->FUN12(VAR5::VAR13, VAR2);
  }
}