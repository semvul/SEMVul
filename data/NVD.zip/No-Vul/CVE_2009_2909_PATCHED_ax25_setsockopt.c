static int FUN1(struct socket *VAR1, int VAR2, int VAR3, 	char VAR4 *VAR5, int VAR6)  
{
	struct VAR1 *VAR7 = VAR1->VAR7;
	VAR8 *VAR9;
	struct VAR10 *VAR11;
	char VAR12[VAR13];
	int VAR14, VAR15 = 0;

	if (VAR2 != VAR16)
		return -VAR17;

	if (VAR6 < (int)sizeof(int))
		return -VAR18;

	if (FUN2(VAR14, (int VAR4 *)VAR5))
		return -VAR19;

	FUN3(VAR7);
	VAR9 = FUN4(VAR7);

	switch (VAR3) {
	case VAR20:
		if (VAR9->VAR21 == VAR22) {
			if (VAR14 < 1 || VAR14 > 7) {
				VAR15 = -VAR18;
				break;
			}
		} else {
			if (VAR14 < 1 || VAR14 > 63) {
				VAR15 = -VAR18;
				break;
			}
		}
		VAR9->VAR23 = VAR14;
		break;

	case VAR24:
		if (VAR14 < 1) {
			VAR15 = -VAR18;
			break;
		}
		VAR9->VAR25 = (VAR14 * VAR26) >> 1;
		VAR9->VAR27  = VAR14 * VAR26;
		break;

	case VAR28:
		if (VAR14 < 1) {
			VAR15 = -VAR18;
			break;
		}
		VAR9->VAR29 = VAR14 * VAR26;
		break;

	case VAR30:
		if (VAR14 < 1 || VAR14 > 31) {
			VAR15 = -VAR18;
			break;
		}
		VAR9->VAR31 = VAR14;
		break;

	case VAR32:
		if (VAR14 < 1) {
			VAR15 = -VAR18;
			break;
		}
		VAR9->VAR33 = VAR14 * VAR26;
		break;

	case VAR34:
		if (VAR14 < 0) {
			VAR15 = -VAR18;
			break;
		}
		VAR9->VAR35 = VAR14 * 60 * VAR26;
		break;

	case VAR36:
		if (VAR14 < 0 || VAR14 > 2) {
			VAR15 = -VAR18;
			break;
		}
		VAR9->VAR37 = VAR14;
		break;

	case VAR38:
		VAR9->VAR21 = VAR14 ? VAR39 : VAR22;
		break;

	case VAR40:
		VAR9->VAR41 = VAR14 ? 1 : 0;
		break;

	case VAR42:
		VAR9->VAR43 = VAR14 ? 1 : 0;
		break;

	case VAR44:
		if (VAR14 < 16 || VAR14 > 65535) {
			VAR15 = -VAR18;
			break;
		}
		VAR9->VAR45 = VAR14;
		break;

	case VAR46:
		if (VAR6 > VAR13)
			VAR6=VAR13;
		if (FUN5(VAR12, VAR5, VAR6)) {
		VAR15 = -VAR19;
			break;
		}

		VAR11 = FUN6(&VAR47, VAR12);
		if (VAR11 == NULL) {
			VAR15 = -VAR48;
			break;
		}

		if (VAR7->VAR49 == VAR50 &&
		   (VAR1->VAR51 != VAR52 ||
		    VAR7->VAR53 == VAR54)) {
			VAR15 = -VAR55;
			FUN7(VAR11);
			break;
		}

		VAR9->VAR56 = FUN8(VAR11);
		FUN9(VAR9, VAR9->VAR56);
		break;

	default:
		VAR15 = -VAR17;
	}
	FUN10(VAR7);

	return VAR15;
}