static inline int FUN1(struct VAR1 *VAR2, 				      const struct VAR3 *VAR4, 				      unsigned int VAR5, 				      unsigned int VAR6, unsigned int VAR7, 				      void VAR8 *VAR9)  
{
	const struct VAR10 *VAR11 = &VAR4->VAR12[VAR5];

	if (!VAR11->VAR13)
		return -VAR14;

	if (!FUN2(VAR15, VAR9, VAR7))
		return -VAR16;

	return VAR11->FUN3(VAR2, VAR11, VAR6, VAR7, NULL, VAR9);
}