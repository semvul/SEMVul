static int FUN1(struct VAR1 *VAR2, int VAR3)  
{
	const unsigned char *VAR4 = FUN2(VAR2);
	struct VAR5 *VAR5 = FUN3(VAR2);
	u32 VAR6;

	if (VAR4[VAR3 + 1] != 4 || (VAR3 & 3) != 2) {
		FUN4(VAR7 "",
			       VAR4[VAR3+1]);
		FUN5(VAR5, FUN6(VAR2),
				 VAR8);
		goto VAR9;
	}

	VAR6 = FUN7(*(VAR10 *)(VAR4 + VAR3 + 2));
	if (VAR6 <= VAR11) {
		FUN5(VAR5, FUN6(VAR2),
				 VAR8);
		FUN8(VAR2, VAR12, VAR3+2);
		return 0;
	}
	if (FUN9(VAR2)->VAR13) {
		FUN5(VAR5, FUN6(VAR2),
				 VAR8);
		FUN8(VAR2, VAR12, VAR3);
		return 0;
	}

	if (VAR6 > VAR2->VAR14 - sizeof(struct VAR15)) {
		FUN5(VAR5, FUN6(VAR2),
				 VAR16);
		goto VAR9;
	}

	if (FUN10(VAR2, VAR6 + sizeof(struct VAR15)))
		goto VAR9;

	return 1;

VAR9:
	FUN11(VAR2);
	return 0;
}