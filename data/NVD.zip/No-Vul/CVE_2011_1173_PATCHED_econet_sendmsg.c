static int FUN1(struct VAR1 *VAR2, struct socket *VAR3, 			  struct VAR4 *VAR5, size_t VAR6)  
{
	struct VAR3 *VAR7 = VAR3->VAR7;
	struct VAR8 *VAR9=(struct VAR8 *)VAR5->VAR10;
	struct VAR11 *VAR12;
	struct ec_addr VAR13;
	int VAR14;
	unsigned char VAR15, VAR16;
#if FUN2(VAR17) || FUN2(VAR18)
	struct VAR19 *VAR20;
	struct VAR21 *VAR22;
#endif
#ifdef VAR17
	struct msghdr VAR23;
	struct iovec VAR24[VAR5->VAR25+1];
	struct aunhdr VAR26;
	struct sockaddr_in VAR27;
	__kernel_size_t VAR28;
	int VAR29;
	mm_segment_t VAR30;
#endif

	

	if (VAR5->VAR31 & ~(VAR32|VAR33))
		return -VAR34;

	

	FUN3(&VAR35);

	if (VAR9 == NULL) {
		struct VAR36 *VAR37 = FUN4(VAR7);

		VAR13.VAR38 = VAR37->VAR38;
		VAR13.VAR39     = VAR37->VAR39;
		VAR15	     = VAR37->VAR15;
		VAR16	     = VAR37->VAR16;
	} else {
		if (VAR5->VAR40 < sizeof(struct VAR8)) {
			FUN5(&VAR35);
			return -VAR34;
		}
		VAR13.VAR38 = VAR9->VAR13.VAR38;
		VAR13.VAR39 = VAR9->VAR13.VAR39;
		VAR15 = VAR9->VAR15;
		VAR16 = VAR9->VAR16;
	}

	
	VAR12 = VAR41[VAR13.VAR39];

	
	if (VAR12 == NULL) {
		VAR12 = VAR41[0];
		
		if (VAR12 == NULL) {
			FUN5(&VAR35);
			return -VAR42;
		}
	}

	if (VAR6 + 15 > VAR12->VAR43) {
		FUN5(&VAR35);
		return -VAR44;
	}

	if (VAR12->VAR45 == VAR46) {
		
#ifdef VAR18
		unsigned short VAR47 = 0;
		int VAR48;

		FUN6(VAR12);

		VAR20 = FUN7(VAR7, VAR6+FUN8(VAR12),
					  VAR5->VAR31 & VAR32, &VAR14);
		if (VAR20==NULL)
			goto VAR49;

		FUN9(VAR20, FUN10(VAR12));
		FUN11(VAR20);

		VAR22 = (struct VAR21 *)&VAR20->VAR16;

		
		VAR22->VAR50 = VAR9->VAR50;
		VAR22->VAR51 = *VAR9;
		VAR22->VAR52 = VAR53;

		VAR14 = -VAR34;
		VAR48 = FUN12(VAR20, VAR12, FUN13(VAR47), &VAR13, NULL, VAR6);
		if (VAR48 < 0)
			goto VAR54;
		if (VAR48 > 0) {
			struct VAR55 *VAR56;
			
			VAR56 = (struct VAR55 *)(VAR20->VAR57);
			VAR56->VAR16 = VAR16;
			VAR56->VAR15 = VAR15;
			if (VAR3->VAR45 != VAR58) {
				FUN14(VAR20);
				VAR20->VAR6 = 0;
			}
		}

		
		VAR14 = FUN15(FUN16(VAR20,VAR6), VAR5->VAR59, VAR6);
		VAR20->VAR60 = VAR47;
		VAR20->VAR12 = VAR12;
		VAR20->VAR61 = VAR7->VAR62;
		if (VAR14)
			goto VAR54;

		VAR14 = -VAR42;
		if (!(VAR12->VAR63 & VAR64))
			goto VAR54;

		

		FUN17(VAR20);
		FUN18(VAR12);
		FUN5(&VAR35);
		return(VAR6);

	VAR54:
		FUN19(VAR20);
	VAR49:
		if (VAR12)
			FUN18(VAR12);
#else
		VAR14 = -VAR65;
#endif
		FUN5(&VAR35);

		return VAR14;
	}

#ifdef VAR17
	

	if (VAR66 == NULL) {
		FUN5(&VAR35);
		return -VAR42;		
	}

	

	memset(&VAR27, 0, sizeof(VAR27));
	VAR27.VAR67 = VAR68;
	VAR27.VAR69 = FUN20(VAR70);

	
	{
		struct VAR71 *VAR72;
		unsigned long VAR73 = 0;

		FUN21();
		VAR72 = FUN22(VAR12);
		if (VAR72) {
			if (VAR72->VAR74)
				VAR73 = FUN23(VAR72->VAR74->VAR75) &
					0xffffff00;		
		}
		FUN24();
		VAR27.VAR76.VAR77 = FUN25(VAR73 | VAR13.VAR38);
	}

	memset(&VAR26, 0, sizeof(VAR26));
	VAR26.VAR15 = VAR15;
	VAR26.VAR16 = VAR16 & 0x7f;
	VAR26.VAR78 = 2;		

	
	VAR28 = sizeof(struct VAR79);
	
	VAR24[0].VAR80 = (void *)&VAR26;
	VAR24[0].VAR81 = VAR28;
	for (VAR29 = 0; VAR29 < VAR5->VAR25; VAR29++) {
		void VAR82 *VAR83 = VAR5->VAR59[VAR29].VAR80;
		size_t VAR81 = VAR5->VAR59[VAR29].VAR81;
		
		if (!FUN26(VAR84, VAR83, VAR81)) {
			FUN5(&VAR35);
			return -VAR85;
		}
		VAR24[VAR29+1].VAR80 = VAR83;
		VAR24[VAR29+1].VAR81 = VAR81;
		VAR28 += VAR81;
	}

	
	if ((VAR20 = FUN7(VAR7, 0,
				       VAR5->VAR31 & VAR32,
				       &VAR14)) == NULL) {
		FUN5(&VAR35);
		return VAR14;
	}

	VAR22 = (struct VAR21 *)&VAR20->VAR16;

	VAR22->VAR50 = VAR9->VAR50;
	VAR22->VAR86 = (5*VAR87);
	VAR22->VAR88 = VAR89;
	VAR26.VAR90 = VAR91;
	VAR22->VAR92 = (VAR91++);
	VAR22->VAR51 = *VAR9;

	FUN27(&VAR93, VAR20);

	VAR23.VAR10 = (void *)&VAR27;
	VAR23.VAR40 = sizeof(VAR27);
	VAR23.VAR59 = &VAR24[0];
	VAR23.VAR25 = VAR5->VAR25 + 1;
	VAR23.VAR94 = NULL;
	VAR23.VAR95 = 0;
	VAR23.VAR31=0;

	VAR30 = FUN28(); FUN29(VAR96);	
	VAR14 = FUN30(VAR66, &VAR23, VAR28);
	FUN29(VAR30);
#else
	VAR14 = -VAR65;
#endif
	FUN5(&VAR35);

	return VAR14;
}