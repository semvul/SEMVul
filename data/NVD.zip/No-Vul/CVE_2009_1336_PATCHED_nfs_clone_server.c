struct VAR1 *FUN1(struct VAR1 *VAR2, 				    struct VAR3 *VAR4, 				    struct VAR5 *VAR6)  
{
	struct VAR1 *VAR7;
	struct nfs_fattr VAR8;
	int VAR9;

	FUN2("",
		(unsigned long long) VAR6->VAR10.VAR11,
		(unsigned long long) VAR6->VAR10.VAR12);

	VAR7 = FUN3();
	if (!VAR7)
		return FUN4(-VAR13);

	
	VAR7->VAR14 = VAR2->VAR14;
	FUN5(&VAR7->VAR14->VAR15);
	FUN6(VAR7, VAR2);

	VAR7->VAR10 = VAR6->VAR10;

	VAR9 = FUN7(VAR7, VAR2->VAR16->VAR17->VAR18);
	if (VAR9 < 0)
		goto VAR19;
	if (!FUN8(VAR2->VAR20))
		FUN9(VAR7);

	
	VAR9 = FUN10(VAR7, VAR4, &VAR8);
	if (VAR9 < 0)
		goto VAR19;

	if (VAR7->VAR21 == 0 || VAR7->VAR21 > VAR22)
		VAR7->VAR21 = VAR22;

	FUN2("",
		(unsigned long long) VAR7->VAR10.VAR11,
		(unsigned long long) VAR7->VAR10.VAR12);

	VAR9 = FUN11(VAR7);
	if (VAR9 < 0)
		goto VAR19;

	FUN12(&VAR23);
	FUN13(&VAR7->VAR24, &VAR7->VAR14->VAR25);
	FUN13(&VAR7->VAR26, &VAR27);
	FUN14(&VAR23);

	VAR7->VAR28 = VAR29;

	FUN2("", VAR7);
	return VAR7;

VAR19:
	FUN15(VAR7);
	FUN2("", VAR9);
	return FUN4(VAR9);
}