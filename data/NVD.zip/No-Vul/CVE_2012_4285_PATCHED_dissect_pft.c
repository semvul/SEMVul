static void FUN1(VAR1 * VAR2, VAR3 * VAR4, VAR5 * VAR6)  
{
  guint16 VAR7;
  gint VAR8 = 0;
  guint16 VAR9, VAR10;
  guint32 VAR11, VAR12;
  VAR5 *VAR13 = NULL;
  VAR14 *VAR15 = NULL, *VAR16 = NULL;
  VAR1 *VAR17 = NULL;
  gboolean VAR18 = VAR19;
  guint16 VAR20=0, VAR21=0;

  VAR4->VAR22 = "";
  FUN2(VAR4->VAR23, VAR24, "");

  if (VAR6) {                   
    VAR15 = FUN3 (VAR6, VAR25, VAR2, 0, -1, VAR26);
    VAR13 = FUN4 (VAR15, VAR27);
    FUN3 (VAR13, VAR28, VAR2, VAR8, 2, VAR29|VAR26);
  }
  VAR8 += 2;
  VAR9 = FUN5 (VAR2, VAR8);
  if (VAR6) {
    FUN3 (VAR13, VAR30, VAR2, VAR8, 2, VAR31);
  }
  VAR8 += 2;
  VAR11 = FUN6 (VAR2, VAR8);
  if (VAR6) {
    FUN3 (VAR13, VAR32, VAR2, VAR8, 3, VAR31);
  }
  VAR8 += 3;
  VAR12 = FUN6 (VAR2, VAR8);
  if (VAR6) {
    FUN3 (VAR13, VAR33, VAR2, VAR8, 3, VAR31);
  }
  VAR8 += 3;
  VAR7 = FUN5 (VAR2, VAR8);
  VAR10 = VAR7 & 0x3fff;
  if (VAR6) {
    FUN3 (VAR13, VAR34, VAR2, VAR8, 2, VAR31);
    FUN3 (VAR13, VAR35, VAR2, VAR8, 2, VAR31);
    VAR16 = FUN3 (VAR13, VAR36, VAR2, VAR8, 2, VAR31);
  }
  VAR8 += 2;
  if (VAR7 & 0x8000) {
    VAR18 = VAR37;
    VAR20 = FUN7 (VAR2, VAR8);
    if (VAR6)
          FUN3 (VAR13, VAR38, VAR2, VAR8, 1, VAR31);
    VAR8 += 1;
    VAR21 = FUN7 (VAR2, VAR8);
    if (VAR6)
          FUN3 (VAR13, VAR39, VAR2, VAR8, 1, VAR31);
    VAR8 += 1;
  }
  if (VAR7 & 0x4000) {
    if (VAR6)
      FUN3 (VAR13, VAR40, VAR2, VAR8, 2, VAR31);
    VAR8 += 2;
    if (VAR6)
          FUN3 (VAR13, VAR41, VAR2, VAR8, 2, VAR31);
    VAR8 += 2;
  }
  if (VAR6) {
    VAR14 *VAR42 = NULL;
    guint VAR43 = VAR8+2;
    const char *VAR44 = (const char *) FUN8(VAR2, 0, VAR43);
    unsigned long VAR45 = FUN9(VAR44, VAR43, 16, 0x11021, 1);
    VAR42 = FUN3 (VAR13, VAR46, VAR2, VAR8, 2, VAR31);
    FUN10(VAR42, "", (VAR45==0xe2f0)?"":"");
    FUN11(VAR13, VAR47, VAR2, VAR8, 2, VAR45==0xe2f0);
  }
  VAR8 += 2;
  if (VAR12 > 1) {             
    gboolean VAR48 = VAR4->VAR49;
    guint16 VAR50 = FUN12(VAR2)-VAR8;
    FUN3 (VAR13, VAR51, VAR2, VAR8, VAR50, VAR26);
    if(VAR50 != VAR10 || VAR50 == 0) {
      if(VAR16)
        FUN10(VAR16, "", VAR50);
    }
    if (VAR50)
      VAR17 = FUN13(VAR2, VAR4, VAR13, VAR11, VAR12,
                                        VAR9, VAR8, VAR50, VAR18, VAR20, VAR21);
    VAR4->VAR49 = VAR48;
  } else {
    VAR17 = FUN14 (VAR2, VAR8);
  }
  if(VAR17) {
    FUN15(VAR17, VAR4, VAR6);
  }
}