void FUN1(GLuint VAR1, GLuint VAR2, const void* VAR3)  
{
        if (VAR4 == VAR5 && VAR6) {
            memcpy((void*) (FUN2(VAR7)+VAR1), VAR3, VAR2);
        }
    }