static long FUN1(struct VAR1 *VAR2,     struct mpt2_ioctl_command VAR3, void VAR4 *VAR5, enum block_state VAR6)  
{
	VAR7 *VAR8 = NULL, *VAR9;
	VAR10 *VAR11;
	u32 VAR12;
	u16 VAR13;
	u16 VAR14;
	unsigned long VAR15, VAR16;
	u8 VAR17;
	u32 VAR18;
	void *VAR19;
	void *VAR20 = NULL;
	dma_addr_t VAR21;
	size_t VAR22 = 0;
	void *VAR23 = NULL;
	dma_addr_t VAR24;
	size_t VAR25 = 0;
	u32 VAR26;
	long VAR27;
	u16 VAR28;

	VAR17 = 0;

	if (VAR6 == VAR29 && !FUN2(&VAR2->VAR30.mutex))
		return -VAR31;
	else if (FUN3(&VAR2->VAR30.mutex))
		return -VAR32;

	if (VAR2->VAR30.VAR33 != VAR34) {
		FUN4(VAR35 "",
		    VAR2->VAR36, VAR37);
		VAR27 = -VAR31;
		goto VAR38;
	}

	VAR28 = 0;
	VAR12 = FUN5(VAR2, 1);
	while (VAR12 != VAR39) {
		if (VAR28++ == 10) {
			FUN4(VAR35
			    "",
			    VAR2->VAR36, VAR37);
			VAR27 = -VAR40;
			goto VAR38;
		}
		FUN6(1);
		VAR12 = FUN5(VAR2, 1);
		FUN4(VAR41 ""
		    "", VAR2->VAR36,
		    VAR37, VAR28);
	}
	if (VAR28)
		FUN4(VAR41 "",
		    VAR2->VAR36, VAR37);

	VAR8 = FUN7(VAR2->VAR42, VAR43);
	if (!VAR8) {
		FUN4(VAR35 ""
		    "", VAR2->VAR36, VAR37);
		VAR27 = -VAR44;
		goto VAR38;
	}

	
	if (VAR3.VAR45 * 4 > VAR2->VAR42 ||
	    VAR3.VAR45 > (VAR46 / 4)) {
		VAR27 = -VAR47;
		goto VAR38;
	}

	
	if (FUN8(VAR8, VAR5, VAR3.VAR45*4)) {
		FUN4(VAR48 "", VAR49, VAR50,
		    VAR37);
		VAR27 = -VAR40;
		goto VAR38;
	}

	if (VAR8->VAR51 == VAR52) {
		VAR14 = FUN9(VAR2, VAR2->VAR53);
		if (!VAR14) {
			FUN4(VAR35 "",
			    VAR2->VAR36, VAR37);
			VAR27 = -VAR31;
			goto VAR38;
		}
	} else {

		VAR14 = FUN10(VAR2, VAR2->VAR53, NULL);
		if (!VAR14) {
			FUN4(VAR35 "",
			    VAR2->VAR36, VAR37);
			VAR27 = -VAR31;
			goto VAR38;
		}
	}

	VAR27 = 0;
	VAR2->VAR30.VAR33 = VAR54;
	memset(VAR2->VAR30.VAR55, 0, VAR2->VAR56);
	VAR9 = FUN11(VAR2, VAR14);
	memcpy(VAR9, VAR8, VAR3.VAR45*4);
	VAR2->VAR30.VAR14 = VAR14;
	VAR22 = VAR3.VAR57;
	VAR25 = VAR3.VAR58;

	if (VAR8->VAR51 == VAR59 ||
	    VAR8->VAR51 == VAR60) {
		if (!FUN12(VAR8->VAR61) ||
		    FUN12(VAR8->VAR61) >
		    VAR2->VAR62.VAR63) {
			VAR27 = -VAR47;
			FUN13(VAR2, VAR14);
			goto VAR38;
		}
	}

	
	if (VAR22)  {
		VAR20 = FUN14(VAR2->VAR64, VAR22,
		    &VAR21);
		if (!VAR20) {
			FUN4(VAR48 "", VAR49,
			    VAR50, VAR37);
			VAR27 = -VAR44;
			FUN13(VAR2, VAR14);
			goto VAR38;
		}
		if (FUN8(VAR20, VAR3.VAR65,
			VAR22)) {
			FUN4(VAR48 "", VAR49,
			    VAR50, VAR37);
			VAR27 =  -VAR40;
			FUN13(VAR2, VAR14);
			goto VAR38;
		}
	}

	if (VAR25)  {
		VAR23 = FUN14(VAR2->VAR64, VAR25,
		    &VAR24);
		if (!VAR23) {
			FUN4(VAR48 "", VAR49,
			    VAR50, VAR37);
			VAR27 = -VAR44;
			FUN13(VAR2, VAR14);
			goto VAR38;
		}
	}

	
	VAR19 = (void *)VAR9 + (VAR3.VAR45*4);

	if (!VAR22 && !VAR25) {
		FUN15(VAR2, VAR19);
	} else if (VAR22 && VAR25) {
		
		VAR26 = (VAR66 |
		    VAR67 | VAR68);
		VAR26 = VAR26 << VAR69;
		VAR2->FUN16(VAR19, VAR26 |
		    VAR22, VAR21);

		
		VAR19 += VAR2->VAR70;

		
		VAR26 = (VAR66 |
		    VAR71 | VAR67 |
		    VAR72);
		VAR26 = VAR26 << VAR69;
		VAR2->FUN16(VAR19, VAR26 |
		    VAR25, VAR24);
	} else if (VAR22)  {
		VAR26 = (VAR66 |
		    VAR71 | VAR67 |
		    VAR72 | VAR68);
		VAR26 = VAR26 << VAR69;
		VAR2->FUN16(VAR19, VAR26 |
		    VAR22, VAR21);
	} else if (VAR25)  {
		VAR26 = (VAR66 |
		    VAR71 | VAR67 |
		    VAR72);
		VAR26 = VAR26 << VAR69;
		VAR2->FUN16(VAR19, VAR26 |
		    VAR25, VAR24);
	}

	
#ifdef VAR73
	FUN17(VAR2, VAR14, "", NULL);
#endif

	switch (VAR8->VAR51) {
	case VAR59:
	case VAR60:
	{
		VAR74 *VAR75 =
		    (VAR74 *)VAR9;
		VAR75->VAR76 = VAR77;
		VAR75->VAR78 =
		    FUN18(VAR2, VAR14);
		memset(VAR2->VAR30.VAR79, 0, VAR77);
		if (VAR8->VAR51 == VAR59)
			FUN19(VAR2, VAR14,
			    FUN12(VAR8->VAR61));
		else
			FUN20(VAR2, VAR14);
		break;
	}
	case VAR52:
	{
		VAR80 *VAR81 =
		    (VAR80 *)VAR9;

		FUN21(VAR2, FUN4(VAR41 ""
		    "", VAR2->VAR36,
		    FUN12(VAR81->VAR82), VAR81->VAR83));

		if (VAR81->VAR83 ==
		    VAR84 ||
		    VAR81->VAR83 ==
		    VAR85) {
			if (FUN22(VAR2, &VAR3, VAR81)) {
				FUN13(VAR2, VAR14);
				goto VAR38;
			}
		}

		FUN23(VAR2, FUN12(
		    VAR81->VAR82));
		FUN24(VAR2, VAR14);
		break;
	}
	case VAR86:
	{
		VAR87 *VAR88 =
		    (VAR87 *)VAR8;
		VAR89 *VAR90;

		
		VAR88->VAR91 = 0xFF;
		if (VAR88->VAR92 &
		    VAR93)
			VAR90 = (VAR89 *)&VAR88->VAR94;
		else
			VAR90 = VAR20;

		if (VAR90[1] == 0x91 && (VAR90[10] == 1 || VAR90[10] == 2)) {
			VAR2->VAR95 = 1;
			VAR2->VAR96 = 1;
		}
		FUN20(VAR2, VAR14);
		break;
	}
	case VAR97:
	{
		VAR98 *VAR99 =
		    (VAR98 *)VAR8;

		if (VAR99->VAR100 == VAR101
		    || VAR99->VAR100 ==
		    VAR102) {
			VAR2->VAR95 = 1;
			VAR2->VAR96 = 1;
		}
		FUN20(VAR2, VAR14);
		break;
	}
	default:
		FUN20(VAR2, VAR14);
		break;
	}

	if (VAR3.VAR15 < VAR103)
		VAR15 = VAR103;
	else
		VAR15 = VAR3.VAR15;
	FUN25(&VAR2->VAR30.VAR104);
	VAR16 = FUN26(&VAR2->VAR30.VAR104,
	    VAR15*VAR105);
	if (VAR8->VAR51 == VAR52) {
		VAR80 *VAR81 =
		    (VAR80 *)VAR8;
		FUN27(VAR2, FUN12(
		    VAR81->VAR82));
	} else if ((VAR8->VAR51 == VAR86 ||
	    VAR8->VAR51 == VAR97) &&
		VAR2->VAR95) {
		VAR2->VAR95 = 0;
		VAR2->VAR96 = 0;
	}
	if (!(VAR2->VAR30.VAR33 & VAR106)) {
		FUN4(VAR35 "", VAR2->VAR36,
		    VAR37);
		FUN28(VAR8, VAR3.VAR45);
		if (!(VAR2->VAR30.VAR33 & VAR107))
			VAR17 = 1;
		goto VAR108;
	}

	VAR11 = VAR2->VAR30.VAR55;
	VAR13 = FUN12(VAR11->VAR109) & VAR110;

#ifdef VAR73
	if (VAR11->VAR51 == VAR52 &&
	    (VAR2->VAR111 & VAR112)) {
		VAR113 *VAR114 =
		    (VAR113 *)VAR11;

		FUN4(VAR41 ""
		    ""
		    "", VAR2->VAR36,
		    FUN12(VAR114->VAR109),
		    FUN29(VAR114->VAR115),
		    FUN29(VAR114->VAR116));
	}
#endif
	
	if (VAR25) {
		if (FUN30(VAR3.VAR117, VAR23,
		    VAR25)) {
			FUN4(VAR48 "", VAR49,
			    VAR50, VAR37);
			VAR27 = -VAR118;
			goto VAR38;
		}
	}

	
	if (VAR3.VAR119) {
		VAR18 = FUN31(VAR120, VAR3.VAR119, VAR2->VAR56);
		if (FUN30(VAR3.VAR121, VAR2->VAR30.VAR55,
		    VAR18)) {
			FUN4(VAR48 "", VAR49,
			    VAR50, VAR37);
			VAR27 = -VAR118;
			goto VAR38;
		}
	}

	
	if (VAR3.VAR122 && (VAR8->VAR51 ==
	    VAR59 || VAR8->VAR51 ==
	    VAR60)) {
		VAR18 = FUN31(VAR120, VAR3.VAR122, VAR77);
		if (FUN30(VAR3.VAR123,
			VAR2->VAR30.VAR79, VAR18)) {
			FUN4(VAR48 "", VAR49,
			    VAR50, VAR37);
			VAR27 = -VAR118;
			goto VAR38;
		}
	}

 VAR108:
	if (VAR17) {
		VAR27 = -VAR118;
		if ((VAR8->VAR51 == VAR59 ||
		    VAR8->VAR51 ==
		    VAR60)) {
			FUN4(VAR41 ""
			    "", VAR2->VAR36,
			    FUN12(VAR8->VAR61));
			FUN32(VAR2);
			FUN33(VAR2,
			    FUN12(VAR8->VAR61), 0, 0,
			    0, VAR124, 0, 10,
			    NULL);
			VAR2->VAR125.VAR33 = VAR34;
		} else
			FUN34(VAR2, VAR126,
			    VAR127);
	}

 VAR38:

	
	if (VAR23)
		FUN35(VAR2->VAR64, VAR25, VAR23,
		    VAR24);

	if (VAR20)
		FUN35(VAR2->VAR64, VAR22, VAR20,
		    VAR21);

	FUN36(VAR8);
	VAR2->VAR30.VAR33 = VAR34;
	FUN37(&VAR2->VAR30.mutex);
	return VAR27;
}