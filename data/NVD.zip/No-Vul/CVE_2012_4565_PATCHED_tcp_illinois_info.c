static void FUN1(struct VAR1 *VAR2, u32 VAR3, 			      struct VAR4 *VAR5)  
{
	const struct VAR6 *VAR7 = FUN2(VAR2);

	if (VAR3 & (1 << (VAR8 - 1))) {
		struct tcpvegas_info VAR9 = {
			.VAR10 = 1,
			.VAR11 = VAR7->VAR12,
			.VAR13 = VAR7->VAR14,
		};

		if (VAR9.VAR11 > 0) {
			u64 VAR15 = VAR7->VAR16;

			FUN3(VAR15, VAR9.VAR11);
			VAR9.VAR17 = VAR15;
		}
		FUN4(VAR5, VAR8, sizeof(VAR9), &VAR9);
	}
}