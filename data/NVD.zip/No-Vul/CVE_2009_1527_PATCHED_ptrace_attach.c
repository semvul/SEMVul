int FUN1(struct VAR1 *VAR2)  
{
	int VAR3;
	unsigned long VAR4;

	FUN2(VAR2);

	VAR3 = -VAR5;
	if (FUN3(VAR2, VAR6))
		goto VAR7;

	
	VAR3 = FUN4(&VAR2->VAR8);
	if (VAR3  < 0)
		goto VAR7;

	VAR3 = -VAR5;
VAR9:
	
	FUN5(VAR2);
	if (!FUN6(&VAR10, VAR4)) {
		FUN7(VAR2);
		do {
			FUN8();
		} while (!FUN9(&VAR10));
		goto VAR9;
	}

	if (!VAR2->VAR11)
		goto VAR12;
	
	if (VAR2->VAR13 & VAR14)
		goto VAR12;
	VAR3 = FUN10(VAR2, VAR15);
	if (VAR3)
		goto VAR12;

	
	VAR2->VAR13 |= VAR14;
	if (FUN11(VAR16))
		VAR2->VAR13 |= VAR17;

	FUN12(VAR2, VAR6);

	FUN13(VAR18, VAR19, VAR2);
VAR12:
	FUN14(&VAR10, VAR4);
	FUN7(VAR2);
	FUN15(&VAR2->VAR8);
VAR7:
	return VAR3;
}