inline VAR1 FUN1(VAR2* VAR3)  
{
    VAR4<VAR2> VAR5 = FUN2(VAR3);

    nsCAutoString VAR6;
    PRUint32 VAR7 = 0;
    if (FUN3(VAR5->FUN4(VAR6)))
        VAR7 = VAR8::FUN5(VAR6.FUN6());

    
    if (VAR6.FUN7(""))
        return VAR7; 

    if (VAR6.FUN7("") ||
        VAR6.FUN7("") ||
        VAR6.FUN7(""))
    {
        nsCAutoString VAR9;
        PRUint32 VAR10 = VAR5->FUN8(VAR9);
        if (FUN3(VAR10))
            VAR10 = VAR8::FUN5(VAR9.FUN6());
        return VAR10;
    }

    nsCAutoString VAR11;
    PRUint32 VAR12 = 0;
    if (FUN3(VAR5->FUN9(VAR11)))
        VAR12 = VAR8::FUN5(VAR11.FUN6());

    
    return VAR7 ^ VAR12 ^ FUN10(VAR5);
}