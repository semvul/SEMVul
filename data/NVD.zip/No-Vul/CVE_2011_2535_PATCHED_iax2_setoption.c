static int FUN1(struct VAR1 *VAR2, int VAR3, void *VAR4, int VAR5)  
{
	struct VAR6 *VAR7;
	int VAR8;

	switch (VAR3) {
	case VAR9:
	case VAR10:
		
		VAR11 = VAR12;
		return -1;
	case VAR13:
		VAR11 = VAR14;
		return -1;
	case VAR15:
	case VAR16:
	{
		unsigned short VAR17 = FUN2(VAR2->VAR18);
		FUN3(&VAR19[VAR17]);
		if ((*(int *) VAR4)) {
			FUN4(VAR20[VAR17], VAR21);
		} else {
			FUN5(VAR20[VAR17], VAR21);
		}
		FUN6(&VAR19[VAR17]);
		return 0;
	}
	
	case VAR22:
	case VAR23:
	case VAR24:
	case VAR25:
	case VAR26:
	case VAR27:
	{
		unsigned short VAR17 = FUN2(VAR2->VAR18);
		struct VAR28 *VAR29;

		FUN3(&VAR19[VAR17]);
		VAR29 = VAR20[VAR17];

		if (FUN7(VAR29)) {
			FUN6(&VAR19[VAR17]);
			return -1;
		}

		FUN6(&VAR19[VAR17]);

		if (!(VAR7 = FUN8(VAR5 + sizeof(*VAR7)))) {
			return -1;
		}

		VAR7->VAR30 = VAR31;
		VAR7->VAR3 = FUN9(VAR3);
		memcpy(VAR7->VAR4, VAR4, VAR5);
		VAR8 = FUN10(FUN2(VAR2->VAR18), VAR32,
					  VAR33, 0, (unsigned char *) VAR7,
					  VAR5 + sizeof(*VAR7), -1);
		FUN11(VAR7);
		return VAR8;
	}
	default:
		return -1;
	}

	
	return -1;
}