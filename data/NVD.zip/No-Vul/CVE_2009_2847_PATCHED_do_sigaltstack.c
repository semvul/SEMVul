int  FUN1 (const stack_t VAR1 *VAR2, stack_t VAR1 *VAR3, unsigned long VAR4)  
{
	stack_t VAR5;
	int VAR6;

	VAR5.VAR7 = (void VAR1 *) VAR8->VAR9;
	VAR5.VAR10 = VAR8->VAR11;
	VAR5.VAR12 = FUN2(VAR4);

	if (VAR2) {
		void VAR1 *VAR7;
		size_t VAR10;
		int VAR12;

		VAR6 = -VAR13;
		if (!FUN3(VAR14, VAR2, sizeof(*VAR2))
		    || FUN4(VAR7, &VAR2->VAR7)
		    || FUN4(VAR12, &VAR2->VAR12)
		    || FUN4(VAR10, &VAR2->VAR10))
			goto VAR15;

		VAR6 = -VAR16;
		if (FUN5(VAR4))
			goto VAR15;

		VAR6 = -VAR17;
		
		if (VAR12 != VAR18 && VAR12 != VAR19 && VAR12 != 0)
			goto VAR15;

		if (VAR12 == VAR18) {
			VAR10 = 0;
			VAR7 = NULL;
		} else {
			VAR6 = -VAR20;
			if (VAR10 < VAR21)
				goto VAR15;
		}

		VAR8->VAR9 = (unsigned long) VAR7;
		VAR8->VAR11 = VAR10;
	}

	VAR6 = 0;
	if (VAR3) {
		VAR6 = -VAR13;
		if (!FUN3(VAR22, VAR3, sizeof(*VAR3)))
			goto VAR15;
		VAR6 = FUN6(VAR5.VAR7, &VAR3->VAR7) |
			FUN6(VAR5.VAR10, &VAR3->VAR10) |
			FUN6(VAR5.VAR12, &VAR3->VAR12);
	}

VAR15:
	return VAR6;
}