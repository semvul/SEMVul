static int FUN1(struct VAR1 *VAR2, 			       struct VAR3 *VAR4, 			       struct VAR5 *VAR6)  
{
	struct VAR7 *VAR8 = FUN2(VAR6->VAR9);

	if (FUN3(VAR6->VAR9, sizeof(*VAR8))) {
		struct inet_diag_entry VAR10;
		const struct VAR11 *VAR12 = FUN4(VAR6->VAR9,
							  sizeof(*VAR8),
							  VAR13);

		VAR10.VAR14 = VAR2->VAR15;
#if FUN5(VAR16) || FUN5 (VAR17)
		if (VAR2->VAR15 == VAR18) {
			struct VAR19 *VAR20 =
						FUN6((struct VAR21 *)VAR2);
			VAR10.VAR22 = VAR20->VAR23.VAR24;
			VAR10.VAR25 = VAR20->VAR26.VAR24;
		} else
#endif
		{
			VAR10.VAR22 = &VAR2->VAR27;
			VAR10.VAR25 = &VAR2->VAR28;
		}
		VAR10.VAR29 = VAR2->VAR30;
		VAR10.VAR31 = FUN7(VAR2->VAR32);
		VAR10.VAR33 = 0;

		if (!FUN8(FUN9(VAR12), FUN10(VAR12), &VAR10))
			return 0;
	}

	return FUN11(VAR2, VAR4, VAR8->VAR34,
				   FUN12(VAR6->VAR4).VAR35,
				   VAR6->VAR9->VAR36, VAR37, VAR6->VAR9);
}