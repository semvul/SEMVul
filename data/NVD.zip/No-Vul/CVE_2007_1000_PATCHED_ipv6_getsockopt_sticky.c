static int FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4, 				  char VAR5 *VAR6, int VAR7)  
{
	struct VAR8 *VAR9;

	if (!VAR4 || !VAR4->VAR10)
		return 0;

	VAR9 = VAR4->VAR10;

	VAR7 = FUN2(int, VAR7, FUN3(VAR9));
	if (FUN4(VAR6, VAR9, VAR7))
		return -VAR11;
	return VAR7;
}