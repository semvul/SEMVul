int FUN1(int VAR1)  
{ 
	struct VAR2 *VAR3 = VAR4;
	static char VAR5[sizeof(VAR3->VAR6)];

	if (FUN2(VAR5, VAR3->VAR6, sizeof(VAR5))) {
	FUN3(VAR7 "", VAR1,
	VAR3->VAR6);
	strncpy(VAR5, VAR3->VAR6, sizeof(VAR5));
	} 
	return -VAR8;	       
}