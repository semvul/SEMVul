static struct VAR1 *FUN1(struct VAR2 *VAR3, struct VAR1 *VAR4)  
{
	struct VAR5 *VAR6 = VAR3->private;
	struct VAR7 *VAR7 = FUN2(VAR3);

	do {
		VAR4 = FUN3(VAR4);
	} while (VAR4 && (!FUN4(FUN5(VAR4), VAR7) || VAR4->VAR8 != VAR6->VAR9));

	if (!VAR4) {
		if (VAR6->VAR10 < VAR11)
			FUN6(&VAR6->VAR12->VAR13[VAR6->VAR10].VAR14);
		return FUN7(VAR3, VAR6->VAR10 + 1);
	}
	return VAR4;
}