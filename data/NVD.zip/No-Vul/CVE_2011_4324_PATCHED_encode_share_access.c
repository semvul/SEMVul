static void FUN1(struct VAR1 *VAR2, fmode_t VAR3)  
{
	VAR4 *VAR5;

	FUN2(8);
	switch (VAR3 & (VAR6|VAR7)) {
		case VAR6:
			FUN3(VAR8);
			break;
		case VAR7:
			FUN3(VAR9);
			break;
		case VAR6|VAR7:
			FUN3(VAR10);
			break;
		default:
			FUN3(0);
	}
	FUN3(0);		
}