void FUN1()
{
    int * VAR1;
    VAR1 = NULL;
    if(VAR2==5)
    {
        
        VAR1 = (int *)malloc(50*sizeof(int));
    }
    {
        int VAR3[100] = {0}; 
        {
            size_t VAR4;
            
            for (VAR4 = 0; VAR4 < 100; VAR4++)
            {
                VAR1[VAR4] = VAR3[VAR4];
            }
            FUN2(VAR1[0]);
            free(VAR1);
        }
    }
}