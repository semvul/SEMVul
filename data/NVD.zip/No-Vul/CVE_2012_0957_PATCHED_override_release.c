static int FUN1(char VAR1 *VAR2, size_t VAR3)  
{
	int VAR4 = 0;

	if (VAR5->VAR6 & VAR7) {
		const char *VAR8 = VAR9;
		char VAR10[65] = { 0 };
		int VAR11 = 0;
		unsigned VAR12;
		size_t copy;

		while (*VAR8) {
			if (*VAR8 == '' && ++VAR11 >= 3)
				break;
			if (!FUN2(*VAR8) && *VAR8 != '')
				break;
			VAR8++;
		}
		VAR12 = ((VAR13 >> 8) & 0xff) + 40;
		copy = FUN3(sizeof(VAR10), FUN4(VAR14, 1, VAR3));
		copy = FUN5(VAR10, copy, "", VAR12, VAR8);
		VAR4 = FUN6(VAR2, VAR10, copy + 1);
	}
	return VAR4;
}