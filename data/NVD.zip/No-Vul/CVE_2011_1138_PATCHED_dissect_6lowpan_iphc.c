static VAR1 * FUN1(VAR1 *VAR2, VAR3 *VAR4, VAR5 *VAR6, gint VAR7)  
{
    gint                VAR8 = 0;
    gint                VAR9;
    VAR5 *        VAR10 = NULL;
    VAR11 *        VAR12 = NULL;
    VAR11 *        VAR13 = NULL;
    VAR11 *        VAR14 = NULL;
    gboolean            VAR15;
    
    guint16             VAR16;
    guint8              VAR17;
    guint8              VAR18;
    guint8              VAR19;
    guint8              VAR20;
    guint8              VAR21 = 0;
    
    guint8              VAR22 = 0;
    struct ip6_hdr      VAR23;
    VAR1 *          VAR24;
    
    struct VAR25 *VAR26;

    
    if (VAR6) {
        VAR12 = FUN2(VAR6, VAR2, 0, sizeof(VAR27), "");
        VAR10 = FUN3(VAR12, VAR28);

        
        FUN4(VAR10, VAR29, VAR2, 0, VAR30, VAR31);
    }

    
    VAR16      = FUN5(VAR2, VAR8);
    VAR17    = (VAR16 & VAR32) >> VAR33;
    VAR18  = (VAR16 & VAR34) >> VAR35;
    VAR19   = (VAR16 & VAR36) >> VAR37;
    VAR20   = (VAR16 & VAR38) >> VAR39;
    if (VAR6) {
        const VAR40 *VAR41;
        FUN6         (VAR10, VAR42,    VAR2, VAR8, sizeof(VAR27), VAR16 & VAR32);
        FUN7      (VAR10, VAR43,  VAR2, VAR8, sizeof(VAR27), VAR16 & VAR44);
        FUN6         (VAR10, VAR45,  VAR2, VAR8, sizeof(VAR27), VAR16 & VAR34);
        FUN7      (VAR10, VAR46,   VAR2, VAR8, sizeof(VAR27), VAR16 & VAR47);
        FUN7      (VAR10, VAR48,   VAR2, VAR8, sizeof(VAR27), VAR16 & VAR49);
        VAR13 = FUN6(VAR10, VAR50,   VAR2, VAR8, sizeof(VAR27), VAR16 & VAR36);
        FUN7      (VAR10, VAR51, VAR2, VAR8, sizeof(VAR27), VAR16 & VAR52);
        FUN7      (VAR10, VAR53,   VAR2, VAR8, sizeof(VAR27), VAR16 & VAR54);
        
        VAR41 = (VAR16 & VAR52) ? (VAR55) : (VAR56);
        VAR14 = FUN8(VAR10, VAR57, VAR2, VAR8, sizeof(VAR27),
            VAR16 & VAR38, "", FUN9(VAR20, VAR41, ""), VAR20);
    }
    VAR8 += sizeof(VAR27);

    
    if (VAR16 & VAR47) {
        VAR21 = FUN10(VAR2, VAR8);
        if (VAR6) {
            FUN6(VAR10, VAR58, VAR2, VAR8, sizeof(VAR59), VAR21 & VAR60);
            FUN6(VAR10, VAR61, VAR2, VAR8, sizeof(VAR59), VAR21 & VAR62);
        }
        VAR8 +=  sizeof(VAR59);
    }

    
    VAR8 <<= 3;
    
    if (VAR17 != VAR63) {
        VAR22 |= FUN11(VAR2, VAR8, VAR64);
        VAR8 += VAR64;
    }
    
    if ((VAR17 == VAR65) || (VAR17 == VAR66)) {
        VAR22 |= (FUN11(VAR2, VAR8, VAR67) << VAR64);
        VAR8 += VAR67;
    }
    
    if ((VAR6) && (VAR17 != VAR63)) {
        
        VAR5 *    VAR68;
        VAR12 = FUN6(VAR6, VAR69, VAR2, VAR8>>3, sizeof(VAR59), VAR22);
        VAR68 = FUN3(VAR12, VAR70);

        
        FUN6(VAR68, VAR71, VAR2, VAR8>>3, sizeof(VAR59), VAR22 & VAR72);
        FUN6(VAR68, VAR73, VAR2, VAR8>>3, sizeof(VAR59), VAR22 & VAR74);
    }

    
    if ((VAR17 == VAR65) || (VAR17 == VAR75)) {
        
        VAR8 += ((4 - VAR8) & 0x7);
        VAR23.VAR76 = FUN12(VAR2, VAR8, VAR77, VAR31);
        if (VAR6) {
            FUN4(VAR6, VAR78, VAR2, VAR8, VAR77, VAR31);
        }
        VAR8 += VAR77;
    }
    else VAR23.VAR76 = 0;

    
    VAR23.VAR76 = FUN13(VAR23.VAR76) | (VAR22 << VAR79);
    VAR23.VAR80 = (0x6 << 4) | (VAR22 >> 4);

    
    VAR8 >>= 3;

    
    
    if (!(VAR16 & VAR44)) {
        VAR23.VAR81 = FUN10(VAR2, VAR8);
        if (VAR6) {
            FUN14(VAR6, VAR82, VAR2, VAR8, sizeof(VAR59), VAR23.VAR81,
                    "", FUN15(VAR23.VAR81), VAR23.VAR81);
        }
        VAR8 += sizeof(VAR59);
    }

    
    if (VAR18 == VAR83) {
        VAR23.VAR84 = 1;
    }
    else if (VAR18 == VAR85) {
        VAR23.VAR84 = 64;
    }
    else if (VAR18 == VAR86) {
        VAR23.VAR84 = 255;
    }
    else {
        VAR23.VAR84 = FUN10(VAR2, VAR8);
        if (VAR6) {
            FUN6(VAR6, VAR87, VAR2, VAR8, sizeof(VAR59), VAR23.VAR84);
        }
        VAR8 += sizeof(VAR59);
    }

    
    VAR15 = VAR31;
    VAR9 = 0;
    memset(&VAR23.VAR88, 0, sizeof(VAR23.VAR88));
    
    if (!(VAR16 & VAR49)) {
        
        VAR23.VAR88.VAR89[0] = 0xfe;
        VAR23.VAR88.VAR89[1] = 0x80;
        
        if (VAR19 == VAR90) {
            VAR9 = sizeof(VAR23.VAR88);
            FUN16(VAR2, &VAR23.VAR88.VAR89[sizeof(VAR23.VAR88) - VAR9], VAR8, VAR9);
        }
        
        else if (VAR19 == VAR91) {
            VAR9 = sizeof(VAR92);
            FUN16(VAR2, &VAR23.VAR88.VAR89[sizeof(VAR23.VAR88) - VAR9], VAR8, VAR9);
        }
        else if (VAR19 == VAR93) {
            VAR9 = sizeof(VAR27);
            FUN16(VAR2, &VAR23.VAR88.VAR89[sizeof(VAR23.VAR88) - VAR9], VAR8, VAR9);
        }
        
        else {
            FUN17(VAR4, &VAR23.VAR88.VAR89[8]);
        }
    }
    
    else {
        
        VAR15 = VAR94;
        
        if (VAR19 == VAR95) {
        	VAR9 = 0;
        	VAR15 = VAR31;
        }
        else if (VAR19 == VAR91) VAR9 = sizeof(VAR92);
        else if (VAR19 == VAR93) VAR9 = sizeof(VAR27);
        else if (VAR19 == VAR96) VAR9 = 0;
        else {
            
            FUN18(VAR4, VAR13, VAR97, VAR98, "");
            return NULL;
        }
    }

    
    if (VAR6) {
        VAR12 = FUN19(VAR6, VAR99, VAR2, VAR8, VAR9, (VAR59 *)&VAR23.VAR88);
    }
    if (VAR15) {
        FUN18(VAR4, VAR12, VAR100, VAR101, "");
    }
    VAR8 += VAR9;
    

    
    VAR15 = VAR31;
    VAR9 = 0;
    memset(&VAR23.VAR102, 0, sizeof(VAR23.VAR102));
    
    if (!(VAR16 & VAR54) && !(VAR16 & VAR52)) {
        
        VAR23.VAR102.VAR89[0] = 0xfe;
        VAR23.VAR102.VAR89[1] = 0x80;
        
        if (VAR20 == VAR90) {
            VAR9 = sizeof(VAR23.VAR102);
            FUN16(VAR2, &VAR23.VAR102.VAR89[sizeof(VAR23.VAR102) - VAR9], VAR8, VAR9);
        }
        
        else if (VAR20 == VAR91) {
            VAR9 = sizeof(VAR92);
            FUN16(VAR2, &VAR23.VAR102.VAR89[sizeof(VAR23.VAR102) - VAR9], VAR8, VAR9);
        }
        else if (VAR20 == VAR93) {
            VAR9 = sizeof(VAR27);
            FUN16(VAR2, &VAR23.VAR102.VAR89[sizeof(VAR23.VAR102) - VAR9], VAR8, VAR9);
        }
        
        else {
            FUN20(VAR4, &VAR23.VAR102.VAR89[8]);
        }
    }
    
    else if (!(VAR16 & VAR54) && (VAR16 & VAR52)) {
    	if (VAR20 == VAR90) {
    		VAR9 = sizeof(VAR23.VAR102);
    		FUN16(VAR2, &VAR23.VAR102.VAR89[sizeof(VAR23.VAR102) - VAR9], VAR8, VAR9);
    	}
    	else if (VAR20 == VAR103) {
            VAR23.VAR102.VAR89[0] = 0xff;
            VAR23.VAR102.VAR89[1] = FUN10(VAR2, VAR8 + (VAR9++));
            VAR23.VAR102.VAR89[11] = FUN10(VAR2, VAR8 + (VAR9++));
            VAR23.VAR102.VAR89[12] = FUN10(VAR2, VAR8 + (VAR9++));
            VAR23.VAR102.VAR89[13] = FUN10(VAR2, VAR8 + (VAR9++));
            VAR23.VAR102.VAR89[14] = FUN10(VAR2, VAR8 + (VAR9++));
            VAR23.VAR102.VAR89[15] = FUN10(VAR2, VAR8 + (VAR9++));
        }
        else if (VAR20 == VAR104) {
            VAR23.VAR102.VAR89[0] = 0xff;
            VAR23.VAR102.VAR89[1] = FUN10(VAR2, VAR8 + (VAR9++));
            VAR23.VAR102.VAR89[13] = FUN10(VAR2, VAR8 + (VAR9++));
            VAR23.VAR102.VAR89[14] = FUN10(VAR2, VAR8 + (VAR9++));
            VAR23.VAR102.VAR89[15] = FUN10(VAR2, VAR8 + (VAR9++));
        }
        else if (VAR20 == VAR105) {
            VAR23.VAR102.VAR89[0] = 0xff;
            VAR23.VAR102.VAR89[1] = 0x02;
            VAR23.VAR102.VAR89[15] = FUN10(VAR2, VAR8 + (VAR9++));
        }
        else {
            
            FUN18(VAR4, VAR14, VAR97, VAR98, "");
            return NULL;
        }
    }
    
    else if ((VAR16 & VAR54) && !(VAR16 & VAR52)) {
        
        VAR15 = VAR94;
        if (VAR20 == VAR91) VAR9 = sizeof(VAR92);
        else if (VAR20 == VAR93) VAR9 = sizeof(VAR27);
        else if (VAR20 == VAR96) VAR9 = 0;
        else {
            
            FUN18(VAR4, VAR14, VAR97, VAR98, "");
            return NULL;
        }
    }
    
    else {
        if (VAR20 == VAR106) {
            VAR23.VAR102.VAR89[0] = 0xff;
            VAR23.VAR102.VAR89[1] = FUN10(VAR2, VAR8 + (VAR9++));
            VAR23.VAR102.VAR89[2] = FUN10(VAR2, VAR8 + (VAR9++));
            
            VAR15 = VAR94;
            VAR23.VAR102.VAR89[12] = FUN10(VAR2, VAR8 + (VAR9++));
            VAR23.VAR102.VAR89[13] = FUN10(VAR2, VAR8 + (VAR9++));
            VAR23.VAR102.VAR89[14] = FUN10(VAR2, VAR8 + (VAR9++));
            VAR23.VAR102.VAR89[15] = FUN10(VAR2, VAR8 + (VAR9++));
        }
        else {
            
            FUN18(VAR4, VAR14, VAR97, VAR98, "");
            return NULL;
        }

    }

    
    if (VAR6) {
        VAR12 = FUN19(VAR6, VAR107, VAR2, VAR8, VAR9, (VAR59 *)&VAR23.VAR102);
    }
    if (VAR15) {
        FUN18(VAR4, VAR12, VAR100, VAR101, "");
    }
    VAR8 += VAR9;
    

    
    
    if (VAR16 & VAR44) {
        
        VAR23.VAR81 = FUN21(VAR2, VAR8);

        
        VAR26 = FUN22(VAR2, VAR4, VAR6, VAR8, VAR7 - sizeof(struct VAR108));
    }
    
    else {
        VAR9 = (VAR109)FUN23(VAR2, VAR8);
        VAR26 = (struct VAR25 *)FUN24(sizeof(struct VAR25) + VAR9);
        VAR26->VAR110 = NULL;
        VAR26->VAR111 = VAR23.VAR81;
        VAR26->VAR9 = VAR9;
        if (VAR7 < 0) {
            VAR26->VAR112 = FUN25(VAR2, VAR8);
        }
        else {
            VAR26->VAR112 = VAR7 - sizeof(struct VAR108);
        }
        FUN16(VAR2, FUN26(VAR26), VAR8, VAR26->VAR9);
    }

    
    
    VAR24 = FUN27(VAR2, &VAR23, VAR26);
    FUN28(VAR4, VAR24, "");
    return VAR24;
}