int FUN1(struct ucontext VAR1 *VAR2, 			 int VAR3, struct sig_dbg_op VAR1 *VAR4, 			 int VAR5, int VAR6, int VAR7, 			 struct VAR8 *VAR9)  
{
	struct sig_dbg_op VAR10;
	int VAR11;
	unsigned char VAR12;
	unsigned long VAR13 = VAR9->VAR14;
#if FUN2(VAR15) || FUN2(VAR16)
	unsigned long VAR17 = VAR18->VAR19.VAR20;
#endif

	for (VAR11=0; VAR11<VAR3; VAR11++) {
		if (FUN3(&VAR10, VAR4 + VAR11, sizeof(VAR10)))
			return -VAR21;
		switch (VAR10.VAR22) {
		case VAR23:
#if FUN2(VAR15) || FUN2(VAR16)
			if (VAR10.VAR24) {
				VAR13 |= VAR25;
				VAR17 |= (VAR26 | VAR27);
			} else {
				VAR13 &= ~VAR25;
				VAR17 &= ~(VAR26 | VAR27);
			}
#else
			if (VAR10.VAR24)
				VAR13 |= VAR28;
			else
				VAR13 &= ~VAR28;
#endif
			break;
		case VAR29:
#if FUN2(VAR15) || FUN2(VAR16)
			return -VAR30;
#else
			if (VAR10.VAR24)
				VAR13 |= VAR31;
			else
				VAR13 &= ~VAR31;
#endif
			break;

		default:
			return -VAR30;
		}
	}

	
	VAR9->VAR14 = VAR13;
#if FUN2(VAR15) || FUN2(VAR16)
	VAR18->VAR19.VAR20 = VAR17;
#endif

	if (!FUN4(VAR32, VAR2, sizeof(*VAR2))
	    || FUN5(VAR12, (u8 VAR1 *) VAR2)
	    || FUN5(VAR12, (u8 VAR1 *) (VAR2 + 1) - 1))
		return -VAR21;

	
	if (FUN6(VAR2, VAR9, 1)) {
		FUN7(VAR33, VAR18);
		goto VAR34;
	}

	
	FUN8(&VAR2->VAR35, NULL, VAR9->VAR36[1]);

	FUN9(VAR37);
 VAR34:
	return 0;
}