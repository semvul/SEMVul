int FUN1(struct VAR1 *VAR1, unsigned long VAR2, 		       void VAR3 *VAR4, unsigned long VAR5, 		       int VAR6)  
{
	unsigned long VAR7;
	void *VAR8;

	VAR8 = FUN2(VAR1);
	if (VAR6) {
		FUN3(VAR9, VAR5);
		VAR7 = FUN4(VAR4, VAR8 + VAR2, VAR5);
	} else {
		FUN3(VAR10, VAR5);
		VAR7 = FUN5(VAR8 + VAR2, VAR4, VAR5);
	}
	FUN6(VAR1);

	return VAR7 ? -VAR11 : 0;
}