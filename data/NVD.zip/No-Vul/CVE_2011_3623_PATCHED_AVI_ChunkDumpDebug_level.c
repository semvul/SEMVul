static void FUN1( VAR1 *VAR2,                                       VAR3  *VAR4, unsigned VAR5 )  
{
    unsigned VAR6;
    VAR3 *VAR7;

    char VAR8[512];
    if( VAR5 * 5 + 1 >= sizeof(VAR8) )
        return;

    memset( VAR8, '', sizeof( VAR8 ) );
    for( VAR6 = 1; VAR6 < VAR5; VAR6++ )
    {
        VAR8[VAR6 * 5] = '';
    }
    if( VAR4->VAR9.VAR10 == VAR11 ||
        VAR4->VAR9.VAR10 == VAR12  ||
        VAR4->VAR9.VAR10 == VAR13 )
    {
        snprintf( &VAR8[VAR5 * 5], sizeof(VAR8) - 5*VAR5,
                 ""VAR14""VAR14,
                 VAR5 ? '' : '',
                 (char*)&VAR4->VAR9.VAR10,
                 (char*)&VAR4->VAR15.VAR16,
                 VAR4->VAR9.VAR17,
                 VAR4->VAR9.VAR18 );
    }
    else
    {
        snprintf( &VAR8[VAR5 * 5], sizeof(VAR8) - 5*VAR5,
                 ""VAR14""VAR14,
                 (char*)&VAR4->VAR9.VAR10,
                 VAR4->VAR9.VAR17,
                 VAR4->VAR9.VAR18 );
    }
    FUN2( VAR2, "", VAR8 );

    VAR7 = VAR4->VAR9.VAR19;
    while( VAR7 )
    {
        FUN1( VAR2, VAR7, VAR5 + 1 );
        VAR7 = VAR7->VAR9.VAR20;
    }
}