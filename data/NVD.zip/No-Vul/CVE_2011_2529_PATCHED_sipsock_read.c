static int FUN1(int *VAR1, int VAR2, short VAR3, void *VAR4)  
{
	struct sip_request VAR5;
	struct ast_sockaddr VAR6;
	int VAR7;
	static char VAR8[65535];

	memset(&VAR5, 0, sizeof(VAR5));
	VAR7 = FUN2(VAR2, VAR8, sizeof(VAR8) - 1, 0, &VAR6);
	if (VAR7 < 0) {
#if !FUN3(VAR9)
		if (VAR10 == VAR11)
			FUN4(VAR12, "");
		else
#endif
		if (VAR10 != VAR13)
			FUN4(VAR14, "", strerror(VAR10));
		return 1;
	}

	VAR8[VAR7] = '';

	if (!(VAR5.VAR15 = FUN5(VAR16))) {
		return 1;
	}

	if (FUN6(&VAR5.VAR15, 0, "", VAR8) == VAR17) {
		return -1;
	}

	
	VAR5.VAR18 = FUN7(VAR5.VAR15);
	VAR5.socket.VAR2 = VAR19;
	FUN8(&VAR5.socket, VAR20);
	VAR5.socket.VAR21	= NULL;
	VAR5.socket.VAR22 = FUN9(FUN10(&VAR23));

	FUN11(&VAR5, &VAR6);
	FUN12(&VAR5);

	return 1;
}