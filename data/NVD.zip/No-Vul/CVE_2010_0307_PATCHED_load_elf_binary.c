static int FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4)  
{
	struct VAR5 *VAR6 = NULL; 
 	unsigned long VAR7 = 0, VAR8 = 0;
	int VAR9 = 0;
	char * VAR10 = NULL;
	unsigned long VAR11;
	struct VAR12 *VAR13, *VAR14;
	unsigned long VAR15, VAR16;
	int VAR17, VAR18;
	unsigned int VAR19;
	unsigned long VAR20;
	unsigned long VAR21 = 0;
	unsigned long VAR22, VAR23, VAR24, VAR25;
	unsigned long VAR26 = 0;
	int VAR27 = VAR28;
	unsigned long VAR29 = 0;
	struct {
		struct elfhdr VAR30;
		struct elfhdr VAR31;
	} *VAR32;

	VAR32 = FUN2(sizeof(*VAR32), VAR33);
	if (!VAR32) {
		VAR17 = -VAR34;
		goto VAR35;
	}
	
	
	VAR32->VAR30 = *((struct VAR36 *)VAR2->VAR37);

	VAR17 = -VAR38;
	
	if (memcmp(VAR32->VAR30.VAR39, VAR40, VAR41) != 0)
		goto VAR42;

	if (VAR32->VAR30.VAR43 != VAR44 && VAR32->VAR30.VAR43 != VAR45)
		goto VAR42;
	if (!FUN3(&VAR32->VAR30))
		goto VAR42;
	if (!VAR2->VAR5->VAR46||!VAR2->VAR5->VAR46->VAR47)
		goto VAR42;

	
	if (VAR32->VAR30.VAR48 != sizeof(struct VAR12))
		goto VAR42;
	if (VAR32->VAR30.VAR49 < 1 ||
	 	VAR32->VAR30.VAR49 > 65536U / sizeof(struct VAR12))
		goto VAR42;
	VAR19 = VAR32->VAR30.VAR49 * sizeof(struct VAR12);
	VAR17 = -VAR34;
	VAR14 = FUN2(VAR19, VAR33);
	if (!VAR14)
		goto VAR42;

	VAR17 = FUN4(VAR2->VAR5, VAR32->VAR30.VAR50,
			     (char *)VAR14, VAR19);
	if (VAR17 != VAR19) {
		if (VAR17 >= 0)
			VAR17 = -VAR51;
		goto VAR52;
	}

	VAR13 = VAR14;
	VAR15 = 0;
	VAR16 = 0;

	VAR22 = ~0UL;
	VAR23 = 0;
	VAR24 = 0;
	VAR25 = 0;

	for (VAR18 = 0; VAR18 < VAR32->VAR30.VAR49; VAR18++) {
		if (VAR13->VAR53 == VAR54) {
			
			VAR17 = -VAR38;
			if (VAR13->VAR55 > VAR56 || 
			    VAR13->VAR55 < 2)
				goto VAR52;

			VAR17 = -VAR34;
			VAR10 = FUN2(VAR13->VAR55,
						  VAR33);
			if (!VAR10)
				goto VAR52;

			VAR17 = FUN4(VAR2->VAR5, VAR13->VAR57,
					     VAR10,
					     VAR13->VAR55);
			if (VAR17 != VAR13->VAR55) {
				if (VAR17 >= 0)
					VAR17 = -VAR51;
				goto VAR58;
			}
			
			VAR17 = -VAR38;
			if (VAR10[VAR13->VAR55 - 1] != '')
				goto VAR58;

			VAR6 = FUN5(VAR10);
			VAR17 = FUN6(VAR6);
			if (FUN7(VAR6))
				goto VAR58;

			
			if (FUN8(VAR6, VAR59) < 0)
				VAR2->VAR60 |= VAR61;

			VAR17 = FUN4(VAR6, 0, VAR2->VAR37,
					     VAR62);
			if (VAR17 != VAR62) {
				if (VAR17 >= 0)
					VAR17 = -VAR51;
				goto VAR63;
			}

			
			VAR32->VAR31 = *((struct VAR36 *)VAR2->VAR37);
			break;
		}
		VAR13++;
	}

	VAR13 = VAR14;
	for (VAR18 = 0; VAR18 < VAR32->VAR30.VAR49; VAR18++, VAR13++)
		if (VAR13->VAR53 == VAR64) {
			if (VAR13->VAR65 & VAR66)
				VAR27 = VAR67;
			else
				VAR27 = VAR68;
			break;
		}

	
	if (VAR10) {
		VAR17 = -VAR69;
		
		if (memcmp(VAR32->VAR31.VAR39, VAR40, VAR41) != 0)
			goto VAR63;
		
		if (!FUN3(&VAR32->VAR31))
			goto VAR63;
	}

	
	VAR17 = FUN9(VAR2);
	if (VAR17)
		goto VAR63;

	
	VAR70->VAR71 &= ~VAR72;
	VAR70->VAR73->VAR29 = VAR29;

	
	FUN10(VAR32->VAR30);
	if (FUN11(VAR32->VAR30, VAR27))
		VAR70->VAR74 |= VAR75;

	if (!(VAR70->VAR74 & VAR76) && VAR77)
		VAR70->VAR71 |= VAR78;

	FUN12(VAR2);

	
	VAR70->VAR73->VAR79 = VAR70->VAR73->VAR80;
	VAR70->VAR73->VAR81 = 0;
	VAR17 = FUN13(VAR2, FUN14(VAR82),
				 VAR27);
	if (VAR17 < 0) {
		FUN15(VAR83, VAR70, 0);
		goto VAR63;
	}
	
	VAR70->VAR73->VAR84 = VAR2->VAR85;

	
	for(VAR18 = 0, VAR13 = VAR14;
	    VAR18 < VAR32->VAR30.VAR49; VAR18++, VAR13++) {
		int VAR86 = 0, VAR87;
		unsigned long VAR88, VAR89;

		if (VAR13->VAR53 != VAR90)
			continue;

		if (FUN16 (VAR16 > VAR15)) {
			unsigned long VAR91;
	            
			
			VAR17 = FUN17 (VAR15 + VAR8,
					  VAR16 + VAR8);
			if (VAR17) {
				FUN15(VAR83, VAR70, 0);
				goto VAR63;
			}
			VAR91 = FUN18(VAR15);
			if (VAR91) {
				VAR91 = VAR92 - VAR91;
				if (VAR91 > VAR16 - VAR15)
					VAR91 = VAR16 - VAR15;
				if (FUN19((void VAR93 *)VAR15 +
							VAR8, VAR91)) {
					
				}
			}
		}

		if (VAR13->VAR65 & VAR94)
			VAR86 |= VAR95;
		if (VAR13->VAR65 & VAR96)
			VAR86 |= VAR97;
		if (VAR13->VAR65 & VAR66)
			VAR86 |= VAR98;

		VAR87 = VAR99 | VAR100 | VAR101;

		VAR89 = VAR13->VAR102;
		if (VAR32->VAR30.VAR43 == VAR44 || VAR9) {
			VAR87 |= VAR103;
		} else if (VAR32->VAR30.VAR43 == VAR45) {
			
#ifdef VAR104
			VAR8 = 0;
#else
			VAR8 = FUN20(VAR105 - VAR89);
#endif
		}

		VAR11 = FUN21(VAR2->VAR5, VAR8 + VAR89, VAR13,
				VAR86, VAR87, 0);
		if (FUN22(VAR11)) {
			FUN15(VAR83, VAR70, 0);
			VAR17 = FUN7((void *)VAR11) ?
				FUN6((void*)VAR11) : -VAR106;
			goto VAR63;
		}

		if (!VAR9) {
			VAR9 = 1;
			VAR7 = (VAR13->VAR102 - VAR13->VAR57);
			if (VAR32->VAR30.VAR43 == VAR45) {
				VAR8 += VAR11 -
				             FUN20(VAR8 + VAR89);
				VAR7 += VAR8;
				VAR26 = VAR8;
			}
		}
		VAR88 = VAR13->VAR102;
		if (VAR88 < VAR22)
			VAR22 = VAR88;
		if (VAR24 < VAR88)
			VAR24 = VAR88;

		
		if (FUN22(VAR88) || VAR13->VAR55 > VAR13->VAR107 ||
		    VAR13->VAR107 > VAR108 ||
		    VAR108 - VAR13->VAR107 < VAR88) {
			
			FUN15(VAR83, VAR70, 0);
			VAR17 = -VAR106;
			goto VAR63;
		}

		VAR88 = VAR13->VAR102 + VAR13->VAR55;

		if (VAR88 > VAR15)
			VAR15 = VAR88;
		if ((VAR13->VAR65 & VAR66) && VAR23 < VAR88)
			VAR23 = VAR88;
		if (VAR25 < VAR88)
			VAR25 = VAR88;
		VAR88 = VAR13->VAR102 + VAR13->VAR107;
		if (VAR88 > VAR16)
			VAR16 = VAR88;
	}

	VAR32->VAR30.VAR109 += VAR8;
	VAR15 += VAR8;
	VAR16 += VAR8;
	VAR22 += VAR8;
	VAR23 += VAR8;
	VAR24 += VAR8;
	VAR25 += VAR8;

	
	VAR17 = FUN17(VAR15, VAR16);
	if (VAR17) {
		FUN15(VAR83, VAR70, 0);
		goto VAR63;
	}
	if (FUN23(VAR15 != VAR16) && FUN16(FUN24(VAR15))) {
		FUN15(VAR110, VAR70, 0);
		VAR17 = -VAR111; 
		goto VAR63;
	}

	if (VAR10) {
		unsigned long FUN25(VAR112);

		VAR20 = FUN26(&VAR32->VAR31,
					    VAR6,
					    &VAR112,
					    VAR8);
		if (!FUN7((void *)VAR20)) {
			
			VAR21 = VAR20;
			VAR20 += VAR32->VAR31.VAR109;
		}
		if (FUN22(VAR20)) {
			FUN27(VAR110, VAR70);
			VAR17 = FUN7((void *)VAR20) ?
					(int)VAR20 : -VAR106;
			goto VAR63;
		}
		VAR26 = VAR21;

		FUN28(VAR6);
		FUN29(VAR6);
		FUN30(VAR10);
	} else {
		VAR20 = VAR32->VAR30.VAR109;
		if (FUN22(VAR20)) {
			FUN27(VAR110, VAR70);
			VAR17 = -VAR106;
			goto VAR63;
		}
	}

	FUN30(VAR14);

	FUN31(&VAR113);

#ifdef VAR114
	VAR17 = FUN32(VAR2, !!VAR10);
	if (VAR17 < 0) {
		FUN15(VAR83, VAR70, 0);
		goto VAR42;
	}
#endif 

	FUN33(VAR2);
	VAR70->VAR71 &= ~VAR72;
	VAR17 = FUN34(VAR2, &VAR32->VAR30,
			  VAR7, VAR21);
	if (VAR17 < 0) {
		FUN15(VAR83, VAR70, 0);
		goto VAR42;
	}
	
	VAR70->VAR73->VAR23 = VAR23;
	VAR70->VAR73->VAR22 = VAR22;
	VAR70->VAR73->VAR24 = VAR24;
	VAR70->VAR73->VAR25 = VAR25;
	VAR70->VAR73->VAR84 = VAR2->VAR85;

#ifdef VAR115
	if ((VAR70->VAR71 & VAR78) && (VAR77 > 1))
		VAR70->VAR73->VAR116 = VAR70->VAR73->VAR117 =
			FUN35(VAR70->VAR73);
#endif

	if (VAR70->VAR74 & VAR118) {
		
		FUN36(&VAR70->VAR73->VAR119);
		VAR11 = FUN37(NULL, 0, VAR120, VAR95 | VAR98,
				VAR103 | VAR99, 0);
		FUN38(&VAR70->VAR73->VAR119);
	}

#ifdef VAR121
	
	FUN39(VAR4, VAR26);
#endif

	FUN40(VAR4, VAR20, VAR2->VAR85);
	VAR17 = 0;
VAR42:
	FUN30(VAR32);
VAR35:
	return VAR17;

	
VAR63:
	FUN28(VAR6);
	if (VAR6)
		FUN29(VAR6);
VAR58:
	FUN30(VAR10);
VAR52:
	FUN30(VAR14);
	goto VAR42;
}