bool VAR1::FUN1(VAR2 *VAR3)  
{
    
    if (VAR4) {
        return true;
    }

    VAR5<VAR6> VAR7 = FUN2(VAR3);
    if (!VAR7) {
        return true;
    }

    nsCAutoString VAR8;
    VAR7->FUN3(FUN4(""),
                                   VAR8);
    VAR9 FUN5(VAR8);

    
    if (VAR10.FUN6())
        return true;

    
    
    VAR11 FUN7(VAR10, '');
    while (VAR12.FUN8()) {
        const VAR13& VAR14 = VAR12.FUN9();
        if (!FUN10(VAR3, VAR14)) {
            
            VAR7->FUN11(VAR15);
            if (VAR16) {
                VAR5<VAR17> FUN12(FUN13(VAR16));
                if (VAR18) {
                    VAR18->FUN14(FUN15("").FUN16(),
                                    0, VAR19, VAR19, VAR19);
                }
            }
            return false;
        }
    }

    return true;
}