static int FUN1(VAR1 *VAR2, int VAR3, int *VAR4, const VAR1 **VAR5, int *VAR6)  
{
	int VAR7 = 0;

	if (FUN2(VAR2, VAR3, VAR4, &VAR7) != 0)
		return -1;

	if (VAR7 > 0) {
		
		if ((*VAR4 + VAR7) > VAR3)
			return -1;

		*VAR6 = VAR7;
		*VAR5 = &VAR2[*VAR4];
		*VAR4 += VAR7;
	}

	return 0;
}