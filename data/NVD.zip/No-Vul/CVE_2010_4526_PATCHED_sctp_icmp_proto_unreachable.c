void FUN1(struct VAR1 *VAR2, 			   struct VAR3 *VAR4, 			   struct VAR5 *VAR6)  
{
	FUN2("",  VAR7);

	if (FUN3(VAR2)) {
		if (FUN4(&VAR6->VAR8))
			return;
		else {
			if (!FUN5(&VAR6->VAR8,
						VAR9 + (VAR10/20)))
				FUN6(VAR4);
		}
			
	} else {
		if (FUN4(&VAR6->VAR8) &&
		    FUN7(&VAR6->VAR8))
			FUN8(VAR4);

		FUN9(VAR11,
			   FUN10(VAR12),
			   VAR4->VAR13, VAR4->VAR14, VAR4, VAR6,
			   VAR15);
	}
}