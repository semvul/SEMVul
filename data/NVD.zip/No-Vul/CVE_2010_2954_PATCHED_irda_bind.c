static int FUN1(struct socket *VAR1, struct VAR2 *VAR3, int VAR4)  
{
	struct VAR1 *VAR5 = VAR1->VAR5;
	struct VAR6 *VAR7 = (struct VAR6 *) VAR3;
	struct VAR8 *VAR9 = FUN2(VAR5);
	int VAR10;

	FUN3(2, "", VAR11, VAR9);

	if (VAR4 != sizeof(struct VAR6))
		return -VAR12;

	FUN4();
#ifdef VAR13
	
	if ((VAR5->VAR14 == VAR15) &&
	    (VAR5->VAR16 == VAR17)) {
		VAR9->VAR18 = VAR7->VAR19;
		VAR10 = -VAR20;
		if (VAR9->VAR18 & 0x80) {
			FUN3(0, "", VAR11);
			goto VAR21;
		}
		VAR10 = FUN5(VAR9, VAR9->VAR18);
		if (VAR10 < 0)
			goto VAR21;

		
		VAR1->VAR22 = VAR23;
		VAR5->VAR24   = VAR25;
		VAR10 = 0;

		goto VAR21;
	}
#endif 

	VAR9->VAR26 = FUN6(VAR7->VAR27, VAR28);
	VAR10 = -VAR29;
	if (VAR9->VAR26 == NULL)
		goto VAR21;

	VAR10 = FUN7(VAR9, VAR7->VAR19, VAR7->VAR27);
	if (VAR10 < 0) {
		FUN8(VAR9->VAR26);
		VAR9->VAR26 = NULL;
		goto VAR21;
	}

	
	FUN9(VAR9->VAR26, "",
				 VAR9->VAR30, VAR31);
	FUN10(VAR9->VAR26);

	VAR10 = 0;
VAR21:
	FUN11();
	return VAR10;
}