int FUN1(struct VAR1 *VAR1, struct VAR2 *VAR2)  
{
	if (VAR2->VAR3 != NULL) {
		FUN2(VAR2->VAR3);
		VAR2->VAR3 = NULL;
	}

	
	return 0;
}