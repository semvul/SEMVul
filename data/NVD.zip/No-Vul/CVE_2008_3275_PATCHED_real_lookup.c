static struct VAR1 * FUN1(struct VAR1 * VAR2, struct VAR3 * VAR4, struct VAR5 *VAR6)  
{
	struct VAR1 * VAR7;
	struct VAR8 *VAR9 = VAR2->VAR10;

	FUN2(&VAR9->VAR11);
	
	VAR7 = FUN3(VAR2, VAR4);
	if (!VAR7) {
		struct VAR1 *VAR1;

		
		VAR7 = FUN4(-VAR12);
		if (FUN5(VAR9))
			goto VAR13;

		VAR1 = FUN6(VAR2, VAR4);
		VAR7 = FUN4(-VAR14);
		if (VAR1) {
			VAR7 = VAR9->VAR15->FUN7(VAR9, VAR1, VAR6);
			if (VAR7)
				FUN8(VAR1);
			else
				VAR7 = VAR1;
		}
VAR13:
		FUN9(&VAR9->VAR11);
		return VAR7;
	}

	
	FUN9(&VAR9->VAR11);
	if (VAR7->VAR16 && VAR7->VAR16->VAR17) {
		VAR7 = FUN10(VAR7, VAR6);
		if (!VAR7)
			VAR7 = FUN4(-VAR12);
	}
	return VAR7;
}