static int FUN1(struct VAR1 *VAR1, struct VAR2 *VAR3)  
{
	int VAR4 = -VAR5;

	FUN2(&VAR1->VAR6);

	if (VAR1->VAR7) {
		VAR4 = 0;
		if (VAR3->VAR8 & VAR9)
			VAR1->VAR7->VAR10++;
		if (VAR3->VAR8 & VAR11)
			VAR1->VAR7->VAR12++;
	}

	FUN3(&VAR1->VAR6);

	return VAR4;
}