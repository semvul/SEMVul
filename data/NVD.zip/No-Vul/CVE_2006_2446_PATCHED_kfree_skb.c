static inline void FUN1(struct VAR1 *VAR2)  
{
	if (FUN2(FUN3(&VAR2->VAR3) == 1))
		FUN4();
	else if (FUN2(!FUN5(&VAR2->VAR3)))
		return;
	FUN6(VAR2);
}