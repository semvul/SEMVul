static const VAR1 * FUN1(VAR2  *VAR3, VAR4  *VAR5, VAR6 *pinfo VAR7)  
{
    VAR2 *VAR8;
    int         VAR9 = 0;
    VAR10 *VAR11;
    guint8      VAR12, VAR13;
    guint32     VAR14;

    while (FUN2(VAR5,VAR9)>0){
        VAR12 = FUN3(VAR5,VAR9);
        VAR13 = FUN3(VAR5,VAR9+1);
        
        VAR14 = FUN4(VAR5,VAR9+2);
        VAR11 = FUN5(VAR3, VAR5, VAR9, VAR13, "",
                                   FUN6(VAR12, VAR15, ""), VAR14);
        VAR8 = FUN7(VAR11, VAR16);

        FUN8(VAR8, VAR17, VAR5, VAR9, 1, VAR18);
        VAR9++;
        VAR11 = FUN8(VAR8, VAR19, VAR5, VAR9, 1, VAR18);
        if (VAR13 < 2) {
            FUN9(VAR20, VAR11, VAR21, VAR22, "");
            VAR13 = 2;
        }
        VAR9++;
        FUN8(VAR8, VAR23, VAR5, VAR9, 2, VAR18);

        VAR9 = VAR9+VAR13-2;
    }

    return "";
}