unsigned long FUN1(struct VAR1 *VAR1, 			    unsigned long VAR2, 			    unsigned long VAR3, 			    unsigned long VAR4, 			    unsigned long VAR5, 			    unsigned long VAR6)  
{
	struct VAR7 *VAR8;
	struct VAR9 *VAR10;
	struct VAR11 *VAR12;
	unsigned long VAR13, VAR14, VAR15;
	int VAR16;

	FUN2("", VAR2, VAR3, VAR4, VAR5, VAR6);

	if (!(VAR5 & VAR17))
		VAR2 = FUN3(VAR2);

	
	VAR16 = FUN4(VAR1, VAR2, VAR3, VAR4, VAR5, VAR6,
				    &VAR13);
	if (VAR16 < 0) {
		FUN5("", VAR16);
		return VAR16;
	}

	
	VAR14 = FUN6(VAR1, VAR4, VAR5, VAR13);

	
	VAR10 = FUN7(VAR18, VAR19);
	if (!VAR10)
		goto VAR20;

	VAR8 = FUN7(VAR21, VAR19);
	if (!VAR8)
		goto VAR22;

	FUN8(&VAR10->VAR23, 1);
	VAR10->VAR14 = VAR14;
	VAR10->VAR24 = VAR6;

	FUN9(&VAR8->VAR25);
	VAR8->VAR14 = VAR14;
	VAR8->VAR24 = VAR6;

	if (VAR1) {
		VAR10->VAR26 = VAR1;
		FUN10(VAR1);
		VAR8->VAR26 = VAR1;
		FUN10(VAR1);
		if (VAR14 & VAR27) {
			FUN11(VAR28->VAR29);
			VAR8->VAR30 = VAR28->VAR29;
		}
	}

	FUN12(&VAR31);

	
	if (VAR14 & VAR32) {
		struct VAR9 *VAR33;
		unsigned long VAR34, VAR35, VAR36, VAR37, VAR38;

		VAR34 = (VAR3 + VAR39 - 1) >> VAR40;
		VAR36 = VAR6 + VAR34;

		for (VAR12 = FUN13(&VAR41); VAR12; VAR12 = FUN14(VAR12)) {
			VAR33 = FUN15(VAR12, struct VAR9, VAR42);

			if (!(VAR33->VAR14 & VAR32))
				continue;

			
			if (VAR33->VAR26->VAR43.VAR44->VAR45 !=
			    VAR1->VAR43.VAR44->VAR45)
				continue;

			if (VAR33->VAR24 >= VAR36)
				continue;

			VAR35 = VAR33->VAR46 - VAR33->VAR47;
			VAR35 = (VAR35 + VAR39 - 1) >> VAR40;
			VAR37 = VAR33->VAR24 + VAR35;
			if (VAR6 >= VAR37)
				continue;

			
			if ((VAR33->VAR24 != VAR6 || VAR35 != VAR34) &&
			    !(VAR6 >= VAR33->VAR24 && VAR36 <= VAR37)) {
				
				if (!(VAR13 & VAR48))
					goto VAR49;
				continue;
			}

			
			FUN16(&VAR33->VAR23);
			VAR8->VAR9 = VAR33;
			VAR38 = VAR33->VAR47;
			VAR38 += (VAR6 - VAR33->VAR24) << VAR40;
			VAR8->VAR47 = VAR38;
			VAR8->VAR46 = VAR38 + VAR3;

			if (VAR33->VAR14 & VAR50) {
				FUN17("");
				VAR8->VAR14 |= VAR50;
			} else {
				FUN17("");
				VAR16 = FUN18(VAR8);
				if (VAR16 < 0) {
					VAR8->VAR9 = NULL;
					VAR8->VAR47 = 0;
					VAR8->VAR46 = 0;
					FUN19(&VAR33->VAR23);
					VAR33 = NULL;
					goto VAR51;
				}
			}
			FUN20(VAR10->VAR26);
			FUN21(VAR18, VAR10);
			VAR10 = VAR33;
			VAR15 = VAR38;
			goto VAR52;
		}

		
		if (VAR1 && VAR1->VAR53->VAR54) {
			VAR2 = VAR1->VAR53->FUN22(VAR1, VAR2, VAR3,
							     VAR6, VAR5);
			if (FUN23((void *) VAR2)) {
				VAR16 = VAR2;
				if (VAR16 != (unsigned long) -VAR55)
					goto VAR51;

				
				VAR16 = (unsigned long) -VAR56;
				if (!(VAR13 & VAR57))
					goto VAR51;

				VAR13 &= ~VAR48;
			} else {
				VAR8->VAR47 = VAR10->VAR47 = VAR2;
				VAR8->VAR46 = VAR10->VAR46 = VAR2 + VAR3;
			}
		}
	}

	VAR8->VAR9 = VAR10;
	FUN24(VAR10);

	
	if (VAR1 && VAR8->VAR14 & VAR58)
		VAR16 = FUN18(VAR8);
	else
		VAR16 = FUN25(VAR8, VAR10, VAR3);
	if (VAR16 < 0)
		goto VAR59;

	
	VAR15 = VAR8->VAR47;

	VAR28->VAR29->VAR60 += VAR3 >> VAR40;

VAR52:
	FUN26(VAR28->VAR29, VAR8);

	FUN27(&VAR31);

	if (VAR4 & VAR61)
		FUN28(VAR15, VAR15 + VAR3);

	FUN5("", VAR15);
	return VAR15;

VAR59:
	FUN29(VAR10);
	if (VAR8) {
		if (VAR8->VAR26) {
			FUN20(VAR8->VAR26);
			if (VAR8->VAR14 & VAR27)
				FUN30(VAR8->VAR30);
		}
		FUN21(VAR21, VAR8);
	}
	FUN5("", VAR16);
	return VAR16;

VAR51:
	FUN27(&VAR31);
VAR62:
	if (VAR10->VAR26)
		FUN20(VAR10->VAR26);
	FUN21(VAR18, VAR10);
	if (VAR8->VAR26)
		FUN20(VAR8->VAR26);
	if (VAR8->VAR14 & VAR27)
		FUN30(VAR8->VAR30);
	FUN21(VAR21, VAR8);
	FUN5("", VAR16);
	return VAR16;

VAR49:
	FUN27(&VAR31);
	FUN31(VAR63 "");
	VAR16 = -VAR64;
	goto VAR62;

VAR22:
	FUN21(VAR18, VAR10);
	FUN31(VAR63 ""
	       "",
	       VAR3, VAR28->VAR65);
	FUN32();
	return -VAR66;

VAR20:
	FUN31(VAR63 ""
	       "",
	       VAR3, VAR28->VAR65);
	FUN32();
	return -VAR66;
}