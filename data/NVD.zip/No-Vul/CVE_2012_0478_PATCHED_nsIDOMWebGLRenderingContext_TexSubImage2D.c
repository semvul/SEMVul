static VAR1 FUN1(VAR2 *VAR3, uintN argc, VAR4 *VAR5)  
{
    FUN2(VAR3);
    VAR6 *VAR7 = FUN3(VAR3, VAR5);
    if (!VAR7)
        return VAR8;

    nsresult VAR9;

    VAR10 *VAR11;
    xpc_qsSelfRef VAR12;
    VAR13::VAR14 FUN4(VAR3);
    if (!FUN5(VAR3, VAR7, VAR15, &VAR11, &VAR12.VAR16, VAR17.FUN6(), VAR15))
        return VAR8;

    if (argc < 7 || argc == 8)
        return FUN7(VAR3, VAR18);

    VAR4 *argv = FUN8(VAR3, VAR5);

    
    FUN9(VAR19, 0);
    FUN10(VAR20, 1);
    FUN10(VAR21, 2);
    FUN10(VAR22, 3);

    if (argc > 6 &&
        !FUN11(argv[6]))
    {
        
        FUN9(VAR23, 4);
        FUN9(VAR24, 5);

        VAR25 *VAR26;
        xpc_qsSelfRef VAR27;
        VAR9 = VAR28<VAR25>(VAR3, argv[6], &VAR26, &VAR27.VAR16, &argv[6]);
        if (FUN12(VAR9)) return VAR8;

        VAR9 = VAR11->FUN13(VAR19, VAR20, VAR21, VAR22, VAR23, VAR24, VAR26);
        
        
        
        if (VAR9 == VAR29) {
            FUN14(VAR3, VAR9, VAR5, 6);
            return VAR8;
        }

        if (FUN12(VAR9)) {
            
            VAR6 *VAR30 = FUN15(argv[6]);
            jsval VAR31, VAR32, VAR33;
            FUN16(VAR3, VAR30, "", &VAR31);
            FUN16(VAR3, VAR30, "", &VAR32);
            FUN16(VAR3, VAR30, "", &VAR33);
            if (VAR31  == VAR34 ||
                VAR32 == VAR34 ||
                !VAR33.FUN17())
            {
                FUN14(VAR3, VAR35, VAR5, 6);
                return VAR8;
            }
            int32_t VAR36, VAR37;
            VAR6 *VAR38 = FUN15(VAR33);
            if (!FUN18(VAR3, VAR31, &VAR36) ||
                !FUN18(VAR3, VAR32, &VAR37))
            {
                return VAR8;
            }
            if (!FUN19(VAR38))
            {
                FUN14(VAR3, VAR35, VAR5, 6);
                return VAR8;
            }
            VAR9 = VAR11->FUN20(VAR19, VAR20, VAR21, VAR22,
                                               VAR36, VAR37,
                                               VAR23, VAR24,
                                               VAR13::VAR39::FUN21(VAR38));
        }
    } else if (argc > 8 &&
               !FUN11(argv[8]))
    {
        
        FUN10(VAR23, 4);
        FUN10(VAR24, 5);
        FUN9(VAR30, 6);
        FUN9(VAR40, 7);

        VAR6 *VAR41 = FUN15(argv[8]);
        
        if (FUN19(VAR41)) {
            VAR9 = VAR11->FUN22(VAR19, VAR20, VAR21, VAR22,
                                           VAR23, VAR24, VAR30, VAR40,
                                           VAR13::VAR39::FUN21(VAR41));
        } else {
            FUN14(VAR3, VAR35, VAR5, 8);
            return VAR8;
        }
    } else {
        FUN7(VAR3, VAR18);
        return VAR8;
    }

    if (FUN12(VAR9))
        return FUN23(VAR3, VAR9, VAR5);

    *VAR5 = VAR34;
    return VAR42;
}