static int FUN1(struct VAR1 *VAR2, 				    char VAR3 *VAR4, 				    int VAR5)  
{
	struct sctp_authchunk VAR6;

	if (!VAR7)
		return -VAR8;

	if (VAR5 != sizeof(struct VAR9))
		return -VAR10;
	if (FUN2(&VAR6, VAR4, VAR5))
		return -VAR11;

	switch (VAR6.VAR12) {
		case VAR13:
		case VAR14:
		case VAR15:
		case VAR16:
			return -VAR10;
	}

	
	return FUN3(FUN4(VAR2)->VAR17, VAR6.VAR12);
}