static int FUN1(struct VAR1 *VAR2, int VAR3, 					   char VAR4 *VAR5, int VAR4 *VAR6)  
{
	struct VAR7 *VAR8;
	struct VAR9 *VAR10;
	int VAR11 = 0;
	struct sctp_getaddrs_old VAR12;
	struct VAR13 *VAR14;
	void VAR4 *VAR15;
	union sctp_addr VAR16;
	struct VAR17 *VAR18 = FUN2(VAR2);
	int VAR19;
	int VAR20 = 0;
	void *VAR21;
	void *VAR22;
	int VAR23 = 0;

	if (VAR3 < sizeof(struct VAR24))
		return -VAR25;

	VAR3 = sizeof(struct VAR24);
	if (FUN3(&VAR12, VAR5, VAR3))
		return -VAR26;

	if (VAR12.VAR27 <= 0 ||
	    VAR12.VAR27 >= (VAR28 / sizeof(union VAR29)))
		return -VAR25;
	
	if (0 == VAR12.VAR30) {
		VAR8 = &FUN2(VAR2)->VAR31->VAR32.VAR33;
	} else {
		VAR10 = FUN4(VAR2, VAR12.VAR30);
		if (!VAR10)
			return -VAR25;
		VAR8 = &VAR10->VAR32.VAR33;
	}

	VAR15 = VAR12.VAR21;

	
	VAR21 = FUN5(sizeof(union VAR29) * VAR12.VAR27,
			VAR34);
	if (!VAR21)
		return -VAR35;

	
	if (FUN6(&VAR8->VAR36)) {
		VAR14 = FUN7(VAR8->VAR36.VAR37,
				  struct VAR13, VAR38);
		if (FUN8(&VAR14->VAR39)) {
			VAR11 = FUN9(VAR2, VAR8->VAR40,
						   VAR12.VAR27,
						   VAR21, &VAR23);
			goto VAR41;
		}
	}

	VAR22 = VAR21;
	
	FUN10(VAR14, &VAR8->VAR36, VAR38) {
		memcpy(&VAR16, &VAR14->VAR39, sizeof(VAR16));
		FUN11(VAR2->VAR42)->FUN12(VAR18, &VAR16);
		VAR19 = FUN13(VAR16.VAR43.VAR44)->VAR45;
		memcpy(VAR22, &VAR16, VAR19);
		VAR22 += VAR19;
		VAR23 += VAR19;
		VAR11 ++;
		if (VAR11 >= VAR12.VAR27) break;
	}

VAR41:
	
	if (FUN14(VAR15, VAR21, VAR23)) {
		VAR20 = -VAR26;
		goto VAR46;
	}

	
	VAR12.VAR27 = VAR11;
	if (FUN14(VAR5, &VAR12, VAR3))
		VAR20 = -VAR26;

VAR46:
	FUN15(VAR21);
	return VAR20;
}