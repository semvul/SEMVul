static VAR1 FUN1(VAR2 *VAR3, VAR4 *VAR5, VAR6 *VAR7, gint VAR8, guint16 VAR9)  
{
	if ((VAR8 & 1))
		FUN2(1);

	if ((VAR9 & VAR10)) {
		FUN3(VAR7, VAR11, VAR3, VAR8, 16, VAR12);
		VAR8 += 16;
	}

	if ((VAR9 & VAR13)) {
		FUN3(VAR7, VAR14, VAR3, VAR8, 16, VAR12);
		VAR8 += 16;
	}

	if ((VAR9 & VAR15)) {
		VAR8 = FUN4(VAR3, VAR5, VAR7, VAR8);
	}

	return VAR8;
}