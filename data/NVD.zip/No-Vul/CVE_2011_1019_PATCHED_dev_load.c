void FUN1(struct VAR1 *VAR1, const char *VAR2)  
{
	struct VAR3 *VAR4;
	int VAR5;

	FUN2();
	VAR4 = FUN3(VAR1, VAR2);
	FUN4();

	VAR5 = !VAR4;
	if (VAR5 && FUN5(VAR6))
		VAR5 = FUN6("", VAR2);
	if (VAR5 && FUN5(VAR7)) {
		if (!FUN6("", VAR2))
			FUN7(""
""
"", VAR2);
	}
}