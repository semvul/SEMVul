int FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4, 			   struct VAR5 *VAR6, unsigned VAR7)  
{
	struct VAR8 *VAR9 = FUN2(VAR2);
	struct VAR10 *VAR11 = FUN3(VAR4);
	const int VAR12 = VAR2->VAR13;
	int VAR14 = 0;

	
	if (VAR2->VAR13 == VAR15) {
		if (VAR6->VAR16 == VAR17) {
			if (FUN4(VAR2)->VAR18->FUN5(VAR2,
								    VAR4) < 0)
				return 1;
			goto VAR19;
		}
		if (VAR6->VAR16 == VAR20)
			goto VAR19;

		
		VAR11->VAR21 = VAR22;
		return 1;
	} else if (VAR2->VAR13 == VAR23) {
		VAR11->VAR21 = VAR22;
		return 1;
	}

	if (VAR2->VAR13 != VAR24 && VAR2->VAR13 != VAR25) {
		if (FUN6(VAR2, VAR4))
			goto VAR19;

		
		if (FUN7(VAR2, NULL, VAR4))
			return 1;

		if (VAR11->VAR26 != VAR27)
			FUN8(VAR2, VAR4);

		if (VAR9->VAR28 != NULL &&
		    FUN9(VAR9->VAR28, VAR2,
				    FUN3(VAR4)->VAR29,
				    VAR30))
			goto VAR19;

		FUN10(VAR2, VAR4);
	}

	
	if (VAR6->VAR16 == VAR20) {
		FUN11(VAR2, VAR4);
		return 0;
		
	} else if ((VAR9->VAR31 != VAR32 &&
		    VAR6->VAR16 == VAR33) ||
		    (VAR9->VAR31 == VAR32 &&
		     VAR6->VAR16 == VAR17) ||
		    (VAR2->VAR13 == VAR25 &&
		     VAR6->VAR16 == VAR34)) {
		FUN12(VAR2, VAR11->VAR29, VAR35);
		goto VAR19;
	} else if (VAR6->VAR16 == VAR36) {
		if (FUN13(VAR2, VAR4))
			return 0;
		goto VAR19;
	} else if (VAR6->VAR16 == VAR37) {
		if (FUN14(VAR2, VAR4))
			return 0;
		goto VAR19;
	}

	switch (VAR2->VAR13) {
	case VAR24:
		VAR14 = FUN15(VAR2, VAR4, VAR6, VAR7);
		if (VAR14 >= 0)
			return VAR14;

		FUN16(VAR4);
		return 0;

	case VAR25:
	case VAR38:
		VAR14 = FUN17(VAR2, VAR4,
								 VAR6, VAR7);
		break;
	}

	if (VAR6->VAR16 == VAR39 ||
	    VAR6->VAR16 == VAR40) {
		switch (VAR12) {
		case VAR38:
			VAR2->FUN18(VAR2);
			FUN19(VAR2, VAR41, VAR42);
			break;
		}
	} else if (FUN20(VAR6->VAR16 == VAR35)) {
		FUN12(VAR2, VAR11->VAR29, VAR43);
		goto VAR19;
	}

	if (!VAR14) {
VAR19:
		FUN16(VAR4);
	}
	return 0;
}