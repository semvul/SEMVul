static int FUN1(VAR1 *VAR2, const VAR1 *VAR3)  
{
    VAR4 *VAR5 = VAR2->VAR6, *VAR7 = VAR3->VAR6;
    int VAR8 = 0, VAR9, VAR10;

#VAR11 FUN2(VAR12, VAR13, VAR14, VAR15) memcpy(&VAR12->VAR14, &VAR13->VAR14, (char*)&VAR12->VAR15 - (char*)&VAR12->VAR14)

    if (!VAR7->VAR16.VAR17[0]
        ||VAR5->VAR18 != VAR7->VAR18
        ||VAR5->VAR19!= VAR7->VAR19) {
        if (VAR5 != VAR7)
            FUN2(VAR5, VAR7, VAR20, VAR21);
        return -1;
    }

    if (VAR5 != VAR7) {
        
        if (!VAR5->VAR16.VAR17[0]) {
            int VAR22, VAR23;
            VAR5->VAR24 = VAR2;
            VAR10 = FUN3(VAR2);
            if (VAR10)
                return VAR10;
            VAR22 = VAR5->VAR25[0] * VAR5->VAR26[0];
            VAR23 = VAR5->VAR25[1] * VAR5->VAR26[1];
            memcpy(VAR5->VAR27[0], VAR7->VAR27[0], VAR22 * sizeof(*VAR5->VAR27[0]));
            memcpy(VAR5->VAR27[1], VAR7->VAR27[1], VAR23 * sizeof(*VAR5->VAR27[1]));
        }

        
        FUN2(VAR5, VAR7, VAR20, VAR28);

        
        for (VAR9 = 0; VAR9 < 3; VAR9++) {
            if (VAR5->VAR29[VAR9] != VAR7->VAR29[1]) {
                VAR8 = 1;
                memcpy(&VAR5->VAR30[VAR9], &VAR7->VAR30[VAR9], sizeof(VAR5->VAR30[VAR9]));
            }
        }

        if (VAR5->VAR29[0] != VAR7->VAR29[0])
            memcpy(&VAR5->VAR31, &VAR7->VAR31, sizeof(VAR5->VAR31));

        if (VAR8)
            FUN2(VAR5, VAR7, VAR29, VAR32);
#undef VAR33
    }

    FUN4(VAR2);

    return 0;
}