static void FUN1(struct VAR1 *VAR2)  
{
	struct VAR3 *VAR4 = FUN2(VAR2);
	struct VAR5 *VAR6 = FUN3(VAR2);
	struct VAR7 *VAR8 = FUN4(VAR2);
	unsigned long VAR9;
	unsigned long VAR10;
	unsigned long VAR11;

	if (VAR6) {
		VAR10 = FUN5(VAR4, VAR2, VAR2->VAR12);
		VAR11 = FUN5(VAR4, VAR2, VAR2->VAR13);

		VAR9 = (VAR11 - VAR10) -
			FUN6(&VAR6->VAR14, VAR10, VAR11);

		FUN7(VAR2);

		if (VAR9) {
			FUN8(VAR4, -VAR9);
			FUN9(VAR8, VAR9);
		}
	}
}