NS_IMETHODIMP VAR1::FUN1(WebGLenum VAR2, VAR3 *VAR4)  
{
    WebGLuint VAR5;
    VAR6* VAR7;
    PRBool VAR8;
    if (!FUN2("", VAR4, &VAR7, &VAR5, &VAR8))
        return VAR9;

    if (VAR2 != VAR10 &&
        VAR2 != VAR11)
    {
        return FUN3("", VAR2);
    }

    if (!VAR8) {
        if ((VAR7->FUN4() != VAR12) && (VAR2 != VAR7->FUN4()))
            return FUN5("");
        VAR7->FUN6(VAR2);
        VAR7->FUN7(VAR13);
    }

    
    
    if (VAR2 == VAR10) {
        VAR14 = VAR7;
    } else if (VAR2 == VAR11) {
        VAR15 = VAR7;
    }

    FUN8();

    VAR16->FUN9(VAR2, VAR5);

    return VAR9;
}