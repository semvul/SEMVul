static void aux_register_types(void)

{

    type_register_static(&aux_bus_info);

    type_register_static(&aux_slave_type_info);

    type_register_static(&aux_to_i2c_type_info);

}
