int FUN1(void)  
{
	int VAR1;
	int VAR2 = 0;

	if (VAR3 > VAR4) {
		VAR3 = VAR4;
		FUN2(VAR5 ""
		       "", VAR6,
		       VAR3);
	}
	FUN3(&VAR7);
	FUN4(&VAR7);
	VAR8 = 1;
	while (VAR3 >> VAR8)
		VAR8++;
	VAR9 = FUN5((sizeof(struct VAR10)
					* (1 << VAR8)),
				       VAR11);
	if (!VAR9) {
		VAR2 = -VAR12;
		FUN2(VAR13 "", VAR6);
		FUN6(&VAR7);
		goto VAR14;
	}
	for (VAR1 = 0; VAR1 < (1 << VAR8); VAR1++)
		FUN7(&VAR9[VAR1]);
	FUN6(&VAR7);
	VAR15 = FUN5((sizeof(struct VAR16)
					* VAR17),
				       VAR11);
	if (!VAR15) {
		VAR2 = -VAR12;
		FUN2(VAR13 "", VAR6);
		goto VAR14;
	}
	FUN3(&VAR18);
	FUN4(&VAR18);
	VAR19 = 0;
	for (VAR1 = 0; VAR1 < VAR17; VAR1++) {
		FUN8(&VAR15[VAR1].VAR20);
		FUN8(&VAR15[VAR1].VAR21);
		FUN3(&VAR15[VAR1].VAR22);
		FUN4(&VAR15[VAR1].VAR22);
		VAR15[VAR1].VAR23 = VAR1;
		VAR15[VAR1].VAR24 = VAR25;
		VAR15[VAR1].VAR26 = 0;
		VAR15[VAR1].VAR27 = NULL;
		VAR15[VAR1].VAR28 = NULL;
		FUN9(&VAR15[VAR1].VAR20,
			      &VAR29);
		FUN6(&VAR15[VAR1].VAR22);
	}
	FUN6(&VAR18);
	VAR2 = FUN10();
	if (VAR2)
		FUN11();
VAR14:
	return VAR2;
}