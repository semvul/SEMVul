asmlinkage long FUN1 (int VAR1, int VAR2, void VAR3 *VAR4, int VAR5)  
{
	struct VAR6 *VAR6 = NULL;
	VAR7 *VAR8 = NULL;
	unsigned long VAR9 = 0UL;
	void *VAR10 = NULL;
	long VAR11; 
	size_t VAR12, VAR13, VAR14 = 0;
	int VAR15, VAR16 = 0, VAR17 = 0, VAR18;
	int (*VAR19)(VAR7 *VAR8, void *VAR4, int VAR5, struct VAR20 *VAR21);
	int (*VAR22)(void *VAR4, VAR23 *VAR13);
#define PFM_MAX_ARGSIZE	4096

	
	if (FUN2(VAR24 == NULL)) return -VAR25;

	if (FUN2(VAR2 < 0 || VAR2 >= VAR26)) {
		FUN3(("", VAR2));
		return -VAR27;
	}

	VAR19      = VAR28[VAR2].VAR29;
	VAR15      = VAR28[VAR2].VAR30;
	VAR12   = VAR28[VAR2].VAR31;
	VAR22   = VAR28[VAR2].VAR32;
	VAR18 = VAR28[VAR2].VAR18;

	if (FUN2(VAR19 == NULL)) {
		FUN3(("", VAR2));
		return -VAR27;
	}

	FUN3(("",
		FUN4(VAR2),
		VAR2,
		VAR15,
		VAR12,
		VAR5));

	
	if (FUN2((VAR15 == VAR33 && VAR5 <= 0) || (VAR15 > 0 && VAR15 != VAR5)))
		return -VAR27;

VAR34:
	VAR13 = VAR14 + VAR12*VAR5;
	
	if (FUN2(VAR13 > VAR35)) {
		FUN5(VAR36 "", VAR37->VAR38, VAR13);
		return -VAR39;
	}

	
	if (FUN6(VAR5 && VAR10 == NULL)) {
		VAR10 = FUN7(VAR35, VAR40);
		if (VAR10 == NULL) return -VAR41;
	}

	VAR11 = -VAR42;

	
	if (VAR13 && FUN8(VAR10, VAR4, VAR13)) {
		FUN3(("", VAR13, VAR4));
		goto VAR43;
	}

	
	if (VAR16 == 0 && VAR22) {
		
		VAR11 = (*VAR22)(VAR10, &VAR14);
		if (VAR11) goto VAR43;

		VAR16 = 1;

		FUN3(("", VAR13, VAR14));

		
		if (FUN6(VAR14)) goto VAR34;
	}

	if (FUN2((VAR18 & VAR44) == 0)) goto VAR45;

	VAR11 = -VAR46;

	VAR6 = FUN9(VAR1);
	if (FUN2(VAR6 == NULL)) {
		FUN3(("", VAR1));
		goto VAR43;
	}
	if (FUN2(FUN10(VAR6) == 0)) {
		FUN3(("", VAR1));
		goto VAR43;
	}

	VAR8 = (VAR7 *)VAR6->VAR47;
	if (FUN2(VAR8 == NULL)) {
		FUN3(("", VAR1));
		goto VAR43;
	}
	FUN11(&VAR8->VAR48);

	FUN12(VAR8, VAR9);

	
	VAR11 = FUN13(VAR8, VAR2, VAR9);
	if (FUN2(VAR11)) goto VAR49;

VAR45:
	VAR11 = (*VAR19)(VAR8, VAR10, VAR5, FUN14(VAR37));

	VAR17 = 1;

VAR49:
	if (FUN6(VAR8)) {
		FUN3((""));
		FUN15(VAR8, VAR9);
	}

	
	if (VAR17 && FUN16(VAR2) && FUN17(VAR4, VAR10, VAR12*VAR5)) VAR11 = -VAR42;

VAR43:
	if (VAR6)
		FUN18(VAR6);

	FUN19(VAR10);

	FUN3(("", FUN4(VAR2), VAR11));

	return VAR11;
}