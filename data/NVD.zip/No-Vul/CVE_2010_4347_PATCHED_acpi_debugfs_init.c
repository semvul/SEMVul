int VAR1 FUN1(void)  
{
	struct VAR2 *VAR3, *VAR4;

	VAR3 = FUN2("", NULL);
	if (!VAR3)
		goto VAR5;

	VAR4 = FUN3("", VAR6,
					VAR3, NULL, &VAR7);
	if (!VAR4)
		goto VAR5;

	return 0;

VAR5:
	if (VAR3)
		FUN4(VAR3);
	return -VAR8;
}