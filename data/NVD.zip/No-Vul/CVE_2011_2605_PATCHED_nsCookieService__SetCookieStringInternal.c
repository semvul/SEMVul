void VAR1::FUN1(VAR2          *VAR3,                                          bool             VAR4,                                          const VAR5 &VAR6,                                          const VAR5 &VAR7,                                          PRBool           VAR8)   
{
  FUN2(VAR3, "");

  if (!VAR9) {
    FUN3("");
    return;
  }

  
  
  
  
  
  PRBool VAR10;
  nsCAutoString VAR11;
  nsresult VAR12 = FUN4(VAR3, VAR11, VAR10);
  if (FUN5(VAR12)) {
    FUN6(VAR13, VAR3, VAR6, 
                      "");
    return;
  }

  
  CookieStatus VAR14 = FUN7(VAR3, VAR4, VAR11,
                                         VAR10, VAR6.FUN8());
  
  switch (VAR14) {
  case VAR15:
    FUN9(VAR3);
  case VAR16:
    return;
  default:
    break;
  }

  
  
  
  
  
  PRTime VAR17;
  PRInt64 VAR18;
  PRStatus VAR19 = FUN10(VAR7.FUN8(), VAR20,
                                       &VAR17);
  if (VAR19 == VAR21) {
    VAR18 = VAR17 / VAR22;
  } else {
    VAR18 = FUN11() / VAR22;
  }

  
  VAR23 FUN12(VAR6);
  while (FUN13(VAR3, VAR11, VAR10,
                           VAR14, VAR24, VAR18, VAR8)) {
    
    if (!VAR8)
      break;
  }
}