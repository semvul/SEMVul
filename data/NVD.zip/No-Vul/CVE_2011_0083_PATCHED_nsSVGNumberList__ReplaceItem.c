NS_IMETHODIMP VAR1::FUN1(VAR2 *VAR3,                              PRUint32 VAR4,                              VAR2 **VAR5)  
{
  *VAR5 = VAR6;

  if (!VAR3) {
    return VAR7;
  }

  if (VAR4 >= VAR8.FUN2()) {
    return VAR9;
  }

  FUN3();
  FUN4(VAR8[VAR4]);
  FUN5(VAR8[VAR4]);
  VAR8[VAR4] = VAR3;
  FUN6(VAR3);
  FUN7(VAR3);
  FUN8();

  FUN6(*VAR5 = VAR3);

  return VAR10;
}