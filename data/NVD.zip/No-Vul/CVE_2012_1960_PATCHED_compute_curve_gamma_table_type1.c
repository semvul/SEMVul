void FUN1(float VAR1[256], uint16_t VAR2)  
{
	unsigned int VAR3;
        float VAR4 = FUN2(VAR2);
	for (VAR3 = 0; VAR3 < 256; VAR3++) {
                
		VAR1[VAR3] = FUN3(VAR3/255., VAR4);
	}
}