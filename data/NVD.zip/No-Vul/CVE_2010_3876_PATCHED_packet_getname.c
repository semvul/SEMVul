static int FUN1(struct socket *VAR1, struct VAR2 *VAR3, 			  int *VAR4, int VAR5)  
{
	struct VAR6 *VAR7;
	struct VAR1 *VAR8 = VAR1->VAR8;
	struct VAR9 *VAR10 = FUN2(VAR8);
	FUN3(struct VAR11 *, VAR12, VAR3);

	if (VAR5)
		return -VAR13;

	VAR12->VAR14 = VAR15;
	VAR12->VAR16 = VAR10->VAR17;
	VAR12->VAR18 = VAR10->VAR19;
	VAR12->VAR20 = 0;
	FUN4();
	VAR7 = FUN5(FUN6(VAR8), VAR10->VAR17);
	if (VAR7) {
		VAR12->VAR21 = VAR7->VAR22;
		VAR12->VAR23 = VAR7->VAR24;
		memcpy(VAR12->VAR25, VAR7->VAR26, VAR7->VAR24);
	} else {
		VAR12->VAR21 = 0;	
		VAR12->VAR23 = 0;
	}
	FUN7();
	*VAR4 = FUN8(struct VAR11, VAR25) + VAR12->VAR23;

	return 0;
}