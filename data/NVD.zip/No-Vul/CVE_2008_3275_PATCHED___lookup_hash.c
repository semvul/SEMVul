static struct VAR1 *FUN1(struct VAR2 *VAR3, 		struct VAR1 *VAR4, struct VAR5 *VAR6)  
{
	struct VAR1 *VAR1;
	struct VAR7 *VAR7;
	int VAR8;

	VAR7 = VAR4->VAR9;

	
	if (VAR4->VAR10 && VAR4->VAR10->VAR11) {
		VAR8 = VAR4->VAR10->FUN2(VAR4, VAR3);
		VAR1 = FUN3(VAR8);
		if (VAR8 < 0)
			goto VAR12;
	}

	VAR1 = FUN4(VAR4, VAR3, VAR6);
	if (!VAR1) {
		struct VAR1 *new;

		
		VAR1 = FUN3(-VAR13);
		if (FUN5(VAR7))
			goto VAR12;

		new = FUN6(VAR4, VAR3);
		VAR1 = FUN3(-VAR14);
		if (!new)
			goto VAR12;
		VAR1 = VAR7->VAR15->FUN7(VAR7, new, VAR6);
		if (!VAR1)
			VAR1 = new;
		else
			FUN8(new);
	}
VAR12:
	return VAR1;
}