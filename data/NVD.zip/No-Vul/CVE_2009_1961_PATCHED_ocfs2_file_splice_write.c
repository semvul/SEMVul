static VAR1 FUN1(struct VAR2 *VAR3, 				       struct VAR4 *VAR5, 				       VAR6 *VAR7, 				       size_t VAR8, 				       unsigned int VAR9)  
{
	int VAR10;
	struct VAR11 *VAR11 = VAR5->VAR12.VAR13->VAR14;

	FUN2("", VAR5, VAR3,
		   (unsigned int)VAR8,
		   VAR5->VAR12.VAR13->VAR15.VAR8,
		   VAR5->VAR12.VAR13->VAR15.VAR16);

	FUN3(&VAR11->VAR17, VAR18);

	VAR10 = FUN4(VAR11, 1);
	if (VAR10 < 0) {
		FUN5(VAR10);
		goto VAR5;
	}

	VAR10 = FUN6(VAR5->VAR12.VAR13, VAR7, VAR8, 0,
					    NULL);
	if (VAR10 < 0) {
		FUN5(VAR10);
		goto VAR19;
	}

	if (VAR3->VAR11)
		FUN3(&VAR3->VAR11->VAR17, VAR20);
	VAR10 = FUN7(VAR3, VAR5, VAR7, VAR8, VAR9);
	if (VAR3->VAR11)
		FUN8(&VAR3->VAR11->VAR17);

VAR19:
	FUN9(VAR11, 1);
VAR5:
	FUN8(&VAR11->VAR17);

	FUN10(VAR10);
	return VAR10;
}