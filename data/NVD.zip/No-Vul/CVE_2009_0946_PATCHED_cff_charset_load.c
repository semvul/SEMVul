static VAR1   FUN1( CFF_Charset  VAR2,                     FT_UInt      VAR3,                     FT_Stream    VAR4,                     FT_ULong     VAR5,                     FT_ULong     VAR6,                     FT_Bool      VAR7 )    
{
    FT_Memory  VAR8 = VAR4->VAR8;
    FT_Error   VAR9  = VAR10;
    FT_UShort  VAR11;


    
    
    if ( VAR6 > 2 )
    {
      FT_UInt  VAR12;


      VAR2->VAR6 = VAR5 + VAR6;

      
      if ( FUN2( VAR2->VAR6 ) ||
           FUN3( VAR2->VAR13 )   )
        goto VAR14;

      
      if ( FUN4( VAR2->VAR15, VAR3 ) )
        goto VAR14;

      
      VAR2->VAR15[0] = 0;

      switch ( VAR2->VAR13 )
      {
      case 0:
        if ( VAR3 > 0 )
        {
          if ( FUN5( ( VAR3 - 1 ) * 2 ) )
            goto VAR14;

          for ( VAR12 = 1; VAR12 < VAR3; VAR12++ )
          {
            FT_UShort VAR16 = FUN6();


            
            if ( VAR16 < 65000 )
              VAR2->VAR15[VAR12] = VAR16;
            else
            {
              FUN7(( ""
                         "", VAR16 ));
              VAR2->VAR15[VAR12] = 0;
            }
          }

          FUN8();
        }
        break;

      case 1:
      case 2:
        {
          FT_UInt  VAR17;
          FT_UInt  VAR18;


          VAR12 = 1;

          while ( VAR12 < VAR3 )
          {
            
            if ( FUN9( VAR11 ) )
              goto VAR14;

            
            if ( VAR2->VAR13 == 2 )
            {
              if ( FUN9( VAR17 ) )
                goto VAR14;
            }
            else
            {
              if ( FUN3( VAR17 ) )
                goto VAR14;
            }

            
            
            if ( VAR11 >= 65000 ) {
              FUN7(( "" ));
              VAR9 = VAR19;
              goto VAR14;
            }

            
            if ( VAR17 > 65000 - 1 || VAR11 >= 65000 - VAR17 ) {
              FUN7(( "" ));
              VAR17 = 65000 - 1 - VAR11;
            }

            
            for ( VAR18 = 0; VAR12 < VAR3 && VAR18 <= VAR17; VAR18++, VAR12++, VAR11++ )
              VAR2->VAR15[VAR12] = VAR11;
          }
        }
        break;

      default:
        FUN7(( "" ));
        VAR9 = VAR19;
        goto VAR14;
      }
    }
    else
    {
      
      
      
      
      
      
      

      VAR2->VAR6 = VAR6;  

      switch ( (VAR20)VAR6 )
      {
      case 0:
        if ( VAR3 > 229 )
        {
          FUN7(( ""
                     "" ));
          VAR9 = VAR19;
          goto VAR14;
        }

        
        if ( FUN4( VAR2->VAR15, VAR3 ) )
          goto VAR14;

        
        FUN10( VAR2->VAR15, VAR21, VAR3 );

        break;

      case 1:
        if ( VAR3 > 166 )
        {
          FUN7(( ""
                     "" ));
          VAR9 = VAR19;
          goto VAR14;
        }

        
        if ( FUN4( VAR2->VAR15, VAR3 ) )
          goto VAR14;

        
        FUN10( VAR2->VAR15, VAR22, VAR3 );

        break;

      case 2:
        if ( VAR3 > 87 )
        {
          FUN7(( ""
                     "" ));
          VAR9 = VAR19;
          goto VAR14;
        }

        
        if ( FUN4( VAR2->VAR15, VAR3 ) )
          goto VAR14;

        
        FUN10( VAR2->VAR15, VAR23, VAR3 );

        break;

      default:
        VAR9 = VAR19;
        goto VAR14;
      }
    }

    
    if ( VAR7 )
      VAR9 = FUN11( VAR2, VAR3, VAR8 );

  VAR14:
    
    if ( VAR9 )
    {
      FUN12( VAR2->VAR15 );
      FUN12( VAR2->VAR24 );
      VAR2->VAR13 = 0;
      VAR2->VAR6 = 0;
      VAR2->VAR15   = 0;
    }

    return VAR9;
  }