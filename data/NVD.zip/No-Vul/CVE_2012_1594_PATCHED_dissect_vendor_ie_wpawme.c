static int FUN1(VAR1 * VAR2, VAR3 * VAR4, int VAR5, guint32 VAR6, int VAR7)  
{
  guint8 VAR8;

  FUN2(VAR2, VAR9, VAR4, VAR5, 1, VAR10);
  VAR8 = FUN3(VAR4, VAR5);
  FUN4(VAR2, "", FUN5(VAR8, VAR11, "" ));
  VAR5 += 1;

  switch(VAR8){
    case 1:   
    {
      VAR12 *VAR13, *VAR14, *VAR15;
      VAR12 *VAR16, *VAR17;
      VAR1 *VAR18, *VAR19, *VAR20;
      VAR1 *VAR21, *VAR22;
      guint16 VAR23, VAR24;
      guint VAR25;

      FUN2(VAR2, VAR26, VAR4, VAR5, 2, VAR27);
      VAR5 += 2;

      
      VAR13 = FUN2(VAR2, VAR28, VAR4, VAR5, 4, VAR29);
      VAR18 = FUN6(VAR13, VAR30);
      FUN2(VAR18, VAR31, VAR4, VAR5, 3, VAR29);

      
      if(FUN7(VAR4, VAR5) == 0x0050F2)
      {
        FUN2(VAR18, VAR32, VAR4, VAR5 + 3, 1, VAR29);
      } else {
        FUN2(VAR18, VAR33, VAR4, VAR5 + 3, 1, VAR29);
      }
      VAR5 += 4;

      
      FUN2(VAR2, VAR34, VAR4, VAR5, 2, VAR27);
      VAR23 = FUN8(VAR4, VAR5);
      VAR5 += 2;

      VAR14 = FUN2(VAR2, VAR35, VAR4, VAR5, VAR23 * 4, VAR29);
      VAR19 = FUN6(VAR14, VAR36);
      for(VAR25=1; VAR25 <= VAR23; VAR25++)
      {
        VAR16 = FUN2(VAR19, VAR37, VAR4, VAR5, 4, VAR29);
        VAR21 = FUN6(VAR16, VAR38);
        FUN2(VAR21, VAR39, VAR4, VAR5, 3, VAR29);

        
        if(FUN7(VAR4, VAR5) == 0x0050F2)
        {
          FUN2(VAR21, VAR40, VAR4, VAR5+3, 1, VAR29);
          FUN4(VAR14, "", FUN9(FUN10(VAR4, VAR5)));
        } else {
          FUN2(VAR21, VAR41, VAR4, VAR5+3, 1, VAR29);
        }
        VAR5 += 4;
      }

      
      FUN2(VAR2, VAR42, VAR4, VAR5, 2, VAR27);
      VAR24 = FUN8(VAR4, VAR5);
      VAR5 += 2;

      VAR15 = FUN2(VAR2, VAR43, VAR4, VAR5, VAR24 * 4, VAR29);
      VAR20 = FUN6(VAR15, VAR44);
      for(VAR25=1; VAR25 <= VAR24; VAR25++)
      {
        VAR17 = FUN2(VAR20, VAR45, VAR4, VAR5, 4, VAR29);
        VAR22 = FUN6(VAR17, VAR46);
        FUN2(VAR22, VAR47, VAR4, VAR5, 3, VAR29);

        
        if(FUN7(VAR4, VAR5) == 0x0050F2)
        {
          FUN2(VAR22, VAR48, VAR4, VAR5+3, 1, VAR29);
          FUN4(VAR15, "", FUN11(FUN10(VAR4, VAR5)));
        } else {
          FUN2(VAR22, VAR49, VAR4, VAR5+3, 1, VAR29);
        }
        VAR5 += 4;
      }
      break;
    }
    case 2:   
    {
      guint8 VAR50;

      FUN2(VAR2, VAR51, VAR4, VAR5, 1, VAR10);
      VAR50 = FUN3(VAR4, VAR5);
      FUN4(VAR2, "", FUN5(VAR50, VAR52, "" ));
      VAR5 += 1;
      switch(VAR50){
        case 0: 
        {
          FUN2(VAR2, VAR53, VAR4, VAR5, 1, VAR10);
          VAR5 += 1;
          
          VAR5 = FUN12(VAR2, VAR4, VAR5, VAR7);
          break;
        }
        case 1: 
        {
          int VAR25;
          FUN2(VAR2, VAR53, VAR4, VAR5, 1, VAR10);
          VAR5 += 1;
          
          VAR5 = FUN12(VAR2, VAR4, VAR5, VAR7);
          FUN2(VAR2, VAR54, VAR4, VAR5, 1, VAR10);
          VAR5 += 1;
          
          for(VAR25 = 0; VAR25 < 4; VAR25++)
          {
            VAR12 *VAR55, *VAR56, *VAR57;
            VAR1 *VAR58, *VAR59, *VAR60;
            guint8 VAR61, VAR62;

            VAR55 = FUN2(VAR2, VAR63, VAR4, VAR5, 4, VAR10);
            VAR58 = FUN6(VAR55, VAR64);

            
            VAR56 = FUN2(VAR58, VAR65, VAR4, VAR5, 1, VAR10);
            VAR59 = FUN6(VAR56, VAR66);
            FUN2(VAR59, VAR67, VAR4, VAR5, 1, VAR10);
            FUN2(VAR59, VAR68, VAR4, VAR5, 1, VAR10);
            FUN2(VAR59, VAR69, VAR4, VAR5, 1, VAR10);
            FUN2(VAR59, VAR70, VAR4, VAR5, 1, VAR10);
            VAR61 = FUN3(VAR4, VAR5);
            FUN4(VAR55, "",
            (VAR61 & 0x60) >> 5, FUN13((VAR61 & 0x60) >> 5, VAR71),
            (VAR61 & 0x10) ? "" : "", VAR61 & 0x0f);
            VAR5 += 1;

            
            VAR57 = FUN2(VAR58, VAR72, VAR4, VAR5, 1, VAR10);
            VAR60 = FUN6(VAR57, VAR73);
            FUN2(VAR60, VAR74, VAR4, VAR5, 1, VAR10);
            FUN2(VAR60, VAR75, VAR4, VAR5, 1, VAR10);
            VAR62 = FUN3(VAR4, VAR5);
            FUN4(VAR55, "", VAR62 & 0x0f, (VAR62 & 0xf0) >> 4 );
            VAR5 += 1;

            
            FUN2(VAR58, VAR76, VAR4, VAR5, 2, VAR27);
            FUN4(VAR55, "", FUN8(VAR4, VAR5));
            VAR5 += 2;
          }
          break;
        }
        case 3:   
        {

            VAR12 *VAR77;
            VAR1 *VAR78;

            VAR77 = FUN2(VAR2, VAR79, VAR4, VAR5, 3, VAR27);
            VAR78 = FUN6(VAR77, VAR80);

            FUN2(VAR78, VAR81, VAR4, VAR5, 3, VAR27);
            FUN2(VAR78, VAR82, VAR4, VAR5, 3, VAR27);
            FUN2(VAR78, VAR83, VAR4, VAR5, 3, VAR27);
            FUN2(VAR78, VAR84, VAR4, VAR5, 3, VAR27);
            FUN2(VAR78, VAR85, VAR4, VAR5, 3, VAR27);
            VAR5 += 3;

            FUN2(VAR2, VAR86, VAR4, VAR5, 2, VAR27);
            VAR5 += 2;

            FUN2(VAR2, VAR87, VAR4, VAR5, 2, VAR27);
            VAR5 += 2;

            FUN2(VAR2, VAR88, VAR4, VAR5, 4, VAR27);
            VAR5 += 4;

            FUN2(VAR2, VAR89, VAR4, VAR5, 4, VAR27);
            VAR5 += 4;

            FUN2(VAR2, VAR90, VAR4, VAR5, 4, VAR27);
            VAR5 += 4;

            FUN2(VAR2, VAR91, VAR4, VAR5, 4, VAR27);
            VAR5 += 4;

            FUN2(VAR2, VAR92, VAR4, VAR5, 4, VAR27);
            VAR5 += 4;

            FUN2(VAR2, VAR93, VAR4, VAR5, 4, VAR27);
            VAR5 += 4;

            FUN2(VAR2, VAR94, VAR4, VAR5, 4, VAR27);
            VAR5 += 4;

            FUN2(VAR2, VAR95, VAR4, VAR5, 4, VAR27);
            VAR5 += 4;

            FUN2(VAR2, VAR96, VAR4, VAR5, 4, VAR27);
            VAR5 += 4;

            FUN2(VAR2, VAR97, VAR4, VAR5, 4, VAR27);
            VAR5 += 4;

            FUN2(VAR2, VAR98, VAR4, VAR5, 4, VAR27);
            VAR5 += 4;

            FUN2(VAR2, VAR99, VAR4, VAR5, 2, VAR27);
            VAR5 += 2;

            FUN2(VAR2, VAR100, VAR4, VAR5, 2, VAR27);
            VAR5 += 2;

          break;
        }
        default:
          
        break;
      } 
      break;
    }
    case 4: 
    {
      FUN14(VAR2, VAR4, VAR5, VAR6-4, NULL);
    }
    break;
    default:
      
    break;
  } 

  return VAR5;
}