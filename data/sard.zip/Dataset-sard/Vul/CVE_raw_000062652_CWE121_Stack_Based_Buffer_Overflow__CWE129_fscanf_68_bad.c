void CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_68_bad()
{
    int data;
    /* Initialize data */
    data = -1;
    /* POTENTIAL FLAW: Read data from the console using fscanf() */
    fscanf(stdin, "%d", &data);
    CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_68_badData = data;
    CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_68b_badSink();
}
