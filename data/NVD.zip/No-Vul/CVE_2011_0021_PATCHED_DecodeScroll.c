static int FUN1( VAR1 *VAR2, const VAR3 *VAR4, int VAR5 )  
{
    uint8_t copy[VAR6*VAR7];

    uint8_t VAR8 = VAR4[0]&0x0f;
    int VAR9;
    int VAR10;
    int VAR11, VAR12;

    
    VAR2->VAR13 = VAR4[1]&0x7;
    if( VAR2->VAR13 >= VAR14 )
        VAR2->VAR13 = VAR14-1;

    VAR2->VAR15 = VAR4[2]&0xf;
    if( VAR2->VAR15 >= VAR16 )
        VAR2->VAR15 = VAR16-1;

    
    switch( (VAR4[1] >> 4)&0x3 )
    {
    case 0x01: VAR9 =  6; break;
    case 0x02: VAR9 = -6; break;
    default:
        VAR9 = 0;
        break;
    }
    switch( (VAR4[2] >> 4)&0x3 )
    {
    case 0x01: VAR10 = 12; break;
    case 0x02: VAR10 =-12; break;
    default:
        VAR10 = 0;
        break;
    }

    if( VAR9 == 0 && VAR10 == 0 )
        return 0;

    
    memcpy( copy, VAR2->VAR17, sizeof(VAR2->VAR17) );

    
    FUN2( VAR2, 0, 0, VAR18, VAR7, VAR8 );

    
    for( VAR12 = 0; VAR12 < VAR7; VAR12++ )
    {
        int VAR19 = VAR10 + VAR12;
        for( VAR11 = 0; VAR11 < VAR18; VAR11++ )
        {
            int VAR20 = VAR9 + VAR11;

            if( VAR5 )
            {
                VAR19 %= VAR7;
                VAR20 %= VAR18;
            }
            else
            {
                if( VAR19 < 0 || VAR19 >= VAR7 ||
                    VAR20 < 0 || VAR20 >= VAR18 )
                    continue;
            }
            VAR2->VAR17[VAR19*VAR6+VAR20] = copy[VAR12*VAR6+VAR11];
        }
    }
    
    
    return 0;
}