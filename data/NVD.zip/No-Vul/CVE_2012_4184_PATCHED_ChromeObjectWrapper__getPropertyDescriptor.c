bool VAR1::FUN1(VAR2 *VAR3, VAR4 *VAR5,                                            jsid VAR6, bool VAR7,                                            VAR8::VAR9 *VAR10)  
{
    
    
    
    VAR10->VAR11 = NULL;
    if (!VAR12::FUN1(VAR3, VAR5, VAR6,
                                                        VAR7, VAR10)) {
        return false;
    }

    
    VAR4 *VAR13 = FUN2(VAR5);
    if (VAR10->VAR11 || VAR7 || !VAR13)
        return true;

    
    FUN3(VAR8::FUN4(VAR5, VAR3));
    return FUN5(VAR3, VAR13, VAR6, 0, VAR10);
}