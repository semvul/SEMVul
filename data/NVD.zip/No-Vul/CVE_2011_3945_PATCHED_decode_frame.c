static int FUN1(VAR1 *VAR2, void *VAR3, int *VAR4, VAR5 *VAR6)  
{
    const VAR7 *VAR8 = VAR6->VAR3;
    const VAR7 *VAR9 = VAR8 + VAR6->VAR10;
    VAR11 * const VAR12 = VAR2->VAR13;
    int VAR14[8];
    VAR15 *VAR16, *VAR17;
    int VAR18 = 0, VAR19;
    int VAR20, VAR21, VAR22;

    if (VAR6->VAR10 < 2)
        return -1;

    VAR20 = (VAR8[0] + 1) * 8;
    VAR21 = (VAR8[1] + 1) * 8;
    VAR8 += 2;

    if (FUN2(VAR20, VAR21, 0, VAR2))
        return -1;

    if (VAR20 != VAR2->VAR23 || VAR21 != VAR2->VAR24)
        FUN3(VAR2, VAR20, VAR21);

    VAR19 = VAR20 * VAR21;

    VAR16 = FUN4(VAR12->VAR25, VAR20 * VAR21 * 2);
    if (!VAR16)
        return -1;
    VAR12->VAR25 = VAR16;

    VAR17 = FUN4(VAR12->VAR17, VAR20 * VAR21 * 2);
    if (!VAR17)
        return -1;
    VAR12->VAR17 = VAR17;

    for (VAR22 = 0; VAR22 < 8; VAR22++)
        VAR14[VAR22] = -1;

    while (VAR18 < VAR19 && VAR9 - 2 > VAR8) {
        int VAR26 = FUN5(VAR8);
        VAR8 += 2;

        if (!(VAR26 & 0x8000)) {
            VAR16[VAR18++] = VAR26; 
        } else {
            int VAR27;
            VAR15 *VAR28;

            if ((VAR26 & 0x6000) == 0x6000) {
                
                int VAR29 = (VAR26 >> 10) & 7;
                int VAR30;

                VAR27 = (VAR26 & 0x3FF) + 3;

                if (VAR14[VAR29] < 0) {
                    if (VAR9 - 3 < VAR8)
                        break;
                    VAR14[VAR29] = FUN6(VAR8);
                    VAR8 += 3;
                }

                VAR30 = (VAR18 + VAR14[VAR29]) % VAR19;

                if (VAR19 - VAR30 < VAR27)
                    break;

                VAR28 = VAR17 + VAR30;
            } else {
                
                int VAR31 = (VAR26 & 0x1FFF) + 1;

                if (!(VAR26 & 0x6000)) {
                    VAR27 = 2;
                } else if ((VAR26 & 0x6000) == 0x2000) {
                    VAR27 = 3;
                } else {
                    if (VAR9 - 1 < VAR8)
                        break;
                    VAR27 = 4 + *VAR8++;
                }

                if (VAR18 < VAR31)
                    break;

                VAR28 = VAR16 + VAR18 - VAR31;
            }

            if (VAR19 - VAR18 < VAR27)
                break;

            for (VAR22 = 0; VAR22 < VAR27; VAR22++)
                VAR16[VAR18++] = VAR28[VAR22];
        }
    }

    if (VAR18 - VAR19)
        FUN7(VAR2, VAR32, "", VAR18 - VAR19);

    VAR12->VAR33.VAR3[0]     = (VAR7 *)VAR12->VAR25;
    VAR12->VAR33.VAR34[0] = VAR20 * 2;

    *VAR4 = sizeof(VAR35);
    *(VAR35*)VAR3 = VAR12->VAR33;

    FUN8(VAR15 *, VAR12->VAR25, VAR12->VAR17);

    return VAR6->VAR10;
}