static int FUN1(VAR1 *VAR2, int VAR3, int *VAR4, int *VAR5)  
{
	if (*VAR4 >= VAR3)
		return -1;
	if ((VAR2[*VAR4] & 0x80) == 0) {
		*VAR5 = VAR2[*VAR4];
		(*VAR4)++;
		return 0;
	}
	if ((VAR2[*VAR4] & 0x40) == 0) {
		if (*VAR4 == VAR3 - 1)
			return -1;
		*VAR5 = (VAR2[*VAR4] & 0x3F) << 8;
		(*VAR4)++;
		*VAR5 |= VAR2[*VAR4];
		(*VAR4)++;
		return 0;
	}
	*VAR5 = (VAR2[*VAR4] & 0x3F) << 14;
	(*VAR4)++;
	
	if (VAR6) {
		FUN2(VAR7, "");
	}
	return 1;
}