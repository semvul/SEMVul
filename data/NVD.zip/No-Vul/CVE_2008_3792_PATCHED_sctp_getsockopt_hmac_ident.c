static int FUN1(struct VAR1 *VAR2, int VAR3, 				    char VAR4 *VAR5, int VAR4 *VAR6)  
{
	struct sctp_hmacalgo  VAR4 *VAR7 = (void VAR4 *)VAR5;
	struct VAR8 *VAR9;
	__u16 VAR10 = 0;
	u32 VAR11;

	if (!VAR12)
		return -VAR13;

	VAR9 = FUN2(VAR2)->VAR14->VAR15;
	VAR10 = FUN3(VAR9->VAR16.VAR17) - sizeof(VAR18);

	if (VAR3 < sizeof(struct VAR19) + VAR10)
		return -VAR20;

	VAR3 = sizeof(struct VAR19) + VAR10;
	VAR11 = VAR10 / sizeof(VAR21);

	if (FUN4(VAR3, VAR6))
		return -VAR22;
	if (FUN4(VAR11, &VAR7->VAR23))
		return -VAR22;
	if (FUN5(VAR7->VAR24, VAR9->VAR25, VAR10))
		return -VAR22;
	return 0;
}