int FUN1(VAR1 *VAR2, int VAR3 *VAR4, int VAR5, 		  void VAR3 *VAR6, size_t VAR3 *VAR7, 		  void VAR3 *VAR8, size_t VAR9, void **VAR10)  
{
	size_t VAR11, VAR12;
	
	if (!VAR2->VAR13 || !VAR2->VAR14) 
		return -VAR15;
	
	if (VAR6 && VAR7) {
		if (FUN2(VAR12, VAR7))
			return -VAR16;
		if (VAR12) {
			VAR11 = strlen(VAR2->VAR13)+1;
			if (VAR12 > VAR11) VAR12 = VAR11;
			if (VAR12 >= VAR2->VAR14)
				VAR12 = VAR2->VAR14;
			if(FUN3(VAR6, VAR2->VAR13, VAR12))
				return -VAR16;
			if(FUN4(VAR12, VAR7))
				return -VAR16;
		}
	}
	if (VAR8 && VAR9) {
		VAR12 = VAR9;
		if (VAR12 > VAR2->VAR14)
			VAR12 = VAR2->VAR14;
		if(FUN5(VAR2->VAR13, VAR8, VAR12))
			return -VAR16;
		if (VAR12 == VAR2->VAR14)
			VAR12--;
		((char *) VAR2->VAR13)[VAR12] = 0;
	}
	return 0;
}