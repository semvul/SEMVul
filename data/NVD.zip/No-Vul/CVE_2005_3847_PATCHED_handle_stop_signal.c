static void FUN1(int VAR1, struct VAR2 *VAR3)  
{
	struct VAR2 *VAR4;

	if (VAR3->signal->VAR5 & VAR6)
		
		return;

	if (FUN2(VAR1)) {
		
		FUN3(FUN4(VAR7), &VAR3->signal->VAR8);
		VAR4 = VAR3;
		do {
			FUN3(FUN4(VAR7), &VAR4->VAR9);
			VAR4 = FUN5(VAR4);
		} while (VAR4 != VAR3);
	} else if (VAR1 == VAR7) {
		
		if (FUN6(VAR3->signal->VAR10 > 0)) {
			
			VAR3->signal->VAR10 = 0;
			VAR3->signal->VAR5 = VAR11;
			FUN7(&VAR3->VAR12->VAR13);
			if (VAR3->VAR14 & VAR15)
				FUN8(VAR3, VAR3->VAR16,
							 VAR17);
			else
				FUN8(
					VAR3->VAR18,
					VAR3->VAR18->VAR19,
							 VAR17);
			FUN9(&VAR3->VAR12->VAR13);
		}
		FUN3(VAR20, &VAR3->signal->VAR8);
		VAR4 = VAR3;
		do {
			unsigned int VAR21;
			FUN3(VAR20, &VAR4->VAR9);
			
			
			VAR21 = VAR22;
			if (FUN10(VAR4, VAR7) && !FUN11(&VAR4->VAR23, VAR7)) {
				FUN12(VAR4, VAR24);
				VAR21 |= VAR25;
			}
			FUN13(VAR4, VAR21);

			VAR4 = FUN5(VAR4);
		} while (VAR4 != VAR3);

		if (VAR3->signal->VAR5 & VAR26) {
			
			VAR3->signal->VAR5 = VAR11;
			VAR3->signal->VAR27 = 0;
			FUN7(&VAR3->VAR12->VAR13);
			if (VAR3->VAR14 & VAR15)
				FUN8(VAR3, VAR3->VAR16,
							 VAR28);
			else
				FUN8(
					VAR3->VAR18,
					VAR3->VAR18->VAR19,
							 VAR28);
			FUN9(&VAR3->VAR12->VAR13);
		} else {
			
			VAR3->signal->VAR5 = 0;
		}
	} else if (VAR1 == VAR29) {
		
		VAR3->signal->VAR5 = 0;
	}
}