static VAR1 FUN1(VAR2 *VAR3, unsigned argc, VAR4 *VAR5)  
{
    CallArgs VAR6 = FUN2(argc, VAR5);

    
    VAR7 *VAR8 = FUN3(VAR3, VAR6, 0);
    if (!VAR8)
        return false;

    
    FUN4(VAR9::VAR10 <= VAR11);

    
    int VAR12 = VAR8->FUN5();
    const VAR13 *VAR14 = VAR8->FUN6();

    
    VAR15 FUN7(VAR3);

    

    
    int VAR16 = 0;
    bool VAR17 = false;

    while (true) {
        
        if (VAR16 == VAR12) {
            VAR7 *VAR18;
            if (VAR17) {
                VAR18 = VAR19.FUN8();
                if (!VAR18)
                    return false;
            } else {
                VAR18 = VAR8;
            }

            VAR6.FUN9() = FUN10(VAR18);
            return true;
        }

        
        jschar VAR20 = VAR14[VAR16];

        
        if (VAR20 != '')
            goto VAR21;

        
        if (VAR16 > VAR12 - 6)
            goto VAR22;

        
        if (VAR14[VAR16 + 1] != '')
            goto VAR22;

#define VAR23                             \
    VAR24                                  \
        if (!VAR17) {                            \
            VAR17 = true;                        \
            if (!VAR19.FUN11(VAR12))                \
                return false;                       \
            VAR19.FUN12(VAR14, VAR14 + VAR16);  \
        }                                           \
    VAR25

        
        if (FUN13(&VAR14[VAR16 + 2], &VAR20)) {
            VAR23;
            VAR16 += 5;
            goto VAR21;
        }

      VAR22:
        
        if (VAR16 > VAR12 - 3)
            goto VAR21;

        
        if (FUN14(&VAR14[VAR16 + 1], &VAR20)) {
            VAR23;
            VAR16 += 2;
        }

      VAR21:
        if (VAR17)
            VAR19.FUN12(VAR20);

        
        VAR16 += 1;
    }
#undef VAR23
}