static inline __must_check int FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4)  
{
	if (FUN2(VAR2, VAR4))
		return -VAR5;

	FUN3(VAR2, VAR4);
	VAR2->VAR6.VAR7 += VAR4->VAR8;
	return 0;
}