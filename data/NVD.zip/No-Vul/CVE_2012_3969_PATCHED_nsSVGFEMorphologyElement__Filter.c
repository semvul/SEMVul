nsresult VAR1::FUN1(VAR2 *VAR3,                                  const VAR4<const VAR5*>& VAR6,                                  const VAR5* VAR7,                                  const VAR8& VAR9)  
{
  PRInt32 VAR10, VAR11;
  FUN2(&VAR10, &VAR11, *VAR3);

  if (VAR10 < 0 || VAR11 < 0) {
    
    return VAR12;
  }
  if (VAR10 == 0 && VAR11 == 0) {
    return VAR12;
  }

  VAR13* VAR14 = VAR6[0]->VAR15->FUN3();
  VAR13* VAR16 = VAR7->VAR15->FUN3();
  PRInt32 VAR17 = VAR7->VAR15->FUN4();
  PRUint8 VAR18[4];         
  PRUint16 VAR19 = VAR20[VAR21].FUN5();

  
  for (PRInt32 VAR22 = VAR9.VAR22; VAR22 < VAR9.FUN6(); VAR22++) {
    PRInt32 VAR23 = FUN7(0, VAR22 - VAR11);
    
    
    
    PRInt32 VAR24 = FUN8(VAR22 + VAR11, VAR3->FUN9() - 1);
    for (PRInt32 VAR25 = VAR9.VAR25; VAR25 < VAR9.FUN10(); VAR25++) {
      PRInt32 VAR26 = FUN7(0, VAR25 - VAR10);
      PRInt32 VAR27 = FUN8(VAR25 + VAR10, VAR3->FUN11() - 1);
      PRInt32 VAR28 = VAR22 * VAR17 + 4 * VAR25;

      for (PRInt32 VAR29 = 0; VAR29 < 4; VAR29++) {
        VAR18[VAR29] = VAR14[VAR28 + VAR29];
      }
      for (PRInt32 VAR30 = VAR23; VAR30 <= VAR24; VAR30++) {
        for (PRInt32 VAR31 = VAR26; VAR31 <= VAR27; VAR31++) {
          for (PRInt32 VAR29 = 0; VAR29 < 4; VAR29++) {
            PRUint8 VAR32 = VAR14[VAR30 * VAR17 + 4 * VAR31 + VAR29];
            if ((VAR18[VAR29] > VAR32 &&
                 VAR19 == VAR33::VAR34) ||
                (VAR18[VAR29] < VAR32 &&
                 VAR19 == VAR33::VAR35)) {
              VAR18[VAR29] = VAR32;
            }
          }
        }
      }
      VAR16[VAR28  ] = VAR18[0];
      VAR16[VAR28+1] = VAR18[1];
      VAR16[VAR28+2] = VAR18[2];
      VAR16[VAR28+3] = VAR18[3];
    }
  }
  return VAR12;
}