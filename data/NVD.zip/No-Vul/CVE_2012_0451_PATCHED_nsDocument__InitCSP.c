nsresult VAR1::FUN1()  
{
  if (VAR2::VAR3) {
    nsAutoString VAR4;
    nsAutoString VAR5;

    this->FUN2(VAR6::VAR7, VAR4);
    this->FUN2(VAR6::VAR8, VAR5);

    bool system = false;
    VAR9 *VAR10 = VAR11::FUN3();

    if (FUN4(VAR10->FUN5(FUN6(), &system)) && system) {
      
      return VAR12;
    }

    if (VAR4.FUN7() && VAR5.FUN7()) {
      
      return VAR12;
    }

#ifdef VAR13 
    FUN8(VAR14, VAR15, ("", this));
#endif

    nsresult VAR16;
    VAR17<VAR18> VAR19;
    VAR19 = FUN9("", &VAR16);

    if (FUN10(VAR16)) {
#ifdef VAR13 
      FUN8(VAR14, VAR15, ("", VAR16));
#endif
      return VAR16;
    }

    
    VAR17<VAR20> VAR21 = FUN11(VAR22);
    VAR19->FUN12(VAR21);

    
    VAR17<VAR23> VAR24;
    VAR22->FUN13(FUN14(VAR24));

#ifdef VAR13 
    FUN8(VAR14, VAR15, (""));
#endif

    
    
    
    
    if (VAR4.FUN7()) {
      VAR19->FUN15(true);

      
      
      
      VAR25 FUN16(VAR5, '');
      while (VAR26.FUN17()) {
        const VAR27& VAR28 = VAR26.FUN18();
        VAR19->FUN19(VAR28, VAR24);
#ifdef VAR13
        {
          FUN8(VAR14, VAR15,
                  (""%VAR29\"",
                    FUN20(VAR28).FUN21()));
        }
#endif
      }
    } else {
      
      

      
      
      
      VAR25 FUN16(VAR4, '');
      while (VAR26.FUN17()) {
        const VAR27& VAR28 = VAR26.FUN18();
        VAR19->FUN19(VAR28, VAR24);
#ifdef VAR13
        {
          FUN8(VAR14, VAR15,
                (""%VAR29\"",
                  FUN20(VAR28).FUN21()));
        }
#endif
      }
    }

    
    VAR17<VAR30> VAR31 = FUN22(VAR32);
    if (VAR31) {
        bool VAR33 = false;

        
        VAR16 = VAR19->FUN23(VAR31, &VAR33);
        FUN24(VAR16, VAR16);

        if (!VAR33) {
#ifdef VAR13
            FUN8(VAR14, VAR15, 
                   (""));
#endif
            
            VAR22->FUN25(VAR34);
        }
    }

    
    VAR35* VAR36 = FUN26();

    if (VAR36) {
        VAR36->FUN27(VAR19);
#ifdef VAR13
        FUN8(VAR14, VAR15, 
                ("", VAR36));
    }
    else {
      FUN8(VAR14, VAR15, 
              ("", VAR36));
#endif
    }
  }
#ifdef VAR13
  else { 
    FUN8(VAR14, VAR15, 
           ("", this));
  }
#endif
  return VAR12;
}