static int FUN1(VAR1 *VAR2, VAR3 *VAR4, VAR5 *VAR6, int VAR7, VAR8 *usb_trans_info VAR9, VAR10 *usb_conv_info VAR9)  
{
    VAR11 *VAR12           = NULL;
    VAR3 *VAR13           = NULL;
    VAR11 *VAR14 = NULL;
    VAR3 *VAR15 = NULL;
    VAR11 *VAR16;
    VAR3 *VAR17;
    int         VAR18     = VAR7;
    guint8      VAR19;
    guint8      VAR20;
    guint8      VAR21;

    if(VAR4){
        VAR12 = FUN2(VAR4, VAR6, VAR7, -1, "");
        VAR13 = FUN3(VAR12, VAR22);
    }

    VAR21 = FUN4(VAR6, VAR7);
    FUN5(VAR13, VAR6, VAR7);
    VAR7 += 2;

    VAR19 = FUN4(VAR6, VAR7)&0x0f;
    FUN6(VAR13, VAR6, VAR7);
    VAR7 += 1;

    
    if((!VAR2->VAR23->VAR24.VAR25)&&VAR26->VAR27){
        VAR28 *VAR29;

        if(VAR2->VAR30==VAR31){
            static address VAR32;
            static usb_address_t VAR33;

            
            VAR33.VAR34 = ((VAR35 *)(VAR2->VAR36.VAR37))->VAR34;
            VAR33.VAR19 = FUN7(VAR19);
            FUN8(&VAR32, VAR38, VAR39, (char *)&VAR33);
            VAR29 = FUN9(VAR2, &VAR32, &VAR2->VAR40, VAR33.VAR19, VAR2->VAR30);
        } else {
            static address VAR32;
            static usb_address_t VAR33;

            
            VAR33.VAR34 = ((VAR35 *)(VAR2->VAR40.VAR37))->VAR34;
            VAR33.VAR19 = FUN7(VAR19);
            FUN8(&VAR32, VAR38, VAR39, (char *)&VAR33);
            VAR29 = FUN9(VAR2, &VAR2->VAR36, &VAR32, VAR2->VAR41, VAR33.VAR19);
        }

        FUN10(VAR29, VAR42, VAR26->VAR27);
    }

    
    VAR20 = FUN11(FUN4(VAR6, VAR7));
    if (VAR13) {
        VAR14 = FUN12(VAR13, VAR43, VAR6, VAR7, 1, VAR44);
        VAR15 = FUN3(VAR14, VAR45);
    }
    FUN12(VAR15, VAR46, VAR6, VAR7, 1, VAR44);
    
    FUN12(VAR15, VAR47, VAR6, VAR7, 1, VAR44);
    
    FUN12(VAR15, VAR48, VAR6, VAR7, 1, VAR44);
    VAR7 += 1;

    
    VAR16 = FUN12(VAR13, VAR49, VAR6, VAR7, 2, VAR44);
    VAR17 = FUN3(VAR16, VAR50);
    if ((VAR20 == VAR51) || (VAR20 == VAR52)) {
        FUN12(VAR17, VAR53, VAR6, VAR7, 2, VAR44);
    }
    FUN12(VAR17, VAR54, VAR6, VAR7, 2, VAR44);
    VAR7+=2;

    
    FUN12(VAR13, VAR55, VAR6, VAR7, 1, VAR44);
    VAR7 += 1;

    if(VAR12){
        FUN13(VAR12, VAR21);
    }
    if (VAR7 != VAR18 + VAR21) {
        
    }

    return VAR7;
}