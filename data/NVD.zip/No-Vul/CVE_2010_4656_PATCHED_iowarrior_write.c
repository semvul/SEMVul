static VAR1 FUN1(struct VAR2 *VAR2, 			       const char VAR3 *VAR4, 			       size_t VAR5, VAR6 *VAR7)  
{
	struct VAR8 *VAR9;
	int VAR10 = 0;
	char *VAR11 = NULL;	
	struct VAR12 *VAR13 = NULL;

	VAR9 = (struct VAR8 *)VAR2->VAR14;

	FUN2(&VAR9->mutex);
	
	if (!VAR9->VAR15) {
		VAR10 = -VAR16;
		goto VAR17;
	}
	FUN3("", VAR18, VAR9->VAR19, VAR5);
	
	if (VAR5 == 0) {
		VAR10 = 0;
		goto VAR17;
	}
	
	if (VAR5 != VAR9->VAR20) {
		VAR10 = -VAR21;
		goto VAR17;
	}
	switch (VAR9->VAR22) {
	case VAR23:
	case VAR24:
	case VAR25:
	case VAR26:
		
		VAR11 = FUN4(VAR5, VAR27);
		if (!VAR11) {
			VAR10 = -VAR28;
			goto VAR17;
		}
		if (FUN5(VAR11, VAR4, VAR5)) {
			VAR10 = -VAR29;
			FUN6(VAR11);
			goto VAR17;
		}
		VAR10 = FUN7(VAR9->VAR30, 2, 0, VAR11, VAR5);
		FUN6(VAR11);
		goto VAR17;
		break;
	case VAR31:
		
		if (FUN8(&VAR9->VAR32) == VAR33) {
			
			if (VAR2->VAR34 & VAR35) {
				VAR10 = -VAR36;
				goto VAR17;
			} else {
				VAR10 = FUN9(VAR9->VAR37,
								  (!VAR9->VAR15 || (FUN8 (&VAR9-> VAR32) < VAR33)));
				if (VAR10) {
					
					VAR10 = -VAR38;
					goto VAR17;
				}
				if (!VAR9->VAR15) {
					
					VAR10 = -VAR16;
					goto VAR17;
				}
				if (!VAR9->VAR39) {
					
					VAR10 = -VAR16;
					goto VAR17;
				}
			}
		}
		FUN10(&VAR9->VAR32);
		VAR13 = FUN11(0, VAR27);
		if (!VAR13) {
			VAR10 = -VAR28;
			FUN3("", VAR18);
			goto VAR40;
		}
		VAR11 = FUN12(VAR9->VAR41, VAR9->VAR20,
					 VAR27, &VAR13->VAR42);
		if (!VAR11) {
			VAR10 = -VAR28;
			FUN3("", VAR18);
			goto VAR43;
		}
		FUN13(VAR13, VAR9->VAR41,
				 FUN14(VAR9->VAR41,
						VAR9->VAR44->VAR45),
				 VAR11, VAR9->VAR20,
				 VAR46, VAR9,
				 VAR9->VAR44->VAR47);
		VAR13->VAR48 |= VAR49;
		if (FUN5(VAR11, VAR4, VAR5)) {
			VAR10 = -VAR29;
			goto VAR50;
		}
		VAR10 = FUN15(VAR13, VAR27);
		if (VAR10) {
			FUN3("", VAR18,
			    VAR10, FUN8(&VAR9->VAR32));
			goto VAR50;
		}
		
		VAR10 = VAR5;
		FUN16(VAR13);
		goto VAR17;
		break;
	default:
		
		FUN17(&VAR9->VAR30->VAR9, "",
			VAR18, VAR9->VAR22);
		VAR10 = -VAR29;
		goto VAR17;
		break;
	}
VAR50:
	FUN18(VAR9->VAR41, VAR9->VAR20, VAR11,
			  VAR13->VAR42);
VAR43:
	FUN16(VAR13);
VAR40:
	FUN19(&VAR9->VAR32);
	FUN20(&VAR9->VAR37);
VAR17:
	FUN21(&VAR9->mutex);
	return VAR10;
}