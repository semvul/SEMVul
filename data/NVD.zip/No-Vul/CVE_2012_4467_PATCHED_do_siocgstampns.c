static int FUN1(struct VAR1 *VAR1, struct socket *VAR2, 			   unsigned int VAR3, void VAR4 *VAR5)  
{
	mm_segment_t VAR6 = FUN2();
	struct timespec VAR7;
	int VAR8;

	FUN3(VAR9);
	VAR8 = FUN4(VAR1, VAR2, VAR3, (unsigned long)&VAR7);
	FUN3(VAR6);
	if (!VAR8)
		VAR8 = FUN5(&VAR7, VAR5);

	return VAR8;
}