static int FUN1(struct VAR1 *VAR2, void *VAR3)  
{
	long VAR4 = VAR5 >> (VAR6-12);
	struct VAR7 *VAR8;
	int VAR9;
	static char *VAR10[] = { "", "", "", "", "" };

	FUN2(&VAR11);
	FUN3(VAR2, "",
		   VAR4 * VAR12, VAR4, VAR12 / 1024);
	VAR9 = 0;
	FUN4(VAR8, &VAR13, VAR14) {
		VAR9++;
		FUN3(VAR2, "",
			   VAR9, VAR8->VAR15, VAR10[VAR8->VAR16.VAR17.VAR18]);
		FUN3(VAR2, "",
			   (unsigned long)VAR8->VAR16.VAR19,
			   (int)VAR8->VAR16.VAR20);
	}
	FUN5(&VAR11);
	return 0;
}