static inline void FUN1(struct VAR1 *VAR2, const struct VAR3 *VAR4)  
{
	VAR5 *VAR6;
 
	FUN2(8);
	FUN3(VAR7);
	FUN3(VAR4->VAR8->VAR9->VAR10);
	FUN4(VAR2, VAR4->VAR11);
	FUN2(28);
	FUN5(VAR4->VAR12);
	FUN3(16);
	FUN6("", 8);
	FUN5(VAR4->VAR13);
}