static int FUN1(const void *VAR1, int VAR2, int VAR3)  
{
	while (VAR2 >= 0) {
		const struct VAR4 *VAR5 = VAR1;

		if (VAR3 > VAR2)
			return 0;
		if (VAR3 == VAR2)
			return 1;
		if (VAR5->VAR6 < 4 || VAR5->VAR6 & 3)
			return 0;
		VAR2 -= VAR5->VAR6;
		VAR1  += VAR5->VAR6;
	}
	return 0;
}