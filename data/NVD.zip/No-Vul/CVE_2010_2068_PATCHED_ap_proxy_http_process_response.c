static VAR1 FUN1(VAR2 * VAR3, VAR4 *VAR5,                                             VAR6 *VAR7,                                             VAR8 *VAR9,                                             VAR10 *VAR11,                                             char *VAR12)  
{
    VAR8 *VAR13 = VAR5->VAR14;
    char VAR15[VAR16];
    const char *VAR17;
    char VAR18;
    VAR4 *VAR19;
    VAR20 *VAR21;
    VAR22 *VAR23, *VAR24;
    int VAR25, VAR26;
    int VAR27 = 0; 
    int VAR28 = 0;
    VAR29 *VAR30;
    int VAR31 = 0;
    static const char *VAR32[] =
        {"", "", "", "", "", NULL};
    int VAR33;
    const char *VAR34 = NULL;

    VAR23 = FUN2(VAR3, VAR13->VAR35);

    

    VAR19 = FUN3(VAR9, VAR5);
    
    VAR19->VAR36 = VAR37;
    VAR24 = FUN2(VAR3, VAR13->VAR35);
    do {
        apr_status_t VAR38;

        FUN4(VAR23);

        VAR38 = FUN5(VAR24, VAR15, sizeof(VAR15), VAR19, 0, &VAR25);
        if (VAR25 == 0) {
            
            VAR38 = FUN5(VAR24, VAR15, sizeof(VAR15), VAR19, 0, &VAR25);
        }
        if (VAR25 <= 0) {
            FUN6(VAR39, VAR40, VAR38, VAR5,
                          ""
                          "", VAR7->VAR41);
            if (FUN7(VAR38)) {
                FUN6(VAR39, VAR42, 0, VAR5,
                              "");
            }
            
            if (VAR5->VAR36 == VAR43 && VAR13->VAR44 &&
                !FUN7(VAR38)) {
                VAR20 *VAR45;

                FUN6(VAR39, VAR42, 0, VAR5,
                              ""
                              ""
                              "", VAR7->VAR41, 
                              VAR13->VAR44);
                FUN8(VAR5, VAR23);
                
                VAR21 = FUN9(VAR13->VAR35);
                VAR45 = FUN10(VAR23);
                while ((FUN11(VAR23) != VAR45)
                       && !FUN12(VAR45)) {
                    VAR45 = FUN13(VAR45);
                }
                if (VAR45 == FUN11(VAR23)) {
                    FUN14(VAR23, VAR21);
                }
                else {
                    FUN15(VAR45, VAR21);
                }
                FUN16(VAR5->VAR46, VAR23);
                
                VAR7->close = 1;
                
                return VAR47;
            }
            else if (!VAR13->VAR44) {
                     FUN6(VAR39, VAR42, 0, VAR5,
                                   ""
                                   ""
                                   "", VAR7->VAR41);
            }
            return FUN17(VAR5, VAR48,
                                 "");
        }
        
        VAR7->VAR49->VAR50->read += VAR25;

        
        if (FUN18(VAR15, "")) {
            int VAR51, VAR52;

            if (2 != sscanf(VAR15, "", &VAR51, &VAR52)) {
                VAR51 = 1;
                VAR52 = 1;
            }
            
            else if ((VAR15[5] != '') || (VAR25 >= sizeof(VAR15)-1)) {
                return FUN17(VAR5, VAR48,
                FUN19(VAR3, ""
                            "", VAR15, NULL));
            }
            VAR26 = 0;

            VAR18 = VAR15[12];
            VAR15[12] = '';
            VAR5->VAR53 = FUN20(&VAR15[9]);

            if (VAR18 != '') {
                VAR15[12] = VAR18;
            } else {
                
                VAR15[12] = '';
                VAR15[13] = '';
            }
            VAR5->VAR54 = FUN21(VAR3, &VAR15[9]);


            
            
            

            
            VAR30 = FUN22(VAR5->VAR55, 2);
            FUN23(VAR56, VAR30, VAR5->VAR57,
                         "", NULL);

            
            FUN24(VAR5, VAR19, VAR15, sizeof(VAR15), VAR9,
                                  &VAR28);

            if (VAR5->VAR57 == NULL) {
                FUN25(VAR39, VAR58, 0,
                             VAR5->VAR59, ""
                             "", VAR51, VAR52, VAR5->VAR60,
                             VAR5->VAR61);
                VAR7->close += 1;
                
                VAR5->VAR57 = FUN22(VAR5->VAR55,1);
                VAR5->VAR53 = VAR48;
                VAR5->VAR54 = "";
                return VAR5->VAR53;
            }

            
            FUN23(VAR56, VAR30, VAR5->VAR57,
                         "", NULL);

            
            if (!FUN26(VAR30)) {
                FUN27(VAR5->VAR57, "");
                VAR5->VAR57 = FUN28(VAR5->VAR55,
                                                   VAR5->VAR57,
                                                   VAR30);
            }

            
            if (FUN29(VAR5->VAR57, "")
                    && FUN29(VAR5->VAR57, "")) {
                
                FUN27(VAR5->VAR57, "");
                FUN25(VAR39, VAR42, 0, VAR5->VAR59,
                             ""
                             "", VAR7->VAR41);
                VAR7->close += 1;
            }

            
            VAR34 = FUN29(VAR5->VAR57, "");
            
            VAR7->close += FUN30(FUN29(VAR5->VAR57,
                                                             ""),
                                              "");
            FUN31(VAR3, VAR5->VAR57);
            if ((VAR17 = FUN29(VAR5->VAR57, ""))) {
                FUN32(VAR5, FUN21(VAR3, VAR17));
            }
            if (!FUN33(VAR5->VAR53)) {
                FUN34(VAR9, VAR19);
            }

            
            for (VAR33=0; VAR32[VAR33]; ++VAR33) {
                FUN27(VAR5->VAR57, VAR32[VAR33]);
            }
            
            VAR5->VAR57 = FUN35(VAR3, VAR5->VAR57);

            
            if (VAR11->VAR62 != VAR63 && VAR11->VAR62 != VAR64) {
                const char *VAR65 = FUN36(VAR5);
                
                if (VAR65 == VAR5->VAR41)
                    VAR65 = VAR5->VAR59->VAR66;
                
                FUN37(VAR5->VAR57, "",
                               (VAR11->VAR62 == VAR67)
                                     ? FUN38(VAR3, "",
                                           FUN39(VAR5->VAR68),
                                           FUN40(VAR5->VAR68),
                                           VAR65,
                                           VAR12,
                                           VAR69)
                                     : FUN38(VAR3, "",
                                           FUN39(VAR5->VAR68),
                                           FUN40(VAR5->VAR68),
                                           VAR65,
                                           VAR12)
                );
            }

            
            if ((VAR51 < 1) || (VAR52 < 1)) {
                VAR7->close += 1;
                VAR9->VAR70 = VAR71;
            }
        } else {
            
            VAR26 = 1;
            VAR5->VAR53 = 200;
            VAR5->VAR54 = "";
            VAR7->close += 1;
        }

        if (FUN33(VAR5->VAR53)) {
            VAR27++;
        }
        else {
            VAR27 = 0;
        }
        if (VAR27) {
            
            const char *VAR72 = FUN29(VAR5->VAR73,
                                               "");
            FUN25(VAR39, VAR42, 0, NULL,
                         "",
                         VAR5->VAR53);
            if (!VAR72 || !FUN41(VAR72, "")) {
                FUN42(VAR5, 1);
            }
            
            else if (FUN41(VAR72, "")) {
                FUN25(VAR39, VAR58, 0, NULL,
                             "");
            }
        }
        

        if ((VAR5->VAR53 == 401) && (VAR11->VAR74)) {
            const char *VAR17;
            const char *VAR75 = "";
            if ((VAR17 = FUN29(VAR5->VAR57, VAR75))) {
                FUN43(VAR5->VAR76, VAR75, VAR17);
            } else {
                FUN25(VAR39, VAR42, 0, VAR5->VAR59,
                             "");
            }
        }

        VAR5->VAR77 = 1;
        
        if (VAR26 || VAR28) {
            apr_ssize_t VAR78 = (VAR79)VAR28;
            if (VAR26) {
                
                FUN44(VAR15, VAR25);
                VAR78 = (VAR79)VAR25;
            }
            VAR21 = FUN45(VAR15, VAR78, NULL, VAR13->VAR35);
            FUN14(VAR23, VAR21);
        }

        
        if ((!VAR5->VAR80) &&                   
            !VAR27 &&                   
            (VAR5->VAR53 != VAR81) &&      
            (VAR5->VAR53 != VAR82)) {    

            
            VAR19->VAR83 = FUN46(VAR5->VAR55, VAR5->VAR57);
            
            if (VAR34 && !FUN29(VAR19->VAR83, "")) {
                FUN47(VAR19->VAR83, "", VAR34);
            }

            FUN27(VAR5->VAR57,"");

            FUN25(VAR39, VAR42, 0, VAR5->VAR59,
                         "");

            
            if (!VAR11->VAR74 || !FUN48(VAR5->VAR53)) {
                
                apr_read_type_e VAR84 = VAR85;
                int VAR86 = VAR87;

                do {
                    apr_off_t VAR88;
                    apr_status_t VAR89;

                    VAR89 = FUN49(VAR19->VAR90, VAR23,
                                        VAR91, VAR84,
                                        VAR11->VAR92);

                    
                    if (FUN50(VAR89)
                        || (VAR89 == VAR93 && FUN51(VAR23))) {
                        
                        VAR21 = FUN52(VAR13->VAR35);
                        FUN14(VAR23, VAR21);
                        if (FUN16(VAR5->VAR46, VAR23)
                            || VAR13->VAR94) {
                            VAR7->close = 1;
                            break;
                        }
                        FUN4(VAR23);
                        VAR84 = VAR95;
                        continue;
                    }
                    else if (VAR89 == VAR96) {
                        break;
                    }
                    else if (VAR89 != VAR93) {
                        
                        FUN53(VAR39, VAR40, VAR89, VAR13,
                                      "");
                        FUN8(VAR5, VAR23);
                        FUN16(VAR5->VAR46, VAR23);
                        VAR31 = 1;
                        VAR7->close = 1;
                        break;
                    }
                    
                    VAR84 = VAR85;

                    FUN54(VAR23, 0, &VAR88);
                    VAR7->VAR49->VAR50->read += VAR88;
#if VAR97
                    {
                    FUN25(VAR39, VAR42, 0,
                                 VAR5->VAR59, "",
                                 FUN55(), VAR88);
                    }
#endif
                    
                    if (FUN51(VAR23)) {
                        FUN4(VAR23);
                        break;
                    }

                    
                    if (FUN12(FUN10(VAR23))) {
                        
                        VAR86 = VAR98;
                    }

                    
                    if (FUN16(VAR5->VAR46, VAR23) != VAR93
                        || VAR13->VAR94) {
                        
                        VAR7->close = 1;  
                        VAR86 = VAR98;
                    }

                    
                    FUN4(VAR23);

                } while (!VAR86);
            }
            FUN25(VAR39, VAR42, 0, VAR5->VAR59,
                         "");
        }
        else if (!VAR27) {
            FUN25(VAR39, VAR42, 0, VAR5->VAR59,
                         "");

            
            VAR21 = FUN56(VAR13->VAR35);
            FUN14(VAR23, VAR21);
            if (FUN16(VAR5->VAR46, VAR23) != VAR93
                || VAR13->VAR94) {
                
                VAR7->close = 1;  
            }

            FUN4(VAR23);
        }
    } while (VAR27 && (VAR27 < VAR99));

    
    if (VAR27 >= VAR99) {
        return FUN17(VAR5, VAR48,
                             FUN38(VAR3, 
                             "",
                             VAR27));
    }

    
    if (VAR13->VAR94 || VAR31) {
        return VAR100;
    }

    if (VAR11->VAR74) {
        
        if (!FUN48(VAR5->VAR53))
            return VAR47;
        else {
            
            int VAR53 = VAR5->VAR53;
            VAR5->VAR53 = VAR101;
            
            if (!VAR5->VAR80 && 
                (VAR53 != VAR81) && 
                (VAR53 != VAR82)) { 
               FUN57(VAR19);
           }
            return VAR53;
        }
    } else
        return VAR47;
}