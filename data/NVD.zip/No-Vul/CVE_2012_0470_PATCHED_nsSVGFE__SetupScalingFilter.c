VAR1::ScaleInfo VAR2::FUN1(VAR3 *VAR4,                             const VAR5 *VAR6, const VAR5 *VAR7,                             const VAR8& VAR9,                             VAR10 *VAR11)  
{
  ScaleInfo VAR12;
  VAR12.VAR13 = VAR11->FUN2();
  if (!VAR12.VAR13) {
    VAR12.VAR14 = VAR6->VAR15;
    VAR12.VAR16 = VAR7->VAR15;
    VAR12.VAR17 = VAR9;
    return VAR12;
  }

  gfxFloat VAR18 = VAR4->FUN3(VAR19::VAR20,
                                                   VAR11,
                                                   VAR10::VAR21);
  gfxFloat VAR22 = VAR4->FUN3(VAR19::VAR23,
                                                   VAR11,
                                                   VAR10::VAR24);
  if (VAR18 <= 0 || VAR22 <= 0)
    return VAR12;

  bool VAR25 = false;
  gfxIntSize VAR26 =
    VAR19::FUN4(FUN5(VAR7->VAR15->FUN6() / VAR18,
                                             VAR7->VAR15->FUN7() / VAR22),
                                     &VAR25);
  
  
  
  
  if (VAR25 || VAR26.VAR27 <= 0 || VAR26.VAR28 <= 0)
    return VAR12;

  VAR29 FUN8(VAR9.VAR30, VAR9.VAR31, VAR9.VAR27, VAR9.VAR28);
  VAR32.FUN9(1 / VAR18, 1 / VAR22);
  VAR32.FUN10();
  if (!VAR33::FUN11(VAR32, &VAR12.VAR17))
    return VAR12;
  
  VAR12.VAR14 = new FUN12(VAR26,
                                       VAR34::VAR35);
  VAR12.VAR16 = new FUN12(VAR26,
                                       VAR34::VAR35);
  if (!VAR12.VAR14 || VAR12.VAR14->FUN13() ||
      !VAR12.VAR16 || VAR12.VAR16->FUN13()) {
    VAR12.VAR14 = VAR36;
    VAR12.VAR16 = VAR36;
    return VAR12;
  }
  VAR12.VAR37 = VAR7->VAR15;

  VAR38 FUN14(VAR12.VAR14);
  VAR39.FUN15(VAR38::VAR40);
  VAR39.FUN9(double(VAR26.VAR27) / VAR7->VAR15->FUN6(),
            double(VAR26.VAR28) / VAR7->VAR15->FUN7());
  VAR39.FUN16(VAR6->VAR15);
  VAR39.FUN17();

  

  return VAR12;
}