static int FUN1(struct socket *VAR1)  
{
	struct VAR1 *VAR2 = VAR1->VAR2;
	struct VAR3 *VAR4;

	if (!VAR2)
		return 0;

	VAR4 = FUN2(VAR2);

	FUN3(&VAR4->VAR5);

	FUN4(VAR2);

	
	if (VAR4->VAR6) {
		if (VAR4->VAR7) {
			struct VAR8 *VAR9;

			VAR9 = FUN5(&VAR10, VAR4->VAR7);
			if (VAR9) {
				FUN6(VAR9, VAR2);
				FUN7(VAR9);
			}
		} else
			FUN6(NULL, VAR2);
	}

	if (VAR4->VAR11 > 1)
		FUN8(VAR4->VAR12);

	VAR4->VAR7 = 0;
	VAR4->VAR6   = 0;
	VAR4->VAR11   = 0;

	FUN9(VAR2);
	VAR1->VAR2 = NULL;

	FUN10(VAR2);
	FUN11(VAR2);

	return 0;
}