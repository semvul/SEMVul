static int FUN1(VAR1 *VAR2, VAR3 *VAR4, guint VAR5, VAR6 *VAR7, int VAR8, int VAR9)  
{
  gint32 VAR10;
  guint VAR11;
  VAR12 *VAR13, *VAR14, *VAR15, *VAR16, *VAR17, *VAR18;
  VAR6 *VAR19, *VAR20, *VAR21, *VAR22, *VAR23, *VAR24;

  VAR10 = FUN2(VAR2, VAR5);

  VAR13 = FUN3(VAR7, VAR8, VAR2, VAR5, VAR10, VAR25);
  VAR19 = FUN4(VAR13, VAR26);

  FUN3(VAR19, VAR27, VAR2, VAR5, 4, VAR28);

  if (VAR9 > VAR29) {
      FUN5(VAR4, VAR13, VAR30, VAR31, "", VAR29);
      FUN6(VAR32);
  }

  if (VAR10 < 5) {
      FUN5(VAR4, VAR13, VAR30, VAR31, "", VAR10);
      FUN6(VAR32);
  }

  if (VAR10 > VAR33) {
      FUN5(VAR4, VAR13, VAR30, VAR31, "", VAR10);
      FUN6(VAR32);
  }

  if (VAR10 == 5) {
    
    
    FUN3(VAR7, VAR34, VAR2, VAR5, VAR10, VAR25);
    return VAR10;
  }

  VAR11 = VAR5 + VAR10;
  VAR5 += 4;

  VAR14 = FUN3(VAR19, VAR35, VAR2, VAR5, VAR10-5, VAR25);
  VAR20 = FUN4(VAR14, VAR36);

  do {
    
    guint8 VAR37 = -1;  
    gint VAR38 = -1;   
    gint VAR39 = -1;     
    gint VAR40 = -1;   

    VAR37 = FUN7(VAR2, VAR5);
    FUN8(VAR2, VAR5+1, &VAR38);

    VAR15 = FUN3(VAR20, VAR41, VAR2, VAR5+1, VAR38-1, VAR42|VAR25);
    VAR21 = FUN4(VAR15, VAR43);
    FUN3(VAR21, VAR44, VAR2, VAR5, 1, VAR28);

    VAR5 += VAR38+1;

    switch(VAR37) {
      case VAR45:
        FUN3(VAR21, VAR46, VAR2, VAR5, 8, VAR28);
        VAR5 += 8;
        break;
      case VAR47:
      case VAR48:
      case VAR49:
        VAR38 = FUN2(VAR2, VAR5);
        FUN3(VAR21, VAR50, VAR2, VAR5, 4, VAR28);
        FUN3(VAR21, VAR51, VAR2, VAR5+4, VAR38, VAR42|VAR25);
        VAR5 += VAR38+4;
        break;
      case VAR52:
      case VAR53:
        VAR5 += FUN1(VAR2, VAR4, VAR5, VAR21, VAR54, VAR9+1);
        break;
      case VAR55:
        VAR39 = FUN2(VAR2, VAR5);
        
        FUN3(VAR21, VAR56, VAR2, VAR5, 4, VAR28);
        FUN3(VAR21, VAR57, VAR2, VAR5+5, VAR39, VAR25);
        VAR5 += VAR39+5;
        break;
      case VAR58:
      case VAR59:
      case VAR60:
      case VAR61:
        
        break;
      case VAR62:
        VAR16 = FUN3(VAR21, VAR63, VAR2, VAR5, 12, VAR25);
        VAR22 = FUN4(VAR16, VAR64);
        
        FUN3(VAR22, VAR65, VAR2, VAR5, 4, VAR66);
        FUN3(VAR22, VAR67, VAR2, VAR5+4, 3, VAR28);
        FUN3(VAR22, VAR68, VAR2, VAR5+7, 2, VAR28);
        FUN3(VAR22, VAR69, VAR2, VAR5+9, 3, VAR66);
        VAR5 += 12;
        break;
      case VAR70:
        FUN3(VAR21, VAR71, VAR2, VAR5, 1, VAR25);
        VAR5 += 1;
        break;
      case VAR72:
        
        FUN8(VAR2, VAR5, &VAR38);
        FUN3(VAR21, VAR73, VAR2, VAR5, VAR38, VAR42|VAR25);
        VAR5 += VAR38;
        
        FUN8(VAR2, VAR5, &VAR38);
        FUN3(VAR21, VAR74, VAR2, VAR5, VAR38, VAR42|VAR25);
        VAR5 += VAR38;
        break;
      case VAR75:
        VAR38 = FUN2(VAR2, VAR5);
        FUN3(VAR21, VAR50, VAR2, VAR5, 4, VAR28);
        FUN3(VAR21, VAR51, VAR2, VAR5+4, VAR38, VAR42|VAR25);
        VAR5 += VAR38;
        FUN3(VAR21, VAR76, VAR2, VAR5, 12, VAR25);
        VAR5 += 12;
        break;
      case VAR77:
        
        FUN3(VAR21, VAR78, VAR2, VAR5, 4, VAR28);
        VAR39 = FUN2(VAR2, VAR5);
        VAR5 += 4;
        VAR38 = FUN2(VAR2, VAR5);
        VAR17 = FUN3(VAR21, VAR79, VAR2, VAR5, VAR38+4, VAR25);
        VAR23 = FUN4(VAR17, VAR80);
        FUN3(VAR23, VAR50, VAR2, VAR5, 4, VAR28);
        FUN3(VAR23, VAR51, VAR2, VAR5+4, VAR38, VAR42|VAR25);
        VAR5 += VAR38+4;
        VAR40 = VAR39 - (VAR38 + 8);
        VAR18 = FUN3(VAR21, VAR81, VAR2, VAR5, VAR40, VAR25);
        VAR24 = FUN4(VAR18, VAR80);
        VAR5 += FUN1(VAR2, VAR4, VAR5, VAR24, VAR54, VAR9+1);
        break;
      case VAR82:
        FUN3(VAR21, VAR83, VAR2, VAR5, 4, VAR28);
        VAR5 += 4;
        break;
      case VAR84:
      case VAR85:
        
        
      case VAR86:
        FUN3(VAR21, VAR87, VAR2, VAR5, 8, VAR28);
        VAR5 += 8;
        break;
      default:
        break;
    }  
  } while (VAR5 < VAR11-1);

  return VAR10;
}