void FUN1()
{
    void * VAR1;
    VAR1 = NULL;
    
    VAR1 = (void *)VAR2;
    FUN2(&VAR1);
}