static void FUN1(VAR1 *VAR2, gint VAR3, VAR4 *VAR5, VAR6 *VAR7)  
{
   VAR6 *VAR8 = 0, *VAR9, *VAR10, *VAR11,
      *VAR12;
   VAR1 *VAR13;
   VAR14 *VAR15 = NULL, *VAR16 = NULL;
   char VAR17[200];
   int VAR18 = sizeof(VAR17)-1;
   int VAR19;

   guint VAR20 = FUN2(VAR2)-VAR3;

   if( VAR7 )
   {
      VAR15 = FUN3(VAR7, VAR21, VAR2, VAR3, VAR20, VAR22);
      FUN4(VAR15, "");

      VAR16 = FUN5(VAR15);
      FUN6(VAR16,"");
   }

   if( VAR20 >= VAR23 )
   {
      ETHERCAT_EOE_HEADER VAR24;
      FUN7(&VAR24, VAR2, VAR3);
      if ( VAR24.VAR25.VAR26.VAR27 == VAR28 )
         FUN8 ( VAR17, VAR18, "", VAR24.VAR29.VAR26.VAR30);
      else
         FUN8 ( VAR17, VAR18, "");
         FUN9(VAR5->VAR31, VAR32, VAR17);

      { 
         VAR8 = FUN10(VAR15, VAR33);

         VAR15 = FUN3(VAR8, VAR34, VAR2, VAR3, 4, VAR22);
         FUN4(VAR15, "");
         VAR9 = FUN10(VAR15, VAR35);

         VAR15 = FUN11(VAR9, VAR36, VAR2, VAR3, 4, VAR24.VAR25.VAR26.VAR27);
         FUN12(&VAR24, VAR17, VAR18);
         FUN4(VAR15, "", VAR17);

         switch ( VAR24.VAR25.VAR26.VAR27 )
         {
         case VAR28:
            VAR15 = FUN11(VAR9, VAR37, VAR2, VAR3, 4, VAR24.VAR29.VAR26.VAR30);
            FUN13(&VAR24, VAR17, VAR18);
            FUN4(VAR15, "", VAR17);

            VAR15 = FUN11(VAR9, VAR38, VAR2, VAR3, 4, 32*VAR24.VAR29.VAR26.VAR39);
            FUN14(&VAR24, VAR17, VAR18);
            FUN4(VAR15, "", VAR17);

            VAR15 = FUN11(VAR9, VAR40, VAR2, VAR3, 4, VAR24.VAR29.VAR26.VAR41);
            FUN15(&VAR24, VAR17, VAR18);
            FUN4(VAR15, "", VAR17);

            VAR15 = FUN11(VAR9, VAR42, VAR2, VAR3, 4, VAR24.VAR25.VAR26.VAR43);
            FUN16(&VAR24, VAR17, VAR18);
            FUN4(VAR15, "", VAR17);

            if ( VAR24.VAR25.VAR26.VAR44 )
            {
               VAR15 = FUN11(VAR9, VAR45, VAR2, VAR3, 4, VAR24.VAR25.VAR26.VAR44);
               FUN4(VAR15, "");
            }

            if ( VAR24.VAR25.VAR26.VAR46 )
            {
               VAR15 = FUN11(VAR9, VAR47, VAR2, VAR3, 4, VAR24.VAR25.VAR26.VAR46);
               FUN4(VAR15, "");
            }

            VAR3+=VAR23;
            FUN3(VAR8, VAR48, VAR2, VAR3, VAR20-VAR3, VAR22);

            if ( VAR24.VAR29.VAR26.VAR30 == 0 )
            {
               VAR13 = FUN17(VAR2, VAR3, VAR20-VAR3, VAR20-VAR3);
               FUN18( VAR49, VAR13, VAR5, VAR8);
            }

            if ( VAR24.VAR25.VAR26.VAR46 )
            {
               FUN3(VAR8, VAR50, VAR2, VAR20-VAR51, VAR51, VAR52);
            }
            break;

         case VAR53:
            FUN3(VAR8, VAR50, VAR2, VAR3+VAR23, VAR51, VAR52);
            break;

         case VAR54:
            VAR3+=VAR23;
            VAR15 = FUN3(VAR9, VAR55, VAR2, VAR3, FUN19(VAR20-VAR3,VAR56), VAR22);
            if( VAR20-VAR3 >= VAR56 )
            {
               VAR10 = FUN10(VAR15, VAR57);

               FUN3(VAR10, VAR58, VAR2, VAR3, 4, VAR52);
               FUN3(VAR10, VAR59, VAR2, VAR3, 4, VAR52);
               FUN3(VAR10, VAR60, VAR2, VAR3, 4, VAR52);
               FUN3(VAR10, VAR61, VAR2, VAR3, 4, VAR52);
               FUN3(VAR10, VAR62, VAR2, VAR3, 4, VAR52);
               FUN3(VAR10, VAR63, VAR2, VAR3, 4, VAR52);
               FUN3(VAR10, VAR64, VAR2, VAR3, 4, VAR52);
               VAR3+=4;

               FUN3(VAR10, VAR65, VAR2, VAR3, VAR66, VAR22);
               VAR3+=VAR66;

               FUN3(VAR10, VAR67, VAR2, VAR3, 4, VAR52);
               VAR3+=4;

               FUN3(VAR10, VAR68, VAR2, VAR3, 4, VAR52);
               VAR3+=4;

               FUN3(VAR10, VAR69, VAR2, VAR3, 4, VAR52);
               VAR3+=4;

               FUN3(VAR10, VAR70, VAR2, VAR3, 4, VAR52);
               VAR3+=4;

               FUN3(VAR10, VAR71, VAR2, VAR3, 32, VAR72|VAR22);
            }
            else
               FUN6(VAR15, "");
            break;

         case VAR73:
            {
               EoeMacFilterOptionsUnion VAR74;
               VAR3+=VAR23;
               VAR15 = FUN3(VAR9, VAR75, VAR2, VAR3, FUN19(VAR20-VAR3, VAR76), VAR22);
               if( VAR20-VAR3 >= VAR76 )
               {
                  VAR6 *VAR77;

                  VAR11 = FUN10(VAR15, VAR78);

                  
                  
                  
                  
                  
                  
                  FUN3(VAR11, VAR79, VAR2, VAR3,  2, VAR52);
                  FUN3(VAR11, VAR80, VAR2, VAR3,  2, VAR52);
                  FUN3(VAR11, VAR81, VAR2, VAR3,  2, VAR52);
                  VAR74.VAR82 = FUN20(VAR2, VAR3);
                  VAR3+= 2;

                  VAR15 = FUN3(VAR11, VAR83, VAR2, VAR3, 16*VAR66, VAR22);
                  VAR12 = FUN10(VAR15, VAR84);
                  for( VAR19=0; VAR19<VAR74.VAR26.VAR85; VAR19++)
                     FUN3(VAR12, VAR86[VAR19], VAR2, VAR3+VAR19*VAR66, VAR66, VAR22);
                  VAR3+=16*VAR66;

                  VAR15 = FUN3(VAR11, VAR87, VAR2, VAR3, 4*sizeof(VAR88), VAR22);
                  VAR77 = FUN10(VAR15, VAR89);
                  for( VAR19=0; VAR19<VAR74.VAR26.VAR90; VAR19++)
                     FUN3(VAR77, VAR91[VAR19], VAR2, VAR3+VAR19*sizeof(VAR88), sizeof(VAR88), VAR22);
               }
               else
                  FUN6(VAR15, "");
            }
            break;

         case VAR92:
         case VAR93:
            break;
         }
      }

      FUN21(VAR5->VAR31, VAR32, "");

      FUN21(VAR5->VAR31, VAR94, "");
   }
   else
   {
      FUN9(VAR5->VAR31, VAR32, "");
   }
}