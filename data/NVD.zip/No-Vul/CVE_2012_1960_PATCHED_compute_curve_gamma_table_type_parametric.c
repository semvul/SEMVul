void FUN1(float VAR1[256], float VAR2[7], int VAR3)  
{
        size_t VAR4;
        float VAR5;
        float VAR6, VAR7, VAR8, VAR9, VAR10;
        float VAR11 = VAR2[0];
        if (VAR3 == 0) {
                VAR6 = 1;
                VAR7 = 0;
                VAR8 = 0;
                VAR9 = 0;
                VAR10 = 0;
                VAR5 = -VAR12;
        } else if(VAR3 == 1) {
                VAR6 = VAR2[1];
                VAR7 = VAR2[2];
                VAR8 = 0;
                VAR9 = 0;
                VAR10 = 0;
                VAR5 = -1 * VAR2[2] / VAR2[1];
        } else if(VAR3 == 2) {
                VAR6 = VAR2[1];
                VAR7 = VAR2[2];
                VAR8 = 0;
                VAR9 = VAR2[3];
                VAR10 = VAR2[3];
                VAR5 = -1 * VAR2[2] / VAR2[1];
        } else if(VAR3 == 3) {
                VAR6 = VAR2[1];
                VAR7 = VAR2[2];
                VAR8 = VAR2[3];
                VAR9 = -VAR8;
                VAR10 = 0;
                VAR5 = VAR2[4];
        } else if(VAR3 == 4) {
                VAR6 = VAR2[1];
                VAR7 = VAR2[2];
                VAR8 = VAR2[3];
                VAR9 = VAR2[5] - VAR8;
                VAR10 = VAR2[6];
                VAR5 = VAR2[4];
        } else {
                assert(0 && "");
                VAR6 = 1;
                VAR7 = 0;
                VAR8 = 0;
                VAR9 = 0;
                VAR10 = 0;
                VAR5 = -VAR12;
        }       
        for (VAR4 = 0; VAR4 < 256; VAR4++) {
                if (VAR4 >= VAR5) {
                        
                        
                        
                        VAR1[VAR4] = FUN2(FUN3(VAR6 * VAR4 / 255. + VAR7, VAR11) + VAR8 + VAR9);
                } else {
                        VAR1[VAR4] = FUN2(VAR8 * VAR4 / 255. + VAR10);
                }
        }
}