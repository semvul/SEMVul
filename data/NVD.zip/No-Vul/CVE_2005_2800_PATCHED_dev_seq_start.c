static void * FUN1(struct VAR1 *VAR2, VAR3 *VAR4)  
{
	struct VAR5 * VAR6 = FUN2(sizeof(*VAR6), VAR7);

	VAR2->private = VAR6;
	if (! VAR6)
		return NULL;

	if (NULL == VAR8)
		return NULL;
	VAR6->VAR9 = *VAR4;
	VAR6->VAR10 = FUN3();
	if (VAR6->VAR9 >= VAR6->VAR10)
		return NULL;
	return VAR6;
}