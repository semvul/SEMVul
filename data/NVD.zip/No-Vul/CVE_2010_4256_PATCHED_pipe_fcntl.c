long FUN1(struct VAR1 *VAR1, unsigned int VAR2, unsigned long VAR3)  
{
	struct VAR4 *VAR5;
	long VAR6;

	VAR5 = FUN2(VAR1);
	if (!VAR5)
		return -VAR7;

	FUN3(&VAR5->VAR8->VAR9);

	switch (VAR2) {
	case VAR10: {
		unsigned int VAR11, VAR12;

		VAR11 = FUN4(VAR3);
		VAR12 = VAR11 >> VAR13;

		VAR6 = -VAR14;
		if (!VAR12)
			goto VAR15;

		if (!FUN5(VAR16) && VAR11 > VAR17) {
			VAR6 = -VAR18;
			goto VAR15;
		}
		VAR6 = FUN6(VAR5, VAR12);
		break;
		}
	case VAR19:
		VAR6 = VAR5->VAR20 * VAR21;
		break;
	default:
		VAR6 = -VAR14;
		break;
	}

VAR15:
	FUN7(&VAR5->VAR8->VAR9);
	return VAR6;
}