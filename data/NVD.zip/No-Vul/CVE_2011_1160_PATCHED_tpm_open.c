int FUN1(struct VAR1 *VAR1, struct VAR2 *VAR2)  
{
	int VAR3 = FUN2(VAR1);
	struct VAR4 *VAR5 = NULL, *VAR6;

	FUN3();
	FUN4(VAR6, &VAR7, VAR8) {
		if (VAR6->VAR9.VAR10.VAR3 == VAR3) {
			VAR5 = VAR6;
			FUN5(VAR5->VAR11);
			break;
		}
	}
	FUN6();

	if (!VAR5)
		return -VAR12;

	if (FUN7(0, &VAR5->VAR13)) {
		FUN8(VAR5->VAR11, "");
		FUN9(VAR5->VAR11);
		return -VAR14;
	}

	VAR5->VAR15 = FUN10(VAR16, VAR17);
	if (VAR5->VAR15 == NULL) {
		FUN11(0, &VAR5->VAR13);
		FUN9(VAR5->VAR11);
		return -VAR18;
	}

	FUN12(&VAR5->VAR19, 0);

	VAR2->VAR20 = VAR5;
	return 0;
}