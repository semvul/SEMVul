static struct VAR1 *FUN1(unsigned long VAR2)  
{
	struct VAR1 *new;
	unsigned long VAR3 = VAR2*sizeof(struct VAR4 *);

	if (VAR5/sizeof(struct VAR4 *) < VAR2)
		return NULL;

	new = FUN2(sizeof(struct VAR1), VAR6);
	if (new == NULL)
		return NULL;

	new->VAR7 = FUN3();

	if (new->VAR7 < 0) {
		FUN4(new);
		return NULL;
	}

	FUN5(VAR3, new);

	if (new->VAR8 == NULL) {
		FUN6(new->VAR7);
		FUN4(new);
		return NULL;
	}
	new->VAR9 = 0;
	return new;
}