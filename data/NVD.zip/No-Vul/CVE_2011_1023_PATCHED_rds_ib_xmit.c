int FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4, 		unsigned int VAR5, unsigned int VAR6, unsigned int VAR7)  
{
	struct VAR8 *VAR9 = VAR2->VAR10;
	struct VAR11 *VAR12 = VAR9->VAR13->VAR14;
	struct VAR15 *send = NULL;
	struct VAR15 *VAR16;
	struct VAR15 *VAR17;
	struct VAR18 *VAR19;
	struct VAR20 *VAR21;
	u32 VAR22;
	u32 VAR23;
	u32 VAR24;
	u32 VAR25 = 0;
	u32 VAR26;
	u32 VAR27 = 0;
	int VAR28 = 0;
	int VAR29 = 0;
	int VAR30;
	int VAR31 = 0;
	int VAR32 = 0;

	FUN2(VAR7 % VAR33);
	FUN2(VAR5 != 0 && VAR5 != sizeof(struct VAR34));

	
	if (VAR2->VAR35
	    && VAR4->VAR36.VAR37.VAR38 & VAR39) {
		FUN3(VAR2->VAR40, ~(VAR41) 0);
		VAR21 = &VAR4->VAR42.VAR43[VAR6];
		VAR30 = sizeof(struct VAR34) + VAR44;
		VAR30 = FUN4(int, VAR30, VAR21->VAR45 - VAR2->VAR46);
		return VAR30;
	}

	
	if (FUN5(VAR4->VAR36.VAR37.VAR47) == 0)
		VAR23 = 1;
	else
		VAR23 = FUN6(FUN5(VAR4->VAR36.VAR37.VAR47), VAR33);

	VAR24 = FUN7(&VAR9->VAR48, VAR23, &VAR22);
	if (VAR24 == 0) {
		FUN8(VAR49, &VAR2->VAR50);
		FUN9(VAR51);
		VAR30 = -VAR52;
		goto VAR53;
	}

	if (VAR9->VAR54) {
		VAR25 = FUN10(VAR9, VAR24, &VAR26, 0, VAR55);
		VAR27 += VAR26;
		if (VAR25 < VAR24) {
			FUN11(&VAR9->VAR48, VAR24 - VAR25);
			VAR24 = VAR25;
			VAR31 = 1;
		}
		if (VAR24 == 0) {
			FUN8(VAR49, &VAR2->VAR50);
			FUN9(VAR56);
			VAR30 = -VAR52;
			goto VAR53;
		}
	}

	
	if (!VAR9->VAR57) {
		if (VAR4->VAR42.VAR58) {
			VAR4->VAR42.VAR59 = FUN12(VAR12,
							  VAR4->VAR42.VAR43,
							  VAR4->VAR42.VAR58,
							  VAR60);
			FUN13("", VAR9, VAR4, VAR4->VAR42.VAR59);
			if (VAR4->VAR42.VAR59 == 0) {
				FUN9(VAR61);
				FUN11(&VAR9->VAR48, VAR24);
				VAR30 = -VAR52; 
				goto VAR53;
			}
		} else {
			VAR4->VAR42.VAR59 = 0;
		}

		FUN14(VAR4);
		VAR9->VAR57 = &VAR4->VAR42;

		
		if (FUN15(VAR62, &VAR4->VAR63))
			VAR4->VAR36.VAR37.VAR38 |= VAR64;
		if (FUN15(VAR65, &VAR4->VAR63))
			VAR4->VAR36.VAR37.VAR38 |= VAR66;

		
		if (VAR4->VAR67.VAR68) {
			struct rds_ext_header_rdma VAR69;

			VAR69.VAR70 = FUN16(VAR4->VAR67.VAR71);
			FUN17(&VAR4->VAR36.VAR37,
					VAR72, &VAR69, sizeof(VAR69));
		}
		if (VAR4->VAR73) {
			FUN18(&VAR4->VAR36.VAR37,
					FUN19(VAR4->VAR73),
					FUN20(VAR4->VAR73));
		}

		
		VAR4->VAR36.VAR37.VAR74 = FUN21(FUN22(VAR9));
		FUN23(&VAR4->VAR36.VAR37);

		
		if (VAR9->VAR54) {
			FUN10(VAR9, 0, &VAR26, 1, VAR55 - VAR27);
			VAR27 += VAR26;
			FUN2(VAR27 > 255);
		}
	}

	
	if (VAR4->VAR67.VAR68 && VAR4->VAR67.VAR75)
		VAR28 = VAR76;

	
	send = &VAR9->VAR77[VAR22];
	VAR16 = send;
	VAR17 = NULL;
	VAR21 = &VAR9->VAR57->VAR43[VAR6];
	VAR23 = 0;
	do {
		unsigned int VAR78 = 0;

		
		send->VAR79.VAR28 = VAR28;
		send->VAR79.VAR80 = VAR81;
		send->VAR79.VAR82 = 1;
		send->VAR79.VAR83 = NULL;
		send->VAR84 = VAR85;
		send->VAR86 = NULL;

		send->VAR87[0].VAR88 = VAR9->VAR89
			+ (VAR22 * sizeof(struct VAR34));
		send->VAR87[0].VAR45 = sizeof(struct VAR34);

		memcpy(&VAR9->VAR90[VAR22], &VAR4->VAR36.VAR37, sizeof(struct VAR34));

		
		if (VAR23 < VAR24
		    && VAR21 != &VAR4->VAR42.VAR43[VAR4->VAR42.VAR59]) {
			VAR78 = FUN24(VAR33, FUN25(VAR12, VAR21) - VAR7);
			send->VAR79.VAR82 = 2;

			send->VAR87[1].VAR88 = FUN26(VAR12, VAR21) + VAR7;
			send->VAR87[1].VAR45 = VAR78;

			VAR29 += VAR78;
			VAR7 += VAR78;
			if (VAR7 == FUN25(VAR12, VAR21)) {
				VAR21++;
				VAR7 = 0;
			}
		}

		FUN27(VAR9, send, 0);

		
		if (VAR9->VAR54 && VAR31 && VAR23 == (VAR24-1))
			send->VAR79.VAR28 |= VAR91 | VAR92;

		if (send->VAR79.VAR28 & VAR91)
			VAR32++;

		FUN13("", send,
			 &send->VAR79, send->VAR79.VAR82, send->VAR79.VAR83);

		if (VAR9->VAR54 && VAR27) {
			struct VAR34 *VAR93 = &VAR9->VAR90[VAR22];

			
			VAR93->VAR94 = VAR27;
			FUN23(VAR93);
			VAR27 = 0;
			FUN9(VAR95);
		}

		if (VAR17)
			VAR17->VAR79.VAR83 = &send->VAR79;
		VAR17 = send;

		VAR22 = (VAR22 + 1) % VAR9->VAR48.VAR96;
		send = &VAR9->VAR77[VAR22];
		VAR23++;

	} while (VAR23 < VAR24
		 && VAR21 != &VAR4->VAR42.VAR43[VAR4->VAR42.VAR59]);

	
	if (VAR5 == 0)
		VAR29 += sizeof(struct VAR34);

	
	if (VAR21 == &VAR4->VAR42.VAR43[VAR4->VAR42.VAR59]) {
		VAR17->VAR86 = VAR9->VAR57;
		VAR17->VAR79.VAR28 |= VAR92;
		VAR9->VAR57 = NULL;
	}

	
	if (VAR23 < VAR24) {
		FUN11(&VAR9->VAR48, VAR24 - VAR23);
		VAR24 = VAR23;
	}
	if (VAR9->VAR54 && VAR23 < VAR25)
		FUN28(VAR2, VAR25 - VAR23);

	if (VAR32)
		FUN29(VAR32, &VAR9->VAR97);

	
	VAR19 = &VAR16->VAR79;
	VAR30 = FUN30(VAR9->VAR13->VAR98, &VAR16->VAR79, &VAR19);
	FUN13("", VAR9,
		 VAR16, &VAR16->VAR79, VAR30, VAR19);
	FUN2(VAR19 != &VAR16->VAR79);
	if (VAR30) {
		FUN31(VAR99 ""
		       "", &VAR2->VAR100, VAR30);
		FUN11(&VAR9->VAR48, VAR24);
		FUN32(VAR9, VAR32);
		if (VAR17->VAR86) {
			VAR9->VAR57 = VAR17->VAR86;
			VAR17->VAR86 = NULL;
		}

		FUN33(VAR9->VAR2, "");
		goto VAR53;
	}

	VAR30 = VAR29;
VAR53:
	FUN2(VAR27);
	return VAR30;
}