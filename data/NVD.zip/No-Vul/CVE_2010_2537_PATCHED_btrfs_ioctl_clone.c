static noinline long FUN1(struct VAR1 *VAR1, unsigned long VAR2, 				       u64 VAR3, u64 VAR4, u64 VAR5)  
{
	struct VAR6 *VAR6 = FUN2(VAR1)->VAR7;
	struct VAR8 *VAR9 = FUN3(VAR6)->VAR9;
	struct VAR1 *VAR10;
	struct VAR6 *VAR11;
	struct VAR12 *VAR13;
	struct VAR14 *VAR15;
	struct VAR16 *VAR17;
	char *VAR18;
	struct btrfs_key VAR19;
	u32 VAR20;
	int VAR21;
	int VAR22;
	u64 VAR23 = VAR4;
	u64 VAR24 = VAR9->VAR25->VAR26->VAR27;
	u64 VAR28;

	

	
	if (!(VAR1->VAR29 & VAR30) || (VAR1->VAR31 & VAR32))
		return -VAR33;

	VAR22 = FUN4(VAR1->VAR34.VAR35);
	if (VAR22)
		return VAR22;

	VAR10 = FUN5(VAR2);
	if (!VAR10) {
		VAR22 = -VAR36;
		goto VAR37;
	}

	VAR11 = VAR10->VAR38->VAR7;

	VAR22 = -VAR33;
	if (VAR11 == VAR6)
		goto VAR39;

	
	if (!(VAR10->VAR29 & VAR40))
		goto VAR39;

	VAR22 = -VAR41;
	if (FUN6(VAR11->VAR42) || FUN6(VAR6->VAR42))
		goto VAR39;

	VAR22 = -VAR43;
	if (VAR11->VAR44 != VAR6->VAR44 || FUN3(VAR11)->VAR9 != VAR9)
		goto VAR39;

	VAR22 = -VAR45;
	VAR18 = FUN7(FUN8(VAR9, 0));
	if (!VAR18)
		goto VAR39;

	VAR15 = FUN9();
	if (!VAR15) {
		FUN10(VAR18);
		goto VAR39;
	}
	VAR15->VAR46 = 2;

	if (VAR6 < VAR11) {
		FUN11(&VAR6->VAR47);
		FUN11(&VAR11->VAR47);
	} else {
		FUN11(&VAR11->VAR47);
		FUN11(&VAR6->VAR47);
	}

	
	VAR22 = -VAR33;
	if (VAR3 + VAR23 > VAR11->VAR48 || VAR3 + VAR23 < VAR3)
		goto VAR49;
	if (VAR23 == 0)
		VAR4 = VAR23 = VAR11->VAR48 - VAR3;
	
	if (VAR3 + VAR23 == VAR11->VAR48)
		VAR23 = ((VAR11->VAR48 + VAR24-1) & ~(VAR24-1))
			- VAR3;

	
	if ((VAR3 & (VAR24-1)) ||
	    ((VAR3 + VAR23) & (VAR24-1)))
		goto VAR49;

	
	while (1) {
		struct VAR50 *VAR51;
		FUN12(&FUN3(VAR11)->VAR52, VAR3, VAR3+VAR23, VAR53);
		VAR51 = FUN13(VAR6, VAR3+VAR23);
		if (FUN3(VAR11)->VAR54 == 0 && !VAR51)
			break;
		FUN14(&FUN3(VAR11)->VAR52, VAR3, VAR3+VAR23, VAR53);
		if (VAR51)
			FUN15(VAR51);
		FUN16(VAR11, VAR3, VAR3+VAR23);
	}

	VAR13 = FUN17(VAR9, 1);
	FUN18(!VAR13);

	
	FUN19(VAR13, VAR6, VAR3, VAR3 + VAR23, &VAR28, 1);

	
	VAR19.VAR55 = VAR11->VAR56;
	VAR19.VAR57 = VAR58;
	VAR19.VAR59 = 0;

	while (1) {
		
		VAR22 = FUN20(VAR13, VAR9, &VAR19, VAR15, 0, 0);
		if (VAR22 < 0)
			goto VAR60;

		VAR20 = FUN21(VAR15->VAR61[0]);
		if (VAR15->VAR62[0] >= VAR20) {
			VAR22 = FUN22(VAR9, VAR15);
			if (VAR22 < 0)
				goto VAR60;
			if (VAR22 > 0)
				break;
			VAR20 = FUN21(VAR15->VAR61[0]);
		}
		VAR17 = VAR15->VAR61[0];
		VAR21 = VAR15->VAR62[0];

		FUN23(VAR17, &VAR19, VAR21);
		if (FUN24(&VAR19) > VAR58 ||
		    VAR19.VAR55 != VAR11->VAR56)
			break;

		if (FUN24(&VAR19) == VAR58) {
			struct VAR63 *VAR64;
			int VAR57;
			u32 VAR65;
			struct btrfs_key VAR66;
			u64 VAR67 = 0, VAR68 = 0;
			u64 VAR69 = 0, VAR70 = 0;
			u8 VAR71;

			VAR65 = FUN25(VAR17, VAR21);
			FUN26(VAR17, VAR18,
					   FUN27(VAR17, VAR21),
					   VAR65);

			VAR64 = FUN28(VAR17, VAR21,
						struct VAR63);
			VAR71 = FUN29(VAR17, VAR64);
			VAR57 = FUN30(VAR17, VAR64);
			if (VAR57 == VAR72 ||
			    VAR57 == VAR73) {
				VAR67 = FUN31(VAR17,
								      VAR64);
				VAR68 = FUN32(VAR17,
								 VAR64);
				VAR69 = FUN33(VAR17, VAR64);
				VAR70 = FUN34(VAR17,
								    VAR64);
			} else if (VAR57 == VAR74) {
				
				VAR70 = FUN35(VAR17,
								    VAR64);
			}
			FUN36(VAR9, VAR15);

			if (VAR19.VAR59 + VAR70 < VAR3 ||
			    VAR19.VAR59 >= VAR3+VAR23)
				goto VAR75;

			memcpy(&VAR66, &VAR19, sizeof(VAR66));
			VAR66.VAR55 = VAR6->VAR56;
			VAR66.VAR59 = VAR19.VAR59 + VAR5 - VAR3;

			if (VAR57 == VAR72 ||
			    VAR57 == VAR73) {
				VAR22 = FUN37(VAR13, VAR9, VAR15,
							      &VAR66, VAR65);
				if (VAR22)
					goto VAR60;

				VAR17 = VAR15->VAR61[0];
				VAR21 = VAR15->VAR62[0];
				FUN38(VAR17, VAR18,
					    FUN27(VAR17, VAR21),
					    VAR65);

				VAR64 = FUN28(VAR17, VAR21,
						struct VAR63);

				if (VAR3 > VAR19.VAR59) {
					VAR69 += VAR3 - VAR19.VAR59;
					VAR70 -= VAR3 - VAR19.VAR59;
				}

				if (VAR19.VAR59 + VAR70 > VAR3 + VAR23)
					VAR70 = VAR3 + VAR23 - VAR19.VAR59;

				
				if (!VAR67)
					VAR69 = 0;

				FUN39(VAR17, VAR64,
							     VAR69);
				FUN40(VAR17, VAR64,
								VAR70);
				if (VAR67) {
					FUN41(VAR6, VAR70);
					VAR22 = FUN42(VAR13, VAR9,
							VAR67, VAR68, 0,
							VAR9->VAR76.VAR55,
							VAR6->VAR56,
							VAR66.VAR59 - VAR69);
					FUN18(VAR22);
				}
			} else if (VAR57 == VAR74) {
				u64 VAR77 = 0;
				u64 VAR78 = 0;
				if (VAR3 > VAR19.VAR59) {
					VAR77 = VAR3 - VAR19.VAR59;
					VAR66.VAR59 += VAR77;
				}

				if (VAR19.VAR59 + VAR70 > VAR3+VAR23)
					VAR78 = VAR19.VAR59 + VAR70 - (VAR3+VAR23);

				if (VAR71 && (VAR77 || VAR78)) {
					VAR22 = -VAR33;
					goto VAR60;
				}
				VAR65 -= VAR77 + VAR78;
				VAR70 -= VAR77 + VAR78;
				VAR22 = FUN37(VAR13, VAR9, VAR15,
							      &VAR66, VAR65);
				if (VAR22)
					goto VAR60;

				if (VAR77) {
					u32 VAR79 =
					  FUN43(0);
					memmove(VAR18+VAR79, VAR18+VAR79+VAR77,
						VAR70);
				}

				VAR17 = VAR15->VAR61[0];
				VAR21 = VAR15->VAR62[0];
				FUN38(VAR17, VAR18,
					    FUN27(VAR17, VAR21),
					    VAR65);
				FUN41(VAR6, VAR70);
			}

			FUN44(VAR17);
		}

VAR75:
		FUN36(VAR9, VAR15);
		VAR19.VAR59++;
	}
	VAR22 = 0;
VAR60:
	FUN36(VAR9, VAR15);
	if (VAR22 == 0) {
		VAR6->VAR80 = VAR6->VAR81 = VAR82;
		if (VAR5 + VAR4 > VAR6->VAR48)
			FUN45(VAR6, VAR5 + VAR4);
		FUN3(VAR6)->VAR83 = FUN3(VAR11)->VAR83;
		VAR22 = FUN46(VAR13, VAR9, VAR6);
	}
	FUN47(VAR13, VAR9);
	FUN14(&FUN3(VAR11)->VAR52, VAR3, VAR3+VAR23, VAR53);
	if (VAR22)
		FUN48(VAR6, 0);
VAR49:
	FUN49(&VAR11->VAR47);
	FUN49(&VAR6->VAR47);
	FUN10(VAR18);
	FUN50(VAR15);
VAR39:
	FUN51(VAR10);
VAR37:
	FUN52(VAR1->VAR34.VAR35);
	return VAR22;
}