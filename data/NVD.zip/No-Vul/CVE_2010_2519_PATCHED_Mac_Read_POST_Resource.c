static VAR1   FUN1( FT_Library  VAR2,                           FT_Stream   VAR3,                           VAR4    *VAR5,                           FT_Long     VAR6,                           FT_Long     VAR7,                           VAR8    *VAR9 )    
{
    FT_Error   VAR10  = VAR11;
    FT_Memory  VAR12 = VAR2->VAR12;
    VAR13*   VAR14;
    int        VAR15, VAR16, VAR17;
    FT_Long    VAR18;
    FT_Long    VAR19, VAR20, VAR21;
    FT_Long    VAR22, VAR23;


    if ( VAR7 == -1 )
      VAR7 = 0;
    if ( VAR7 != 0 )
      return VAR10;

    
    
    VAR19 = 0;
    for ( VAR15 = 0; VAR15 < VAR6; ++VAR15 )
    {
      VAR10 = FUN2( VAR3, VAR5[VAR15] );
      if ( VAR10 )
        goto VAR24;
      if ( FUN3( VAR23 ) )
        goto VAR24;
      VAR19 += VAR23 + 6;
    }

    if ( FUN4( VAR14, (VAR4)VAR19 + 2 ) )
      goto VAR24;

    VAR14[0] = 0x80;
    VAR14[1] = 1;            
    VAR14[2] = 0;            
    VAR14[3] = 0;
    VAR14[4] = 0;
    VAR14[5] = 0;
    VAR20     = 6;
    VAR21  = 2;

    VAR18 = 0;
    VAR16 = 1;
    for ( VAR15 = 0; VAR15 < VAR6; ++VAR15 )
    {
      VAR10 = FUN2( VAR3, VAR5[VAR15] );
      if ( VAR10 )
        goto VAR25;
      if ( FUN3( VAR22 ) )
        goto VAR24;
      if ( FUN5( VAR17 ) )
        goto VAR24;
      FUN6(( "",
                   VAR15, VAR5[VAR15], VAR22, VAR17 ));

      if ( ( VAR17 >> 8 ) == 0 )        
        continue;

      
      
      if ( VAR22 > 2 )
        VAR22 -= 2;
      else
        VAR22 = 0;

      if ( ( VAR17 >> 8 ) == VAR16 )
        VAR18 += VAR22;
      else
      {
        VAR14[VAR21    ] = (VAR13)( VAR18 );
        VAR14[VAR21 + 1] = (VAR13)( VAR18 >> 8 );
        VAR14[VAR21 + 2] = (VAR13)( VAR18 >> 16 );
        VAR14[VAR21 + 3] = (VAR13)( VAR18 >> 24 );

        if ( ( VAR17 >> 8 ) == 5 )      
          break;

        VAR14[VAR20++] = 0x80;

        VAR16 = VAR17 >> 8;
        VAR18 = VAR22;

        VAR14[VAR20++] = (VAR13)VAR16;
        VAR21          = VAR20;
        VAR14[VAR20++] = 0;        
        VAR14[VAR20++] = 0;
        VAR14[VAR20++] = 0;
        VAR14[VAR20++] = 0;
      }

      VAR10 = FUN7( VAR3, (VAR13 *)VAR14 + VAR20, VAR22 );
      VAR20 += VAR22;
    }

    VAR14[VAR20++] = 0x80;
    VAR14[VAR20++] = 3;

    VAR14[VAR21    ] = (VAR13)( VAR18 );
    VAR14[VAR21 + 1] = (VAR13)( VAR18 >> 8 );
    VAR14[VAR21 + 2] = (VAR13)( VAR18 >> 16 );
    VAR14[VAR21 + 3] = (VAR13)( VAR18 >> 24 );

    return FUN8( VAR2,
                                  VAR14,
                                  VAR20,
                                  VAR7,
                                  "",
                                  VAR9 );

  VAR25:
    FUN9( VAR14 );

  VAR24:
    return VAR10;
  }