static int FUN1(void VAR1 *VAR2, unsigned int VAR3)  
{
	unsigned int VAR4;
	struct xt_counters_info VAR5, *VAR6;
	struct VAR7 *VAR8;
	struct VAR9 *private;
	int VAR10 = 0;
	void *VAR11;

	if (FUN2(&VAR5, VAR2, sizeof(VAR5)) != 0)
		return -VAR12;

	if (VAR3 != sizeof(VAR5) + VAR5.VAR13*sizeof(struct VAR14))
		return -VAR15;

	VAR6 = FUN3(VAR3);
	if (!VAR6)
		return -VAR16;

	if (FUN2(VAR6, VAR2, VAR3) != 0) {
		VAR10 = -VAR12;
		goto free;
	}

	VAR8 = FUN4(VAR17, VAR5.VAR18);
	if (!VAR8 || FUN5(VAR8)) {
		VAR10 = VAR8 ? FUN6(VAR8) : -VAR19;
		goto free;
	}

	FUN7(&VAR8->VAR20);
	private = VAR8->private;
	if (private->VAR21 != VAR5.VAR13) {
		VAR10 = -VAR15;
		goto VAR22;
	}

	VAR4 = 0;
	
	VAR11 = private->VAR23[FUN8()];
	FUN9(VAR11,
			   private->VAR24,
			   VAR25,
			   VAR6->VAR26,
			   &VAR4);
 VAR22:
	FUN10(&VAR8->VAR20);
	FUN11(VAR8);
	FUN12(VAR8->VAR27);
 free:
	FUN13(VAR6);

	return VAR10;
}