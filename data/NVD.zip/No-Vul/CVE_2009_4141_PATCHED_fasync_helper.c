* FUN1() is used by almost all character device VAR1  * to set up the fasync VAR2, and for regular files by the VAR3  * lease VAR4. It returns negative on VAR5, 0 if it did no VAR6  * and positive if it VAR7/deleted the VAR8.  */ int FUN1(int VAR9, struct VAR3 * VAR10, int VAR11, struct VAR12 **VAR13)  
{
	if (!VAR11)
		return FUN2(VAR10, VAR13);
	return FUN3(VAR9, VAR10, VAR13);
}