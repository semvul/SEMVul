struct VAR1 *FUN1(struct VAR2 *VAR3)  
{
	struct VAR1 *VAR4 = FUN2(VAR3);
	if (!VAR4)
		return NULL;
	if (VAR4 != VAR5->VAR4) {
		
		if (!FUN3(VAR3, VAR6) ||
		    VAR4 != VAR3->VAR4) {
			FUN4(VAR4);
			return NULL;
		}
	}
	FUN5(&VAR4->VAR7);
	return VAR4;
}