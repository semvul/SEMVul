int FUN1(const struct tiocl_selection VAR1 *VAR2, struct VAR3 *VAR4)  
{
	struct VAR5 *VAR6 = VAR7[VAR8].VAR9;
	int VAR10, VAR11, VAR12, VAR13;
	char *VAR14, *VAR15;
	int VAR16, VAR17, VAR18, VAR19;
	u16 VAR20;
	struct VAR21 *VAR22 = VAR23 + VAR8;

	FUN2();

	{ unsigned short VAR24, VAR25, VAR26, VAR27;

	  if (!FUN3(VAR28, VAR2, sizeof(*VAR2)))
		return -VAR29;
	  FUN4(VAR24, &VAR2->VAR24);
	  FUN4(VAR25, &VAR2->VAR25);
	  FUN4(VAR26, &VAR2->VAR26);
	  FUN4(VAR27, &VAR2->VAR27);
	  FUN4(VAR10, &VAR2->VAR10);
	  VAR24--; VAR25--; VAR26--; VAR27--;
	  VAR24 = FUN5(VAR24, VAR6->VAR30 - 1);
	  VAR25 = FUN5(VAR25, VAR6->VAR31 - 1);
	  VAR26 = FUN5(VAR26, VAR6->VAR30 - 1);
	  VAR27 = FUN5(VAR27, VAR6->VAR31 - 1);
	  VAR17 = VAR25 * VAR6->VAR32 + (VAR24 << 1);
	  VAR18 = VAR27 * VAR6->VAR32 + (VAR26 << 1);

	  if (VAR10 == VAR33) {
	      
	      FUN6();
	      return 0;
	  }

	  if (FUN7() && (VAR10 & VAR34)) {
	      FUN8(VAR4, VAR10 & VAR35, VAR24, VAR25);
	      return 0;
	  }
        }

	if (VAR17 > VAR18)	
	{
		int VAR36 = VAR17;
		VAR17 = VAR18;
		VAR18 = VAR36;
	}

	if (VAR37 != VAR7[VAR8].VAR9) {
		FUN6();
		VAR37 = VAR7[VAR8].VAR9;
	}
	VAR38 = VAR22 && VAR22->VAR39 == VAR40;

	switch (VAR10)
	{
		case VAR41:	
			VAR11 = VAR17;
			VAR12 = VAR18;
			break;
		case VAR42:	
			VAR13 = FUN9(FUN10(VAR17));
			for (VAR11 = VAR17; ; VAR17 -= 2)
			{
				if ((VAR13 && !FUN9(FUN10(VAR17))) ||
				    (!VAR13 && !FUN11(FUN10(VAR17))))
					break;
				VAR11 = VAR17;
				if (!(VAR17 % VAR6->VAR32))
					break;
			}
			VAR13 = FUN9(FUN10(VAR18));
			for (VAR12 = VAR18; ; VAR18 += 2)
			{
				if ((VAR13 && !FUN9(FUN10(VAR18))) ||
				    (!VAR13 && !FUN11(FUN10(VAR18))))
					break;
				VAR12 = VAR18;
				if (!((VAR18 + 2) % VAR6->VAR32))
					break;
			}
			break;
		case VAR43:	
			VAR11 = VAR17 - VAR17 % VAR6->VAR32;
			VAR12 = VAR18 + VAR6->VAR32
				    - VAR18 % VAR6->VAR32 - 2;
			break;
		case VAR44:
			FUN12(VAR18);
			return 0;
		default:
			return -VAR45;
	}

	
	FUN12(-1);

	
	if (VAR12 > VAR11 &&
		!FUN13(VAR12, VAR6->VAR32) &&
		FUN9(FUN10(VAR12))) {
		for (VAR18 = VAR12 + 2; ; VAR18 += 2)
			if (!FUN9(FUN10(VAR18)) ||
			    FUN13(VAR18, VAR6->VAR32))
				break;
		if (FUN9(FUN10(VAR18)))
			VAR12 = VAR18;
	}
	if (VAR46 == -1)	
		FUN14(VAR11, VAR12);
	else if (VAR11 == VAR46)
	{
		if (VAR12 == VAR47)	
			return 0;
		else if (VAR12 > VAR47)	
			FUN14(VAR47 + 2, VAR12);
		else				
			FUN14(VAR12 + 2, VAR47);
	}
	else if (VAR12 == VAR47)
	{
		if (VAR11 < VAR46)	
			FUN14(VAR11, VAR46 - 2);
		else				
			FUN14(VAR46, VAR11 - 2);
	}
	else	
	{
		FUN6();
		FUN14(VAR11, VAR12);
	}
	VAR46 = VAR11;
	VAR47 = VAR12;

	
	VAR19 = VAR38 ? 3 : 1;  
	VAR14 = FUN15(((VAR47-VAR46)/2+1)*VAR19, VAR48);
	if (!VAR14) {
		FUN16(VAR49 "");
		FUN6();
		return -VAR50;
	}
	FUN17(VAR51);
	VAR51 = VAR14;

	VAR15 = VAR14;
	for (VAR16 = VAR46; VAR16 <= VAR47; VAR16 += 2) {
		VAR20 = FUN10(VAR16);
		if (VAR38)
			VAR14 += FUN18(VAR20, VAR14);
		else
			*VAR14++ = VAR20;
		if (!FUN9(VAR20))
			VAR15 = VAR14;
		if (! ((VAR16 + 2) % VAR6->VAR32)) {
			
			if (VAR15 != VAR14) {
				VAR14 = VAR15;
				*VAR14++ = '';
			}
			VAR15 = VAR14;
		}
	}
	VAR52 = VAR14 - VAR51;
	return 0;
}