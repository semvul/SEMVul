static inline VAR1 FUN1(struct VAR2 *VAR3)  
{
	if (FUN2(FUN3(VAR3->VAR4)))
		return ((VAR1)FUN4(VAR3->VAR5) << 32) |
			FUN4(VAR3->VAR6);
	else
		return (VAR1) FUN4(VAR3->VAR6);
}