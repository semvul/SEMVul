int FUN1(struct VAR1 *VAR2, 			    unsigned long VAR3, unsigned long VAR4, 			    unsigned long VAR5, struct VAR6 **VAR7)  
{
	int VAR8;
	struct VAR9 *VAR10;

	VAR10 = FUN2(VAR11, VAR12);
	if (FUN3(VAR10 == NULL))
		return -VAR13;

	FUN4(&VAR10->VAR14);
	VAR10->VAR15 = VAR2;
	VAR10->VAR16 = VAR3;
	VAR10->VAR17 = VAR3 + VAR4;

	VAR10->VAR5 = VAR5 | VAR2->VAR18 | VAR19;
	VAR10->VAR20 = FUN5(VAR10->VAR5);

	VAR10->VAR21 = &VAR22;
	VAR10->VAR23 = VAR7;

	VAR8 = FUN6(NULL, 0, 0, 0, VAR10->VAR16, 1);
	if (VAR8)
		goto VAR24;

	VAR8 = FUN7(VAR2, VAR10);
	if (VAR8)
		goto VAR24;

	VAR2->VAR25 += VAR4 >> VAR26;

	FUN8(VAR10);

	return 0;

VAR24:
	FUN9(VAR11, VAR10);
	return VAR8;
}