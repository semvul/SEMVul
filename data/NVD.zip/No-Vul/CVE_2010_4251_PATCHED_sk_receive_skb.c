int FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4, const int VAR5)  
{
	int VAR6 = VAR7;

	if (FUN2(VAR2, VAR4))
		goto VAR8;

	VAR4->VAR9 = NULL;

	if (VAR5)
		FUN3(VAR2);
	else
		FUN4(VAR2);
	if (!FUN5(VAR2)) {
		
		FUN6(&VAR2->VAR10.VAR11, 0, 1, VAR12);

		VAR6 = FUN7(VAR2, VAR4);

		FUN8(&VAR2->VAR10.VAR11, 1, VAR12);
	} else if (FUN9(VAR2, VAR4)) {
		FUN10(VAR2);
		FUN11(&VAR2->VAR13);
		goto VAR8;
	}

	FUN10(VAR2);
VAR14:
	FUN12(VAR2);
	return VAR6;
VAR8:
	FUN13(VAR4);
	goto VAR14;
}