static void FUN1( VAR1 *VAR2, VAR3 *VAR4, mtime_t VAR5 )  
{
    VAR6 *VAR7 = VAR2->VAR7;
    VAR8 *VAR9 = VAR4->VAR10;

    if( VAR7->VAR11 < VAR4->VAR12
     || VAR4->VAR13 >= VAR4->VAR14 )
        return;

    if( !VAR9 )
    {
        VAR9 = FUN2( VAR2, VAR4->VAR12 * VAR4->VAR14 );
        if( !VAR9 )
            return;
        VAR4->VAR10 = VAR9;
    }
    memcpy( VAR9->VAR15 + VAR4->VAR13 * VAR4->VAR12,
            VAR7->VAR16, VAR4->VAR12 );
    if (!VAR4->VAR13)
    {
        VAR9->VAR17 =
        VAR9->VAR5 = VAR5;
    }

    if( ++VAR4->VAR13 < VAR4->VAR14 )
        return;

    FUN3(VAR9->VAR15, VAR4->VAR14, VAR4->VAR12);
    FUN4( VAR2, VAR4, VAR9->VAR5 );
    FUN5( VAR2->VAR18, VAR4->VAR19, VAR9 );
    VAR4->VAR13 = 0;
    VAR4->VAR10 = NULL;
}