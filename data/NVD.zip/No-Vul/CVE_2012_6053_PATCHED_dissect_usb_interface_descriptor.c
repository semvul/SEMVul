static int FUN1(VAR1 *VAR2, VAR3 *VAR4, VAR5 *VAR6, int VAR7, VAR8 *VAR9, VAR10 *VAR11)  
{
    VAR12 *VAR13       = NULL;
    VAR3 *VAR14       = NULL;
    int         VAR15 = VAR7;
    guint8      VAR16;
    guint8      VAR17;
    guint8      VAR18;

    if(VAR4){
        VAR13 = FUN2(VAR4, VAR6, VAR7, -1, "");
        VAR14 = FUN3(VAR13, VAR19);
    }

    VAR16 = FUN4(VAR6, VAR7);
    FUN5(VAR14, VAR6, VAR7);
    VAR7 += 2;

    
    VAR17 = FUN4(VAR6, VAR7);
    FUN6(VAR14, VAR20, VAR6, VAR7, 1, VAR21);
    VAR7 += 1;

    
    VAR18 = FUN4(VAR6, VAR7);
    FUN6(VAR14, VAR22, VAR6, VAR7, 1, VAR21);
    VAR7 += 1;

    
    FUN6(VAR14, VAR23, VAR6, VAR7, 1, VAR21);
    VAR7 += 1;

    
    FUN6(VAR14, VAR24, VAR6, VAR7, 1, VAR21);
    
    VAR11->VAR25 = FUN4(VAR6, VAR7);
    if (!VAR2->VAR26->VAR27.VAR28 && (VAR18 == 0)) {
        VAR29 *VAR30;
        guint32 VAR31;

        VAR9->VAR32 = FUN7(sizeof(VAR10));
        VAR9->VAR32->VAR25 = FUN4(VAR6, VAR7);
        
        VAR9->VAR32->VAR33 = FUN4(VAR6, VAR7+1);
        VAR9->VAR32->VAR34 = FUN8(VAR35, "");

        
        VAR31 = FUN9(VAR36 | VAR17);
        VAR30 = FUN10(VAR2, &VAR2->VAR37, &VAR2->VAR38, VAR31, VAR2->VAR39);
        FUN11(VAR30, VAR40, VAR9->VAR32);
    }
    VAR7 += 1;

    
    FUN6(VAR14, VAR41, VAR6, VAR7, 1, VAR21);
    
    VAR11->VAR33 = FUN4(VAR6, VAR7);
    VAR7 += 1;

    
    FUN6(VAR14, VAR42, VAR6, VAR7, 1, VAR21);
    VAR7 += 1;

    
    FUN6(VAR14, VAR43, VAR6, VAR7, 1, VAR21);
    VAR7 += 1;

    if(VAR13){
        FUN12(VAR13, VAR16);
    }
    if (VAR7 != VAR15 + VAR16) {
        
    }

    return VAR7;
}