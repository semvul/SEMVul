static int FUN1(struct VAR1 *VAR2, void VAR3 *VAR4)  
{
	struct ethtool_rxnfc VAR5;
	const struct VAR6 *VAR7 = VAR2->VAR6;
	int VAR8;
	void *VAR9 = NULL;

	if (!VAR7->VAR10)
		return -VAR11;

	if (FUN2(&VAR5, VAR4, sizeof(VAR5)))
		return -VAR12;

	if (VAR5.VAR13 == VAR14) {
		if (VAR5.VAR15 > 0) {
			if (VAR5.VAR15 <= VAR16 / sizeof(VAR17))
				VAR9 = FUN3(VAR5.VAR15 * sizeof(VAR17),
						   VAR18);
			if (!VAR9)
				return -VAR19;
		}
	}

	VAR8 = VAR7->FUN4(VAR2, &VAR5, VAR9);
	if (VAR8 < 0)
		goto VAR20;

	VAR8 = -VAR12;
	if (FUN5(VAR4, &VAR5, sizeof(VAR5)))
		goto VAR20;

	if (VAR9) {
		VAR4 += FUN6(struct VAR21, VAR22);
		if (FUN5(VAR4, VAR9,
				 VAR5.VAR15 * sizeof(VAR17)))
			goto VAR20;
	}
	VAR8 = 0;

VAR20:
	FUN7(VAR9);

	return VAR8;
}