static VAR1 FUN1(struct VAR2 *VAR2, char VAR3 *VAR4, 			    size_t VAR5, VAR6 *VAR7)  
{
	struct VAR8 *VAR9;
	char VAR3 *VAR10;
	int VAR11;
	FUN2(VAR12);

	VAR10 = VAR4;
	VAR9 = VAR2->VAR13;

	while (1) {
		struct VAR14 *VAR15;

		FUN3(&VAR9->VAR16, &VAR12, VAR17);

		FUN4(&VAR9->VAR18);
		VAR15 = FUN5(VAR9, VAR5);
		FUN6(&VAR9->VAR18);

		if (VAR15) {
			VAR11 = FUN7(VAR15);
			if (FUN8(VAR15))
				break;
			VAR11 = FUN9(VAR15, VAR4);
			FUN10(VAR15);
			if (VAR11 < 0)
				break;
			VAR4 += VAR11;
			VAR5 -= VAR11;
			continue;
		}

		VAR11 = -VAR19;
		if (VAR2->VAR20 & VAR21)
			break;
		VAR11 = -VAR22;
		if (FUN11(VAR23))
			break;

		if (VAR10 != VAR4)
			break;

		FUN12();
	}

	FUN13(&VAR9->VAR16, &VAR12);
	if (VAR10 != VAR4 && VAR11 != -VAR24)
		VAR11 = VAR4 - VAR10;
	return VAR11;
}