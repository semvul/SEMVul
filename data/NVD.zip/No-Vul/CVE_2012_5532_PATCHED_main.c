int FUN1(void)  
{
	int VAR1, VAR2, VAR3;
	int VAR4;
	struct VAR5 *VAR6;
	struct pollfd VAR7;
	struct VAR8 *VAR9;
	struct VAR5	*VAR10;
	struct VAR11 *VAR12;
	char	*VAR13;
	char	*VAR14;
	char	*VAR15;
	int	VAR16;
	int	VAR17;
	char	*VAR18;
	struct VAR19 *VAR20;

	FUN2(1, 0);
	FUN3("", 0, VAR21);
	syslog(VAR22, "", FUN4());
	
	FUN5();

	if (FUN6()) {
		syslog(VAR23, "");
		FUN7(VAR24);
	}

	VAR1 = socket(VAR25, VAR26, VAR27);
	if (VAR1 < 0) {
		syslog(VAR23, "", VAR1);
		FUN7(VAR24);
	}
	VAR28.VAR29 = VAR25;
	VAR28.VAR30 = 0;
	VAR28.VAR31 = 0;
	VAR28.VAR32 = VAR33;


	VAR4 = FUN8(VAR1, (struct VAR34 *)&VAR28, sizeof(VAR28));
	if (VAR4 < 0) {
		syslog(VAR23, "", VAR4);
		close(VAR1);
		FUN7(VAR24);
	}
	VAR3 = VAR28.VAR32;
	FUN9(VAR1, 270, 1, &VAR3, sizeof(VAR3));
	
	VAR6 = (struct VAR5 *)VAR35;
	VAR6->VAR36.VAR37 = VAR33;
	VAR6->VAR36.VAR38 = VAR39;

	VAR12 = (struct VAR11 *)VAR6->VAR40;
	VAR12->VAR41.VAR42 = VAR43;
	VAR6->VAR44 = 0;
	VAR6->VAR2 = sizeof(struct VAR11);

	VAR2 = FUN10(VAR1, VAR6);
	if (VAR2 < 0) {
		syslog(VAR23, "", VAR2);
		close(VAR1);
		FUN7(VAR24);
	}

	VAR7.VAR1 = VAR1;

	while (1) {
		struct VAR34 *VAR45 = (struct VAR34 *) &VAR28;
		socklen_t VAR46 = sizeof(VAR28);
		VAR7.VAR47 = VAR48;
		VAR7.VAR49 = 0;
		FUN11(&VAR7, 1, -1);

		VAR2 = recvfrom(VAR1, VAR50, sizeof(VAR50), 0,
				VAR45, &VAR46);

		if (VAR2 < 0) {
			syslog(VAR23, "",
					VAR28.VAR31, VAR51, strerror(VAR51));
			close(VAR1);
			return -1;
		}

		if (VAR28.VAR31) {
			syslog(VAR52, "",
					VAR28.VAR31);
			continue;
		}

		VAR9 = (struct VAR8 *)VAR50;
		VAR10 = (struct VAR5 *)FUN12(VAR9);
		VAR12 = (struct VAR11 *)VAR10->VAR40;

		
		VAR16 = VAR12->VAR41.VAR42;
		VAR17 = VAR12->VAR41.VAR17;
		VAR12->VAR4 = VAR53;

		if ((VAR54) && (VAR16 == VAR43)) {
			
			VAR54 = 0;
			VAR13 = (char *)VAR12->VAR55.VAR56.VAR57;
			VAR58 = malloc(strlen(VAR13) + 1);
			if (VAR58) {
				strcpy(VAR58, VAR13);
				syslog(VAR22, "",
					VAR58);
			} else {
				syslog(VAR23, "");
			}
			continue;
		}

		switch (VAR16) {
		case VAR59:
			VAR20 = &VAR12->VAR55.VAR20;
			VAR18 =
			FUN13((char *)VAR20->VAR60);

			if (VAR18 == NULL) {
				
				VAR12->VAR4 = VAR61;
				break;
			}
			VAR4 = FUN14(
						0, VAR18, VAR59,
						VAR20,
						(VAR62 * 2));

			if (VAR4)
				VAR12->VAR4 = VAR4;

			free(VAR18);
			break;

		case VAR63:
			VAR20 = &VAR12->VAR55.VAR20;
			VAR18 = FUN15(
					(char *)VAR20->VAR60);
			if (VAR18 == NULL) {
				
				VAR12->VAR4 = VAR64;
				break;
			}
			VAR4 = FUN16(VAR18, VAR20);
			if (VAR4)
				VAR12->VAR4 = VAR4;

			free(VAR18);
			break;

		case VAR65:
			if (FUN17(VAR17,
					VAR12->VAR55.VAR66.VAR40.VAR67,
					VAR12->VAR55.VAR66.VAR40.VAR68,
					VAR12->VAR55.VAR66.VAR40.VAR69,
					VAR12->VAR55.VAR66.VAR40.VAR70))
					VAR12->VAR4 = VAR71;
			break;

		case VAR72:
			if (FUN18(VAR17,
					VAR12->VAR55.VAR66.VAR40.VAR67,
					VAR12->VAR55.VAR66.VAR40.VAR68,
					VAR12->VAR55.VAR66.VAR40.VAR69,
					VAR12->VAR55.VAR66.VAR40.VAR70))
					VAR12->VAR4 = VAR71;
			break;

		case VAR73:
			if (FUN19(VAR17,
					VAR12->VAR55.VAR74.VAR67,
					VAR12->VAR55.VAR74.VAR68))
					VAR12->VAR4 = VAR71;
			break;

		default:
			break;
		}

		if (VAR16 != VAR75)
			goto VAR76;

		
		if (VAR17 != VAR77) {
			if (FUN20(VAR17,
					VAR12->VAR55.VAR78.VAR79,
					VAR12->VAR55.VAR78.VAR40.VAR67,
					VAR80,
					VAR12->VAR55.VAR78.VAR40.VAR69,
					VAR81))
					VAR12->VAR4 = VAR71;
			goto VAR76;
		}

		VAR12 = (struct VAR11 *)VAR10->VAR40;
		VAR15 = (char *)VAR12->VAR55.VAR78.VAR40.VAR67;
		VAR14 = (char *)VAR12->VAR55.VAR78.VAR40.VAR69;

		switch (VAR12->VAR55.VAR78.VAR79) {
		case VAR82:
			FUN21(VAR14,
					VAR81);
			strcpy(VAR15, "");
			break;
		case VAR83:
			strcpy(VAR15, "");
			strcpy(VAR14, VAR58);
			break;
		case VAR84:
			FUN14(VAR85, NULL, VAR75,
				VAR14, VAR81);
			strcpy(VAR15, "");
			break;
		case VAR86:
			FUN14(VAR87, NULL, VAR75,
				VAR14, VAR81);
			strcpy(VAR15, "");
			break;
		case VAR88:
			strcpy(VAR14, VAR89);
			strcpy(VAR15, "");
			break;
		case VAR90:
			strcpy(VAR14, VAR91);
			strcpy(VAR15, "");
			break;
		case VAR92:
			strcpy(VAR14, VAR93);
			strcpy(VAR15, "");
			break;
		case VAR94:
			strcpy(VAR14, VAR95);
			strcpy(VAR15, "");
			break;
		case VAR96:
			strcpy(VAR14, VAR89);
			strcpy(VAR15, "");
			break;
		case VAR97:
			strcpy(VAR14, VAR98);
			strcpy(VAR15, "");
			break;
		default:
			VAR12->VAR4 = VAR71;
			break;
		}
		
VAR76:

		VAR10->VAR36.VAR37 = VAR33;
		VAR10->VAR36.VAR38 = VAR39;
		VAR10->VAR44 = 0;
		VAR10->VAR2 = sizeof(struct VAR11);

		VAR2 = FUN10(VAR1, VAR10);
		if (VAR2 < 0) {
			syslog(VAR23, "", VAR2);
			FUN7(VAR24);
		}
	}

}