int FUN1(struct VAR1 *VAR2, void *VAR3, 		      struct VAR4 *VAR5)  
{
	struct VAR6 *VAR7 = VAR3;
	struct VAR8 *VAR9;
	struct VAR10 *VAR11;
	int VAR12 = 0;

	VAR9 = FUN2(VAR2, VAR5, VAR7->VAR13);
	if (VAR9 == NULL)
		return -VAR14;
	VAR11 = FUN3(VAR9);

	
	if (VAR7->VAR15 > VAR9->VAR16 || VAR7->VAR16 > VAR9->VAR16 ||
	    VAR7->VAR15 + VAR7->VAR16 > VAR9->VAR16) {
		VAR12 = -VAR17;
		goto VAR18;
	}

	if (!FUN4(VAR19,
		       (char VAR20 *)(VAR21)VAR7->VAR22,
		       VAR7->VAR16)) {
		VAR12 = -VAR23;
		goto VAR18;
	}

	
	if (VAR11->VAR24)
		VAR12 = FUN5(VAR2, VAR9, VAR7, VAR5);
	else if (VAR11->VAR25 == VAR26 &&
		 VAR2->VAR27 != 0 &&
		 VAR9->VAR28 != VAR29) {
		VAR12 = FUN6(VAR2, VAR9, VAR7, VAR5);
		if (VAR12 == -VAR23) {
			VAR12 = FUN7(VAR2, VAR9, VAR7,
						       VAR5);
		}
	} else if (FUN8(VAR9)) {
		VAR12 = FUN9(VAR2, VAR9, VAR7, VAR5);
	} else {
		VAR12 = FUN10(VAR2, VAR9, VAR7, VAR5);
		if (VAR12 == -VAR23) {
			VAR12 = FUN9(VAR2, VAR9, VAR7,
							 VAR5);
		}
	}

#if VAR30
	if (VAR12)
		FUN11("", VAR12);
#endif

VAR18:
	FUN12(VAR9);
	return VAR12;
}