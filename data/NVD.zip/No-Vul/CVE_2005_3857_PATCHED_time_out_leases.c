static void FUN1(struct VAR1 *VAR1)  
{
	struct VAR2 **VAR3;
	struct VAR2 *VAR4;

	VAR3 = &VAR1->VAR5;
	while ((VAR4 = *VAR3) && FUN2(VAR4) && (VAR4->VAR6 & VAR7)) {
		if ((VAR4->VAR8 == 0)
				|| FUN3(VAR9, VAR4->VAR8)) {
			VAR3 = &VAR4->VAR10;
			continue;
		}
		FUN4(VAR3, VAR4->VAR6 & ~VAR7);
		if (VAR4 == *VAR3)	
			VAR3 = &VAR4->VAR10;
	}
}