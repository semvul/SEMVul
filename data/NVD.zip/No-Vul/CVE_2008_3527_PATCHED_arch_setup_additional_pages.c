int FUN1(struct VAR1 *VAR2, int VAR3)  
{
	struct VAR4 *VAR5 = VAR6->VAR5;
	unsigned long VAR7;
	int VAR8;

	FUN2(&VAR5->VAR9);
	VAR7 = FUN3(NULL, 0, VAR10, 0, 0);
	if (FUN4(VAR7)) {
		VAR8 = VAR7;
		goto VAR11;
	}

	
	VAR8 = FUN5(VAR5, VAR7, VAR10,
				      VAR12|VAR13|
				      VAR14|VAR15|VAR16|
				      VAR17,
				      VAR18);
	if (VAR8)
		goto VAR11;

	VAR6->VAR5->VAR19.VAR20 = (void *)VAR7;
	FUN6()->VAR21 =
				    (void *)FUN7(&VAR22);
VAR11:
	FUN8(&VAR5->VAR9);
	return VAR8;
}