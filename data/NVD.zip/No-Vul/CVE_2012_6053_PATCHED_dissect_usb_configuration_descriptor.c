static int FUN1(VAR1 *pinfo VAR2, VAR3 *VAR4, VAR5 *VAR6, int VAR7, VAR8 *VAR9, VAR10 *VAR11)  
{
    VAR12 *VAR13       = NULL;
    VAR3 *VAR14       = NULL;
    int         VAR15 = VAR7;
    guint16     VAR16;
    VAR12 *VAR17 = NULL;
    VAR3 *VAR18 = NULL;
    guint8      VAR19;
    VAR12 *VAR20;
    guint8      VAR21;

    VAR11->VAR22    = VAR23;
    VAR11->VAR24 = VAR25;

    if(VAR4){
        VAR13 = FUN2(VAR4, VAR6, VAR7, -1, "");
        VAR14 = FUN3(VAR13, VAR26);
    }

    FUN4(VAR14, VAR6, VAR7);
    VAR7 += 2;

    
    FUN5(VAR14, VAR27, VAR6, VAR7, 2, VAR28);
    VAR16 = FUN6(VAR6, VAR7);
    VAR7+=2;

    
    FUN5(VAR14, VAR29, VAR6, VAR7, 1, VAR28);
    VAR7 += 1;

    
    FUN5(VAR14, VAR30, VAR6, VAR7, 1, VAR28);
    VAR7 += 1;

    
    FUN5(VAR14, VAR31, VAR6, VAR7, 1, VAR28);
    VAR7 += 1;

    
    if(VAR14){
        VAR17 = FUN5(VAR14, VAR32, VAR6, VAR7, 1, VAR28);
        VAR18 = FUN3(VAR17, VAR33);
    }
    VAR19 = FUN7(VAR6, VAR7);
    FUN5(VAR18, VAR34, VAR6, VAR7, 1, VAR28);
    FUN5(VAR18, VAR35, VAR6, VAR7, 1, VAR28);
    FUN8(VAR17, "", (VAR19&0x40)?"":"");
    FUN5(VAR18, VAR36, VAR6, VAR7, 1, VAR28);
    FUN8(VAR17, "", (VAR19&0x20)?"":"");
    VAR7 += 1;

    
    VAR20 = FUN5(VAR14, VAR37, VAR6, VAR7, 1, VAR28);
    VAR21 = FUN7(VAR6, VAR7);
    FUN8(VAR20, "", VAR21*2);
    VAR7 += 1;

    
    VAR9->VAR38 = NULL;

    
    while(VAR16>(VAR7-VAR15)){
        guint8 VAR39;
        VAR5 *VAR40 = NULL;

        if(FUN9(VAR6, VAR7)<2){
            break;
        }
        VAR39 = FUN7(VAR6, VAR7+1);
        switch(VAR39){
        case VAR41:
            VAR7 = FUN10(VAR42, VAR4, VAR6, VAR7, VAR9, VAR11);
            break;
        case VAR43:
            VAR7 = FUN11(VAR42, VAR4, VAR6, VAR7, VAR9, VAR11);
            break;
        case VAR44:
            VAR7 = FUN12(VAR42, VAR4, VAR6, VAR7, VAR9, VAR11);
            break;
        default:
            VAR40 = FUN13(VAR6, VAR7);
            if (FUN14(VAR45, VAR11->VAR22, VAR40, VAR42, VAR4)){
                VAR7 += FUN7(VAR40, 0);
            } else {
                VAR7 = FUN15(VAR42, VAR4, VAR6, VAR7, VAR9, VAR11);
            }
            break;
            
        }
    }

    if(VAR13){
        FUN16(VAR13, VAR7-VAR15);
    }

    
    VAR11->VAR22    = VAR23;
    VAR11->VAR24 = VAR25;

    return VAR7;
}