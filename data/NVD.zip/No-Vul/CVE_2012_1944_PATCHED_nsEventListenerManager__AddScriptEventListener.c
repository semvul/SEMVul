nsresult VAR1::FUN1(VAR2 *VAR3,                                                const VAR4& VAR5,                                                PRUint32 VAR6,                                                bool VAR7,                                                bool VAR8)  
{
  FUN2(VAR6 != VAR9::VAR10,
                  "");

  
  
  
  
  
  if (VAR8 && 
      VAR6 != VAR9::VAR11) {
    FUN3("");
    return VAR12;
  }

  VAR13<VAR14> FUN4(FUN5(VAR15));

  VAR13<VAR16> VAR17;

  VAR13<VAR18> VAR19;

  if (VAR20) {
    
    
    
    VAR17 = VAR20->FUN6();
    VAR19 = VAR17->FUN7();
  } else {
    VAR13<VAR21> FUN8(FUN5(VAR15));
    if (VAR22) {
      FUN9(VAR22->FUN10(),
                   "");

      VAR13<VAR23> VAR24;
      VAR22->FUN11(FUN12(VAR24));
      VAR17 = FUN5(VAR24);
      VAR19 = FUN5(VAR22);
    } else {
      VAR19 = FUN5(VAR15);
    }
  }

  if (!VAR19) {
    
    
    return VAR25;
  }

  nsresult VAR26 = VAR25;
  
  
  if (VAR17) {
    VAR13<VAR27> VAR28;
    VAR26 = VAR17->FUN13()->FUN14(FUN12(VAR28));
    FUN15(VAR26, VAR26);

    if (VAR28) {
      bool VAR29;
      VAR26 = VAR28->FUN16(&VAR29);
      FUN15(VAR26, VAR26);

      if ( !VAR29 ) {
        
        VAR30* VAR31 = VAR17->FUN17();
        nsCAutoString VAR32;
        if (VAR31)
          VAR31->FUN18(VAR32);
        nsAutoString VAR33, VAR34, FUN19(FUN20(""));
        VAR3->FUN21(VAR34);
        VAR13<VAR35> FUN22(FUN5(VAR15));
        if (VAR36)
          VAR36->FUN23(VAR37);
        
        VAR33.FUN24(VAR34);
        VAR33.FUN25("");
        VAR33.FUN26(VAR37);
        VAR33.FUN25("");
        VAR28->FUN27(VAR27::VAR38,
                                 FUN28(VAR32),
                                 VAR33,
                                 VAR39);
        return VAR25;
      }
    }
  }

  
  
  if (FUN29(VAR19->FUN30(VAR6))) {
    FUN3("");
    
  }

  VAR40* VAR41 = VAR19->FUN31(VAR6);
  FUN32(VAR41, VAR12);

  VAR42* VAR43 = VAR19->FUN33();

  VAR44 *VAR45;
  VAR26 = FUN34(VAR41, VAR43, VAR3, VAR39,
                          VAR8, &VAR45);
  FUN15(VAR26, VAR26);

  if (!VAR7) {
    return FUN35(VAR45, true, &VAR5);
  }

  return VAR25;
}