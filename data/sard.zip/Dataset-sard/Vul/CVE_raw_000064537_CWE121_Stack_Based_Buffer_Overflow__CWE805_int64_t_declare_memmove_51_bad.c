void FUN1()
{
    VAR1 * VAR2;
    int64_t VAR3[50];
    int64_t VAR4[100];
    
    VAR2 = VAR3;
    FUN2(VAR2);
}