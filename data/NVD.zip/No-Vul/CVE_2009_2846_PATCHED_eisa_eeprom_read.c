static VAR1 FUN1(struct VAR2 * VAR2, 			      char VAR3 *VAR4, size_t VAR5, VAR6 *VAR7 )  
{
	unsigned char *VAR8;
	ssize_t VAR9;
	int VAR10;
	
	if (*VAR7 < 0 || *VAR7 >= VAR11)
		return 0;
	
	VAR5 = *VAR7 + VAR5 < VAR11 ? VAR5 : VAR11 - *VAR7;
	VAR8 = FUN2(VAR5, VAR12);
	if (VAR8) {
		for (VAR10 = 0; VAR10 < VAR5; VAR10++)
			VAR8[VAR10] = FUN3(VAR13+(*VAR7)++);

		if (FUN4 (VAR4, VAR8, VAR5))
			VAR9 = -VAR14;
		else
			VAR9 = VAR5;
		FUN5 (VAR8);
	} else
		VAR9 = -VAR15;
	
	return VAR9;
}