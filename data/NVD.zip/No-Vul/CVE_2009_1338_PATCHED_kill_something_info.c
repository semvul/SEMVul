static int FUN1(int VAR1, struct VAR2 *VAR3, int VAR4)  
{
	int VAR5;

	if (VAR4 > 0) {
		FUN2();
		VAR5 = FUN3(VAR1, VAR3, FUN4(VAR4));
		FUN5();
		return VAR5;
	}

	FUN6(&VAR6);
	if (VAR4 != -1) {
		VAR5 = FUN7(VAR1, VAR3,
				VAR4 ? FUN4(-VAR4) : FUN8(VAR7));
	} else {
		int VAR8 = 0, VAR9 = 0;
		struct VAR10 * VAR11;

		FUN9(VAR11) {
			if (FUN10(VAR11) > 1 &&
					!FUN11(VAR11, VAR7)) {
				int VAR12 = FUN12(VAR1, VAR3, VAR11);
				++VAR9;
				if (VAR12 != -VAR13)
					VAR8 = VAR12;
			}
		}
		VAR5 = VAR9 ? VAR8 : -VAR14;
	}
	FUN13(&VAR6);

	return VAR5;
}