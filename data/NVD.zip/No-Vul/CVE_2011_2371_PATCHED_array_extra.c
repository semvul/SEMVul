static VAR1 FUN1(VAR2 *VAR3, ArrayExtraMode VAR4, uintN argc, VAR5 *VAR6)  
{
    VAR7 *VAR8 = FUN2(VAR3, &VAR6[1]);
    if (!VAR8)
        return false;

    jsuint VAR9;
    if (!FUN3(VAR3, VAR8, &VAR9))
        return VAR10;

    
    if (argc == 0) {
        FUN4(VAR3, *VAR6, 0);
        return VAR10;
    }
    VAR5 *argv = VAR6 + 2;
    VAR7 *VAR11 = FUN5(VAR3, &argv[0], VAR12);
    if (!VAR11)
        return VAR10;

    
    jsuint VAR13;
    VAR7 *VAR14;
#ifdef VAR15 
    VAR13 = 0;
    VAR14 = NULL;
#endif
    uint64 VAR16 = 0, VAR17 = VAR9, VAR18 = 1;

    switch (VAR4) {
      case VAR19:
        VAR16 = VAR9 - 1, VAR17 = VAR20, VAR18 = VAR20;
        
      case VAR21:
        if (VAR9 == 0 && argc == 1) {
            FUN6(VAR3, VAR22, NULL,
                                 VAR23);
            return VAR10;
        }
        if (argc >= 2) {
            *VAR6 = argv[1];
        } else {
            JSBool VAR24;
            do {
                if (!FUN7(VAR3, VAR8, VAR16, &VAR24, VAR6))
                    return VAR10;
                VAR16 += VAR18;
            } while (VAR24 && VAR16 != VAR17);

            if (VAR24 && VAR16 == VAR17) {
                FUN6(VAR3, VAR22, NULL,
                                     VAR23);
                return VAR10;
            }
        }
        break;
      case VAR25:
      case VAR26:
        VAR13 = (VAR4 == VAR25) ? VAR9 : 0;
        VAR14 = FUN8(VAR3, VAR13);
        if (!VAR14)
            return VAR10;
        VAR6->FUN9(*VAR14);
        break;
      case VAR27:
        VAR6->FUN10(false);
        break;
      case VAR28:
        VAR6->FUN10(true);
        break;
      case VAR29:
        VAR6->FUN11();
        break;
    }

    if (VAR9 == 0)
        return VAR30;

    Value VAR31 = (argc > 1 && !FUN12(VAR4)) ? argv[1] : FUN13();

    
    argc = 3 + FUN12(VAR4);

    InvokeSessionGuard VAR32;
    if (!VAR32.FUN14(VAR3, FUN15(*VAR11), VAR31, argc))
        return VAR10;

    FUN16("");
    JSBool VAR33 = VAR30;
    JSBool VAR34;

    Value VAR35 = FUN15(*VAR8);
    VAR36 FUN17(VAR3);
    for (uint64 VAR37 = VAR16; VAR37 != VAR17; VAR37 += VAR18) {
        JSBool VAR24;
        VAR33 = FUN18(VAR3) &&
             FUN7(VAR3, VAR8, VAR37, &VAR24, VAR38.FUN19());
        if (!VAR33)
            goto VAR39;
        if (VAR24)
            continue;

        
        uintN VAR40 = 0;
        if (FUN12(VAR4))
            VAR32[VAR40++] = *VAR6;
        VAR32[VAR40++] = VAR38.FUN20();
        VAR32[VAR40++] = FUN21(VAR37);
        VAR32[VAR40]   = VAR35;

        
        VAR33 = VAR32.FUN22(VAR3);
        if (!VAR33)
            break;

        const VAR5 &VAR41 = VAR32.FUN23();

        if (VAR4 > VAR25)
            VAR34 = FUN24(VAR41);
#ifdef VAR15 
        else
            VAR34 = VAR10;
#endif

        switch (VAR4) {
          case VAR29:
            break;
          case VAR21:
          case VAR19:
            *VAR6 = VAR41;
            break;
          case VAR25:
            VAR33 = FUN25(VAR3, VAR14, VAR37, VAR41);
            if (!VAR33)
                goto VAR39;
            break;
          case VAR26:
            if (!VAR34)
                break;
            
            VAR33 = FUN25(VAR3, VAR14, VAR13++, VAR38.FUN20());
            if (!VAR33)
                goto VAR39;
            break;
          case VAR27:
            if (VAR34) {
                VAR6->FUN10(true);
                goto VAR39;
            }
            break;
          case VAR28:
            if (!VAR34) {
                VAR6->FUN10(false);
                goto VAR39;
            }
            break;
        }
    }

  VAR39:
    if (VAR33 && VAR4 == VAR26)
        VAR33 = FUN26(VAR3, VAR14, VAR13);
    return VAR33;
}