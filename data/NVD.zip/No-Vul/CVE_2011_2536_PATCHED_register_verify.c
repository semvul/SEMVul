*/ static enum VAR1 FUN1(struct VAR2 *VAR3, struct VAR4 *VAR5, 					      struct VAR6 *VAR7, const char *VAR8)  
{
	enum check_auth_result VAR9 = VAR10;
	struct VAR11 *VAR12;
	char VAR13[256];
	char *VAR14 = NULL, *VAR15, *VAR16 = NULL, *VAR17 = NULL;
	char *VAR18 = FUN2(VAR8);

	FUN3(VAR18);

	FUN4(VAR13, FUN5(VAR7, ""), sizeof(VAR13));

	VAR15 = FUN6(VAR13);
	VAR15 = FUN7(VAR15);

	if (FUN8(VAR15, "", &VAR14, &VAR17, &VAR16, NULL)) {
		FUN9(VAR19, "", VAR15, FUN10(VAR5));
		return -1;
	}

	FUN11(VAR14);
	FUN11(VAR16);

	
	if (!FUN12(VAR16) && !FUN13(&VAR20)) {
		if (!FUN14(VAR16, NULL, 0)) {
			FUN15(VAR3, "", &VAR3->VAR21);
			return VAR22;
		}
	}

	FUN16(VAR3, VAR23, VAR14);
	FUN17(VAR3);
	if (VAR7->VAR24) {
		
		const char *VAR25 = FUN5(VAR7, "");
		int VAR26 = FUN18(VAR25);

		if (FUN12(VAR25)) { 
			if ((VAR25 = FUN19(FUN5(VAR7, ""), ""))) {
				VAR26 = FUN18(VAR25 + 9);
			}
		}
		if (!FUN12(VAR25) && VAR26 == 0) {
			FUN20(VAR3, "", VAR7);
			return 0;
		}
	}
	VAR12 = FUN21(VAR14, NULL, VAR27, VAR28, VAR29, 0);

	if (!(VAR12 && FUN22(VAR12->VAR30, VAR5))) {
		
		if (VAR12) {
			FUN23(VAR12, "");
			VAR12 = NULL;
			VAR9 = VAR31;
		} else {
			VAR9 = VAR10;
		}
	}

	if (VAR12) {
		FUN24(VAR12);
		if (!VAR12->VAR32) {
			FUN9(VAR33, "", VAR12->VAR14);
			VAR9 = VAR34;
		} else {
			FUN25(&VAR3->VAR35[0], &VAR12->VAR35[0], VAR36);
			if (FUN26(&VAR3->VAR35[1], VAR37))
				FUN15(VAR3, "", VAR7);
			if (!(VAR9 = FUN27(VAR3, VAR7, VAR12->VAR14, VAR12->VAR38, VAR12->VAR39, VAR40, VAR18, VAR41, VAR7->VAR24))) {
				if (FUN28(VAR3))
					FUN9(VAR42, "");

				if (FUN29(VAR12, VAR7)) {
					FUN30(&VAR3->VAR35[0], VAR43);
					FUN20(VAR3, "", VAR7);
					VAR9 = VAR44;
				} else {

					
					switch (FUN31(VAR3, VAR12, VAR7)) {
					case VAR45:
						FUN9(VAR42, "");
						FUN20(VAR3, "", VAR7);
						VAR12->VAR46 = -1;
						VAR9 = 0;
						break;
					case VAR47:
						FUN9(VAR42, "");
						FUN20(VAR3, "", VAR7);
						VAR12->VAR46 = -1;
						VAR9 = 0;
						break;
					case VAR48:
						FUN16(VAR3, VAR49, VAR12->VAR49);
						FUN20(VAR3, "", VAR7);
						VAR12->VAR46 = -1;
						VAR9 = 0;
						break;
					case VAR50:
						FUN16(VAR3, VAR49, VAR12->VAR49);
						FUN32(VAR12, VAR3->VAR51);
						
						FUN20(VAR3, "", VAR7);
						if (!FUN26((&VAR12->VAR35[1]), VAR52))
							VAR12->VAR46 = -1;
						VAR9 = 0;
						break;
					}
				}

			}
		}
		FUN33(VAR12);
	}
	if (!VAR12 && VAR53.VAR54) {
		
		VAR12 = FUN34(VAR14);
		if (VAR12) {
			FUN35(VAR55, VAR12, "");
			if (!FUN36(&VAR12->VAR5)) {
				FUN35(VAR56, VAR12, "");
			}
			FUN24(VAR12);
			if (FUN28(VAR3))
				FUN9(VAR42, "");
			switch (FUN31(VAR3, VAR12, VAR7)) {
			case VAR45:
				FUN9(VAR42, "");
				FUN20(VAR3, "", VAR7);
				VAR12->VAR46 = -1;
				VAR9 = 0;
				break;
			case VAR47:
				FUN9(VAR42, "");
				FUN20(VAR3, "", VAR7);
				VAR12->VAR46 = -1;
				VAR9 = 0;
				break;
			case VAR48:
				FUN16(VAR3, VAR49, VAR12->VAR49);
				FUN20(VAR3, "", VAR7);
				VAR12->VAR46 = -1;
				VAR9 = 0;
				break;
			case VAR50:
				FUN16(VAR3, VAR49, VAR12->VAR49);
				
				FUN20(VAR3, "", VAR7);
				FUN37(VAR57, "", "", VAR12->VAR14, FUN38(VAR5));
				VAR12->VAR46 = -1;
				VAR9 = 0;
				break;
			}
			FUN33(VAR12);
		}
	}
	if (!VAR12 && VAR53.VAR58 && FUN26(&VAR3->VAR35[1], VAR37)) {
		
		FUN15(VAR3, "", VAR7);
		
		FUN39();
	}
	if (!VAR9) {
		FUN40(VAR59, "", VAR12->VAR14);
	}
	if (VAR9 < 0) {
		switch (VAR9) {
		case VAR60:
			
			FUN15(VAR3, "", &VAR3->VAR21);
			if (VAR61) {
				const char *VAR62 = FUN2(FUN10(VAR5));
				const char *VAR63 = FUN2(FUN41(VAR5));
				FUN37(VAR57, "",
					      ""
					      ""
					      ""
					      ""
					      ""
					      "",
					      VAR14, VAR62, VAR63);
			}
			break;
		case VAR64:
			
		case VAR10:
		case VAR34:
		case VAR31:
			if (VAR53.VAR58) {
				FUN42(VAR3, VAR40, &VAR3->VAR21, VAR41);
				if (VAR61) {
					const char *VAR62 = FUN2(FUN10(VAR5));
					const char *VAR63 = FUN2(FUN41(VAR5));
					FUN37(VAR57, "",
						      ""
						      ""
						      ""
						      ""
						      ""
						      "",
						      VAR14,
						      VAR9 == VAR34 ? "" : "",
						      VAR62, VAR63);
				}
			} else {
				
				if (VAR9 == VAR34) {
					FUN15(VAR3, "", &VAR3->VAR21);
					if (VAR61) {
						const char *VAR62 = FUN2(FUN10(VAR5));
						const char *VAR63 = FUN2(FUN41(VAR5));
						FUN37(VAR57, "",
							""
							""
							""
							""
							""
							"",
							VAR14, VAR62, VAR63);
					}
				} else {
					FUN15(VAR3, "", &VAR3->VAR21);
					if (VAR61) {
						const char *VAR62 = FUN2(FUN10(VAR5));
						const char *VAR63 = FUN2(FUN41(VAR5));
						FUN37(VAR57, "",
							""
							""
							""
							""
							""
							"",
							VAR14,
							(VAR9 == VAR64) ? "" : "",
							VAR62, VAR63);
					}
				}
			}
			break;
		case VAR44:
		default:
			break;
		}
	}
	if (VAR12) {
		FUN23(VAR12, "");
	}

	return VAR9;
}