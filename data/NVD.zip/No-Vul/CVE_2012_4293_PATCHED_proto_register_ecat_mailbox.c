void FUN1(void)  
{
   static const true_false_string VAR1 =
   {
      "",
      ""
   };

   static hf_register_info VAR2[] =
   {
      { &VAR3,
      { "", "",
      VAR4, VAR5, NULL, 0x0,
      NULL, VAR6 }
      },
      { &VAR7,
      { "", "",
      VAR4, VAR8, NULL, 0x0,
      NULL, VAR6 }
      },
      { &VAR9,
      { "", "",
      VAR10, VAR11, NULL, 0x0,
      NULL, VAR6 }
      },
      { &VAR12,
      { "", "",
      VAR10, VAR11, NULL, 0x0,
      NULL, VAR6 }
      },
      { &VAR13,
      { "", "",
      VAR14, VAR5, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR15,
      { "", "",
      VAR14, VAR5, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR16,
      { "", "",
      VAR14, VAR5, NULL, 0x0, NULL, VAR6}
      },
      { &VAR17,
      { "", "",
      VAR14, VAR5, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR18,
      { "", "",
      VAR14, VAR5, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR19,
      { "", "",
      VAR14, VAR5, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR20,
      { "", "",
      VAR14, VAR5, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR21,
      { "", "",
      VAR10, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR22,
      { "", "",
      VAR23, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR24,
      { "", "",
      VAR25, 32, FUN2(&VAR1), 0x00000001, NULL, VAR6 }
      },
      { &VAR26,
      { "", "",
      VAR25, 32, FUN2(&VAR1), 0x00000002, NULL, VAR6 }
      },
      { &VAR27,
      { "", "",
      VAR25, 32, FUN2(&VAR1), 0x00000004, NULL, VAR6 }
      },
      { &VAR28,
      { "", "",
      VAR25, 32, FUN2(&VAR1), 0x00000008, NULL, VAR6 }
      },
      { &VAR29,
      { "", "",
      VAR25, 32, FUN2(&VAR1), 0x00000010, NULL, VAR6 }
      },
      { &VAR30,
      { "", "",
      VAR25, 32, FUN2(&VAR1), 0x00000020, NULL, VAR6 }
      },
      { &VAR31,
      { "", "",
      VAR25, 32, FUN2(&VAR1), 0x00010000, NULL, VAR6 }
      },
      { &VAR32,
      { "", "",
      VAR33, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR34,
      { "", "",
      VAR35, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR36,
      { "", "",
      VAR35, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR37,
      { "", "",
      VAR35, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR38,
      { "", "",
      VAR35, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR39,
      { "", "",
      VAR40, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR41,
      { "", "",
      VAR10, VAR11, NULL, 0x0, NULL, VAR6 }
      },

      
      
      { &VAR42,
      { "", "",
        VAR4, VAR5, NULL, 0xF000, NULL, VAR6 }
      },
      { &VAR43,
      { "", "",
        VAR4, VAR5, NULL, 0x0C00, NULL, VAR6 }
      },
      { &VAR44,
      { "", "",
      VAR25, 16,  FUN2(&VAR1), 0x0100, NULL, VAR6 }
      },
      

      { &VAR45,
      { "", "",
      VAR10, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR46[0],
      { "", "",
      VAR33, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR46[1],
      { "", "",
      VAR33, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR46[2],
      { "", "",
      VAR33, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR46[3],
      { "", "",
      VAR33, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR46[4],
      { "", "",
      VAR33, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR46[5],
      { "", "",
      VAR33, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR46[6],
      { "", "",
      VAR33, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR46[7],
      { "", "",
      VAR33, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR46[8],
      { "", "",
      VAR33, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR46[9],
      { "", "",
      VAR33, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR46[10],
      { "", "",
      VAR33, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR46[11],
      { "", "",
      VAR33, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR46[12],
      { "", "",
      VAR33, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR46[13],
      { "", "",
      VAR33, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR46[14],
      { "", "",
      VAR33, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR46[15],
      { "", "",
      VAR33, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR47,
      { "", "",
      VAR10, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR48[0],
      { "", "",
      VAR33, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR48[1],
      { "", "",
      VAR33, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR48[2],
      { "", "",
      VAR33, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR48[3],
      { "", "",
      VAR33, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR49,
      { "", "",
      VAR14, VAR5, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR50,
      { "", "",
      VAR10, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR51,
      { "", "",
      VAR4, VAR5, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR52,
      { "", "",
      VAR4, VAR5, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR53,
      { "", "",
      VAR54, VAR5, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR55,
      { "", "",
      VAR54, VAR8, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR56,
      { "", "",
      VAR25, 8, FUN2(&VAR1), 0x00000001,
      NULL, VAR6 }
      },
      { &VAR57,
      { "", "",
      VAR25, 8, FUN2(&VAR1), 0x00000002,
      NULL, VAR6 }
      },
      { &VAR58,
      { "", "",
      VAR25, 8, FUN2(&VAR1), 0x00000004,
      NULL, VAR6 }
      },
      { &VAR59,
      { "", "",
      VAR25, 8, FUN2(&VAR1), 0x00000008,
      NULL, VAR6 }
      },
      { &VAR60,
      { "", "",
      VAR25, 8, FUN2(&VAR61), 0x00000010,
      NULL, VAR6 }
      },
      { &VAR62,
      { "", "",
      VAR54, VAR8, NULL, 0x0,
      NULL, VAR6 }
      },
      { &VAR63,
      { "", "",
      VAR25, 8, FUN2(&VAR1), 0x00000001,
      NULL, VAR6 }
      },
      { &VAR64,
      { "", "",
      VAR54, VAR5, NULL, 0x0000000E,
      NULL, VAR6 }
      },
      { &VAR65,
      { "", "",
      VAR25, 8, FUN2(&VAR1), 0x00000010,
      NULL, VAR6 }
      },
      { &VAR66,
      { "", "",
      VAR54, VAR8, NULL, 0x0,
      NULL, VAR6 }
      },
      { &VAR67,
      { "", "",
      VAR25, 8, FUN2(&VAR1), 0x00000010,
      NULL, VAR6 }
      },
      { &VAR68,
      { "", "",
      VAR54, VAR8, NULL, 0x0,
      NULL, VAR6 }
      },
      { &VAR69,
      { "", "",
      VAR25, 8, FUN2(&VAR1), 0x00000010,
      NULL, VAR6 }
      },

      { &VAR70,
      { "", "",
      VAR4, VAR8, NULL, 0x0,
      NULL, VAR6 }
      },
      { &VAR71,
      { "", "",
      VAR54, VAR8, NULL, 0x0,
      NULL, VAR6 }
      },
      { &VAR72,
      { "", "",
      VAR14, VAR8, NULL, 0x0,
      NULL, VAR6 }
      },
      { &VAR73,
      { "", "",
      VAR54, VAR8, NULL, 0x0,
      NULL, VAR6 }
      },
      { &VAR74,
      { "", "",
      VAR4, VAR8, NULL, 0x0,
      NULL, VAR6 }
      },
      { &VAR75,
      { "", "",
      VAR10, VAR11, NULL, 0x0,
      NULL, VAR6 }
      },
      { &VAR76,
      { "", "",
      VAR14, VAR8, NULL, 0x0,
      NULL, VAR6 }
      },
      { &VAR77,
      { "", "",
      VAR14, VAR8, NULL, 0x0,
      NULL, VAR6 }
      },
      { &VAR78,
      { "", "",
      VAR54, VAR5, NULL, 0x0,
      NULL, VAR6 }
      },
      { &VAR79,
      { "", "",
      VAR54, VAR8, NULL, 0x0,
      NULL, VAR6 }
      },
      { &VAR80,
      { "", "",
      VAR25, 8, FUN2(&VAR1), 0x00000001,
      NULL, VAR6 }
      },
      { &VAR81,
      { "", "",
      VAR25, 8, FUN2(&VAR1), 0x00000002,
      NULL, VAR6 }
      },
      { &VAR82,
      { "", "",
      VAR25, 8, FUN2(&VAR1), 0x00000004,
      NULL, VAR6 }
      },
      { &VAR83,
      { "", "",
      VAR25, 8, FUN2(&VAR1), 0x00000008,
      NULL, VAR6 }
      },
      { &VAR84,
      { "", "",
      VAR25, 8, FUN2(&VAR61), 0x00000010,
      NULL, VAR6 }
      },
      { &VAR85,
      { "", "",
      VAR54, VAR8, NULL, 0x0,
      NULL, VAR6 }
      },
      { &VAR86,
      { "", "",
      VAR25, 8, FUN2(&VAR1), 0x00000010,
      NULL, VAR6 }
      },
      { &VAR87,
      { "", "",
      VAR54, VAR8, NULL, 0x0,
      NULL, VAR6 }
      },
      { &VAR88,
      { "", "",
      VAR25, 8, FUN2(&VAR1), 0x00000001,
      NULL, VAR6 }
      },
      { &VAR89,
      { "", "",
      VAR54, VAR5, NULL, 0x0000000E,
      NULL, VAR6 }
      },
      { &VAR90,
      { "", "",
      VAR25, 8, FUN2(&VAR1), 0x00000010,
      NULL, VAR6 }
      },
      { &VAR91,
      { "", "",
      VAR54, VAR8, NULL, 0x0,
      NULL, VAR6 },
      },
      { &VAR92,
      { "", "",
      VAR4, VAR8, NULL, 0x0, NULL, VAR6 },
      },
      { &VAR93,
      { "", "",
      VAR4, VAR8, NULL, 0x0, NULL, VAR6 },
      },
      { &VAR94,
      { "", "",
      VAR23, VAR11, NULL, 0x0, NULL, VAR6 },
      },
      { &VAR95,
      { "", "",
      VAR4, VAR8, NULL, 0x0, NULL, VAR6 },
      },
      { &VAR96,
      { "", "",
      VAR54, VAR8, NULL, 0x0, NULL, VAR6 },
      },
      { &VAR97,
      { "", "",
      VAR54, VAR8, NULL, 0x0, NULL, VAR6 },
      },
      { &VAR98,
      { "", "",
      VAR14, VAR8, NULL, 0x0, NULL, VAR6 },
      },
      { &VAR99,
      { "", "",
      VAR4, VAR8, NULL, 0x0, NULL, VAR6 },
      },
      { &VAR100,
      { "", "",
      VAR54, VAR8, NULL, 0x0, NULL, VAR6 },
      },
      { &VAR101,
      { "", "",
      VAR54, VAR8, NULL, 0x0, NULL, VAR6 },
      },
      { &VAR102,
      { "", "",
      VAR40, VAR11, NULL, 0x0, NULL, VAR6 },
      },
      { &VAR103,
      { "", "",
      VAR4, VAR8, NULL, 0x0, NULL, VAR6 },
      },
      { &VAR104,
      { "", "",
      VAR4, VAR8, NULL, 0x0, NULL, VAR6 },
      },
      { &VAR105,
      { "", "",
      VAR4, VAR8, NULL, 0x0, NULL, VAR6 },
      },
      { &VAR106,
      { "", "",
      VAR23, VAR11, NULL, 0x0, NULL, VAR6 },
      },
      { &VAR107,
      { "", "",
      VAR23, VAR11, NULL, 0x0, NULL, VAR6 },
      },
      { &VAR108,
      { "", "",
      VAR23, VAR11, NULL, 0x0, NULL, VAR6 },
      },
      { &VAR109,
      { "", "",
      VAR23, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR110,
      { "", "",
      VAR10, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR111,
      { "", "",
      VAR54, VAR8, FUN3(VAR112), 0x0, "", VAR6 }
      },
      { &VAR113,
      { "" , "",
      VAR14, VAR5, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR114,
      { "", "",
      VAR40, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR115,
      { "", "",
      VAR4, VAR5, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR116,
      { "", "",
      VAR14, VAR5, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR117,
      { "", "",
      VAR40, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR118,
      { "", "",
      VAR4, VAR8, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR119,
      { "", "",
      VAR4, VAR8, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR120,
      { "", "",
      VAR10, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR121,
      { "", "",
      VAR10, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR122,
      { "", "",
      VAR4, VAR8, FUN3(VAR123), 0x0, NULL, VAR6 }
      },
      { &VAR124,
      { "", "",
      VAR4, VAR5, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR125,
      { "", "",
      VAR4, VAR8, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR126,
      { "", "",
      VAR4, VAR8, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR127,
      { "", "",
      VAR10, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR128,
      { "", "",
      VAR10, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR129,
      { "", "",
      VAR4, VAR8, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR130,
      { "", "",
      VAR4, VAR5, FUN3(VAR131), 0x00000007, NULL, VAR6 }
      },
      { &VAR132,
      { "", "",
      VAR25, 16, FUN2(&VAR1), 0x00000008, NULL, VAR6 }
      },
      { &VAR133,
      { "", "",
      VAR25, 16, FUN2(&VAR1), 0x00000010,
      NULL, VAR6 }
      },
      { &VAR134,
      { "", "",
      VAR4, VAR5, NULL, 0x000000e0, NULL, VAR6 }
      },
      { &VAR135,
      { "", "",
      VAR25, 16, FUN2(&VAR1), 0x00000100,
      NULL, VAR6 }
      },
      { &VAR136,
      { "", "",
      VAR25, 16, FUN2(&VAR1), 0x00000200,
      NULL, VAR6 }
      },
      { &VAR137,
      { "", "",
      VAR25, 16, FUN2(&VAR1), 0x00000400,
      NULL, VAR6 }
      },
      { &VAR138,
      { "", "",
      VAR25, 16, FUN2(&VAR1), 0x00000800,
      NULL, VAR6 }
      },
      { &VAR139,
      { "", "",
      VAR25, 16, FUN2(&VAR1), 0x00001000,
      NULL, VAR6 }
      },
      { &VAR140,
      { "", "",
      VAR25, 16, FUN2(&VAR1), 0x00002000,
      NULL, VAR6 }
      },
      { &VAR141,
      { "", "",
      VAR25, 16, FUN2(&VAR1), 0x00004000,
      NULL, VAR6 }
      },
      { &VAR142,
      { "", "",
      VAR25, 16, FUN2(&VAR1), 0x00008000,
      NULL, VAR6 }
      },
      { &VAR143,
      { "", "",
      VAR4, VAR8, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR144,
      { "", "",
      VAR10, VAR11, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR145,
      { "", "",
      VAR4, VAR8, NULL, 0x0, NULL, VAR6 }
      },
      { &VAR146,
      { "", "",
      VAR4, VAR8, NULL, 0x0, NULL, VAR6 }
      }
   };

   static VAR147 *VAR148[] =
   {
      &VAR149,
      &VAR150,
      &VAR151,
      &VAR152,
      &VAR153,
      &VAR154,
      &VAR155,
      &VAR156,
      &VAR157,
      &VAR158,
      &VAR159,
      &VAR160,
      &VAR161,
      &VAR162,
      &VAR163,
      &VAR164
   };

   VAR165 = FUN4("",
      "", "");
   FUN5(VAR165, VAR2,FUN6(VAR2));
   FUN7(VAR148, FUN6(VAR148));

   FUN8("", VAR166, VAR165);
}