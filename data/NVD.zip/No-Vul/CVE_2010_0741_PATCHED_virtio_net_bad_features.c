static VAR1  FUN1(VAR2 *VAR3)  
{
    uint32_t VAR4 = 0;

    
    VAR4 |= (1 << VAR5);
    VAR4 |= (1 << VAR6);
    VAR4 |= (1 << VAR7);
    VAR4 |= (1 << VAR8);
    VAR4 |= (1 << VAR9);

    return VAR4 & FUN2(VAR3);
}