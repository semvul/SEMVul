NS_IMETHODIMP VAR1::FUN1(    const char * VAR2, VAR3 * VAR4,      VAR5 * VAR6, VAR3 * VAR7)  
{
   static const PRUint16 VAR8[128] =
   {

     0xFFFD, 0xFFFD, 0xFFFD, 0xFFFD, 0xFFFD, 0xFFFD, 0xFFFD, 0xFFFD,
     0xFFFD, 0xFFFD, 0xFFFD, 0xFFFD, 0xFFFD, 0xFFFD, 0xFFFD, 0xFFFD,

     0xFFFD, 0xFFFD, 0xFFFD, 0xFFFD, 0xFFFD, 0xFFFD, 0xFFFD, 0xFFFD,
     0xFFFD, 0xFFFD, 0xFFFD, 0xFFFD, 0xFFFD, 0xFFFD, 0xFFFD, 0xFFFD,

     0xFFFD, 0,      94,     94* 2,  94* 3,  94* 4,  94* 5,  94* 6,  
     94* 7,  94* 8 , 94* 9,  94*10,  94*11,  94*12,  94*13,  94*14,

     94*15,  94*16,  94*17,  94*18,  94*19,  94*20,  94*21,  94*22,
     94*23,  94*24,  94*25,  94*26,  94*27,  94*28,  94*29,  94*30,

     94*31,  94*32,  94*33,  94*34,  94*35,  94*36,  94*37,  94*38,
     94*39,  94*40,  94*41,  94*42,  94*43,  94*44,  94*45,  94*46,

     94*47,  94*48,  94*49,  94*50,  94*51,  94*52,  94*53,  94*54,
     94*55,  94*56,  94*57,  94*58,  94*59,  94*60,  94*61,  94*62,

     94*63,  94*64,  94*65,  94*66,  94*67,  94*68,  94*69,  94*70,
     94*71,  94*72,  94*73,  94*74,  94*75,  94*76,  94*77,  94*78,

     94*79,  94*80,  94*81,  94*82,  94*83,  94*84,  94*85,  94*86,
     94*87,  94*88,  94*89,  94*90,  94*91,  94*92,  94*93,  0xFFFD,
   };
   static const PRUint8 VAR9[256] =
   {

     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,

     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,

     0xFF, 0,    1,    2,    3,    4,    5,    6,  
     7,    8 ,   9,    10,   11,   12,   13,   14,

     15,   16,   17,   18,   19,   20,   21,   22, 
     23,   24,   25,   26,   27,   28,   29,   30, 

     31,   32,   33,   34,   35,   36,   37,   38, 
     39,   40,   41,   42,   43,   44,   45,   46, 

     47,   48,   49,   50,   51,   52,   53,   54, 
     55,   56,   57,   58,   59,   60,   61,   62, 

     63,   64,   65,   66,   67,   68,   69,   70, 
     71,   72,   73,   74,   75,   76,   77,   78, 

     79,   80,   81,   82,   83,   84,   85,   86, 
     87,   88,   89,   90,   91,   92,   93,   0xFF, 

     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,

     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,

     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,

     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,

     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,

     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,

     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,

     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
   };

   const unsigned char* VAR10 = (unsigned char*)VAR2 + *VAR4;
   const unsigned char* VAR11 =(unsigned char*) VAR2;
   VAR5* VAR12 = VAR6 + *VAR7;
   VAR5* VAR13 = VAR6;
   while((VAR11 < VAR10))
   {
     
       switch(VAR14)
       {
          case VAR15:
            if(0x1b == *VAR11)
            {
              VAR16 = VAR14;
              VAR14 = VAR17;
            } else if(*VAR11 & 0x80) {
              goto VAR18;
            } else {
              if (FUN2(VAR13, VAR12, 1))
                goto VAR19;
              *VAR13++ = (VAR5) *VAR11;
            }
          break;
          
          case VAR17:
            if( '' == *VAR11) {
              VAR14 = VAR20;
            } else if ('' == *VAR11)  {
              VAR14 = VAR21;
            } else if ('' == *VAR11)  { 
              VAR14 = VAR22;
            } else if ('' == *VAR11)  { 
              VAR14 = VAR23;
            } else  {
              if (FUN2(VAR13, VAR12, 2))
                goto VAR19;
              *VAR13++ = (VAR5) 0x1b;
              if(0x80 & *VAR11)
                goto VAR18;
              *VAR13++ = (VAR5) *VAR11;
              VAR14 = VAR16;
            }
          break;

          case VAR20: 
            if( '' == *VAR11) {
              VAR14 = VAR15;
              if (VAR24 == 0) {
                if (FUN2(VAR13, VAR12, 1))
                  goto VAR19;
                *VAR13++ = 0xFFFD;
              }
              VAR24 = 0;
            } else if ('' == *VAR11)  {
              VAR14 = VAR25;
              if (VAR24 == 0 && VAR16 != VAR15) {
                if (FUN2(VAR13, VAR12, 1))
                  goto VAR19;
                if (VAR26 == VAR27)
                  goto VAR18;
                *VAR13++ = 0xFFFD;
              }
              VAR24 = 0;
            } else if ('' == *VAR11)  {
              VAR14 = VAR28;
              VAR24 = 0;
            } else  {
              if (FUN2(VAR13, VAR12, 3))
                goto VAR19;
              *VAR13++ = (VAR5) 0x1b;
              *VAR13++ = (VAR5) '';
              if(0x80 & *VAR11)
                goto VAR18;
              *VAR13++ = (VAR5) *VAR11;
              VAR14 = VAR16;
            }
          break;

          case VAR21: 
            if( '' == *VAR11) {
              VAR14 = VAR29;
              VAR24 = 0;
            } else if ('' == *VAR11)  {
              VAR14 = VAR30;
              VAR24 = 0;
            } else if ('' == *VAR11)  {
              VAR14 = VAR31;
              VAR24 = 0;
            } else if ('' == *VAR11)  {
              VAR14 = VAR32;
            } else  {
              if (FUN2(VAR13, VAR12, 3))
                goto VAR19;
              *VAR13++ = (VAR5) 0x1b;
              *VAR13++ = (VAR5) '';
              if(0x80 & *VAR11)
                goto VAR18;
              *VAR13++ = (VAR5) *VAR11;
              VAR14 = VAR16;
            }
          break;

          case VAR32: 
            if( '' == *VAR11) {
              VAR14 = VAR33;
              VAR24 = 0;
            } else if ('' == *VAR11) {
              VAR14 = VAR34;
              VAR24 = 0;
            } else  {
              if (FUN2(VAR13, VAR12, 4))
                goto VAR19;
              *VAR13++ = (VAR5) 0x1b;
              *VAR13++ = (VAR5) '';
              *VAR13++ = (VAR5) '';
              if(0x80 & *VAR11)
                goto VAR18;
              *VAR13++ = (VAR5) *VAR11;
              VAR14 = VAR16;
            }
          break;

          case VAR25:
            if(0x1b == *VAR11) {
              VAR16 = VAR14;
              VAR14 = VAR17;
            } else if(*VAR11 & 0x80) {
              goto VAR18;
            } else {
              
              
              
              if (FUN2(VAR13, VAR12, 1))
                goto VAR19;
              *VAR13++ = (VAR5) *VAR11;
              ++VAR24;
            }
          break;

          case VAR28:
            if(0x1b == *VAR11) {
              VAR16 = VAR14;
              VAR14 = VAR17;
            } else {
              if((0x21 <= *VAR11) && (*VAR11 <= 0x5F)) {
                if (FUN2(VAR13, VAR12, 1))
                  goto VAR19;
                *VAR13++ = (0xFF61-0x0021) + *VAR11;
                ++VAR24;
              } else {
                goto VAR18;
              }
            }
          break;

          case VAR29:
            if(0x1b == *VAR11) {
              VAR16 = VAR14;
              VAR14 = VAR17;
            } else if(*VAR11 & 0x80) {
              VAR16 = VAR14;
              VAR14 = VAR35;
            } else {
              VAR36 = VAR37[*VAR11 & 0x7F];
              if(0xFFFD == VAR36)
                goto VAR18;
              VAR14 = VAR38;
            }
          break;

          case VAR30:
            if(0x1b == *VAR11) {
              VAR16 = VAR14;
              VAR14 = VAR17;
            } else if(*VAR11 & 0x80) {
              VAR16 = VAR14;
              VAR14 = VAR35;
            } else {
              VAR36 = VAR8[*VAR11 & 0x7F];
              if(0xFFFD == VAR36)
                goto VAR18;
              VAR14 = VAR39;
            }
          break;

          case VAR31:
            if(0x1b == *VAR11) {
              VAR16 = VAR14;
              VAR14 = VAR17;
            } else if(*VAR11 & 0x80) {
              VAR16 = VAR14;
              VAR14 = VAR35;
            } else {
              VAR36 = VAR37[*VAR11 & 0x7F];
              if(0xFFFD == VAR36)
                goto VAR18;
              VAR14 = VAR40;
            }
          break;

          case VAR33:
            if(0x1b == *VAR11) {
              VAR16 = VAR14;
              VAR14 = VAR17;
            } else if(*VAR11 & 0x80) {
              VAR16 = VAR14;
              VAR14 = VAR35;
            } else {
              VAR36 = VAR8[*VAR11 & 0x7F];
              if(0xFFFD == VAR36)
                goto VAR18;
              VAR14 = VAR41;
            }
          break;

          case VAR34:
            if(0x1b == *VAR11) {
              VAR16 = VAR14;
              VAR14 = VAR17;
            } else if(*VAR11 & 0x80) {
              VAR16 = VAR14;
              VAR14 = VAR35;
            } else {
              VAR36 = VAR42[*VAR11 & 0x7F];
              if(0xFFFD == VAR36)
                goto VAR18;
              VAR14 = VAR43;
            }
          break;

          case VAR38:
          {
            PRUint8 VAR44 = VAR9[*VAR11];
            if(0xFF == VAR44) {
               goto VAR18;
            } else {
               
               
              if (FUN2(VAR13, VAR12, 1))
                goto VAR19;
              *VAR13++ = VAR45[VAR36+VAR44];
              ++VAR24;
            }
            VAR14 = VAR29;
          }
          break;

          case VAR39:
          {
            PRUint8 VAR44 = VAR9[*VAR11];
            if(0xFF == VAR44) {
               goto VAR18;
            } else {
              if (!VAR46) {
                
                nsresult VAR47;
                VAR48<VAR49> VAR50 = 
                         FUN3(VAR51, &VAR47);
                if (FUN4(VAR47)) {
                  VAR47 = VAR50->FUN5("", &VAR46);
                }
              }
              if (!VAR46) {
                goto VAR18;
              } else {
                if (FUN2(VAR13, VAR12, 1))
                  goto VAR19;
                unsigned char VAR52[2];
                PRUnichar VAR53;
                PRInt32 VAR54 = 2, VAR55 = 1;
                
                
                
                VAR52[0] = ((VAR36 / 94) + 0x21) | 0x80;
                VAR52[1] = *VAR11 | 0x80;
                
                VAR46->FUN1((const char *)VAR52, &VAR54,
                                        &VAR53, &VAR55);
                *VAR13++ = VAR53;
                ++VAR24;
              }
            }
            VAR14 = VAR30;
          }
          break;

          case VAR40:
          {
            PRUint8 VAR44 = VAR9[*VAR11];
            if(0xFF == VAR44) {
               goto VAR18;
            } else {
              if (FUN2(VAR13, VAR12, 1))
                goto VAR19;
              *VAR13++ = VAR45[VAR36+VAR44];
              ++VAR24;
            }
            VAR14 = VAR31;
          }
          break;

          case VAR41:
          {
            PRUint8 VAR44 = VAR9[*VAR11];
            if(0xFF == VAR44) {
               goto VAR18;
            } else {
              if (!VAR56) {
                
                nsresult VAR47;
                VAR48<VAR49> VAR50 = 
                         FUN3(VAR51, &VAR47);
                if (FUN4(VAR47)) {
                  VAR47 = VAR50->FUN5("", &VAR56);
                }
              }
              if (!VAR56) {
                goto VAR18;
              } else {              
                if (FUN2(VAR13, VAR12, 1))
                  goto VAR19;
                unsigned char VAR57[2];
                PRUnichar VAR53;
                PRInt32 VAR58 = 2, VAR55 = 1;
                
                
                
                VAR57[0] = ((VAR36 / 94) + 0x21) | 0x80;
                VAR57[1] = *VAR11 | 0x80;
                
                VAR56->FUN1((const char *)VAR57, &VAR58,
                                       &VAR53, &VAR55);
                *VAR13++ = VAR53;
                ++VAR24;
              }
            }
            VAR14 = VAR33;
          }
          break;

          case VAR43:
          {
            PRUint8 VAR44 = VAR9[*VAR11];
            if(0xFF == VAR44) {
               goto VAR18;
            } else {
              if (FUN2(VAR13, VAR12, 1))
                goto VAR19;
              *VAR13++ = VAR45[VAR36+VAR44];
              ++VAR24;
            }
            VAR14 = VAR34;
          }
          break;

          case VAR22: 
            
            VAR14 = VAR16;
            if( '' == *VAR11) {
              VAR59 = VAR60;
            } else if ('' == *VAR11) {
              VAR59 = VAR61;
            } else  {
              if (FUN2(VAR13, VAR12, 3))
                goto VAR19;
              *VAR13++ = (VAR5) 0x1b;
              *VAR13++ = (VAR5) '';
              if(0x80 & *VAR11)
                goto VAR18;
              *VAR13++ = (VAR5) *VAR11;
            }
          break;

          case VAR23: 
            
            
            
            VAR14 = VAR16;
            if((0x20 <= *VAR11) && (*VAR11 <= 0x7F)) {
              if (VAR60 == VAR59) {
                if (FUN2(VAR13, VAR12, 1))
                  goto VAR19;
                *VAR13++ = *VAR11 | 0x80;
                ++VAR24;
              } else if (VAR61 == VAR59) {
                if (!VAR62) {
                  
                  nsresult VAR47;
                  VAR48<VAR49> VAR50 = 
                           FUN3(VAR51, &VAR47);
                  if (FUN4(VAR47)) {
                    VAR47 = VAR50->FUN5("", &VAR62);
                  }
                }
                if (!VAR62) {
                  goto VAR18;
                } else {
                  if (FUN2(VAR13, VAR12, 1))
                    goto VAR19;
                  
                  unsigned char VAR63 = *VAR11 | 0x80;
                  PRUnichar VAR53;
                  PRInt32 VAR64 = 1, VAR55 = 1;
                  
                  VAR62->FUN1((const char *)&VAR63, &VAR64,
                                            &VAR53, &VAR55);
                  *VAR13++ = VAR53;
                  ++VAR24;
                }
              } else {
                goto VAR18;
              }
            } else {
              if (FUN2(VAR13, VAR12, 3))
                goto VAR19;
              *VAR13++ = (VAR5) 0x1b;
              *VAR13++ = (VAR5) '';
              if(0x80 & *VAR11)
                goto VAR18;
              *VAR13++ = (VAR5) *VAR11;
            }
          break;

          case VAR35:
             VAR14 = VAR16;
             VAR24 = 0;
             goto VAR18;
          break;

       } 
       VAR11++;
   }
   *VAR7 = VAR13 - VAR6;
   return VAR65;
VAR19:
   *VAR7 = VAR13 - VAR6;
   *VAR4 = VAR11 - (const unsigned char*)VAR2;
   return VAR66;
VAR18:
   *VAR4 = VAR11 - (const unsigned char*)VAR2;
   *VAR7 = VAR13 - VAR6;
   return VAR67;
}