static struct VAR1 *FUN1(struct VAR2 *VAR3, struct VAR2 *VAR2, 			int VAR4, mode_t VAR5, struct mq_attr VAR6 *VAR7)  
{
	struct mq_attr VAR8;
	int VAR9;

	if (VAR7) {
		VAR9 = -VAR10;
		if (FUN2(&VAR8, VAR7, sizeof(VAR8)))
			goto VAR11;
		VAR9 = -VAR12;
		if (!FUN3(&VAR8))
			goto VAR11;
		
		VAR2->VAR13 = &VAR8;
	}

	VAR9 = FUN4(VAR3->VAR14, VAR2, VAR5, NULL);
	VAR2->VAR13 = NULL;
	if (VAR9)
		goto VAR11;

	return FUN5(VAR2, VAR15, VAR4);

VAR11:
	FUN6(VAR2);
	FUN7(VAR15);
	return FUN8(VAR9);
}