static int FUN1(VAR1 *VAR2)  
{
    const char *VAR3;
    const char *VAR4;
    const char *VAR5;
    const char *VAR6;
    char * VAR7;
    int VAR8;

    if (VAR2->VAR9) {
        return 0;
    }

    

    if (!(VAR3 = FUN2(VAR2->VAR10, ""))) {
        VAR3 = FUN2(VAR2->VAR10, "");
    }

    if (!VAR3 || FUN3(VAR3, "", 6) || VAR2->VAR11 != VAR12) {
        return 0;
    }

    
    if (FUN2(VAR2->VAR13, "")) {
       return 0;
    }

    
    if ((VAR6 = FUN2(VAR2->VAR13, ""))
        && (!FUN3(VAR6, "", 20)
            || !FUN3(VAR6, "", 22))) {
       return 0;
    }

    
    if ((VAR4 = FUN2(VAR2->VAR10, ""))) {
        if (VAR4[0] == '') {
            if (!(VAR5 = FUN2(VAR2->VAR13, ""))
                || (strcmp(VAR4, VAR5) != 0)) {
                return 0;
            }
        }
        else if (!(VAR5 = FUN2(VAR2->VAR13, ""))
                 || (strcmp(VAR4, VAR5) != 0)) {
            return 0;
        }
    }

    
    VAR7=VAR3+6;
    VAR8=1;
    while(*++VAR7)
        if(*VAR7 == '')
           if(++VAR8 > 10)
               return 0;

    VAR2->VAR11 = VAR14;
    VAR2->VAR3 = VAR3 + 6;

    return VAR8;
}