static int FUN1(struct VAR1 *VAR2, struct VAR3 *VAR4, struct VAR5 *VAR6)  
{
	VAR7 *VAR8;
	char *VAR9;
	char VAR10[256];
	char VAR11[256];
	char VAR12[32];
	char VAR13[16];
	char VAR14[32];
	char VAR15[VAR16];
	int VAR17 = 0;
	char *VAR18;
	char *VAR19;

	VAR6->VAR20 = 0; 
	if(VAR21 > 2)
		FUN2 (VAR22,"",VAR6->VAR23, VAR6->VAR24[VAR6->VAR23]);
	if (VAR6->VAR24[VAR6->VAR23] == 0) {
		FUN2 (VAR25,"");
		return -1;
	}

	
	VAR9 = FUN3 (VAR6->VAR26, VAR6->VAR24[VAR6->VAR23]);
	
	if (FUN4(VAR9)) {
		FUN2 (VAR27,"",VAR6->VAR24[VAR6->VAR23]);
		return -1;
	}
	snprintf(VAR15, sizeof(VAR15), "", VAR28, VAR4->VAR11, VAR4->VAR29);
	FUN5(VAR6->VAR30, VAR6->VAR31, VAR15, VAR6->VAR23);

	FUN6 (VAR6->VAR26,VAR6->VAR24[VAR6->VAR23],&VAR8);
	
	
	if (VAR8->VAR32.VAR33 && VAR8->VAR32.VAR33->VAR34 && VAR8->VAR32.VAR33->VAR34->VAR8.VAR35->VAR36) {
		VAR18 = FUN7(VAR8->VAR32.VAR33->VAR34->VAR8.VAR35->VAR36);
	} else {
		FUN2(VAR27, "");
		return -1;
	}
	
	

	FUN8(&VAR18, "");
	if (!VAR18) {
		FUN2(VAR27, "");
		return -1;
	}
	FUN9(VAR8, VAR6, "", VAR18);

	FUN10(VAR2, VAR6);
	if (!VAR6->VAR23)
		VAR17 = FUN11(VAR2, VAR6, "");	
	else if (VAR6->VAR23 == VAR6->VAR37)
		VAR17 = FUN11(VAR2, VAR6, "");		
	if (!VAR17) {
		VAR17 = FUN11(VAR2, VAR6, "");	
		if (VAR6->VAR23 && (VAR6->VAR23 != VAR6->VAR37)) {
			if (!VAR17)
				VAR17 = FUN12(VAR2, VAR6->VAR23 + 1, VAR38, VAR2->VAR39, (char *) NULL);
		}
	}

	
	VAR19 = FUN13(VAR9, "");

	if (VAR19)
		FUN14(VAR10, VAR19, sizeof(VAR10)); 
	else 
		VAR10[0] = '';

	VAR19 = FUN13(VAR9, "");

	if (VAR19)
		FUN14(VAR11, VAR19, sizeof(VAR11)); 
	else
		VAR11[0] = '';

	VAR19 = FUN13(VAR9, "");

	if (VAR19)
		FUN14(VAR12, VAR19, sizeof(VAR12));
	else
		VAR12[0] = '';

	VAR19 = FUN13(VAR9, "");

	if (VAR19)
		FUN14(VAR13,VAR19, sizeof(VAR13));
	else
		VAR13[0] = '';
	
	VAR19 = FUN13(VAR9, "");
	
	if (VAR19)
		FUN14(VAR14,VAR19, sizeof(VAR14));
	else
		VAR14[0] = '';

	
	
	if (VAR17 == '')
		VAR17 = 0;

	if ((!VAR17) && !FUN4(VAR14)) {
		VAR17 = FUN15(VAR2, VAR14);
	}

	if ((!VAR17) && (FUN16(VAR4, VAR40)) && VAR12[0] != '')
		VAR17 = FUN17(VAR2, VAR4, VAR12, "");
	if ((!VAR17) && (FUN16(VAR4, VAR41)) && VAR10[0] !='' && VAR11[0] !='')
		VAR17 = FUN18(VAR2, VAR6, VAR10, VAR11, 0);

	if ((!VAR17) && (FUN16(VAR4, VAR42)) && VAR13[0] != '')
		VAR17 = FUN19(VAR2, VAR6, VAR13, VAR4->VAR43);

	
	
	
	VAR17 = 0;

	if (!VAR17) {
		VAR6->VAR44[VAR6->VAR23] = 1;
		VAR17 = FUN20(VAR2, VAR6, VAR6->VAR30);
	}
	FUN21(VAR6->VAR45, VAR6->VAR23);
	FUN22(0, 0, VAR6->VAR30);
	return VAR17;
}