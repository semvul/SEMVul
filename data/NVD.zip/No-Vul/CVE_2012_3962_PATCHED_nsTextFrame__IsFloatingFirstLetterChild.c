bool VAR1::FUN1() const  
{
  VAR2* VAR3 = FUN2();
  return VAR3 && VAR3->FUN3()->FUN4() &&
         VAR3->FUN5() == VAR4::VAR5;
}