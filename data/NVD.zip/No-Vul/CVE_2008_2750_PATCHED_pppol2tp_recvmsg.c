static int FUN1(struct VAR1 *VAR2, struct socket *VAR3, 			    struct VAR4 *VAR5, size_t VAR6, 			    int VAR7)  
{
	int VAR8;
	struct VAR9 *VAR10;
	struct VAR3 *VAR11 = VAR3->VAR11;

	VAR8 = -VAR12;
	if (VAR11->VAR13 & VAR14)
		goto VAR15;

	VAR5->VAR16 = 0;

	VAR8 = 0;
	VAR10 = FUN2(VAR11, VAR7 & ~VAR17,
				VAR7 & VAR17, &VAR8);
	if (!VAR10)
		goto VAR15;

	if (VAR6 > VAR10->VAR6)
		VAR6 = VAR10->VAR6;
	else if (VAR6 < VAR10->VAR6)
		VAR5->VAR18 |= VAR19;

	VAR8 = FUN3(VAR10, 0, VAR5->VAR20, VAR6);
	if (FUN4(VAR8 == 0))
		VAR8 = VAR6;

	FUN5(VAR10);
VAR15:
	return VAR8;
}