static int FUN1(int VAR1, struct VAR2 *VAR3, int VAR4)  
{
	struct VAR5 *VAR6;
	unsigned long VAR7;
	int VAR8 = 0;

	FUN2();
	VAR6 = (struct VAR5 *)VAR3->VAR9;
	if (FUN3(VAR6, VAR3->VAR10.VAR11->VAR12, ""))
		goto VAR13;

	VAR8 = FUN4(VAR1, VAR3, VAR4, &VAR6->VAR14);
	if (VAR8 <= 0)
		goto VAR13;

	if (VAR4) {
		enum pid_type VAR15;
		struct VAR16 *VAR16;
		if (!FUN5(&VAR6->VAR17))
			VAR6->VAR18 = 1;
		FUN6(&VAR6->VAR19, VAR7);
		if (VAR6->VAR20) {
			VAR16 = VAR6->VAR20;
			VAR15 = VAR21;
		} else {
			VAR16 = FUN7(VAR22);
			VAR15 = VAR23;
		}
		VAR8 = FUN8(VAR3, VAR16, VAR15, 0);
		FUN9(&VAR6->VAR19, VAR7);
		if (VAR8)
			goto VAR13;
	} else {
		if (!VAR6->VAR14 && !FUN5(&VAR6->VAR17))
			VAR6->VAR18 = VAR24;
	}
	VAR8 = 0;
VAR13:
	FUN10();
	return VAR8;
}